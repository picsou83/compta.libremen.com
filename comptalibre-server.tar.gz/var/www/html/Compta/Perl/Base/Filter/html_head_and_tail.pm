package Base::Filter::html_head_and_tail ;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Modifié par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version initiale - Aôut 2016
#-----------------------------------------------------------------------------------------
#	Copyright ou © ou Copr.
#	Vincent Veyron - Aôut 2016 (https://github.com/picsou83)
#	vincent.veyron@libremen.org
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use utf8 ;
use Apache2::Const -compile => qw( OK DECLINED REDIRECT);

sub handler {

    my $f = shift ;
    my $r = $f->r ;
    my $racine = $r->dir_config('racine') ;
    
    #traiter toutes les URL contenant /$racine; 
    #rejeter le login puisqu'on a pas encore de session, et le logout puisqu'on a plus de session; on laisse aussi passer les xmlhttprequests
    if ( ( $r->uri !~ /$racine/ ) or ( $r->uri =~ /login|logout|xmlhttprequest/ ) ) {

	return Apache2::Const::DECLINED ;

    } elsif ( $r->uri =~ /downloads/ ) {

	#force le navigateur a télécharger le dossier plutôt que l'ouvrir directement
	$r->headers_out->set('Content-Disposition' => 'attachment' ) ;

	return Apache2::Const::DECLINED ;
		
    } else {
		
	#accumulation du contenu des invocations précédentes du filtre
	my $content = $f->ctx ;

	while ($f->read(my $buffer)) {

	    #pour la 1ère invocation, on veut positionner le menu
	    unless ( defined $content ) { 
		
		my $dbh = $r->pnotes('dbh') ;
		my ( $sql, $option_set, @bind_array ) ;	
		my $sql = 'SELECT etablissement, id_client, id_tva_regime FROM compta_client WHERE id_client = ?' ;
		my $societe_get = $dbh->selectall_arrayref( $sql, { Slice => { } }, $r->pnotes('session')->{id_client} ) ;	
		
		my ($exercice, $display_parameters, $display_modify, $display_tva) ;

		#en-tête de page : lien vers le choix de fiscal_year
		my $fiscal_year_href = '/'.$racine.'/fiscal_year?fiscal_year' ;
		
		# afficher l'onglet paramétres pour l'utilisateur superadmin
		if ( $r->pnotes('session')->{username} eq 'superadmin') {
		$display_parameters = '<a style="margin: .5em;" class=' . ( ($r->uri =~ /parametres/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/parametres">' . Encode::encode_utf8('Paramètres') . '</a>';
		$display_modify	= '/'.$racine.'/parametres?utilisateurs=0&amp;modification_utilisateur=1&amp;selection_utilisateur=' . Encode::decode_utf8($r->user()) . '';
		}
		
		# afficher l'onglet tva si id_tva_regime != franchise
		if (not( $societe_get->[0]->{id_tva_regime} eq 'franchise')) {
		$display_tva = '<a style="margin: .5em;" class=' . ( ($r->uri =~ /tva/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/tva">TVA</a>';
		}
		
		if ( $r->pnotes('session')->{fiscal_year_offset} ) {

		    $exercice = ($r->pnotes('session')->{fiscal_year} -1 ). '-' . ( $r->pnotes('session')->{fiscal_year}  ) ;
		    
		} else {

		    $exercice = $r->pnotes('session')->{fiscal_year}
		    
		}
		
		$content = '

<div class="topbox">

	<div style="float: left ">
		<a href="/'.$racine.'/" title="Retour vers Menu"><img height="50" width="64" class="logo" src="/Compta/style/logo.png" alt="Logo"></a>
	</div>
	
	<div style="float: right;">
		<ul style="margin-top: auto; padding-right: 10px; list-style-type: none; margin-block-end:0px;">
		<li class="listitem"><a style="color: inherit; text-decoration: none;" href="'.$display_modify.'"><i class="icon-user1"></i>' . Encode::decode_utf8($r->user()) . '</a></li>
		<li class="listitem"><a style="color: red; text-decoration: none;" href="/'.$racine.'/parametres?logout"><i class="icon-sign-out1"></i>' . Encode::encode_utf8('déconnexion') . '</a></li>
		<li class="centrer listitem"><a style="color: inherit; text-decoration: none;" href="/'.$racine.'/#version">v1.103</a></li>
		</ul>
	</div>

	<div style="width: 100%; text-align: center;">
		<h2 style="margin: 0;"><a style="text-decoration : none;" href="' . $fiscal_year_href . '">' . $societe_get->[0]->{etablissement} . ' : ' . Encode::encode_utf8('Exercice ') . $exercice . '</a></h2>
		<br>
		<a style="margin: .5em;" class=' . ( (($r->uri =~ /journal|entry/ ) && not($r->uri =~ /docsentry/)) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/journal">Journaux</a>
		<a style="margin: .5em;" class=' . ( ($r->uri =~ /compte/ && $r->args !~ /grandlivre|balance/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/compte">Comptes</a>
		<a style="margin: .5em;" class=' . ( ($r->uri =~ /docs/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/docs">Documents</a>
		<a style="margin: .5em;" class=' . ( ($r->args =~ /grandlivre/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/compte?grandlivre=0">Grand Livre</a>
		<a style="margin: .5em;" class=' . ( ($r->args =~ /balance/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/compte?balance=0">Balance</a>
		'.$display_parameters.'
		'.$display_tva.'
		<a style="margin: .5em;" class=' . ( ($r->uri =~ /export/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/export">Export</a>
		<a style="margin: .5em;" class=' . ( ($r->uri =~ /bilan/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/bilan">Bilan</a>
	</div>
	<hr>
</div>

    ' ;

		#<a style="margin: .5em;" class=' . ( ($r->uri =~ /documentation/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$racine.'/documentation">FAQ</a>
		
	    } #	    unless ( defined $content ) {
	    
	    #ajouter le contenu des buckets brigades de cette invocation
	    $content .= $buffer  ;

	} #	while ($f->read(my $buffer)) 

	#on arrive à la fin du contenu
	if ($f->seen_eos) {
	    
	    $content = Encode::decode_utf8( $content ) . '</div>' ;
	    
	    #<head> section de la page html
	    my $html_head = html_head( $r ) ;

	    #</body> tag
	    my $html_tail = html_tail( $r ) ;

	    $content = $html_head . $content . $html_tail ;

	    #reset du header 'Content-Length'
	    my $len = length $content ;

	    $f->r->headers_out->set('Content-Length', $len) ;

	    $f->print($content) if defined $content ;

	} else {

	    #ce n'est pas fini, on stocke dans l'accumulateur
	    $f->ctx($content) if defined $content ;

	} #	if ($f->seen_eos) 
	
	return Apache2::Const::OK ;

    } #     if ( ( $r->uri !~ /'.$racine.'/ ) or ( $r->uri =~ /login|logout/ ) ) {
    
}


1 ;


sub html_head {

    my $r = shift;
    

    #on utilise html 5
    my $content = qq | <!DOCTYPE html> 
<html lang=fr>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <link href="/Compta/style/style.css" rel="stylesheet" type="text/css">
  <link href="/Compta/style/print.css" rel="stylesheet" type="text/css" media="print">
  <script src="/Compta/javascript/entry.js"></script>
  <title>Wiki</title>
</head>

<body> | ;
    
    return $content ;

}


sub html_tail {

    my $r = shift;

    my $content ;
    
    #inclure le dump de la session dans la page? le paramètre session->{dump} est réglé dans le headerparser get_session_id.pm
    if ( $r->pnotes('session')->{dump} == 1 ) {

	use Data::Dumper ;

	$content .= '<div><pre>' . Data::Dumper::Dumper( $r->pnotes('session') ) . '</pre></div>';

    }

    $content .= '</body></html>' ;

    return $content ;

}
