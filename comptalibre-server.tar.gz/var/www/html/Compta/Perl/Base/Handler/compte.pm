package Base::Handler::compte ;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Modifié par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version initiale - Aôut 2016
#-----------------------------------------------------------------------------------------
#	Copyright ou © ou Copr.
#	Vincent Veyron - Aôut 2016 (https://compta.libremen.com/)
#	vincent.veyron@libremen.org
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Time::Piece;
use utf8;
use Apache2::Const -compile => qw( OK REDIRECT ) ;

sub handler {

    binmode(STDOUT, ":utf8") ;
    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content ;
    my $req = Apache2::Request->new( $r ) ;

    #récupérer les arguments
    my (%args, @args) ;

    #recherche des paramètres de la requête
    @args = $req->param ;

    for ( @args ) {

	$args{ $_ } = Encode::decode_utf8( $req->param($_) ) ;

	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;

    }
    
    if ( defined $args{numero_compte} ) {

	#rapprochement bancaire pour les comptes de classe 5
	if ( defined $args{rapprochement} ) {
	    
	    $content = rapprochement( $r, \%args ) ;
	    
	} else {

	    $content = visiter_un_compte( $r, \%args ) ; 

	}
	
    } elsif ( defined $args{edit_compte_set} ) {
	
	if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {
	#éditer la liste des comptes
	$content = edit_compte_set( $r, \%args ) ;
	} else {
	$content = liste_des_comptes( $r, \%args ) ;
	}
	
    } elsif ( defined $args{reports} ) {
	
	if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {	

	if ( $args{reports} eq '0' ) {

	    $content = reports( $r, \%args ) ; 

	} else {

	    reports( $r, \%args ) ;
	    
	    #rediriger l'utilisateur vers le formulaire de saisie d'une entrée pour validation
	    my $location = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=A%20NOUVEAUX&id_entry=0&redo=0&_token_id=' . $args{_token_id} ;
	    
	    $r->headers_out->set(Location => $location) ;

	    return Apache2::Const::REDIRECT ;

	}
	
	} else {
	$content = liste_des_comptes( $r, \%args ) ;
	}

    } elsif ( defined $args{cloture} ) {

	if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {	
		
	#première demande de cloture des comptes
	if ( $args{cloture} eq '0' ) {

	    $content = cloture( $r, \%args ) ; 

	} else {
	    
	    #l'utilisateur a confirmé la demande de cloture
	    #on génère les écritures de solde des comptes et de calcul du résultat
	    #que l'on place dans journal_staging
	    cloture( $r, \%args ) ;
	    
	    #rediriger l'utilisateur vers le formulaire de saisie d'une entrée pour validation
	    my $location = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=CLOTURE&id_entry=0&redo=0&_token_id=' . $args{_token_id} ;
	    $r->headers_out->set(Location => $location) ;
	    return Apache2::Const::REDIRECT ;

	}
	
	} else {
	$content = liste_des_comptes( $r, \%args ) ;
	}
	
    } elsif ( defined $args{balance} ) {

	#l'utilisateur a cliqué sur le lien de téléchargement de la balance
	#le rediriger vers le fichier généré par sub balance
	if ( defined $args{download} ) {

	    my $location = balance( $r, \%args ) ;

	    #si un message d'erreur est renvoyé par sub balance, il contient class=warning
	    if ( $location =~ /warning/ ) {

		$content .= $location ;
 
	    } else {

		#adresse du fichier précédemment généré
		$r->headers_out->set(Location => $location) ;
		
		#rediriger le navigateur vers le fichier
		$r->status(Apache2::Const::REDIRECT) ;
		
		return Apache2::Const::REDIRECT ;
		
	    } #	    if ( $location =~ /warning/ )

	} else {

	    #afficher la balance
	    $content = balance( $r, \%args ) ; 

	} #	if ( defined $args{download} ) 

    } elsif ( defined $args{grandlivre} ) {

	    #afficher le grandlivre
	    $content = grandlivre( $r, \%args ) ; 
    
   } else {

	$content = liste_des_comptes( $r, \%args ) ;

    }
    
    $r->no_cache(1) ;
 
    $r->content_type('text/html; charset=utf-8') ;

    print $content ;
    
    return Apache2::Const::OK ;

}

sub reports {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content, $en_attente_count ) ;
	
    if ( $args->{reports} eq '0' ) {
		
	#
	$sql = q [
	with t1 as ( SELECT id_entry FROM tbljournal WHERE id_client = ? AND fiscal_year = ? GROUP BY id_entry)
	SELECT count(id_entry) FROM t1
	] ;

	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} -1 ) ;
	
	eval { $en_attente_count = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] } ;
	
	if ($en_attente_count eq '0') {
	
		$content .= '<h3 class="warning centrer">Attention : il n\'existe aucune écriture pour l\'exercice précédent.<br>
		Le report ne peut pas être effectuée</h3>' ;	
		
		return $content ;
		
	} else {		
		
		

	#1ère demande de suppression; afficher lien d'annulation/confirmation
	my $non_href = '/'.$r->pnotes('session')->{racine}.'/compte' ;

	my $oui_href = '/'.$r->pnotes('session')->{racine}.'/compte?reports=1' ;

	$content .= '<h3 class=warning>Reprendre les soldes de l\'exercice précédent?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;
	
	return $content ;
	}

    } else {
		
	my $token_id = join "", map +(0..9,"a".."z","A".."Z")[rand(10+26*2)], 1..32 ;

	$args->{_token_id} = $token_id ;	

	my $ecriture_debut_exercice = 'A.N. au '.$r->pnotes('session')->{Exercice_debut_DMY};
    	
	#supprimer d'abord les données éventuellement présentes dans tbljournal_staging pour cet utilisateur
	$sql = 'DELETE FROM tbljournal_staging WHERE _session_id = ? AND _token_id NOT LIKE \'%recurrent%\'' ;

	$dbh->do( $sql, undef, ( $r->pnotes('session')->{_session_id} ) ) ;
	
	#création du journal A NOUVEAUX pour les écritures d A NOUVEAUX
	my $var_lib_journal = 'A NOUVEAUX';
	my $var_code_journal = 'AN';
	my $var_type_journal = 'A-nouveaux';
	my $sql = 'INSERT INTO tbljournal_liste (id_client, fiscal_year, libelle_journal, code_journal, type_journal) VALUES (?, ?, ?, ?, ?)
	ON CONFLICT (id_client, fiscal_year, libelle_journal) DO NOTHING' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $var_lib_journal, $var_code_journal, $var_type_journal ) ;
	eval { $dbh->do( $sql, undef, @bind_array ) } ;
	
		#reconduction des comptes
	    $sql = '
INSERT INTO tblcompte (numero_compte, libelle_compte, default_id_tva, contrepartie, id_client, fiscal_year) 
SELECT numero_compte, libelle_compte, default_id_tva, contrepartie, ?, ? FROM tblcompte WHERE id_client = ? AND fiscal_year = ?
ON CONFLICT (id_client, fiscal_year, numero_compte) DO NOTHING' ;

	    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1 ) ;

	    eval { $dbh->do( $sql, undef, @bind_array ) } ;
	

	#création des comptes 110 et 119 s'ils n'existent pas
	my $var_compte_110 = '110000';
	my $var_compte_119 = '119000';
	my $var_comptelib_110 = 'Report à nouveau - solde créditeur';
	my $var_comptelib_119 = 'Report à nouveau - solde débiteur';

	$sql = '
	INSERT INTO tblcompte (numero_compte, libelle_compte, id_client, fiscal_year)  VALUES (?, ?, ?, ?)
	ON CONFLICT (id_client, fiscal_year, numero_compte) DO NOTHING' ;
	@bind_array = ( $var_compte_110, $var_comptelib_110, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	eval { $dbh->do( $sql, undef, @bind_array ) } ;
	
	@bind_array = ( $var_compte_119, $var_comptelib_119, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	eval { $dbh->do( $sql, undef, @bind_array ) } ;

	$sql = q {
with t1 as (
SELECT numero_compte, libelle_compte, sum(credit - debit) as solde 
FROM tbljournal INNER JOIN tblcompte using (id_client, fiscal_year, numero_compte ) 
WHERE id_client = ? and fiscal_year = ? AND substring(numero_compte from 1 for 1)::integer in (1, 2, 3, 4, 5)
GROUP BY numero_compte, libelle_compte HAVING sum(debit - credit) != 0
)
INSERT INTO tbljournal_staging (_session_id, id_entry, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, id_client, date_ecriture, libelle, numero_compte, libelle_journal, debit, credit, _token_id)
SELECT ?, 0, ?, ?, ?, ?, ?, ?, ?, numero_compte, 'A NOUVEAUX', -least(0, solde), greatest(0, solde), ?
FROM t1
} ;
	
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1,
			   $r->pnotes('session')->{_session_id}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset},
			   $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD},
			   $r->pnotes('session')->{id_client}, $r->pnotes('session')->{Exercice_debut_YMD}, $ecriture_debut_exercice, $args->{_token_id}
	    ) ;

	$dbh->do( $sql, undef, @bind_array ) ;
	
	return ;
	    
    } #    if ( $args->{reports} eq '0' ) 

} #sub reports 

sub cloture {

    my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my $content ;

    if ( $args->{cloture} eq '0' ) {

	#1ère demande de suppression; afficher lien d'annulation/confirmation
	my $non_href = '/'.$r->pnotes('session')->{racine}.'/compte' ;

	my $oui_href = '/'.$r->pnotes('session')->{racine}.'/compte?cloture=1' ;

	$content .= '<h3 class=warning>Cette action solde les comptes de classe 6 et 7 et calcule le résultat de l\'exercice. Elle est réversible par suppressions de l\'écriture insérée dans le journal des OD<br><br>
Vraiment clôturer les comptes?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;
	
	return $content ;

    } else {
  
	#création du journal Clôture pour les écritures de Clôture
	my $var_lib_journal = 'CLOTURE';
	my $var_code_journal = 'CL';
	my $var_type_journal = 'Clôture';
	my $sql = 'INSERT INTO tbljournal_liste (id_client, fiscal_year, libelle_journal, code_journal, type_journal) VALUES (?, ?, ?, ?, ?)
	ON CONFLICT (id_client, fiscal_year, libelle_journal) DO NOTHING' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $var_lib_journal, $var_code_journal, $var_type_journal ) ;
	eval { $dbh->do( $sql, undef, @bind_array ) } ;
	
	#création des comptes 120 et 129 s'ils n'existent pas
	my $var_compte_120 = '120000';
	my $var_compte_129 = '129000';
	my $var_comptelib_120 = 'Résultat de l\'exercice - bénéfice';
	my $var_comptelib_129 = 'Résultat de l\'exercice - perte';

	$sql = '
	INSERT INTO tblcompte (numero_compte, libelle_compte, id_client, fiscal_year)  VALUES (?, ?, ?, ?)
	ON CONFLICT (id_client, fiscal_year, numero_compte) DO NOTHING' ;
	@bind_array = ( $var_compte_120, $var_comptelib_120, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	eval { $dbh->do( $sql, undef, @bind_array ) } ;
	
	@bind_array = ( $var_compte_129, $var_comptelib_129, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	eval { $dbh->do( $sql, undef, @bind_array ) } ;
	

	#supprimer d'abord les données éventuellement présentes dans tbljournal_staging pour cet utilisateur
	$sql = 'DELETE FROM tbljournal_staging WHERE _session_id = ? AND _token_id NOT LIKE \'%recurrent%\'' ;

	$dbh->do( $sql, undef, ( $r->pnotes('session')->{_session_id} ) ) ;

	my $token_id = join "", map +(0..9,"a".."z","A".."Z")[rand(10+26*2)], 1..32 ;

	$args->{_token_id} = $token_id ;
	
	#recherche des soldes des comptes de classe 6 et 7
	$sql = q {
with t1 as (
SELECT numero_compte, sum(debit - credit) as solde 
FROM tbljournal 
WHERE id_client = ? and fiscal_year = ? AND substring(numero_compte from 1 for 1) = '6' 
GROUP BY numero_compte 
HAVING sum(debit - credit) > 0
UNION SELECT numero_compte, sum(credit - debit) as solde 
FROM tbljournal 
WHERE id_client = ? and fiscal_year = ? AND substring(numero_compte from 1 for 1) = '7'  
GROUP BY numero_compte 
HAVING sum(credit - debit) > 0
)
INSERT INTO tbljournal_staging (_session_id, id_entry, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, id_client, date_ecriture, libelle, numero_compte, libelle_journal, id_facture, debit, credit, _token_id)
SELECT ?, 0, ?, ?, ?, ?, ?, ((?||'-01-01')::date + '1 year'::interval)::date -1 + ?::integer, 'Clôture', numero_compte, 'CLOTURE', 'N/A', case when substring(numero_compte from 1 for 1) = '6' then 0 else solde end, case when substring(numero_compte from 1 for 1) = '6' then solde else 0 end, ?
from t1
} ;

	@bind_array = ( 
	    $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, 
	    $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year},
	    $r->pnotes('session')->{_session_id}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset},
	    $args->{_token_id}
) ;

	$dbh->do( $sql, undef, @bind_array ) ;
	
	
	#########################################	
	#Vérification des comptes 120 et 129	#
	#########################################
	$sql = 'SELECT sum(debit - credit) as resultat , (select numero_compte from tblcompte where id_client = 1 and fiscal_year = ? and substring(numero_compte from 1 for 3) = \'129\' )FROM tbljournal_staging WHERE _token_id = ?';
	my $calcul_resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{fiscal_year}, $args->{_token_id} ) ) ;
	my $calcul_resultat_compte = 120;
		
	if (defined $calcul_resultat->[0]->{numero_compte}) {
	if ((defined $calcul_resultat->[0]->{resultat} && $calcul_resultat->[0]->{resultat} < 0) && (defined $calcul_resultat->[0]->{numero_compte} && $calcul_resultat->[0]->{numero_compte} =~ /129/) ) {
		$calcul_resultat_compte = 129;
	} } 
		

	#les soldes sont calculés et placés dans tbljournal_staging
	#calculer le résultat et l'insérer au débit/crédit de 120 si 129 existe pas ou bien au débit de 129 s'il existe
	$sql = q {
with t1 as (
SELECT sum(debit - credit) as resultat FROM tbljournal_staging WHERE _token_id = ?
)
INSERT INTO tbljournal_staging (_session_id, id_entry, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, id_client, date_ecriture, libelle, numero_compte, libelle_journal, id_facture, debit, credit, _token_id)
SELECT ?, 0, ?, ?, ?, ?, ?, ((?||'-01-01')::date + '1 year'::interval)::date -1 + ?::integer, 'Clôture', (select numero_compte from tblcompte where id_client = ? and fiscal_year = ? and substring(numero_compte from 1 for 3) = ?), 'CLOTURE', 'N/A', -least(0, resultat), greatest(0, resultat), ?
from t1
} ;

	@bind_array = ( $args->{_token_id}, $r->pnotes('session')->{_session_id}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $calcul_resultat_compte, $args->{_token_id} ) ;
	    
	$dbh->do( $sql, undef, @bind_array ) ;
	
	Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'compte.pm => Clôture des comptes pour l\'exercice '.$r->pnotes('session')->{fiscal_year}.'');

	return ;

    }
    	    
} #sub cloture 

sub rapprochement {

    my ( $r, $args ) = @_ ;

    $args->{leur_solde} ||= 0 ;
    
    my $dbh = $r->pnotes('dbh') ;

    ( my $return_href = $r->unparsed_uri() ) =~ s/&rapprochement=0(.*)// ;

    my $content = '<table><tr><td><h2>Rapprochement</h2></td><td><a class=nav href="' . $return_href .'" style="margin-left: 3em;">Retour</a></td></tr></table>' ;

    my $sql ;
    
    #on veut les deux paramètres de la requête
    unless ( $args->{date_rapprochement} ) {

	my $date_rapprochement_input = '<tr><th style="text-align: right;">Date du rapprochement</th><td><input name=date_rapprochement onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')"></td></tr>';

	my $solde_input = '<tr><th style="text-align: right;">Solde du compte</th><td><input name=leur_solde></td></tr>' ;

	$content .= '<form action="' . $r->uri() . '"><p><input type=hidden name=numero_compte value="' . $args->{numero_compte} . '">
	<input type=hidden name=libelle_compte value="' . $args->{libelle_compte} . '">
	<input type=hidden name="racine" id="racine" value="' . $r->pnotes('session')->{racine} . '">
	<input type=hidden name=rapprochement value=0></p><table>' . $date_rapprochement_input . $solde_input . '</table><p class=submit><input type=submit value=Valider></p></form>' ;

      	return $content ;
	
    } #    unless ( $args->{date_rapprochement} )

    #En-tête
    $content .= '<h2>Compte ' . $args->{numero_compte} . ' - État de rapprochement au ' . $args->{date_rapprochement} . '</h2>' ;
    
    #on fait faire le travail de conversion des inputs/outputs localisés par postgresql via to_number 
    $sql = 'SELECT to_number(?, \'999999999999D99\') as leur_solde_numeric' ;    

    my @bind_array = ( $args->{leur_solde} ) ;

    my $leur_solde_set ;

    eval { $leur_solde_set = $dbh->selectall_arrayref( $sql, { Slice => { } } , @bind_array ) } ;

    if ( $@ ) {
	
	if ( $@ =~ / numeric / ) {

	    $content .= '<h3 class=warning>Solde non valide : ' . $args->{leur_solde} . '</h3>' ;

	    return $content ;

	} else {

	    $content .= '<h3 class=warning>' . $@ . '</h3>' ;

	    return $content ;
	    
	} #	if ( $@ =~ / numeric / ) 

    } #    if ( $@ ) 

    #on affiche $args->{leur_solde} tel qu'on l'a reçu
    my $not_in_their_book = '<li class=listitem>
<div class=container><div class=spacer></div>
<strong>
<span class=headerspan style="width: 62ch;">Leur solde</span>
<span class=headerspan style="width: 15ch; text-align: right;">&nbsp;</span>
<span class=headerspan style="width: 15ch; text-align: right;">' . $args->{leur_solde} . '</span>
</strong>
<div class=spacer></div></div></li>
' ;

    $not_in_their_book .= '<li class=listitem><hr></li><li class=listitem>
<div class=container><div class=spacer></div>
<strong>
<span class=blockspan style="width: 100%;">À passer par eux :</span>
</strong>
<div class=spacer></div></div></li>
' ;

    #ligne d'en-têtes
    $not_in_their_book .= '<li class=listitem>
<div class=container><div class=spacer></div>
<i>
<span class=blockspan style="width: 12ch;">Date</span>
<span class=blockspan style="width: 15ch;">Paiement</span>
<span class=blockspan style="width: 35ch;">Libellé</span>
<span class=blockspan style="width: 15ch; text-align: right;">Débit</span>
<span class=blockspan style="width: 15ch; text-align: right;">Crédit</span>
</i>
<div class=spacer></div></div></li>
' ;

    #liste des écritures non pointées
    #on réutilise total_debit et total_credit dans les calculs. Pour éviter une reconversion hasardeuse,
    #on calcule deux versions : numerique et formatée. la version formatée est affichée dans la page web
    $sql = '
SELECT t1.id_line, date_ecriture, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.libelle, \'&nbsp;\') as libelle, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, (sum(t1.debit) over())/100::numeric as total_debit, (sum(t1.credit) over())/100::numeric as total_credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit_formatted, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit_formatted
FROM tbljournal t1 
WHERE t1.id_client = ? and t1.fiscal_year = ? and t1.numero_compte = ? and date_ecriture <= ? and pointage = false ORDER BY date_ecriture
' ;

    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{numero_compte}, $args->{date_rapprochement} ) ;

    my $unchecked_set ;
    
    eval { $unchecked_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) } ;
	    
    if ( $@ ) {
	
	if ( $@ =~ / date / ) {

	    $content .= '<h3 class=warning>Date non valide : ' . $args->{date_rapprochement} . '</h3>' ;

	    return $content ;
	    
	} else {

	    $content .= '<h3 class=warning>' . $@ . '</h3>' ;

	    return $content ;
	    
	} #	if ( $@ =~ / date / )

    } #    if ( $@ ) 

    for ( @$unchecked_set ) {
	#
	#Attention! les colonnes débit et crédit sont inversées
	#on liste les écritures qu'ils n'ont pas passées, en inversant les colonnes
	#
	$not_in_their_book .= '<li class=listitem>
<div class=container><div class=spacer></div>
<span class=blockspan style="width: 12ch;">' . $_->{date_ecriture} . '</span>
<span class=blockspan style="width: 15ch;">' . $_->{id_paiement} . '</span>
<span class=blockspan style="width: 35ch;">' . $_->{libelle} . '</span>
<span class=blockspan style="width: 15ch; text-align: right;">' . $_->{credit} . '</span>
<span class=blockspan style="width: 15ch; text-align: right;">' . $_->{debit} . '</span>
<div class=spacer></div></div></li>' ;

    } #	for ( @$result_set ) 

   $sql = '
SELECT to_char(?::numeric, \'999G999G999G990D00\') as total_debit, to_char(?::numeric, \'999G999G999G990D00\') as total_credit
	';

    my $total_set ;

    @bind_array = ( $unchecked_set->[0]->{total_debit}, $unchecked_set->[0]->{total_credit} ) ;

    eval { $total_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) } ;
    
    if ( $@ ) {
	
	$content .= '<h3 class=warning>' . $@ . '</h3>' ;

	return $content ;
	
    } #    if ( $@ ) 

    #ligne de total des écritures à passer par eux
    $not_in_their_book .= '<li class=listitem>
<div class=container><div class=spacer></div>
<strong>
<span class=blockspan style="width: 12ch;">&nbsp;</span>
<span class=blockspan style="width: 15ch;">&nbsp;</span>
<span class=blockspan style="width: 35ch; text-align: right;">Total</span>
<span class=blockspan style="width: 15ch; text-align: right;">' . $unchecked_set->[0]->{total_credit_formatted} . '</span>
<span class=blockspan style="width: 15ch; text-align: right;">' . $unchecked_set->[0]->{total_debit_formatted} . '</span>
</strong>
<div class=spacer></div></div></li>
<li class=listitem><hr></li>
' ;
    
    #leur solde corrigé
    my $their_corrected_set ;

    #on calcul ici leur solde corrigé des opérations non passées par eux
    $sql = 'SELECT to_char(?::numeric + ?::numeric - ?::numeric, \'999G999G999G990D00\') as their_corrected' ;

    @bind_array = ( $leur_solde_set->[0]->{leur_solde_numeric} , $unchecked_set->[0]->{total_debit} , $unchecked_set->[0]->{total_credit} ) ;

    eval { $their_corrected_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) } ;

    $not_in_their_book .= '<li class=listitem>
<div class=container><div class=spacer></div>
<strong>
<span class=headerspan style="width: 62ch">Leur solde corrigé</span>
<span class=headerspan style="width: 15ch; text-align: right;">&nbsp;</span>
<span class=headerspan style="width: 15ch; text-align: right;" id="their_corrected">' . $their_corrected_set->[0]->{their_corrected} . '</span>
</strong>
<div class=spacer></div></div></li>' ;
    
    #notre solde; il nous faut inverser l'opération normale crédit - débit, puisque nous comparons avec leur solde
    $sql = 'SELECT to_char(sum(debit - credit)/100::numeric, \'999G999G999G990D00\') as notre_solde
FROM tbljournal t1 
WHERE t1.id_client = ? and t1.fiscal_year = ? and t1.numero_compte = ? and date_ecriture <= ? 
	';
    
    @bind_array =  ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{numero_compte}, $args->{date_rapprochement} ) ;
    
    my $notre_solde_set = $dbh->selectall_arrayref( $sql, { Slice => { } } , @bind_array ) ;
    
    $not_in_their_book .= '<li class=listitem>
<div class=container><div class=spacer></div>
<strong>
<span class=headerspan style="width: 62ch;">Notre solde</span>
<span class=headerspan style="width: 15ch; text-align: right;">&nbsp;</span>
<span class=headerspan style="width: 15ch; text-align: right;" id="notre_solde">' . $notre_solde_set->[0]->{notre_solde} . '</span>
</strong>
<div class=spacer></div></div></li>' ;
    
    $content .= '<div style="width: 97ch;"><ul>' . $not_in_their_book . '</ul></div>' ;

    #message de résultat
    if ( $notre_solde_set->[0]->{notre_solde} eq $their_corrected_set->[0]->{their_corrected} ) {

	$content .= '<h3 style="text-align: center;">Rapprochement exact</h3>' ;

    } else {

	#Erreur de rapprochement; dans ce cas, afficher en rouge les montants "notre_solde" et "their_corrected"
	$content .= '<h3 class=warning style="text-align: center;">Erreur de rapprochement</h3><script>document.getElementById("notre_solde").style.color = "red";document.getElementById("their_corrected").style.color = "red";</script>' ;
	
    }

    return $content ;

} #sub rapprochement

sub import_form {
#formulaire d'upload d'un fichier d'importation des comptes
    my $r = shift ;
    
	my $form_web .= '
		<fieldset><legend><h3 style="color: green; background-color: #ddefef;">Comptes - Importer une liste de compte</h3></legend>
		<div class="centrer">
	    <div class=Titre10>Fichier à importer</div>
	    <div class="form-int">
			<form style ="display:inline;" action="/'.$r->pnotes('session')->{racine}.'/compte" method=POST enctype="multipart/form-data">
			<input type=hidden name=edit_compte_set value=0>
			<input type=hidden name=import value=1>
			<input type=file name=import_file>
			 <br><br>
			<input type="submit" class="btnform1 gris" style ="width : 25%;" value="Cliquez ici pour envoyer">
			<p style="">(* : taille maximum 64Mo par fichier)</p>
			</form>
	    </div></div></fieldset>
		';
    
	my $content .= '<div class="formulaire1">' . $form_web . '</div>' ;
    return $content ;

} #sub import_form

sub edit_compte_set {
	
	# définition des variables
    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array ) ;
    my $content = '' ;
    my $i = "1"; 
    	
    ################ Affichage MENU ################
    $content .= display_menu_compte( $r, $args ) ;
	################ Affichage MENU ################
	
	#Requête compta_client sur les informations de la société
    $sql = 'SELECT id_tva_regime FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;


	#/************ ACTION DEBUT *************/
	
	####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Supprimer' 					  #
	#######################################################################
    if ( defined $args->{delete_compte} ) {

		if ( $args->{delete_compte} eq '0' ) {
			
			#1ère demande de suppression; afficher lien d'annulation/confirmation
			my $non_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0' ;

			my $oui_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0&amp;delete_compte=1&amp;delete_numero=' . $args->{delete_numero} ;

			$content .= '<h3 class=warning>Vraiment supprimer le compte &quot;' . $args->{delete_numero} . '&quot;?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;

		} else {

			$sql = 'DELETE FROM tblcompte WHERE id_client = ? and fiscal_year = ? and numero_compte = ?' ;

			@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{delete_numero} ) ;

			eval { $dbh->do( $sql, undef, @bind_array ) } ;

			if ( $@ ) {

			if ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {

				$content .= '<h3 class=warning>Le compte n\'est pas vide : suppression impossible </h3>' ;
				
			} else {
				
				$content .= '<h3 class=warning>' . $@ . '</h3>' ;

			}

			} #	    if ( $@ ) 

		} #	if ( $args->{delete_compte} eq '0' ) 

    } #    if ( defined $args->{delete_compte} )
    
    #attention aux débuts d'exercice décalés
    #pour l'affichage, l'exercice mentionné est "année N - année N+1"
    my $exercice_a_reconduire ;
    if ( $r->pnotes('session')->{fiscal_year_offset} ) {
	$exercice_a_reconduire = ( $r->pnotes('session')->{fiscal_year} - 1 ) . '-' .  $r->pnotes('session')->{fiscal_year}
    } else {
	$exercice_a_reconduire = $r->pnotes('session')->{fiscal_year} - 1 ;
    }

    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Reconduire' 					  #
	#######################################################################
    if ( defined $args->{reconduire} ) {

		if ( $args->{reconduire} eq '0' ) {
			
			#1ère demande de reconduction; afficher lien d'annulation/confirmation
			my $non_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0' ;

			my $oui_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0&amp;reconduire=1' ;

			$content .= '<h3 class=warning>Vraiment reconduire l\'exercice ' . $exercice_a_reconduire . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;

		} else {

			#reconduire les comptes
			$sql = '
			INSERT INTO tblcompte (numero_compte, libelle_compte, default_id_tva, contrepartie, id_client, fiscal_year) 
			SELECT numero_compte, libelle_compte, default_id_tva, contrepartie, ?, ? FROM tblcompte WHERE id_client = ? AND fiscal_year = ?
			ON CONFLICT (id_client, fiscal_year, numero_compte) DO NOTHING' ;

			@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1 ) ;

			eval { $dbh->do( $sql, undef, @bind_array ) } ;

			if ( $@ ) {

			if ( $@ =~ /tblcompte_client_year_numero_compte_pk/ ) {

				$content .= '<h3 class=warning>Des comptes de l\'année précédente existent déjà : reconduction impossible</h3>' ;

			} else {
				
				$content .= '<h3 class=warning>' . $@ . '</h3>' ;

			}
			
			} #	    if ( $@ ) 
			
			if (not($parametre_set->[0]->{id_tva_regime} eq 'franchise')) {

			#reconduire les formulaires cerfa
			$sql = '
			INSERT INTO tblcerfa (id_item, id_client, fiscal_year, form_number, credit_first, included_compte) 
			SELECT id_item, ?, ?, form_number, credit_first, included_compte FROM tblcerfa WHERE id_client = ? AND fiscal_year = ?
			ON CONFLICT (id_item, id_client, fiscal_year) DO NOTHING' ;

			#on commence par tblcerfa_2
			$sql = '
			INSERT INTO tblcerfa_2 (id_item, id_client, fiscal_year, credit_first) 
			SELECT id_item, ?, ?, credit_first FROM tblcerfa_2 WHERE id_client = ? AND fiscal_year = ?
			ON CONFLICT (id_item, id_client, fiscal_year) DO NOTHING' ;

			@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1 ) ;

			eval { $dbh->do( $sql, undef, @bind_array ) } ;

			if ( $@ ) {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}  else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'compte.pm => Reconduction de la liste de compte pour l\'exercice '.$r->pnotes('session')->{fiscal_year}.'');
			}

			#on continue avec tblcerfa_2_detail
			$sql = '
			with t1 as (
			SELECT id_entry, id_item
				   FROM tblcerfa_2 WHERE id_client = ? AND fiscal_year = ?),
			t2 as (
				   SELECT id_item, numero_compte
					  FROM tblcerfa_2 INNER JOIN tblcerfa_2_detail using (id_entry)
					  WHERE id_client = ? AND fiscal_year = ?)
			insert into tblcerfa_2_detail (id_entry, numero_compte)
			select t1.id_entry, t2.numero_compte from t1 inner join t2 using (id_item);
			' ;

			@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1 ) ;

			eval { $dbh->do( $sql, undef, @bind_array ) } ;

			if ( $@ ) {   
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			} 
			
			}
			
		} #	if ( $args->{reconduire} eq '0' )

    } #    if ( defined $args->{reconduire} )

    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Importer' 					  #
	#######################################################################
    if ( defined $args->{import} ) {

		if ( $args->{import} eq '0' ) {

			#première demande d'importation : afficher le formulaire d'upload d'un fichier
			$content .= import_form( $r ) ;

		} else {

			#envoi d'un fichier par l'utilisateur
			unless ( $args->{import_file} ) {
			
			#pas de fichier!
			$content .= '<h3 class=warning>Fichier absent!</h3>' ;

			} else {

			#on a un fichier, traiter les données
			my $req = Apache2::Request->new( $r ) ;

			my $upload = $req->upload("import_file") or warn $!  ;

			my $upload_fh = $upload->fh() ;
			
			my $compte_liste = '' ;

			#on suppose que les données sont en UTF-8
			my $valid_data = 1 ;
			
			while (my $data = <$upload_fh>) {
				
				if ($data =~ /comptenum|comptelib|contrepartie/ ) {
					
				next;}

				chomp($data);

				#vérifier qu'on a bien du utf8; sinon, avorter et envoyer message d'erreur
				eval { $data = Encode::decode( "utf8", $data, Encode::FB_CROAK ) };

				if ( $@ ) { # input was not utf8

					$content .= '<h3 class=warning>Les données transmises ne sont pas au format UTF-8, importation impossible</h3>' ;		    

				#mettre valid_data à 0 pour empêcher l'importation
				$valid_data = 0 ;

				#inutile de continuer
					last ;
					
				} 
				
				#remplacer les ' par '' pour postgres
				$data =~ s/'/''/g ;
				
				my @data = split ';', $data ;
				
				#$data[0] => comptenum
				#$data[1] => comptelib
				#$data[2] => contrepartie
				if ( $data[2] ) { $data[2] = qq [ $data[2] ] } else { $data[2] ='NULL' } ;

				$compte_liste .= ',(' . $r->pnotes('session')->{id_client} . ', ' . $r->pnotes('session')->{fiscal_year} . ', E\'' . $data[0] . '\', E\'' . $data[1] . '\', ' . $data[2] . ')' ;


			} #		while (my $data = <$upload_fh>) 

			if ( $valid_data ) {
				
				#on retire la première virgule de $comte_liste
				$sql = 'INSERT INTO tblcompte (id_client, fiscal_year, numero_compte, libelle_compte, contrepartie) VALUES ' . substr( $compte_liste, 1).'
				ON CONFLICT (id_client, fiscal_year, numero_compte) 
				DO UPDATE SET (libelle_compte, contrepartie) = (EXCLUDED.libelle_compte, EXCLUDED.contrepartie)
				';

				#insérer les données
				eval { $dbh->do( $sql ) } ;

				if ( $@ ) {

				if ( $@ =~ /unique/ ) {

					$content .= '<h3 class=warning>Un des numéros de compte importés existe déjà</h3>' ;		    

				} else {
					
					$content .= '<h3 class=warning>' . $@ . '</h3>' ;		    

				} #		    if ( $@ =~ /unique/ ) 
				
				} else {
				
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'compte.pm => Restauration des comptes à partir d\'un fichier pour l\'exercice '.$r->pnotes('session')->{fiscal_year}.'');
				
				}

			} #		if ( $valid_data ) {

			} #	    unless ( $args->{import_file} )
			
		} #	if ( $args->{import} eq '0' ) 

    } #    if ( defined $args->{import} )
    
    ########################################################################################## 
	#l'utilisateur a ajouté/modifié un compte; on ne fait rien si le numero_compte est vide  #
	##########################################################################################
    if ( ( defined $args->{new_numero_compte} ) and ( $args->{new_numero_compte} ) and ( $args->{libelle_compte} ) ) {

		if ( $args->{old_numero_compte} eq 'new_numero_compte' ) {

			#nouveau compte
			$sql = 'INSERT INTO tblcompte (numero_compte, libelle_compte, contrepartie, id_client, fiscal_year) VALUES (?, ?, ?, ?, ?)' ;
			#$args->{libelle_compte} = Encode::encode_utf8($args->{libelle_compte});
			@bind_array = ( $args->{new_numero_compte}, $args->{libelle_compte}, ($args->{contrepartie} || undef), $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
			
		} else {

			#mise à jour d'un compte existant; les comptes de classe 7 ont une valeur default_id_tva, pour les autres mettre à 0
			$sql = 'UPDATE tblcompte set numero_compte = ?, libelle_compte = ?, default_id_tva = ?, contrepartie = ? WHERE id_client = ? and fiscal_year = ? and numero_compte = ?' ;
			#$args->{libelle_compte} = Encode::encode_utf8($args->{libelle_compte});

			@bind_array = ( $args->{new_numero_compte}, $args->{libelle_compte}, $args->{default_id_tva} || 0, ($args->{contrepartie} || undef), $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{old_numero_compte} ) ;

		} #	if ( $args->{id_compte} eq '0' ) 

		#on vérifie que le numéro de compte commence bien par un chiffre
		if ( substr( $args->{new_numero_compte}, 0, 1 ) =~ /\d/ ) {
			
			eval { $dbh->do( $sql, undef, @bind_array ) } ;

			if ( $@ ) {

			if ( $@ =~ /tblcompte_client_year_numero_compte_pk/ ) {
				
				my $message = "Ce numéro de compte existe déjà." ;
				
				$content .= '<h3 class=warning>' . $message . '</h3>' ;

			} else { 

				$content .= '<h3 class=warning>' . $@ . '</h3>' ;

			}
			
			} #	if ( $@ )

		} else {

			$content .= '<h3 class=warning>Le numéro de compte doit commencer par un chiffre - Enregistrement impossible</h3>' ;

		} #	if ( substr( $args->{new_numero_compte}, 0, 1 ) =~ /\d/ )
	
    } #    if ( defined $args->{new_numero_compte} )
   
    #lien de retour
    my $return_href = '/'.$r->pnotes('session')->{racine}.'/compte' ;

    #lien de reconduction année N-1
    my $reconduire_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0&amp;reconduire=0' ;
    my $reconduire_link = '<a class=nav href="' . $reconduire_href . '" style="margin-left: 3ch;">Reconduire ' . $exercice_a_reconduire . '</a>' ;

    #lien d'importation d'un fichier de comptes
    my $import_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0&amp;import=0' ;
    my $import_link = '<a class=nav href="' . $import_href . '" style="margin-left: 2%;">Importer</a> <a class=nav href="/'.$r->pnotes('session')->{racine}.'/menu#comptes" style="text-decoration: none;">(Aide)</a>' ;
    
    $content .= '<p style="text-align : center;">' . $reconduire_link . $import_link . '</p>' ;
    
    #Requête tblcompte
    $sql = 'SELECT numero_compte, libelle_compte, default_id_tva, contrepartie FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER by numero_compte' ;
    my $compte_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;

    my ( $compte_list, $class ) = ( '', '' ) ;

	#select_compte4
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req4 = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte4 = '<select name=contrepartie id=contrepartie style="width: 35ch;">' ;
	$select_compte4 .= '<option value="">--contrepartie--</option>' ;
	for ( @$compte_req4 ) {
	$select_compte4 .= '<option value="' . $_->[0] . '" >' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte4 .= '<option value="" selected>--contrepartie--</option>' ;
	
	#nouveau compte
    $compte_list .= '<tr><th>Ajouter un compte</th></tr>' ;
    
    $compte_list .= '
    <tr><td><form action="/'.$r->pnotes('session')->{racine}.'/compte" method=POST>
    <input type=text name="new_numero_compte" value="" style="width: 15ch;">
    <input type=hidden name="old_numero_compte" value="new_numero_compte">
    <input type=text name="libelle_compte" value="" style="width: 60ch; margin-left: 1ch;">
    '.$select_compte4.'
    <input type=hidden name="edit_compte_set" value=0>
    <input type=hidden name="new_compte" value=0>
    <input type=submit value=Valider style="margin-left: 1ch;">
    </form></td></tr><br>' ;

    for ( @$compte_set ) {
		
	#select_compte4
	my $selected_compte4 = $_->{contrepartie};
	$select_compte4 = '<select name=contrepartie id=contrepartie_'.($i ++).' style="width: 35ch;">' ;
	$select_compte4 .= '<option value="">--contrepartie--</option>' ;
	for ( @$compte_req4 ) {
	my $selected = ( $_->[0] eq ($selected_compte4 || '') ) ? 'selected' : '' ;
	$select_compte4 .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	if (!($_->{contrepartie})) {
	$select_compte4 .= '<option value="" selected>--contrepartie--</option>' ;
	}
	$select_compte4 .= '</select>' ;	
	

	#afficher le type de compte
	unless ( substr($_->{numero_compte}, 0, 1)  eq $class) {

	    $compte_list .= '<tr><th><span class=headerspan style="width: 100%;">Classe ' . substr($_->{numero_compte}, 0, 1) . '</span></th></tr>' ;

	    $class = substr($_->{numero_compte}, 0, 1) ;

	} #    for ( @$compte_set ) 

	my $delete_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0&amp;delete_compte=0&amp;delete_numero=' . $_->{numero_compte} ;
	
	
	$compte_list .= '
	<tr><td><form action="/'.$r->pnotes('session')->{racine}.'/compte" method=POST>
	<input type=text name="new_numero_compte" value="' . $_->{numero_compte} . '" style="width: 15ch;">
	<input type=hidden name="old_numero_compte" value="' . $_->{numero_compte} . '">
	<input type=text name="libelle_compte" onkeyup="verif(this);" value="' . $_->{libelle_compte} . '" style="width: 60ch; margin-left: 1ch;">
	'.$select_compte4.'
	<input type=hidden name="edit_compte_set" value=0>
	<input type=hidden name="new_compte" value=0>
	<input type=submit value=Valider style="margin-left: 1ch;">
	<a href="' . $delete_href . '" style="margin-left: 1ch;">Supprimer</a>
	' . default_id_tva( $r, $_->{default_id_tva}, $_->{numero_compte} ) . '
	</form></td></tr>' ;

    } #    for ( @$compte_set )

    $content .= '<div class="wrapper-compte">' . $compte_list . '</div>' ;
	
    return $content ;

} #sub edit_compte_set

sub default_id_tva {

    my ( $r, $default_id_tva, $numero_compte ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my $content = '' ;

    return $content unless ( substr( $numero_compte, 0, 1 ) eq '7' ) ;
    
    my $sql = 'SELECT id_tva FROM tbltva ORDER BY 1' ;

    my $tva_set = $dbh->selectall_arrayref( $sql ) ;

    my $option_set ;

    for ( @$tva_set ) {

	my $selected = ( $_->[0] eq $default_id_tva ) ? 'selected' : '' ;

	$option_set .= '<option ' . $selected . ' value="' . $_->[0] . '">' . $_->[0] . '</option>' ;

    }
    
    $content = '<select name=default_id_tva style="margin-left: 1em;">' . $option_set . '</select>' ;

    return $content ;

} #sub default_tva 

sub option_list {
    #liste les options d'affichage des écritures (lettrées/pointées : oui/non/toutes)
    
    my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    #sans pointage/lettrage, on affiche un paragraphe vide pour éviter que l'affichage de la liste ne bouge
    return '<p>&nbsp;</p>' unless ( defined $args->{pointage} or defined $args->{lettrage} ) ;

    my ( $yes_class, $no_class, $all_class ) ;
    
    my ( $yes_href, $no_href, $all_href ) ;

    my ( $yes_link, $no_link, $all_link ) ;

    if ( defined $args->{pointage} ) {

	( $yes_href, $no_href, $all_href ) = ( $args->{base_uri} . '&amp;pointage=true', $args->{base_uri} . '&amp;pointage=false', $args->{base_uri} . '&amp;pointage=0' ) ;

	( $yes_class, $no_class, $all_class ) = ( ( $args->{pointage} eq 'true' ) ? 'selecteditem' : 'nav', ( $args->{pointage} eq 'false' ) ? 'selecteditem' : 'nav', ( $args->{pointage} eq '0' ) ? 'selecteditem' : 'nav' ) ;

	( $yes_link, $no_link, $all_link ) = ( 'pointées', 'non pointées', 'toutes' ) ;

    } else {

	( $yes_href, $no_href, $all_href ) =( $args->{base_uri} . '&amp;lettrage=not%20null', $args->{base_uri} . '&amp;lettrage=null', $args->{base_uri} . '&amp;lettrage=0' ) ;

	( $yes_class, $no_class, $all_class ) = ( ( $args->{lettrage} eq 'not null' ) ? 'selecteditem' : 'nav', ( $args->{lettrage} eq 'null' ) ? 'selecteditem' : 'nav', ( $args->{lettrage} eq '0' ) ? 'selecteditem' : 'nav' ) ;
	
	( $yes_link, $no_link, $all_link ) = ( 'lettrées', 'non lettrées', 'toutes' ) ;
	
    } #    if ( defined $args->{pointage} ) 
    
    my $content = '<p>Afficher les écritures <a class=' . $yes_class . ' href="' . $yes_href . '" style="margin-left: 3em;">' . $yes_link . '</a><a class=' . $no_class . ' href="' . $no_href . '" style="margin-left: 3em;">' . $no_link . '</a><a class=' . $all_class . ' href="' . $all_href . '" style="margin-left: 3em;">' . $all_link . '</a>' ;

    return $content ;

} #sub option_list 

sub visiter_un_compte {
    #affiche le contenu d'un compte
    
    my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;
    my ($sql,@bind_array) ;

    my $content = '' ;
    
    ################ Affichage MENU ################
    $content .= display_classe_compte( $r, $args ) ;
	################ Affichage MENU ################


    my $return_href = '/'.$r->pnotes('session')->{racine}.'/compte' ;

    my ( $lettrage_href, $lettrage_link, $lettrage_input, $lettrage_base ) ;
    
    my ( $pointage_href, $pointage_link, $pointage_input, $pointage_base ) ; 
    
    $args->{base_uri} = $r->unparsed_uri() ;

    #effacer les deux options de $args->{base_uri} pour garder une base propre
    $args->{base_uri} =~ s/&pointage=(.*)|&lettrage=(.*)// ;

    #options d'affichage du lettrage/pointage
    if ( defined $args->{lettrage} ) {

	$lettrage_href = $args->{base_uri} ;

    } else {

	$lettrage_href = $args->{base_uri} . '&amp;lettrage=0' ;

    } #    if ( defined $args->{lettrage} ) 

    if ( defined $args->{pointage} ) {

	$pointage_href = $args->{base_uri} ;
	
    } else {

	$pointage_href = $args->{base_uri} . '&amp;pointage=0' ;

    } #    if ( defined $args->{pointage} ) 

    $pointage_href =~ s/&lettrage=0// ;
    
    my $rapprochement_link = '<a class=nav href="' . $args->{base_uri} . '&amp;rapprochement=0' . '" style="margin-left: 3ch;">Rapprochement</a>' ;

    #ajout éventuel d'une condition à la clause WHERE pour l'affichage de pointée|lettrées/non pointées|lettrées/toutes
    my $lettrage_pointage_condition = '' ;

    $pointage_base = '<input type=checkbox id=id value=value style="vertical-align: middle;" onclick="pointage(this, \'' . $args->{numero_compte} . '\', \'' . $r->pnotes('session')->{racine}. '\')">
    ' ;
    
    if (defined $args->{pointage} ) {

	$lettrage_pointage_condition = ' AND pointage = ' . $args->{pointage} unless ( $args->{pointage} eq '0' ) ;

    } #    if (defined $args->{pointage} ) 

    $lettrage_base = '<input type=text id=id style="margin-left: 0.5em; padding: 0; width: 7ch; height: 1em; text-align: right;" value=value placeholder=&rarr; oninput="lettrage(this, \'' . $args->{numero_compte} . '\', \'' . $r->pnotes('session')->{racine}. '\')">' ;

    if (defined $args->{lettrage} ) {

	$lettrage_pointage_condition = ' AND lettrage IS ' . $args->{lettrage} unless ( $args->{lettrage} eq '0' ) ;
	    
    } #    if (defined $arg{lettrage} ) 

    my $class = ( defined $args->{pointage} ) ? 'selecteditem' : 'nav' ;
    
    $pointage_link = '<a class=' . $class . ' href="' . $pointage_href . '" style="margin-left: 3ch;">Pointage</a>' ;

    $class = ( defined $args->{lettrage} ) ? 'selecteditem' : 'nav' ;

    $lettrage_link = '<a class=' . $class . ' href="' . $lettrage_href . '" style="margin-left: 3ch;">Lettrage</a>' ;
    
    #contenu du/des compte(s); on limite la clause where si on a un numero_compte
    my $numero_compte_condition = ( $args->{numero_compte} ) ? ' AND numero_compte = ? ' : '' ;

    $sql = '
with t1 as (
SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, libelle_journal, coalesce(id_facture, \'&nbsp;\') as id_facture, coalesce(id_paiement, \'&nbsp;\') as id_paiement, coalesce(libelle, \'&nbsp;\') as libelle, debit/100::numeric as debit, credit/100::numeric as credit, lettrage, pointage
FROM tbljournal
WHERE id_client = ? and fiscal_year = ?  ' . $lettrage_pointage_condition . $numero_compte_condition . '
ORDER BY numero_compte, date_ecriture, id_facture, libelle, id_line
) 
SELECT t1.numero_compte, regexp_replace(t2.libelle_compte, \'\\s\', \'&nbsp;\', \'g\') as libelle_compte, id_entry, id_line, date_ecriture, libelle_journal, coalesce(id_facture, \'&nbsp;\') as id_facture, coalesce(id_paiement, \'&nbsp;\') as id_paiement, coalesce(libelle, \'&nbsp;\') as libelle, to_char(debit, \'999G999G999G990D00\') as debit, to_char(credit, \'999G999G999G990D00\') as credit, lettrage, pointage, to_char(sum(debit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_debit, to_char(sum(credit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_credit, to_char(sum(credit-debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_facture, libelle), \'999G999G999G990D00\') as solde
FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
ORDER BY numero_compte, date_ecriture, id_facture, libelle, id_line
' ;  
    
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;

    #si numero_compte != 0, on veut un seul compte
    push @bind_array, $args->{numero_compte} if ( $args->{numero_compte} ) ;
    
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;

	
    #ligne d'en-têtes
    my $entry_list = '' ;

    #pas trouvé de moyen évident de formater les résultats à zéro conformément à la locale avec perl
    #si postgres ne retourne aucun résultat; ne rien afficher laisse une sorte de doute
    #du coup, on affiche dans ce cas un 0 simple, immédiatement compréhensible
    #un peu dérangeant car le format n'est pas localisé, mais qui va visiter des comptes vides de toutes façons?
    my ( $total_credit, $total_debit ) = ( '0', '0' ) ;

    #pour un seul compte, il faut placer l'en-tête et les options de pointage/lettrage
    if ( $args->{numero_compte} ) {

	my $libelle_compte = ( $args->{libelle_compte} =~ s/\s/&nbsp;/g ) ;
	
		$entry_list .= '
<li style="text-align: center; list-style: none; margin: 0;">' . $lettrage_link . $pointage_link . $rapprochement_link . option_list( $r, $args ) .'</li>' ;

	foreach my $varclasse (1..7) {
	if  (substr( $args->{numero_compte}, 0, 1 ) eq $varclasse ) {
	my $classe_colonne ='<li class="style1"><div class=flex-table><div class=spacer></div><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&amp;classe='. $varclasse .'"><span class=classenum>Classe ' . $varclasse .'</span></a><div class=spacer></div></div></li>' ;
    my $compte_href = '/'.$r->pnotes('session')->{racine}.'/compte?classe=' . $varclasse . '&amp;numero_compte=' . URI::Escape::uri_escape_utf8( $args->{numero_compte} ) . '&amp;libelle_compte=' . URI::Escape::uri_escape_utf8( $args->{libelle_compte}) ;
	my $libcompte_colonne = '<span class=compte><li class=listitem><div class=flex-table><div class=spacer></div><a href="' . $compte_href . '">
	  	<span class=blockspan style="width: 68%;">Compte ' . $args->{numero_compte} . ' - ' . $args->{libelle_compte} . '</span>
	  	<span class=blockspan style="width: 32%;">&nbsp;</span>
	  	</a><div class=spacer></div></div></li></span>' ;;
		$entry_list .= $classe_colonne ;
		$entry_list .= $libcompte_colonne;
	}
	}

	
			
	$entry_list .= '
<li class=listitem><div class=flex-table><div class=spacer></div>
<span class=headerspan style="width: 10%;">Date</span>
<span class=headerspan style="width: 8%;">Journal</span>
<span class=headerspan style="width: 16%;">Pièce</span>
<span class=headerspan style="width: 30%;">Libellé</span>
<span class=headerspan style="width: 8%; text-align: right;">Débit</span>
<span class=headerspan style="width: 8%; text-align: right;">Crédit</span>
<span class=headerspan style="width: 8%;">&nbsp;</span>
<span class=headerspan style="width: 8%; text-align: right;">Solde</span>
<div class=spacer></div></div></li>
' ;

    }
    
    for ( @$result_set ) {
		
		

	#changement de numero_compte : mettre un recap et l'en-tête du compte suivant
	unless ( $_->{numero_compte} eq $args->{numero_compte} ) {

	    #titre du Grand Livre
	    $entry_list .= '<li style="list-style: none; margin: 0;"><h2>Grand Livre</h2>' if ( $args->{numero_compte} eq '0' ) ;
	    
	    #pas de recap avant d'avoir parcouru le premier compte
	    unless ( $args->{numero_compte} eq '0' ) {

		$entry_list .=  '
		<li class=listitem><hr></li><li class=listitem><div class=flex-table><div class=spacer></div>
<span class=blockspan style="width: 10%;">&nbsp;</span>
<span class=blockspan style="width: 8%;">&nbsp;</span>
<span class=blockspan style="width: 16%;">&nbsp;</span>
<span class=blockspan style="width: 30%; text-align: right;">Total</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $total_debit . '</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $total_credit . '</span>
<div class=spacer></div></div></li>' ;

	    } #	    unless ( $args->{numero_compte} eq '0' ) 

	    #en-têtes du compte
	    $entry_list .= '<li style="list-style: none; margin: 0;"><table><tr><td><h3>Compte N° '. $_->{numero_compte} . ' [ '. $_->{libelle_compte} . ' ]</h3></td><td>&nbsp;</td><td>&nbsp;</td></tr></table></li>' ;

	    $entry_list .= '
<li class=listitem><div class=flex-table><div class=spacer></div>
<span class=headerspan style="width: 10%;">Date</span>
<span class=headerspan style="width: 8%;">Journal</span>
<span class=headerspan style="width: 16%;">Pièce</span>
<span class=headerspan style="width: 30%;">Libellé</span>
<span class=headerspan style="width: 8%; text-align: right;">Débit</span>
<span class=headerspan style="width: 8%; text-align: right;">Crédit</span>
<span class=headerspan style="width: 8%;">&nbsp;</span>
<span class=headerspan style="width: 8%; text-align: right;">Solde</span>
<div class=spacer></div></div></li>
' ;

	    $args->{numero_compte} = $_->{numero_compte} ;
	    
	} #	unless ( $_->{numero_compte} eq $args->{numero_compte} )

	$sql = 'SELECT id_client FROM tbllocked_month 
	WHERE id_client = ? and ( id_month = to_char(?::date, \'MM\') ) AND fiscal_year = ?';
	@bind_array = ( $r->pnotes('session')->{id_client}, $_->{date_ecriture}, $r->pnotes('session')->{fiscal_year}) ;
	my $result_block = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
	

	my $lettrage_pointage = '&nbsp;' ;
	
	#l'id_line de la checkox de pointage commence par pointage_ pour être différente de id_line sur l'input de lettrage
	my $pointage_id = 'id=pointage_' . $_->{id_line} ;
	
	( $pointage_input = $pointage_base ) =~ s/id=id/$pointage_id/ ;

	my $pointage_value = ( $_->{pointage} eq 't' ) ? 'checked' : '' ;

	$pointage_input =~ s/value=value/$pointage_value/ ;

	if (defined $result_block && $result_block eq $r->pnotes('session')->{id_client}) {
	$lettrage_pointage .= ( $_->{pointage} eq 't' ) ? '<img class="redimmage nav" title="Check complet" src="/Compta/images/icone-valider.png" alt="valide">' : '&nbsp;' ;
	} else {
	$lettrage_pointage .= $pointage_input ;
	}
	
	
	my $lettrage_id = 'id=' . $_->{id_line} ;

	( $lettrage_input = $lettrage_base ) =~ s/id=id/$lettrage_id/ ;
	
	my $lettrage_value = ( $_->{lettrage} ) ? 'value=' . $_->{lettrage} : '' ;

	$lettrage_input =~ s/value=value/$lettrage_value/ ;
	
	if (defined $result_block && $result_block eq $r->pnotes('session')->{id_client}) {
	$lettrage_pointage .= ( $_->{lettrage} || '&nbsp;' );
	} else {
	$lettrage_pointage .= $lettrage_input ;
	}
	


	#lien vers le formulaire d'édition de l'entrée considérée
	my $journal_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . URI::Escape::uri_escape_utf8( $_->{id_entry} ) ;

	$entry_list .= '<li class=listitem><div class=flex-table><div class=spacer></div><a href="' . $journal_href . '">
<span class=blockspan style="width: 10%;">' . $_->{date_ecriture} . '</span>
<span class=blockspan style="width: 8%;">' . $_->{libelle_journal} . '</span>
<span class=blockspan style="width: 16%;">' . $_->{id_facture} . '</span>
<span class=blockspan style="width: 30%;">' . $_->{libelle} . '</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $_->{debit} . '</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $_->{credit} . '</span>
</a>
<span class=blockspan style="width: 8%; margin-left: 1ch;">' . $lettrage_pointage . '</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $_->{solde} . '</span>
<div class=spacer></div></div></li>' ;

	#les totaux sont repris en début de boucle, juste avant de commencer le compte suivant
	$total_debit = $_->{total_debit} ;

	$total_credit = $_->{total_credit} ;

    } #    for ( @$result_set ) 

	
		
    #recap du dernier compte de la liste, qui n'est pas dans la boucle
    $entry_list .=  '	
			<li class=listitem><hr></li><li class=listitem><div class=flex-table><div class=spacer></div>
<span class=blockspan style="width: 10%;">&nbsp;</span>
<span class=blockspan style="width: 8%;">&nbsp;</span>
<span class=blockspan style="width: 16%;">&nbsp;</span>
<span class=blockspan style="width: 30%; text-align: right;">Total</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $total_debit . '</span>
<span class=blockspan style="width: 8%; text-align: right;">' . $total_credit . '</span>
<div class=spacer></div></div></li>' ;

		
	$content .= '<div class="wrapper"><ul class=wrapper>' . $entry_list . '</ul></div>' ;

    return $content ;
    
} #sub visiter_un_compte 

sub liste_des_comptes {

    my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;
    my $content;

    ################ Affichage MENU ################
    $content .= display_menu_compte( $r, $args ) ;
	################ Affichage MENU ################
    
    #liste des comptes
    my $sql = 'SELECT numero_compte, substring(numero_compte from \'^.\') as classe, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER by numero_compte' ;

    my $compte_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;

    my $compte_list = '' ;
    
    my $classe = '' ;
    
    for ( @$compte_set ) {
	
	#afficher la classe si on change de classe
	unless ( $_->{classe} eq $classe ) {

	my $classe_href3 = '/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&amp;classe=' . $_->{classe} ;

	    $compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href3 . '"><span class=headerspan style="width: 100%; font-size: larger;">
Classe ' . $_->{classe} . '
</span><div class=spacer></div></a></div></li>' ;



	    $classe = $_->{classe} ;

	} #    for ( @$compte_set ) 

	#lien vers le contenu du compte
	my $compte_href = '/'.$r->pnotes('session')->{racine}.'/compte?numero_compte=' . URI::Escape::uri_escape_utf8( $_->{numero_compte} ) . '&amp;libelle_compte=' . URI::Escape::uri_escape_utf8( $_->{libelle_compte} ) ;
	
	#ligne du compte
	$compte_list .= '<li class=listitem><div class=container style="margin-left: 1ch;"><div class=spacer></div><a href="' . $compte_href . '"><span class=blockspan>
<span class=blockspan style="width: 15ch;">' . $_->{numero_compte} . '</span>
<span class=blockspan style="width: 80ch;">' . $_->{libelle_compte} . '</span>
</span></a><div class=spacer></div></div></li>' ;

    } #    for ( @$compte_set ) {

   $content .= '<div class="wrapper-compte" ><ul class=wrapper>' . $compte_list . '</ul></div>' ;
    
    return $content ;

} #sub liste_des_comptes 

sub balance {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content, $varbalance ) ;
    my $date = localtime->strftime('%d/%m/%Y');

    #Récupérations des informations de la société
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, adresse_1, code_postal, ville, journal_tva FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    
#####################################       
# Manipulation des dates			#
#####################################  

	#en 1ère arrivée, balance = 0; mettre la date du jour par défaut ou date de fin d'exercice
    if ( $args->{balance} eq '0' || (!defined $args->{balance}) || not($args->{balance} =~ /^(?<year>[0-9]{4})-(?<month>[0-9]{2})-(?<day>[0-9]{2})$/ )) {
	my $date_1 = localtime->strftime('%Y-%m-%d');
	my $date_2 = $r->pnotes('session')->{Exercice_fin_YMD} ;
	if ($date_1 gt $date_2) {$args->{balance} = $date_2;} else {$args->{balance} = $date_1;}
    } 
    
    ##Mise en forme de la date dans $args->{balance} de %Y-%m-%d vers 2000-02-29
	my $date_balance_select = eval {Time::Piece->strptime($args->{balance}, "%Y-%m-%d")->dmy("/")};

    #on affiche un message d'erreur si la date fournie est incompréhensible
    if ( $@ ) {
	if ( $@ =~ /type date/ ) {
	    $content = '<h3 class=warning>Mauvaise date : ' . $args->{balance} . '</h3>' ;
	} elsif  ( $@ =~ /parsing time/ ) {
	    $content = '<h3 class=warning>Mauvaise date : ' . $args->{balance} . '</h3>' ;
	} else {
	    $content = '<h3 class=warning>' . $@ . '</h3>' ;
	}
    }
    
#####################################       
# Préparation à l'impression		#
#####################################   
	#Titre impression de la balance
    if (defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq 1) {
	$varbalance = 'de clôture';
	} else {
	$varbalance = 'générale';
	}

	#en tête impression
	$content .= '
		<div class="printable">
		<div style="float: left ">
		<address><strong>'.$parametre_set->[0]->{etablissement} . '</strong><br>
		' . ($parametre_set->[0]->{adresse_1} || '') . ' <br> ' . ($parametre_set->[0]->{code_postal} || '') . ' ' . ($parametre_set->[0]->{ville} || '') .'<br>
		SIRET : ' . $parametre_set->[0]->{siret}. '<br>
		</address></div>
		<div style="float: right; text-align: right;">
		Imprimé le ' . $date . '<br>
		<div>
		Exercice du '.$r->pnotes('session')->{Exercice_debut_DMY}.' 
		</div>
		au '.$r->pnotes('session')->{Exercice_fin_DMY}.'<br>
		</div>
		<div style="width: 100%; text-align: center;"><h1>Balance '.$varbalance.' au '.($date_balance_select ||'').'</h1>
		<div style="font-size: 9pt;">
		Etat exprimé en Euros</div>
		</div></div>' ;

    #les 5 premiers paramètres dont on a besoin pour la fonction calcul_balance dans postgresql
    #sont placés tout de suite dans @bind_array; le 6ème paramètre (le format désiré pour les chiffres
    #selon qu'on affiche le résultat à l'écran ou qu'on l'écrit dans un fichier à télécharger)
    #est ajouté plus bas
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{balance}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;

    #if $args->{download} est présent, l'utilisateur a cliqué sur le lien de téléchargement
    if ( defined $args->{download} ) {

	#il faut passer par $1 pour untainter les paramètres
	#ces derniers sont ordonnés comme @bind_array

	#$args->{balance} a été accepté par postgresql en entrée de procédure
	#laquelle efface le lien de téléchargement en cas de date non valide
	#on peut donc prendre le paramètre tel quel, on sait qu'il est bon
	#il serait souhaitable de l'ajouter au chemin vers le fichier à télécharger
	#mais les différents formats de date possibles rendent le chemin trop aléatoire
	$args->{balance} =~ /(.*)/ ;
	
	my $param_2 = $1 ;

	$r->pnotes('session')->{id_client} =~ /(\d+)/ ;

	my $param_0 = $1 ;

	my $param_3 = $1 ;
	
	$r->pnotes('session')->{fiscal_year} =~ /(\d\d\d\d)/ ;

	my $param_1 = $1 ;

	my $param_4 = $1 ;

	#le format que doit utiliser postgres pour afficher les nombres
	#on ne met pas de séparateur de milliers pour ne pas affoler les tableurs
	#on utilise le séparateur décimal local (D); on force l'affichage sur deux décimales et du premier zéro (0D00)
	#on supprime les éléments vides du formatage (FM)
	my $param_5 = 'FM999999999990D00' ;

	#le fichier csv à générer
	#il faut faire un untaint du suffixe de session
	substr($r->pnotes('session')->{_session_id}, 0, 10) =~ /(.*)/ ;
	
	my $file_name = 'balance_' . $1 . '.csv' ;
	    
	my $location = '/Compta/base/downloads/' . $file_name ;

	my $file_path = $r->document_root() . $location ;

	#les colonnes de calculs cumulés par classe présentes dans calcul_balance() ne sont pas incluses
	#il faut ajouter les quotes autour de $param_2 et $param_5 pour éviter une erreur de type
	$sql = qq{\\copy (select numero_compte, libelle_compte, debit, credit, solde_debit, solde_credit from calcul_balance($param_0, $param_1, '$param_2', $param_3, $param_4, '$param_5')) to '$file_path' with csv header delimiter ';'} ;

	#nécessaire pour éviter l'erreur Insecure $ENV{PATH} while running with -T switch
	$ENV{'PATH'} = '/bin:/usr/bin' ;
	
	my $db_name = $r->dir_config('db_name') ;
	my $db_host = $r->dir_config('db_host') ;
    my $db_user = $r->dir_config('db_user') ;
    my $db_mdp = $r->dir_config('db_mdp') ;

	system ("PGPASSWORD=\"$db_mdp\" psql -h \"$db_host\" -U \"$db_user\" -d \"$db_name\" -c \"$sql\"") == 0 or die "Bad copy: $?";

	#
	#add BOM
	#
	
	my @args = ( 'sed', '-i', '1s/^/\xef\xbb\xbf/', $r->document_root() . $location) ;

	system( @args ) == 0 or die "Bad BOM: $?";
	
	return $location ;

    } else { #	demande d'affichage de la balance		

	my $download_href = $r->uri . '?balance=' . $args->{balance} . '&download=0' ;
	my $balance_cloture_href = $r->uri . '?balance=' . $args->{balance} . '&affichagecloture=1' ;

	my $download_link = '<a class=nav href="' . $download_href . '" style="margin-left: 2ch;" title="Télécharger la balance générale au ' . $args->{balance} . '" id="download_balance_link">Télécharger</a>' ;
	my $print_link ='<a class="btn btn-success nav" href="#" style="margin-left: 2ch;" onClick="window.print();return false" >Print</a>' ;
	my $balance_cloture_link = '<a href="' . $balance_cloture_href . '" style="margin-left: 2ch;" title="Balance de clôture">balance de clôture</a>' ;

	#fonction javascript qui efface le lien de téléchargement si l'utilisateur modifie la date
	#ce dernier doit alors cliquer sur 'Valider' pour que le lien réapparaisse avec la nouvelle date
	# + document.getElementById => affichage des options via le bouton
	$content .= '
	    <script>
	function hide_download_balance_link() {document.getElementById("download_balance_link").style.visibility = "hidden";}
	function showButtons() {
	document.getElementById("ecriture_cloture").style.display = "inline";
	document.getElementById("ecriture_cloture_label").style.display = "inline";
	}
	</script>' ;
	
	my $checked = ( defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq '1' ) ? 'checked' : '' ;
	
	#titre
	$content .= '
	<div class=titre-non-printable>
	<form action="/'.$r->pnotes('session')->{racine}.'/compte">
	<label style="font-weight: normal; text-align: right;" for="balance">Balance générale au </label>
	<input style ="width : 18ch; margin-right: 1.5ch;" type="date" name=balance id=balance value="' . $args->{balance} . '" oninput="hide_download_balance_link()" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')">
	<input type=hidden name="racine" id="racine" value="' . $r->pnotes('session')->{racine} . '">
	</td><input type=submit value=Valider>
	<input type=button value="Options..." style="" onclick="showButtons();">
	<input style="vertical-align: middle !important; margin-left: 2ch;" type="checkbox" id="ecriture_cloture" name="ecriture_cloture" title="Tenir compte des écritures de clôture" value="1" '.$checked.'>
	<label style="font-weight: normal; text-align: right;" for="ecriture_cloture" id="ecriture_cloture_label">Tenir compte des écritures de clôture</label>
	<td style="margin-left: 2ch;">' . $download_link . $print_link .'
	</form></div>' ;
	
	#en-têtes
	my $compte_list .= '<li class="style1"><h4>
<span class=displayspan style="width: 55%;">&nbsp;</span>
<span class=displayspan style="width: 11%; text-align: right;">Sommes</span>
<span class=displayspan style="width: 11%; text-align: right;">&nbsp;</span>
<span class=displayspan style="width: 11%; text-align: right;">Soldes</span>
<span class=displayspan style="width: 11%; text-align: right;">&nbsp;</span>
</h4></li>' ;

	$compte_list .= '<li class="style1">
<span class=displayspan style="width: 55%;">&nbsp;</span>
<span class=displayspan style="width: 11%; text-align: right;">Débit</span>
<span class=displayspan style="width: 11%; text-align: right;">Crédit</span>
<span class=displayspan style="width: 11%; text-align: right;">Débit</span>
<span class=displayspan style="width: 11%; text-align: right;">Crédit</span>
</li>' ;

	#liste des comptes avec les calculs de soldes
	#il faut ajouter le format que l'on souhaite pour l'affichage web à @bind_array
	push @bind_array, 'FM999G999G999G990D00' ;
	
	if (defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq 1) {
	$sql = 'select * from calcul_balance_cloture(?, ?, ?, ?, ?, ?) WHERE solde_debit NOT SIMILAR TO \'0,00\' OR solde_credit NOT SIMILAR TO \'0,00\' OR debit NOT SIMILAR TO \'0,00\' OR credit NOT SIMILAR TO \'0,00\'';
	} else {
	$sql = 'select * from calcul_balance(?, ?, ?, ?, ?, ?) WHERE solde_debit NOT SIMILAR TO \'0,00\' OR solde_credit NOT SIMILAR TO \'0,00\' OR debit NOT SIMILAR TO \'0,00\' OR credit NOT SIMILAR TO \'0,00\'';
	}
	
	my $compte_set ;

	#à ce stade, la date de calcul de la balance a été formatée en iso
	eval { $compte_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) } ;
	
	if ( $@ ) {
	    if ( $@ =~ / date/ ) {
		#erreur de date; dans ce cas, ne pas afficher le lien de téléchargement
		$content .= '<h3 class=warning>Date non valide : ' . $args->{balance}. '</h3><script>document.getElementById("download_balance_link").style.visibility = "hidden";</script>' ;
	    } else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
	    }
	} #    if ( $@ ) 
	
	# définition des variables
	my ( $classe, $classe_solde_line, $tot_classe_6, $tot_classe_7, $tot_perte_129, $tot_gain_119)  = ( '', '' ) ;
	
	#$content .= '<pre>' . Data::Dumper::Dumper($compte_set) . '</pre></div>' ;

	for ( @$compte_set ) {
	    
	    #afficher la classe si on change de classe
	    unless ( $_->{classe} eq $classe ) {

		$compte_list .= $classe_solde_line ;

		if ($_->{classe} eq 1) {
		$compte_list .= '<li class="style1"><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&classe='.$_->{classe}.'"><span class=headerspan style="width: 100%; font-size: larger;">CLASSE 1 - COMPTES DE CAPITAUX</span></a></li>' ;
		} elsif ($_->{classe} eq 2) {
		$compte_list .= '<li class="style1"><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&classe='.$_->{classe}.'"><span class=headerspan style="width: 100%; font-size: larger;">CLASSE 2 - COMPTES D\'IMMOBILISATIONS</span></a></li>' ;
		} elsif ($_->{classe} eq 4) {
		$compte_list .= '<li class="style1"><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&classe='.$_->{classe}.'"><span class=headerspan style="width: 100%; font-size: larger;">CLASSE 4 - COMPTES DE TIERS</span></a></li>' ;
		} elsif ($_->{classe} eq 5) {
		$compte_list .= '<li class="style1"><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&classe='.$_->{classe}.'"><span class=headerspan style="width: 100%; font-size: larger;">CLASSE 5 - COMPTES FINANCIERS</span></a></li>' ;
		} elsif ($_->{classe} eq 6) {
		$compte_list .= '<li class="style1"><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&classe='.$_->{classe}.'"><span class=headerspan style="width: 100%; font-size: larger;">CLASSE 6 - COMPTES DE CHARGES</span></a></li>' ;
		} elsif ($_->{classe} eq 7) {
		$compte_list .= '<li class="style1"><a href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&classe='.$_->{classe}.'"><span class=headerspan style="width: 100%; font-size: larger;">CLASSE 7 - COMPTES DE PRODUITS</span></a></li>' ;
		} 
			
		$classe = $_->{classe} ;

	    }

	    #lien vers le contenu du compte
	    my $compte_href = '/'.$r->pnotes('session')->{racine}.'/compte?numero_compte=' . URI::Escape::uri_escape_utf8( $_->{numero_compte} ) . '&amp;libelle_compte=' . URI::Escape::uri_escape_utf8( $_->{libelle_compte} ) ;

	    #ligne du compte
	    $compte_list .= '<li class=listitem><a href="' . $compte_href . '">
		<span class=blockspan style="width: 10%;">' . $_->{numero_compte} . '</span>
		<span class=blockspan style="width: 45%;">' . $_->{libelle_compte} . '</span>
		<span class=blockspan style="width: 11%; text-align: right;">' . $_->{debit} . '</span>
		<span class=blockspan style="width: 11%; text-align: right;">' . $_->{credit} . '</span>
		<span class=blockspan style="width: 11%; text-align: right;">' . $_->{solde_debit} . '</span>
		<span class=blockspan style="width: 11%; text-align: right;">' . $_->{solde_credit} . '</span>
		</a></li>' ;
		
		# remplacer résultat à 0 par un espace
		if ($_->{classe_total_credit_solde_dif} eq '0,00') {
		$_->{classe_total_credit_solde_dif} = '&nbsp' ;	
		}
		
		if ($_->{classe_total_debit_solde_dif} eq '0,00') {
		$_->{classe_total_debit_solde_dif} = '&nbsp' ;	
		}
		
############# DEBUG##########
		#my $num1 = $_->{classe_total_credit_solde_dif} ;
		#$content .= '<pre>' . $num1 . '</pre></div>';
############# DEBUG##########
        
        # Calcul du solde des comptes de classe
        my $classe_solde_debit_solde = '' ;
		my $classe_solde_credit_solde = '';
		(my $classe_total_debit_solde = $_->{classe_total_debit_solde}) =~ s/[^a-zA-Z0-9]//g;
		(my $classe_total_credit_solde = $_->{classe_total_credit_solde}) =~ s/[^a-zA-Z0-9]//g;
		my $classe_solde_debit_temp = $classe_total_debit_solde - $classe_total_credit_solde;
		my $classe_solde_credit_temp = $classe_total_credit_solde - $classe_total_debit_solde ;
		
		# Mise en forme des résultats
		if ($classe_solde_debit_temp > $classe_solde_credit_temp) {
		($classe_solde_debit_solde = sprintf( "%.2f",$classe_solde_debit_temp/100)) =~ s/\./\,/g;
		$classe_solde_debit_solde =~ s/\B(?=(...)*$)/ /g ;
		$classe_solde_credit_solde = '&nbsp' ;
		} 
		if ($classe_solde_debit_temp < $classe_solde_credit_temp){
		($classe_solde_credit_solde = sprintf( "%.2f",$classe_solde_credit_temp/100)) =~ s/\./\,/g ;
		$classe_solde_credit_solde =~ s/\B(?=(...)*$)/ /g ;
		$classe_solde_debit_solde = '&nbsp' ;
		}
		
		# passage des résultats aux variables
		if ( $_->{classe} =~ /6/) { 
		($tot_classe_6 = $classe_solde_debit_solde) =~ s/[^a-zA-Z0-9]//g;
		}
		
		if ( $_->{classe} =~ /7/) { 
		($tot_classe_7 = $classe_solde_credit_solde) =~ s/[^a-zA-Z0-9]//g;
		}
		
		# récupération du solde des comptes de cloture
		if (substr( $_->{numero_compte}, 0, 3 ) =~ /129/ ) {
		$tot_perte_129 = $_->{solde_debit} ;
		} 
		
		if ((substr( $_->{numero_compte}, 0, 3 ) =~ /119/) ) {
		$tot_gain_119 = $_->{solde_credit} ;
		} 
		
		#affichage Total classe
	    $classe_solde_line = '<li class="submit_balance style1">
		<span class=displayspan style="width: 55%; text-align: right;">Total classe ' . $_->{classe} . '</span>
		<span class=displayspan style="width: 11%; text-align: right;">' .  $_->{classe_total_debit} . '</span>
		<span class=displayspan style="width: 11%; text-align: right;">' .  $_->{classe_total_credit}. '</span>
		<span class=displayspan style="width: 11%; text-align: right;">' . $_->{classe_total_debit_solde_dif} . '</span>
		<span class=displayspan style="width: 11%; text-align: right;">' . $_->{classe_total_credit_solde_dif} . '</span>
		</li>' ;
		
	} #    for ( @$compte_set ) {

	#ajouter la dernière ligne des sous-totaux par classe
	$compte_list .= $classe_solde_line ;

	#affichage Total Balance
	my $grand_total_line = '
	<li class="style1"><span class=displayspan style="width: 100%;">&nbsp;</span></li><li class="style1">
	<span class=displayspan style="width: 55%; text-align: right; font-weight:bold;">Total Balance&nbsp;</span>
	<span class=displayspan style="width: 11%; text-align: right; font-weight:bold;">' . ( $compte_set->[0]->{grand_total_debit} || 0 ) . '</span>
	<span class=displayspan style="width: 11%; text-align: right; font-weight:bold;">' . ( $compte_set->[0]->{grand_total_credit} || 0 ) . '</span>
	<span class=displayspan style="width: 11%; text-align: right; font-weight:bold;">' . ( $compte_set->[0]->{grand_total_debit_solde} || 0 ) . '</span>
	<span class=displayspan style="width: 11%; text-align: right; font-weight:bold;">' . ( $compte_set->[0]->{grand_total_credit_solde} || 0 ) . '</span>
	</li><li class="style1"><span class=displayspan style="width: 100%;">&nbsp;</span></li>
	' ;

	# si $@ est défini, la requête a échoué, il n'y a pas de grand total à afficher
	$compte_list .= $grand_total_line unless ( $@ ) ;
	
	#Calcul du résultat comptable
	my ($total_pain_gain, $colour_resultat_N, $desc_resultat);
	
	$total_pain_gain = ( $tot_classe_7 || 0) - ($tot_classe_6 || 0);
	$total_pain_gain = sprintf( "%.2f",$total_pain_gain/100) ;
	
	if (defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq 1) {
		if (defined $tot_perte_129 && ($tot_perte_129 =~/\d/) && $tot_perte_129 ne '0,00') {
		$total_pain_gain = $tot_perte_129 ;
		$colour_resultat_N = 'color: red;';
		$desc_resultat = 'Perte de ';
		} else {
			if (defined $tot_gain_119 && ($tot_gain_119 =~/\d/) && $tot_gain_119 ne '0,00') {
			$total_pain_gain = $tot_gain_119 ;	 
			$colour_resultat_N = 'color: green;';
			$desc_resultat = 'Bénéfice de ';
			} else {
			
			if ($total_pain_gain > 0) {
			$colour_resultat_N = 'color: green;';
			$desc_resultat = 'Bénéfice de ';
			} 
			elsif ($total_pain_gain < 0) {
			$total_pain_gain = $total_pain_gain * -1;	
			$colour_resultat_N = 'color: red;';
			$desc_resultat = 'Perte de ';
			} 
			
			}
		}	
	} else {
	
	if ($total_pain_gain > 0) {
	$colour_resultat_N = 'color: green;';
	$desc_resultat = 'Bénéfice de ';
	} 
	elsif ($total_pain_gain < 0) {
	$total_pain_gain = $total_pain_gain * -1;	
	$colour_resultat_N = 'color: red;';
	$desc_resultat = 'Perte de ';
	} 
	
	}
	
	$total_pain_gain =~ s/\./\,/g ;
	$total_pain_gain =~ s/\B(?=(...)*$)/ /g ;
	

	my $style_resultat2 = '<span>' . $total_pain_gain . ' Euros</span></span>';
	my $style_resultat3 = ( defined $colour_resultat_N && defined $desc_resultat ) ? '<span style="'. $colour_resultat_N .'">'. $desc_resultat .' ' . $total_pain_gain . ' Euros</span></span>' : $style_resultat2 ;

	#affichage du résultat comptable
	my $perte_gain_provisoire  = '<li class="style1" style="font-weight:bold; ">
	<span class=displayspan style="width: 100%; text-align: left; background-color:#ddefef;">Résultat au '.($date_balance_select || '').' : 
	'.$style_resultat3.'
	</li>' ;

	$compte_list .= $perte_gain_provisoire unless ( $@ ) ;

	$content .= '<div class="wrapper-balance"><ul class=wrapper>' . $compte_list . '</ul></div>' ;

	return $content ;
    } #    if ( defined $args->{download} ) 
    
} #sub balance

sub grandlivre {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array ) ;
    my $date = localtime->strftime('%d/%m/%Y');
	my $content ;
	
	#Récupérations des informations de la société
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, adresse_1, code_postal, ville, journal_tva FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
	  
#####################################       
# Manipulation des dates			#
#####################################  

	#en 1ère arrivée, balance = 0; mettre la date du jour par défaut ou date de fin d'exercice
    if ( $args->{grandlivre} eq '0' || (!defined $args->{grandlivre}) || not($args->{grandlivre} =~ /^(?<year>[0-9]{4})-(?<month>[0-9]{2})-(?<day>[0-9]{2})$/ )) {
	my $date_1 = localtime->strftime('%Y-%m-%d');
	my $date_2 = $r->pnotes('session')->{Exercice_fin_YMD} ;
	if ($date_1 gt $date_2) {$args->{grandlivre} = $date_2;} else {$args->{grandlivre} = $date_1;}
    } 
    
    ##Mise en forme de la date dans $args->{balance} de %Y-%m-%d vers 2000-02-29
	my $date_grandlivre_select = eval {Time::Piece->strptime($args->{grandlivre}, "%Y-%m-%d")->dmy("/")};

    #on affiche un message d'erreur si la date fournie est incompréhensible
    if ( $@ ) {
	if ( $@ =~ /type date/ ) {
	    $content = '<h3 class=warning>Mauvaise date : ' . $args->{grandlivre} . '</h3>' ;
	} elsif  ( $@ =~ /parsing time/ ) {
	    $content = '<h3 class=warning>Mauvaise date : ' . $args->{grandlivre} . '</h3>' ;
	} else {
	    $content = '<h3 class=warning>' . $@ . '</h3>' ;
	}
    }
    
#####################################       
# Préparation à l'impression		#
##################################### 

	my $printer = '
		<div class="printable">
		<div style="float: left ">
		<address><strong>'.$parametre_set->[0]->{etablissement} . '</strong><br>
		' . ($parametre_set->[0]->{adresse_1} || '') . ' <br> ' . ($parametre_set->[0]->{code_postal} || '') . ' ' . ($parametre_set->[0]->{ville} || '') .'<br>
		SIRET : ' . $parametre_set->[0]->{siret} . '<br>
		</address></div>
		<div style="float: right; text-align: right;">
		Imprimé le ' . $date . '<br>
		<div>
		Exercice du '.$r->pnotes('session')->{Exercice_debut_DMY}.' 
		</div>
		au '.$r->pnotes('session')->{Exercice_fin_DMY}.'<br>
		</div>
		<div style="width: 100%; text-align: center;"><h1>Grand livre au '.($date_grandlivre_select|| '').'</h1>
		<div >
		Etat exprimé en Euros</div>
		</div></div>' ;

	$content .= $printer;

    #les 5 premiers paramètres dont on a besoin pour la fonction calcul_balance dans postgresql
    #sont placés tout de suite dans @bind_array; le 6ème paramètre (le format désiré pour les chiffres
    #selon qu'on affiche le résultat à l'écran ou qu'on l'écrit dans un fichier à télécharger)
    #est ajouté plus bas
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{grandlivre}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	
	#fonction javascript qui efface le lien de téléchargement si l'utilisateur modifie la date
	#ce dernier doit alors cliquer sur 'Valider' pour que le lien réapparaisse avec la nouvelle date
	$content .= '
	<script>
	    function showButtons() {
	document.getElementById("ecriture_cloture").style.display = "inline";
	document.getElementById("ecriture_cloture_label").style.display = "inline";
	}
	</script>' ;
	
	#gestion des options
	my $checked = ( defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq '1' ) ? 'checked' : '' ;
	
	#gestion des filtres classe
	my $var_input_classe = ( defined $args->{classe} ) ? '<input class="inputtest" type=hidden name=classe id=classe value="' . $args->{classe} . '">' : '' ;
	my $bdd_filter_classe = ( defined $args->{classe} ) ? 'classe = \''.$args->{classe}.'\' AND (' : '' ;
	my $bdd_filter_classe_end = ( defined $args->{classe} ) ? ')' : '' ;
	
	#formulaire date + options
	$content .= '
	<form action="/'.$r->pnotes('session')->{racine}.'/compte">
	<div  class=titre-non-printable>
	<label style="font-weight: normal; text-align: right;" for="grandlivre">Grand livre au</label>
	<input type="date" name=grandlivre id=grandlivre value="' . $args->{grandlivre} . '" style="width: 18ch; margin-right: 1.5ch;"  onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required >
	<input type=hidden name="racine" id="racine" value="' . $r->pnotes('session')->{racine} . '">
	<input type=submit value=Valider>
	'.$var_input_classe.'
	<input type=button value="Options..." style="" onclick="showButtons();">
	<input style="vertical-align: middle !important; margin-left: 2ch;" type="checkbox" id="ecriture_cloture" name="ecriture_cloture" title="Tenir compte des écritures de clôture" value="1" '.$checked.'>
	<label style="font-weight: normal; text-align: right;" for="ecriture_cloture" id="ecriture_cloture_label">Tenir compte des écritures de clôture</label>
	</div></form>' ;
	
	################ Affichage MENU ################
    $content .= display_classe_compte( $r, $args ) ;
	################ Affichage MENU ################

	#liste des comptes avec les calculs de soldes
	#il faut ajouter le format que l'on souhaite pour l'affichage web à @bind_array
	push @bind_array, 'FM999G999G999G990D00' ;
	
	#
	if (defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq 1) {
	$sql = 'select * from calcul_balance_cloture(?, ?, ?, ?, ?, ?) WHERE '.$bdd_filter_classe.' solde_debit NOT SIMILAR TO \'0,00\' OR solde_credit NOT SIMILAR TO \'0,00\' OR debit NOT SIMILAR TO \'0,00\' OR credit NOT SIMILAR TO \'0,00\''.$bdd_filter_classe_end.'';
	} else {
	$sql = 'select * from calcul_balance(?, ?, ?, ?, ?, ?) WHERE '.$bdd_filter_classe.' solde_debit NOT SIMILAR TO \'0,00\' OR solde_credit NOT SIMILAR TO \'0,00\' OR debit NOT SIMILAR TO \'0,00\' OR credit NOT SIMILAR TO \'0,00\''.$bdd_filter_classe_end.'';
	}
	
	my $compte_set ;

	#à ce stade, la date de calcul de la balance a été formatée en iso
	eval { $compte_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) } ;
	
	if ( $@ ) {
	    if ( $@ =~ / date/ ) {
		#erreur de date; dans ce cas, ne pas afficher le lien de téléchargement
		$content .= '<h3 class=warning>Date non valide : ' . $args->{grandlivre}. '</h3>' ;
	    } else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
	    }
	} #    if ( $@ ) 

	#définition des variables
	my ( $filter_classe_dest, $compte_list, $classe, $numero_compte, $classe_solde_line, $tot_classe_6, $tot_classe_7, $tot_perte_129, $tot_gain_119, $classe_compte_line)  = ( '', '' ) ;

	#########################################	
	#compte_set - Début						#
	#########################################	

	for ( @$compte_set ) {

	#appliquer le filtre => Classe
    my ($filter_classe_dest) = (  defined $args->{classe} ) ? ' AND substring(numero_compte from 1 for 1) = ?' : '' ;
    #appliquer le filtre => ecriture de clôture
	my $display_ecriture_cloture = ( defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq '1' ) ? '' : 'AND libelle_journal NOT LIKE \'%CLOTURE%\'' ;
    
	my $sql = '
	SELECT t2.date_validation, t1.id_entry, t1.id_export, coalesce(t1.num_mouvement, \'&nbsp;\') as num_mouvement, t1.date_ecriture,  t1.libelle_journal, t1.numero_compte, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit, to_char((sum(credit-debit) over(PARTITION BY numero_compte ORDER BY date_ecriture, id_line))/100::numeric, \'999G999G999G990D00\') as solde, lettrage, pointage
	FROM tbljournal t1
	LEFT JOIN tblexport t2 on t1.id_client = t2.id_client and t1.fiscal_year = t2.fiscal_year and t1.id_export = t2.id_export
	WHERE t1.id_client = ? AND t1.fiscal_year = ? AND numero_compte = ? AND date_ecriture <= ? '.$display_ecriture_cloture.' 
	ORDER BY numero_compte, date_ecriture, id_facture, libelle, id_line
	' ;	  
	
		my $classe_href = '/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0&amp;classe=' . $_->{classe} ;
		
		#entête $compte_colonne
		my $compte_colonne = '
			<li class=headerspan2><div class=spacer></div>
			<span class=headerspan style="width: 3%;">#</span>
			<span class=headerspan style="width: 8%;">Date</span>
			<span class=headerspan style="width: 6.5%;">Journal</span>
			<span class=headerspan style="width: 5%;">Libre</span>
			<span class=headerspan style="width: 5%;">Compte</span>
			<span class=headerspan style="width: 11%;">Pièce</span>
			<span class=headerspan style="width: 28%;">Libellé</span>
			<span class=headerspan style="width: 8.5%; text-align: right;">Débit</span>
			<span class=headerspan style="width: 8.5%; text-align: right;">Crédit</span>
			<span class=headerspan style="width: 8.5%; text-align: right;">Solde</span>
			<span class=headerspan style="width: 0.5%; text-align: center;">&nbsp;</span>
			<span class=headerspan style="width: 1.2%; text-align: center;">&nbsp;</span>
			<span class=headerspan style="width: 1.2%; text-align: center;">&nbsp;</span>
			<span class=headerspan style="width: 2.7%; text-align: center;">L</span>
			<span class=headerspan style="width: 1.2%; text-align: center;">P</span>
			<span class=headerspan style="width: 1.2%; text-align: center;">V</span>
			<div class=spacer></div></li>
			' ;
	
	    #lien vers le contenu du compte
	    my $compte_href = '/'.$r->pnotes('session')->{racine}.'/compte?classe='. $_->{classe} . '&amp;numero_compte=' . URI::Escape::uri_escape_utf8( $_->{numero_compte} ) . '&amp;libelle_compte=' . URI::Escape::uri_escape_utf8( $_->{libelle_compte} ) ;
		
		#colonne total compte
		my $totalcompte_colonne = '
		<li class="totalcompte listitem"><div class=spacer></div>
		<span class=blockspan style="width: 66.5%;text-align: left;">Total Compte ' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</span>
		<a href="' . $compte_href . '">
		<span class=blockspan style="width: 8.5%; text-align: right;">' . $_->{debit} . '</span>
		<span class=blockspan style="width: 8.5%; text-align: right;">' . $_->{credit} . '</span>
		</a><div class=flex-table>
		<span class=blockspan style="width: 66.5%;text-align: right;">Solde</span>
		<span class=blockspan style="width: 8.5%; text-align: right;">' . $_->{solde_debit} . '</span>
		<span class=blockspan style="width: 8.5%; text-align: right;">' . $_->{solde_credit} . '</span>
		<div class=spacer></div></li>' ;
		
		#entête libellé colonne
		my $libcompte_colonne = '<li class="compte listitem"><div class=flex-table><div class=spacer></div><a href="' . $compte_href . '">
	  	<span class=blockspan style="width: 66.5%;">Compte ' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</span>
	  	<span class=blockspan style="width: 33%;">&nbsp;</span>
	  	</a><div class=spacer></div></div></li>' ;

		unless (defined $classe && $_->{classe} eq $classe)  {
			
		if ( defined $classe_solde_line ) {
			$compte_list .= $classe_solde_line ;
			}	
		
		if ($_->{classe} eq 1) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 1 - COMPTES DE CAPITAUX</span></a><div class=spacer></div></div></li>' ;
		} elsif ($_->{classe} eq 2) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 2 - COMPTES D\'IMMOBILISATIONS</span></a><div class=spacer></div></div></li>' ;	
		} elsif ($_->{classe} eq 3) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 3 - COMPTES DE STOCKS</span></a><div class=spacer></div></div></li>' ;	
		} elsif ($_->{classe} eq 4) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 4 - COMPTES DE TIERS</span></a><div class=spacer></div></div></li>' ;	
		} elsif ($_->{classe} eq 5) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 5 - COMPTES FINANCIERS</span></a><div class=spacer></div></div></li>' ;		
		} elsif ($_->{classe} eq 6) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 6 - COMPTES DE CHARGES</span></a><div class=spacer></div></div></li>' ;		
		} elsif ($_->{classe} eq 7) {
		$compte_list .= '<li class="style1"><div class=flex-table><div class=spacer></div><a href="' . $classe_href . '"><span class=classenum>CLASSE 7 - COMPTES DE PRODUITS</span></a><div class=spacer></div></div></li>' ;		
		}
		
		$compte_list .= $compte_colonne ;
	    } 

	    #afficher le numero de compte si on change de compte
	    unless ( defined $numero_compte && $_->{numero_compte} eq $numero_compte ) {
		#lien vers le contenu du compte
	    $compte_list .= $libcompte_colonne;
		$numero_compte = $_->{numero_compte} ;
	    } #    for ( @$numero_compte_set ) 
	    
		$classe = $_->{classe} ;

	
#########################################		    
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $numero_compte , $args->{grandlivre}) ;	
   	my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;	
	my $detail_list = '';
	
	for ( @$result_set ) {
	my $http_link_documents1 = '';
	my $http_link_documents2 = '';
	my $http_link_ecriture_valide = '<img class="redimmage nav" title="Validée le '. (defined $_->{date_validation}).'" style="border: 0;" src="/Compta/images/cadena.png" alt="valide">' ;
	
	my $ecriture_validee = (defined $_->{date_validation} eq '') ? '' : '<img class="redimmage nav" title="Validée le '. $_->{date_validation}.'" src="/Compta/images/cadena.png" alt="valide">';
	
	
	if ( $_->{documents1} =~ /docx|odt|pdf|jpg/) { 
    my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
    my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents1} ) ;
		if ($id_name_documents->[0]->{id_name} || '') {
		$http_link_documents1 ='<a class=nav style="margin-left: 0ch;" href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img style="border: 0;" src="/Compta/images/documents.png" class=redimmage alt="documents"></a>' ;
		} else {
		$http_link_documents1 ='<a class=nav style="margin-left: 0ch;" href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
		} 
	} 	
	if ( $_->{documents2} =~ /docx|odt|pdf|jpg/) { 
	my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
    my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents2} ) ;
    	if ($id_name_documents->[0]->{id_name} || '') {
		$http_link_documents2 ='<a class=nav style="margin-left: 0ch;" href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img style="border: 0;" src="/Compta/images/releve-bancaire.png" class=redimmage alt="releve-bancaire"></a>' ;	
		} else {
		$http_link_documents2 ='<a class=nav style="margin-left: 0ch;" href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
		} 
	}
		
	#lien vers le formulaire d'édition de l'entrée considérée
	my $journal_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . URI::Escape::uri_escape_utf8( $_->{id_entry} ) ;
	my $pointage_value = ( $_->{pointage} eq 't' ) ? '<img class="redimmage nav" title="Check complet" src="/Compta/images/icone-valider.png" alt="valide">' : '' ;
	
	$compte_list .= '
<li class="displayspan2 listitem"><div class=flex-table><div class=spacer></div><a href="' . $journal_href . '">
<span class=blockspan style="width: 3%;">' . $_->{num_mouvement} . '</span>
<span class=blockspan style="width: 8%;">' . $_->{date_ecriture} . '</span>
<span class=blockspan style="width: 6.5%;">' . $_->{libelle_journal} .'</span>
<span class=blockspan style="width: 5%;">' . $_->{id_paiement} .'</span>
<span class=blockspan style="width: 5%;">' . $_->{numero_compte} . '</span>
</a>
<span class=blockspan style="width: 11%;">' . $_->{id_facture} . '</span>
<a href="' . $journal_href . '">
<span class=blockspan style="width: 28%;">' . $_->{libelle} . '</span>
<span class=blockspan style="width: 8.5%; text-align: right;">' . $_->{debit} . '</span>
<span class=blockspan style="width: 8.5%; text-align: right;">' .  $_->{credit} . '</span>
<span class=blockspan style="width: 8.5%; text-align: right;">' .  $_->{solde} . '</span>
</a>
<span class=blockspan style="width: 0.5%; text-align: center;">&nbsp;</span>
<span class=blockspan style="width: 1.2%; text-align: center;">' . ($http_link_documents1 || '&nbsp;' ). '</span>
<span class=blockspan style="width: 1.2%; text-align: center;">' . ($http_link_documents2 || '&nbsp;' ). '</span>
<span class=blockspan style="width: 2.7%; text-align: center;">' .( $_->{lettrage} || '&nbsp;' ) . '</span>
<span class=blockspan style="width: 1.2%; text-align: center;">' .( $pointage_value || '&nbsp;' ). '</span>
<span class=blockspan style="width: 1.2%; text-align: center;">' .( $ecriture_validee || '&nbsp;' ). '</span>
<div class=spacer></div></div></li>' ;
    } #    for ( @$result_set ) 
		
		# remplacer résultat à 0 par un espace
		if ($_->{classe_total_credit_solde_dif} eq '0,00') {
		$_->{classe_total_credit_solde_dif} = '&nbsp' ;	
		}
		
		if ($_->{classe_total_debit_solde_dif} eq '0,00') {
		$_->{classe_total_debit_solde_dif} = '&nbsp' ;	
		}

        # Calcul du solde des comptes de classe
        my $classe_solde_debit_solde = '' ;
		my $classe_solde_credit_solde = '';
		(my $classe_total_debit_solde = $_->{classe_total_debit_solde}) =~ s/[^a-zA-Z0-9]//g;
		(my $classe_total_credit_solde = $_->{classe_total_credit_solde}) =~ s/[^a-zA-Z0-9]//g;
		my $classe_solde_debit_temp = $classe_total_debit_solde - $classe_total_credit_solde;
		my $classe_solde_credit_temp = $classe_total_credit_solde - $classe_total_debit_solde ;
		
		# Mise en forme des résultats
		if ($classe_solde_debit_temp > $classe_solde_credit_temp) {
		($classe_solde_debit_solde = sprintf( "%.2f",$classe_solde_debit_temp/100)) =~ s/\./\,/g;
		$classe_solde_debit_solde =~ s/\B(?=(...)*$)/ /g ;
		$classe_solde_credit_solde = '&nbsp' ;
		} 
		if ($classe_solde_debit_temp < $classe_solde_credit_temp){
		($classe_solde_credit_solde = sprintf( "%.2f",$classe_solde_credit_temp/100)) =~ s/\./\,/g ;
		$classe_solde_credit_solde =~ s/\B(?=(...)*$)/ /g ;
		$classe_solde_debit_solde = '&nbsp' ;
		}
		
		if (not(substr( $_->{numero_compte}, 0, 3 ) =~ /129|119/) ) {
		# passage des résultats aux variables
		if ( $_->{classe} =~ /6/) { 
		($tot_classe_6 = $classe_solde_debit_solde) =~ s/[^a-zA-Z0-9]//g;
		}
		
		if ( $_->{classe} =~ /7/) { 
		($tot_classe_7 = $classe_solde_credit_solde) =~ s/[^a-zA-Z0-9]//g;
		}
		
		}
		
		# récupération du solde des comptes de cloture
		if (substr( $_->{numero_compte}, 0, 3 ) =~ /129/ ) {
		$tot_perte_129 = $_->{solde_debit} ;
		} 
		
		if (substr( $_->{numero_compte}, 0, 3 ) =~ /119/ ) {
		$tot_gain_119 = $_->{solde_credit} ;
		} 
		
		$compte_list .= $totalcompte_colonne;

  		$classe_solde_line = '<li class=submit2><div class=spacer></div>
		<span class=displayspan style="width: 66.5%;">Total classe ' . $_->{classe} . '</span>
		<span class=displayspan style="width: 8.5%; text-align: right;">' .  $_->{classe_total_debit} . '</span>
		<span class=displayspan style="width: 8.5%; text-align: right;">' .  $_->{classe_total_credit}. '</span>
		<div class=spacer></div>
		<span class=displayspan style="width: 66.5%; text-align: right;">Solde</span>
		<span class=displayspan style="width: 8.5%; text-align: right;">' . $_->{classe_total_debit_solde_dif} . '</span>
		<span class=displayspan style="width: 8.5%; text-align: right;">' . $_->{classe_total_credit_solde_dif} . '</span>
		<div class=spacer></div></li>
		' ;
		
	} #    for ( @$compte_set ) {
	
	if (defined $classe_solde_line) {
	$compte_list .= $classe_solde_line ;
	}
	
	my $grand_total_line ;

	if (defined $compte_set->[0]->{grand_total_debit} != 0 || defined $compte_set->[0]->{grand_total_credit} != 0 ||
	defined $compte_set->[0]->{grand_total_debit_solde} != 0 || defined $compte_set->[0]->{grand_total_credit_solde} != 0 ){
		
	#grand_total
	my $grand_total_line = '<li class="style1">
<span class=displayspan style="width: 66.5%; text-align: right; color: black; font-weight: bold; ">Total Balance</span>
<span class=displayspan style="width: 8.5%; text-align: right; color: black; font-weight: bold;">' . ( $compte_set->[0]->{grand_total_debit} || 0 ) . '</span>
<span class=displayspan style="width: 8.5%; text-align: right; color: black; font-weight: bold;">' . ( $compte_set->[0]->{grand_total_credit} || 0 ) . '</span>
<span class=displayspan style="width: 15.4%;">&nbsp;</span>
<div class=spacer></div>
<span class=displayspan style="width: 66.5%; text-align: right; color: black; font-weight: bold; ">Solde Balance</span>
<span class=displayspan style="width: 8.5%; text-align: right; color: black; font-weight: bold;">' . ( $compte_set->[0]->{grand_total_debit_solde} || 0 ) . '</span>
<span class=displayspan style="width: 8.5%; text-align: right; color: black; font-weight: bold;">' . ( $compte_set->[0]->{grand_total_credit_solde} || 0 ) . '</span>
<span class=displayspan style="width: 15.4%;">&nbsp;</span>
<div class=spacer></div></li><li class="style1"><span class=displayspan style="width: 100%;">&nbsp;</span></li>' ;


	if (not(defined $args->{classe} && $args->{classe} =~ /1|2|3|4|5|6|7/)) {
		
	
	#Calcul du résultat comptable
	my ($total_pain_gain, $colour_resultat_N, $desc_resultat);
	
	$total_pain_gain = ( $tot_classe_7 || 0) - ($tot_classe_6 || 0);
	$total_pain_gain = sprintf( "%.2f",$total_pain_gain/100) ;
	
	if (defined $args->{ecriture_cloture} && $args->{ecriture_cloture} eq 1) {
		if (defined $tot_perte_129 && ($tot_perte_129 =~/\d/) && $tot_perte_129 ne '0,00') {
		$total_pain_gain = $tot_perte_129 ;
		$colour_resultat_N = 'color: red;';
		$desc_resultat = 'Perte de ';
		} else {
			if (defined $tot_gain_119 && ($tot_gain_119 =~/\d/) && $tot_gain_119 ne '0,00') {
			$total_pain_gain = $tot_gain_119 ;	 
			$colour_resultat_N = 'color: green;';
			$desc_resultat = 'Bénéfice de ';
			} else {
			
			if ($total_pain_gain > 0) {
			$colour_resultat_N = 'color: green;';
			$desc_resultat = 'Bénéfice de ';
			} 
			elsif ($total_pain_gain < 0) {
			$total_pain_gain = $total_pain_gain * -1;	
			$colour_resultat_N = 'color: red;';
			$desc_resultat = 'Perte de ';
			} 
			
			}
		}	
	} else {
	
	if ($total_pain_gain > 0) {
	$colour_resultat_N = 'color: green;';
	$desc_resultat = 'Bénéfice de ';
	} 
	elsif ($total_pain_gain < 0) {
	$total_pain_gain = $total_pain_gain * -1;	
	$colour_resultat_N = 'color: red;';
	$desc_resultat = 'Perte de ';
	} 
	
	}
	
	$total_pain_gain =~ s/\./\,/g ;
	$total_pain_gain =~ s/\B(?=(...)*$)/ /g ;
	

	#affichage du résultat comptable
	my $perte_gain_provisoire  = '<li class="style1" style="font-weight:bold; ">
	<span class=displayspan style="width: 100%; text-align: left; background-color:#ddefef;">Résultat comptable au '.$date_grandlivre_select.': 
	<span style="'.($colour_resultat_N || '').'">'.($desc_resultat|| '').' ' . ($total_pain_gain || 0) . ' Euros</span></span>
	</li>' ;
	
	# si $@ est défini, la requête a échoué, il n'y a pas de grand total à afficher
	$compte_list .= $grand_total_line unless ( $@ ) ;
	$compte_list .= $perte_gain_provisoire unless ( $@ ) ;	
	}
	
	}
	
	unless ($compte_list ) {
	    $content .= '<div class=warning><h3>Aucune information à afficher ...</h3>
					<ul>
					<li>Ajouter des journaux</li>
					<li>Ajouter des comptes</li>
					<li>Ajouter des écritures</li>
					</ul>
					<p>Veuillez vérifier la liste des comptes
					</div>
					' ;

	} else {
		$content .= '<div class="wrapper"><ul class="wrapper style1">' . $compte_list . '</ul></div>' ;
	}
	 
	return $content ;

} #sub grandlivre

#/*—————————————— Menu des classes ——————————————*/
sub display_classe_compte {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    
    unless ( defined $args->{classe}) {
	    $args->{classe} = '' ;
    } 	
    
    unless ( defined $args->{grandlivre}) {
	    $args->{grandlivre} = 0 ;
    } 
    
    unless ( defined $args->{ecriture_cloture}) {
	    $args->{ecriture_cloture} = 0 ;
    } 
    

    

#########################################	
#définition des liens					#
#########################################			
	#lien des classes 
	my $print_link ='<a class="btn btn-success nav" href="#" style="margin-left: 3ch;" onClick="window.print();return false" >Print</a>' ;
	my $classeall_link = '<a class=' . ( ($args->{grandlivre} =~ /0/ && $args->{classe} eq '' ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">ALL</a>' ;
    my $classe1_link = '<a class=' . ( ($args->{classe} =~ /1/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;classe=1&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">Classe 1</a>' ;
    my $classe2_link = '<a class=' . ( ($args->{classe} =~ /2/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;classe=2&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">Classe 2</a>' ;
    my $classe4_link = '<a class=' . ( ($args->{classe} =~ /4/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;classe=4&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">Classe 4</a>' ;
    my $classe5_link = '<a class=' . ( ($args->{classe} =~ /5/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;classe=5&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">Classe 5</a>' ;
    my $classe6_link = '<a class=' . ( ($args->{classe} =~ /6/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;classe=6&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">Classe 6</a>' ;
    my $classe7_link = '<a class=' . ( ($args->{classe} =~ /7/ ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre='.$args->{grandlivre}.'&amp;classe=7&amp;ecriture_cloture='.$args->{ecriture_cloture}.'" style="margin-left: 3ch;">Classe 7</a>' ;

#########################################	
#génération du menu						#
#########################################
	my $content .= '<div class="menu">' . $classeall_link . $classe1_link . $classe2_link . $classe4_link . $classe5_link . $classe6_link . $classe7_link . $print_link . '</div>' ;
    
    return $content ;

} #sub display_classe_compte 

#/*—————————————— Menu des comptes ——————————————*/
sub display_menu_compte {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my $content;
    
    
#########################################	
#définition des liens					#
#########################################				

    my $edit_list_href = '/'.$r->pnotes('session')->{racine}.'/compte?edit_compte_set=0' ;
    my $grand_livre_href = '/'.$r->pnotes('session')->{racine}.'/compte?numero_compte=0' ;
    my $cloture_href = '/'.$r->pnotes('session')->{racine}.'/compte?cloture=0' ;
    my $reports_href = '/'.$r->pnotes('session')->{racine}.'/compte?reports=0' ;
    
    my $edit_list_link = '<a class=nav href="' . $edit_list_href . '" style="margin-left: 3ch;">Modifier&nbsp;la&nbsp;liste</a>' ;
    my $grand_livre_link = '<a class=nav href="' . $grand_livre_href. '" style="margin-left: 3ch;">Grand&nbsp;Livre</a>' ;
    my $cloture_link = '<a class=nav href="' . $cloture_href. '" style="margin-left: 3ch;">Clôture</a>' ;
    my $reports_link = '<a class=nav href="' . $reports_href. '" style="margin-left: 3ch;">Reports</a>' ;

#########################################	
#génération du menu						#
#########################################
    
    if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {	
	$content .= '<div class="menu">' . $edit_list_link . $grand_livre_link . $reports_link . $cloture_link .'</div>' ;
	} else {
	$content .= '<div class="menu">' . $grand_livre_link .'</div>' ;	
	}
    
    
    return $content ;

} #sub display_menu_compte 


1 ;
