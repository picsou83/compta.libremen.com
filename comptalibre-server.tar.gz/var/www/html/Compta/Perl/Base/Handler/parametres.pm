package Base::Handler::parametres;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Modifié par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version initiale - Aôut 2016
#-----------------------------------------------------------------------------------------
#	Copyright ou © ou Copr.
#	Vincent Veyron - Aôut 2016 (https://github.com/picsou83)
#	vincent.veyron@libremen.org
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Time::Piece;
use utf8 ;
use Apache2::Const -compile => qw( OK REDIRECT ) ;
use Apache2::Upload;
use File::Path ;
use Fcntl qw< LOCK_EX SEEK_END >;

sub handler {

	binmode(STDOUT, ":utf8") ;
    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content = '' ;
    my $req = Apache2::Request->new($r, MAX_BODY => "1000000000M") ;
    #récupérer les arguments
    my ( %args, @args, $sql, @bind_values ) ;
    #recherche des paramètres de la requête
    @args = $req->param ;

    for (@args) {
	$args{$_} = Encode::decode_utf8( $req->param($_) ) ;
	#nix those sql injection/htmlcode attacks!
	$args{$_} =~ tr/<>;/-/ ;
	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;
    }
    
    if ( defined $args{bt_remove} and $args{bt_remove} eq '1' ) {
		
		my $repertoire = $r->document_root() . '/Compta/base/backup/' ;
		my $sauvegarde_file = $repertoire . $args{name_fichier} ;
	    #suppression du fichier
	    unlink $sauvegarde_file ;
		
		my $location = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde' ;
		
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'parametres.pm => Suppression du fichier '.$args{name_fichier}.'');
		
		$r->headers_out->set(Location => $location) ;
		return Apache2::Const::REDIRECT 
		}
		
	if ( defined $args{bt_download} and $args{bt_download} eq '1' and defined $args{name_fichier} ) {
			my $location = '/Compta/base/backup/' . $args{name_fichier} ;
			my $export_file =  $r->document_root() . $location;

		#adresse du fichier précédemment généré
		$r->headers_out->set(Location => $location) ;
		
		#rediriger le navigateur vers le fichier
		$r->status(Apache2::Const::REDIRECT) ;
		
		return Apache2::Const::REDIRECT ;
			
		}
		
	if ( defined $args{bt_backup_perl} and  $args{bt_backup_perl} eq '1' ) {
		
			my $date = localtime->strftime('%d_%m_%Y-%Hh%M'); 
			$content .= '<h3 class=warning>Sauvegarde en cours merci de patienter .........</h3>' ;
			#system "tar czfP \"/var/www/html/Compta/base/backup/backup_appli.$date.tar.gz\"  --exclude=/var/www/html/Compta/base/backup /var/www/html/Compta/ &"; 
			system "tar cvzpf \"/var/www/html/Compta/base/backup/backup_appli.$date.tar.gz\"  --exclude=/var/www/html/Compta/base/backup /var/www/html/Compta/ &"; 
		
		
			if ( $? == 0 ) {
			sleep 2;
			my $location = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde' ;
			$r->headers_out->set(Location => $location) ;
			return Apache2::Const::REDIRECT 
			}
		}	
		
	if ( defined $args{purge} and $args{purge} eq '1' ) {
		
		my $fichier = $r->document_root() . '/Compta/base/logs/Compta.log' ;

	    #purge du fichier de log
	    open (my $fh, ">:encoding(UTF-8)", $fichier) or die "Impossible d'ouvrir le fichier $fichier : $!" ;
	    close ($fh);

		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'parametres.pm => Purge du fichier de log');
		
		my $location = '/'.$r->pnotes('session')->{racine}.'/parametres?logs' ;
		
		
		
		$r->headers_out->set(Location => $location) ;
		return Apache2::Const::REDIRECT 
		}
		
		
		
		
		
#####################################       
#l'utilisateur a envoyé un nouveau fichier de dump à enregistrer
#####################################   
if ( defined $args{bt_add} and $args{bt_add} eq '1' and defined $args{bt_name_file} and not($args{bt_name_file} eq '')) {

		#file handle du document uploadé
		my $upload = $req->upload("bt_name_file") or warn $! ;
		my $upload_fh = $upload->fh() ;

	    my $repertoire = $r->document_root() . '/Compta/base/backup/' ;
	    chdir $repertoire ;
		my $sauvegarde_file = $repertoire . $args{bt_name_file} ;

    
	    open (my $fh, ">", $sauvegarde_file) or die "Impossible d'ouvrir le fichier $sauvegarde_file : $!" ;
	    
	    close ($fh);

	    #récupération des données du fichier
	    while ( my $data = <$upload_fh> ) {
		print $fh $data ;
	    }

	    close $fh ;

	    #l'enregistrement s'est bien passé, on peut retourner à la liste des documents
	    undef $args{bt_add} ;

    } #	if ( defined $args{bt_add} and $args{bt_add} eq '1'  )
    
    
    
    unless (not( $r->pnotes('session')->{username} eq 'superadmin' )) {
		
		if ( defined $args{societes} ) {

	    $content = societes( $r, \%args ) ;

		} elsif ( defined $args{sauvegarde}) {

			$content = sauvegarde( $r, \%args ) ;

		} elsif ( defined $args{utilisateurs}) {

			$content = utilisateurs( $r, \%args ) ;
		
		} elsif ( defined $args{achats}) {

			$content = form_edit_achats( $r, \%args ) ;
		
		} elsif ( defined $args{loyer}) {

			$content = form_edit_loyer( $r, \%args ) ;
		
		} elsif ( defined $args{recurrent}) {

			$content = form_edit_recurrent( $r, \%args ) ;
		
		} elsif ( defined $args{logs}) {

			$content = logs( $r, \%args ) ;
		
		} elsif ( defined $args{logout}) {

			$content = logout( $r, \%args ) ;
		
		} else {
			$content = societes( $r, \%args ) ;
		}

	} else {
		
		if (not(defined $args{logout})){
		$content = '<div class=warning><h3>Vous n\'êtes pas autorisé à afficher cette page </h3></div>' ;
		} else {
		$content = logout( $r, \%args ) ;	
		}
	
	}
     

    $r->no_cache(1) ;
    $r->content_type('text/html; charset=utf-8') ;
    print $content ;
    return Apache2::Const::OK ;
}

sub sauvegarde {
	
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
    
    my $db_name = $r->dir_config('db_name') ;
	my $db_host = $r->dir_config('db_host') ;
    my $db_user = $r->dir_config('db_user') ;
    my $db_mdp = $r->dir_config('db_mdp') ;

	######## Affichage MENU display_menu Début ######
	   $content .= display_menu( $r, $args ) ;
	######## Affichage MENU display_menu Fin ########

		if ( defined $args->{bt_backup} and  $args->{bt_backup} eq '1' ) {
			
			
			my $date = localtime->strftime('%d_%m_%Y-%Hh%M'); 
			# sauvegarde  bdd format dump
			system "PGPASSWORD=\"$db_mdp\" pg_dump -h \"$db_host\" -U \"$db_user\" -Fc -b -v \"$db_name\" -f \"/var/www/html/Compta/base/backup/backup_database.$date.dump\" 2>&1"; 
			# sauvegarde  bdd format sql
			#system "PGPASSWORD=\"$db_mdp\" pg_dump -h \"$db_host\" -O -x -U \"$db_user\" --format=plain -b -v \"$db_name\" -f \"/var/www/html/Compta/base/backup/backup_database.$date.sql\" 2>&1"; 

			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'parametres.pm => Sauvegarde de la base donnée via pg_dump (backup_database.'.$date.'.dump)');
		
		}
		
		
		if ( defined $args->{bt_restore} and  $args->{bt_restore} eq '1' ) {
			my $location = '/Compta/base/backup/' . $args->{name_fichier} ;
			my $export_file =  $r->document_root() . $location;
			# restauration 
			system "PGPASSWORD=\"compta\" pg_restore -c -h \"$db_host\" -U \"$db_user\" -d \"$db_name\" \"$export_file\" "; 

			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'parametres.pm => Restauration de '.$args->{name_fichier}.' via pg_restore');
		
		}
		
		if ( defined $args->{bt_restore_perl} and  $args->{bt_restore_perl} eq '1' ) {
			
		
		my $keep_newer_files = ( defined $args->{recent} and $args->{recent} eq '1' ) ? '--keep-newer-files' : '' ;
			
			my $location = '/Compta/base/backup/' . $args->{name_fichier} ;
			my $export_file =  $r->document_root() . $location;
			# restauration 
			#system "sudo tar xfP \"$export_file\" --keep-newer-files -C &" ; 
			
			if (defined $args->{del} and $args->{del} eq '1'){
			rmtree "/var/www/html/Compta/base/documents/";
			rmtree "/var/www/html/Compta/base/downloads/";

			}
			
			my $rc = system("tar xfP \"$export_file\" $keep_newer_files -C / 2>&1");

			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'parametres.pm => Restauration de '.$args->{name_fichier}.' via tar (keep_newer_files = '.$args->{recent}.';del = '.$args->{del}.')');


		}
		

		#première demande de suppression d'une sauvegarde; réclamer confirmation
		if ( defined $args->{bt_remove} and $args->{bt_remove} eq '0' and defined $args->{name_fichier} ) {
		    my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde=&amp;bt_remove=1&amp;name_fichier=' . $args->{name_fichier} . '' ;
		    my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde' ;
		    my $message = ( 'Vraiment supprimer la sauvegarde ' . $args->{name_fichier} .' ?') . '<a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		    $content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . $message . '</h3>' ;
		} 
		
		#première demande de restauration d'une sauvegarde; réclamer confirmation
		if ( defined $args->{bt_restore} and $args->{bt_restore} eq '0' and defined $args->{name_fichier} ) {
		    my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde=&amp;bt_restore=1&amp;name_fichier=' . $args->{name_fichier} . '' ;
		    my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde' ;
		    my $message = ( 'Vraiment restaurer la sauvegarde ' . $args->{name_fichier} .' ?') . '<a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
			$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . $message . '</h3>' ;
		} 
		
		#première demande de restauration d'une sauvegarde; réclamer confirmation
		if ( defined $args->{bt_restore_perl} and $args->{bt_restore_perl} eq '0' and defined $args->{name_fichier} ) {
		    my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde=&amp;bt_restore_perl=1&amp;name_fichier=' . $args->{name_fichier} . '&amp;recent=' . ($args->{recent} || '0') . '&amp;del=' . ($args->{del} || '0') . '' ;
		    my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde' ;
		    my $message = ( 'Vraiment restaurer la sauvegarde ' . $args->{name_fichier} .' ?') . '<a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		    $content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . $message . '</h3>' ;
		} 
		
	    my $repertoire = $r->document_root() . '/Compta/base/backup/' ;
	    chdir $repertoire ;
	    unless ( -d $repertoire ) {
		mkpath $repertoire or die "can't do mkpath : $!" ;
	    }

		opendir (my $rep_fh, $repertoire) or die "impossible d'ouvrir le repertoire $repertoire\n";
		my @file_rep = grep { !/^\.\.?$/ } readdir($rep_fh);
		closedir ($rep_fh);
 
		my $nom_fichier .= '<select class="login-text" name=name_fichier id=name_fichier>' ;
		my $nom_fichier_perl .= '<select  class="login-text" name=name_fichier id=name_fichier_perl>' ;

		foreach my $nom (@file_rep) {
		if ( -f "$repertoire/$nom" and $nom =~ /\.dump$/i) {
		$nom_fichier .= '<option value="' . $nom . '">' . $nom . '</option>' ; 
		} elsif ( -f "$repertoire/$nom" and $nom =~ /\.gz$/i) {
		$nom_fichier_perl .= '<option value="' . $nom . '">' . $nom . '</option>' ;
		}
		}
		$nom_fichier .= '</select>' ;
		$nom_fichier_perl .= '</select>' ;
 
		my $contenu_web .= '
		<fieldset><legend><h3 style="color: green; background-color: #ddefef;">Gestion des sauvegardes</h3></legend>
		<div class="centrer">
		
			<div class=Titre10>Sauvegarde & restauration database</div>
			<div class="form-int">
				<form action=/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde>
				<br>
				<input type=hidden name=sauvegarde value=>
				<input type=hidden name=bt_backup value=1>
				<button style ="width : 25%;" class="btnform1 vert">Lancer une sauvegarde</button>
				</form>
				<br><hr><br>
				<form method="post">
				<label class="forms" for="name_fichier">Sauvegardes disponibles</label>
				'.$nom_fichier.'
				<br><br>
				<input type="submit" class="btnform1 vert" style ="width : 25%;" formaction="parametres&#63;sauvegarde=&amp;bt_download=1" value="Télécharger la sauvegarde">
				<input type="submit" class="btnform1 orange" style ="width : 25%;"  formaction="parametres&#63;sauvegarde=&amp;bt_restore=0" value="Restaurer la sauvegarde">
				<input type="submit" class="btnform1 rouge" style ="width : 25%;" formaction="parametres&#63;sauvegarde=&amp;bt_remove=0" value="Supprimer la sauvegarde">
				</form>

			</div>
		
		
			<div class=Titre10>Sauvegarde & restauration appli</div>
			<div class="form-int">
				<form action=/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde>
				<br>
				<input type=hidden name=sauvegarde value=>
				<input type=hidden name=bt_backup_perl value=1>
				<button class="btnform1 vert" style ="width : 25%;">Lancer une sauvegarde</button>
				</form>
				<br><hr><br>
				<form style ="display:inline;" method="post">
				<label class="forms" style ="width : 39%;" for="name_fichier_perl">Sauvegardes disponibles</label>
				'.$nom_fichier_perl.'
				<label class="forms" style ="width : 74%;" for="del">Supprimer les données avant restauration ?</label><input type="checkbox" style ="width : 25%;" id="del" name="del" value=1>
				<label class="forms" style ="width : 74%;" for="recent">Ne pas écraser les fichiers existants plus récents ou de même date</label><input type="checkbox" style ="width : 25%;" id="recent" name="recent" checked value=1>
				<br><br>
				<input type="submit" class="btnform1 vert" style ="width : 25%;" formaction="parametres&#63;sauvegarde=&amp;bt_download=1" value="Télécharger la sauvegarde">
				<input type="submit" class="btnform1 orange" style ="width : 25%;" formaction="parametres&#63;sauvegarde=&amp;bt_restore_perl=0" value="Restaurer la sauvegarde">
				<input type="submit" class="btnform1 rouge" style ="width : 25%;" formaction="parametres&#63;sauvegarde=&amp;bt_remove=0" value="Supprimer la sauvegarde">
				</form>
			</div>
	   
			<div class=Titre10>Ajouter un fichier</div>
			<div class="form-int">
				<form style ="display:inline;" action=/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde method=POST enctype="multipart/form-data">
				<input type=file name=bt_name_file>
				<br><br>
				<input type=hidden name=sauvegarde value=>
				<input type=hidden name=bt_add value=1>
				<input type="submit" class="btnform1 gris" style ="width : 25%;" value="Ajouter le fichier">
				</form>
			</div>
	   
	   </div></fieldset>

		';
		$content .= '<div class="formulaire1">' . $contenu_web . '</div>' ;
		
    return $content ;
    
} #sub sauvegarde 

sub societes {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, $option_set, @bind_array, $content ) ;
    
	######## Affichage MENU display_menu Début ######
	   $content .= display_menu( $r, $args ) ;
	######## Affichage MENU display_menu Fin ########
	
	
    $args->{societes} ||= 0 ;
    
    $sql = 'SELECT etablissement, id_client FROM compta_client WHERE id_client = ?' ;
    my $societe_get = $dbh->selectall_arrayref( $sql, { Slice => { } }, $args->{id_client} ) ;
    
	#1ère demande de suppression; afficher lien d'annulation/confirmation
	if ( defined $args->{supprimer_societe} && $args->{supprimer_societe} eq '0' ) {
	my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?societe=0&amp;id_client=' . $args->{id_client} ;
	my $oui_href = '/'.$r->pnotes('session')->{racine}.'/parametres?societe=0&amp;supprimer_societe=1&amp;id_client=' . $args->{id_client} ;
	$content .= '<h3 class=warning>Vraiment supprimer la société : '.$societe_get->[0]->{id_client}.' - ' . $societe_get->[0]->{etablissement} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;
	 }
	 
	#2emes demande de suppression; afficher lien d'annulation/confirmation
	if ( defined $args->{supprimer_societe} && $args->{supprimer_societe} eq '1' ) {
	my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?societe=0&amp;id_client=' . $args->{id_client} ;
	my $oui_ofcourse_href = '/'.$r->pnotes('session')->{racine}.'/parametres?societe=0&amp;supprimer_societe_ofcourse=1&amp;id_client=' . $args->{id_client} ;
	$content .= '<h3 class=warning>êtes-vous sûr et certain de vouloir supprimer la société : '.$societe_get->[0]->{id_client}.' - ' . $societe_get->[0]->{etablissement} . '?<a href="' . $non_href . '" style="margin-left: 3ch;">Non</a><a href="' . $oui_ofcourse_href . '" style="margin-left: 3ch;">Oui</a></h3>' ;
	}
	
	if ( defined $args->{creation} && $args->{creation} eq '1' ) {
		
	$sql = 'INSERT INTO compta_client (id_client, etablissement, siret, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, id_tva_regime, adresse_1, code_postal, ville, date_debut, date_fin, type_compta)
	VALUES (nextval(\'compta_client_id_client_seq\'), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning id_client';
	my $sth = $dbh->prepare($sql) ;
	my @bind_array = ( $args->{etablissement}, $args->{siret}, $args->{padding_zeroes}, $args->{fiscal_year_start}, $args->{id_tva_periode} || undef, $args->{id_tva_option} || undef, $args->{id_tva_regime} || undef, $args->{adresse_1} || undef, $args->{code_postal} || undef, $args->{ville} || undef, $args->{date_debut} || undef, $args->{date_fin} || undef, $args->{typecompta} || undef) ;

	my $next_id_client ;
	eval { $next_id_client = $dbh->selectall_arrayref( $sql, undef, ( @bind_array ) )->[0]->[0] } ;
		
	if ( $@ ) {

			if ( $@ =~ /journal_tva/ ) {

			$content .= '<h3 class=warning>Il faut créer au moins un journal. Vous pouvez reconduire les journaux de l\'année précédente dans Journaux -> Modifier la liste</h3>' ;

			} else {

			$content .= '<h3 class=warning>' . $@ . '</h3>' ;

			} #		if ( $@ =~ /journal_tva/ ) 
			
		} 	
		
		#ajouter la catégorie Temp dans documents
		my $var_cat_doc = 'Temp';
	    $sql = 'INSERT INTO tbldocuments_categorie (libelle_cat_doc, id_client) values (?, ?)' ;
	    @bind_array = ( $var_cat_doc, $next_id_client ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;	
	    $var_cat_doc = 'Inter-exercice';
	    $sql = 'INSERT INTO tbldocuments_categorie (libelle_cat_doc, id_client) values (?, ?)' ;
	    @bind_array = ( $var_cat_doc, $next_id_client ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
	    #ajouter les journaux par défault dans journal
	    #BQ BANQUE Trésorerie
	    #CL CLOTURE Clôture
	    #OD OD OD
	    #AC ACHATS Achat
	    #VE VENTES Ventes
	    #AN A NOUVEAUX A-nouveaux
	    #$sql = 'INSERT INTO tbljournal_liste (id_client, code_journal, libelle_journal, fiscal_year, type_journal) values (?, ?, ?, ?, ?)' ;
	    #@bind_array = ( $next_id_client, $var_cat_doc,  ) ;
	    #eval {$dbh->do( $sql, undef, @bind_array ) } ;	
	    
	    
	    
	    

		
    } #    if ( $args->{creation} eq '1' ) 
    
    
    
    #l'utilisateur a cliqué sur le bouton 'Supprimer', supprimer l'enregistrement
    if ( defined $args->{supprimer_societe_ofcourse} && $args->{supprimer_societe_ofcourse} eq '1' ) {
	my $nb_societe_count = '';	
	#on vérifie combien il y a de société dans la base
	$sql = 'SELECT count(id_client) FROM compta_client';

	eval { $nb_societe_count = $dbh->selectall_arrayref( $sql, undef, () )->[0]->[0] } ;
	
	if ($nb_societe_count == '1') {
		$content .= '<h3 class="warning centrer">Attention : il n\'existe qu\'une société dans la base, impossible de la supprimer</h3>' ;
	} else {
		$sql = 'SELECT delete_account_data (?)' ;

	    @bind_array = ( $args->{id_client} ) ;
	    eval { $dbh->do( $sql, undef, @bind_array ) } ;
	    if ( $@ ) {
		if ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
		    $content .= '<h3 class=warning>Le compte n\'est pas vide : suppression impossible </h3>' ;
		    } else {
		    $content .= '<h3 class=warning>' . $@ . '</h3>' ;
	}	
	}}}
    
  
    #l'utilisateur a cliqué sur le bouton 'Valider', enregistrer les modifications
    if ( $args->{societes} eq '1' ) {

	$sql = 'UPDATE compta_client set etablissement = ?, siret = ?, padding_zeroes = ?, fiscal_year_start = ?, date_debut = ?, date_fin = ?, adresse_1 = ?, code_postal = ?, ville = ?, journal_tva = ?, id_tva_periode = ?, id_tva_option = ?, id_tva_regime = ?, type_compta = ? WHERE id_client = ? ' ;

	my @bind_array = ( $args->{etablissement}, $args->{siret}, $args->{padding_zeroes}, $args->{fiscal_year_start}, $args->{date_debut} || undef, $args->{date_fin} || undef, $args->{adresse_1} || undef, $args->{code_postal} || undef, $args->{ville} || undef, $args->{journal_tva} || 'OD', $args->{id_tva_periode} || undef, $args->{id_tva_option} || undef, $args->{id_tva_regime} || undef, $args->{typecompta} || undef, $args->{id_client} ) ;

	eval { $dbh->do( $sql, undef, ( @bind_array ) ) } ;

	if ( $@ ) {

	    if ( $@ =~ /journal_tva/ ) {

		$content .= '<h3 class=warning>Il faut créer au moins un journal. Vous pouvez reconduire les journaux de l\'année précédente dans Journaux -> Modifier la liste</h3>' ;

	    } else {

		$content .= '<h3 class=warning>' . $@ . '</h3>' ;

	    } #		if ( $@ =~ /journal_tva/ ) 
	    
	} else {
	    
	    #mettre à jour les paramètres de la session
	    $r->pnotes('session')->{padding_zeroes} = $args->{padding_zeroes} ;
	    $r->pnotes('session')->{Exercice_fin_DMY} = $args->{date_fin} ;
	    $r->pnotes('session')->{Exercice_debut_DMY} = $args->{date_debut} ;
		$r->pnotes('session')->{Exercice_fin_YMD} = Time::Piece->strptime( $args->{date_fin}, "%d/%m/%Y" )->ymd;
		$r->pnotes('session')->{Exercice_debut_YMD} = Time::Piece->strptime( $args->{date_debut}, "%d/%m/%Y" )->ymd;
		$r->pnotes('session')->{Exercice_fin_DMY_N1} = Time::Piece->strptime( $args->{date_fin}, "%d/%m/%Y" )->add_years(-1)->ymd;
	    freeze_session( $r ) ;

	} #	    if ( $@ ) 
    } #    if ( $args->{societes} eq '1' ) 
    
	#
    #sélection des sociétés 
    #
    $sql = 'SELECT etablissement, id_client FROM compta_client' ;
    my $selected = '';
    my $societe_set = $dbh->selectall_arrayref( $sql, { Slice => { } }) ;
    my $societe_select = '<select class="login-text" name=id_client id=id_client>' ;
    for ( @$societe_set ) {
	if 	(defined $args->{id_client}) {
	$selected = ( $_->{id_client} eq $args->{id_client} ) ? 'selected' : '' ;
	} elsif (defined $args->{etablissement}) {
	$selected = ( $_->{etablissement} eq $args->{etablissement} ) ? 'selected' : '' ;
	} else {
	$selected = ( $_->{id_client} eq $r->pnotes('session')->{id_client} ) ? 'selected' : '' ;
	}
	$societe_select .= '<option value="' . $_->{id_client} . '" ' . $selected . '>' . $_->{id_client} . ' - ' . $_->{etablissement} . '</option>' ;
    }
    $societe_select .= '</select>' ;
    

	my $delete_href = 'parametres&#63;societe=0&amp;supprimer_societe=0' ;
	my $valid_href = 'parametres&#63;societe=0&amp;modification_societe=1' ;
	my $new_href = 'parametres&#63;societe=0&amp;creation_societe=1' ;
	my $delete_link = '<input type="submit" class="btnform1 rouge" style ="width : 25%;" formaction="' . $delete_href . '" value="Supprimer" >' ;	
	my $new_link = '<input type="submit" class="btnform1 vert" style ="width : 50%;" formaction="' . $new_href . '" value="Créer une nouvelle société" >' ;

    
    # div.Titre10 + label class="forms" + input class="login-text" + input type=submit class="btnform1 vert"
    
    #
    #construire la table des paramètres
    #
    my $fiche_client .= '

	<fieldset><legend><h3 style="color: green; background-color: #ddefef;">Gestion des sociétés</h3></legend>
    <div class="centrer">
    <div class=Titre10>Ajouter une nouvelle société</div>
     <div class="form-int">
     <form method=POST>
    '.$new_link	.'
    </div>
  
    <div class=Titre10>Modifier une société existante</div>
    <div class="form-int">
    
    
    <input type=hidden name=societe value=0>
    '.$societe_select.'
    <br><br>
    
	<input type=submit class="btnform1 gris" style ="width : 25%;" formaction="' . $valid_href . '" value=Modifier>
	'.$delete_link	.'
	<br><br>
	
	</form></div>
		
	<hr>
	<br>
 
 	';

 	if ((defined $args->{creation_societe}) && ($args->{creation_societe} eq 1)) {
		

		 #formatage des numéros de pièces
		my $padding_zeroes_options = '' ;
		$sql = q { select s.p as value, case when padding_zeroes = s.p then 'selected' else '' end as selected from generate_series(2, 5) s(p), compta_client where id_client = ? } ;
		$option_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
		for ( @$option_set ) {
		my $pattern = '%0' . $_->{value} . 'd' ;
		$padding_zeroes_options .= '<option ' . $_->{selected} . ' value="' . $_->{value} . '">A' . sprintf( $pattern, 1)  . ', A' . sprintf( $pattern, 2)  . '...</option>' ;
		}
		my $padding_zeroes_select = '<select class="login-text" name=padding_zeroes id=padding_zeroes>' . $padding_zeroes_options . '</select>' ;


		#option TVA
		my $id_tva_option_select = '<select class="login-text" name=id_tva_option id=id_tva_option>
		<option value=encaissements>TVA sur les encaissements</option>
		<option value=débits>TVA sur les débits</option>
		</select>
		' ;
		
		#type compta
		my $typecompta = '<select class="login-text" name=typecompta id=typecompta>
		<option value=engagement>Comptabilité d\'engagement</option>
		<option value=tresorerie>Comptabilité de trésorerie</option>
		</select>
		' ;
		
		#régime TVA
		my $id_tva_regime_select = '<select class="login-text" name=id_tva_regime id=id_tva_regime>
		<option value=normal>Réel normal de TVA</option>
		<option value=simplifié>Réel simplifié de TVA</option>
		<option value=franchise>Franchise en base de TVA</option>
		</select>
		' ;
    
		#
		#periode TVA
		#
		my $id_tva_periode_select = '<select class="login-text" name=id_tva_periode id=id_tva_periode>
		<option value=mensuelle>mensuelle</option>
		<option value=trimestrielle>trimestrielle</option>
		</select>
		' ;
		
		#
		#Fiscal year start format :
		#
		my $select_fiscal_year_start = '<select class="login-text" name=fiscal_year_start id=fiscal_year_start>
		<option value="01-01">1er Janvier</option>
		<option value="01-02">1er Février</option>
		<option value="01-03">1er Mars</option>
		<option value="01-04">1er Avril</option>
		<option value="01-05">1er Mai</option>
		<option value="01-06">1er Juin</option>
		<option value="01-07">1er Juillet</option>
		<option value="01-08">1er Août</option>
		<option value="01-09">1er Septembre</option>
		<option value="01-10">1er Octobre</option>
		<option value="01-11">1er Novembre</option>
		<option value="01-12">1er Décembre</option>
		</select>
		' ;
		

		#
		#construire la table des paramètres
		#
		$fiche_client .= '
			<div class=Titre10>Création d\'une nouvelle société</div>
			<div class="form-int">
			<form action=/'.$r->pnotes('session')->{racine}.'/parametres>
			<label class="forms para" for="etablissement">Nom de l\'entreprise :</label><input class="login-text" type=text name=etablissement id=etablissement required/>
			<label class="forms para" for="adresse_1">Adresse :</label><input class="login-text" type=text name=adresse_1  id=adresse_1 />
			<label class="forms para" for="code_postal">Code postal :</label><input class="login-text" type=text name=code_postal id=code_postal />
			<label class="forms para" for="ville">Ville :</label><input class="login-text" type=text name=ville id=ville />
			<label class="forms para" for="siret">Siret :</label><input class="login-text" type=text name=siret id=siret required/>
			<label class="forms para" for="fiscal_year_start">Début d\'exercice :</label>' . $select_fiscal_year_start. '
			<label class="forms para" for="date_debut">Date de début du 1er exercice :</label><input class="login-text" type="text" placeholder="Entrer la date au format jj/mm/aaaa" title="Entrer la date au format jj/mm/aaaa" name=date_debut required="" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})"/>
			<label class="forms para" for="date_fin">Date de fin du 1er exercice :</label><input class="login-text" type="text" placeholder="Entrer la date au format jj/mm/aaaa" title="Entrer la date au format jj/mm/aaaa" name=date_fin required="" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})"/>
			<label class="forms para" for="typecompta">Système comptable :</label>' . $typecompta. '
			<br><label class="forms para" for="submit"></label><input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Valider > <br>		
			</div>
			<div class=Titre10>Divers</div>
			<div class="form-int">
			<br>
			<label class="forms para" for="padding_zeroes">Numérotation des pièces :</label>' . $padding_zeroes_select . '
			<br><label class="forms para" for="submit"></label><input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Valider> <br>		
			</div>
			<div class=Titre10>TVA</div>
			<div class="form-int">
			<br>
			<label class="forms para" for="id_tva_regime">Régime de TVA :</label>' . $id_tva_regime_select . '
			<label class="forms para" for="id_tva_option">TVA collectée :</label>' . $id_tva_option_select . '
			<label class="forms para" for="id_tva_periode">Périodicité de la TVA :</label>' . $id_tva_periode_select . '
			<input type=hidden name=creation value=1>
			<br>
			<label class="forms para" for="submit"></label><input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Valider>
			<br>
			</form></div>
			';	
	}
 	
 	
	if ((defined $args->{modification_societe}) && ($args->{modification_societe} eq 1)) {
	
 	#
    #préparation de la modification de la fiche société
    #
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, id_tva_regime, adresse_1, code_postal, ville, journal_tva, type_compta FROM compta_client WHERE id_client = ?' ;

    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $args->{id_client} ) ) ;
    
    my $var_id_tva_regime = defined $result_set->[0]->{id_tva_regime} && $result_set->[0]->{id_tva_regime} eq 'franchise' ? 'style="display:none;"' : '' ;
    
    #option TVA
    my $id_tva_option_select = '<select class="login-text" name=id_tva_option id=id_tva_option '.$var_id_tva_regime.'>
    <option ' . ( ( defined $result_set->[0]->{id_tva_option} && $result_set->[0]->{id_tva_option} eq 'encaissements' ) ? 'selected' : '' ) . ' value=encaissements>encaissements</option>
    <option ' . ( ( defined $result_set->[0]->{id_tva_option} && $result_set->[0]->{id_tva_option} eq 'débits' ) ? 'selected' : '' ) . ' value=débits>débits</option>
    </select>' ;
    
    #type compta
	my $typecompta = '<select class="login-text" name=typecompta id=typecompta>
	<option ' . ( ( defined $result_set->[0]->{type_compta} && $result_set->[0]->{type_compta} eq 'engagement' ) ? 'selected' : '' ) . ' value=engagement>Comptabilité d\'engagement</option>
    <option ' . ( ( defined $result_set->[0]->{type_compta} && $result_set->[0]->{type_compta} eq 'tresorerie' ) ? 'selected' : '' ) . ' value=tresorerie>Comptabilité de trésorerie</option>
	</select>
	' ;
    
    #régime TVA
	my $id_tva_regime_select = '<select class="login-text" name=id_tva_regime id=id_tva_regime>
	<option ' . ( ( defined $result_set->[0]->{id_tva_regime} && $result_set->[0]->{id_tva_regime} eq 'normal' ) ? 'selected' : '' ) . ' value=normal>Réel normal de TVA</option>
	<option ' . ( ( defined $result_set->[0]->{id_tva_regime} && $result_set->[0]->{id_tva_regime} eq 'simplifié' ) ? 'selected' : '' ) . ' value=simplifié>Réel simplifié de TVA</option>
	<option ' . ( ( defined $result_set->[0]->{id_tva_regime} && $result_set->[0]->{id_tva_regime} eq 'franchise' ) ? 'selected' : '' ) . ' value=franchise>Franchise en base de TVA</option>
	</select>
	' ;
    
    #
    #periode TVA
    #
    my $id_tva_periode_select = '<select class="login-text" name=id_tva_periode id=id_tva_periode '.$var_id_tva_regime.'>
    <option ' . ( ( defined $result_set->[0]->{id_tva_periode} && $result_set->[0]->{id_tva_periode} eq 'mensuelle' ) ? 'selected' : '' ) . ' value=mensuelle>mensuelle</option>
    <option ' . ( ( defined $result_set->[0]->{id_tva_periode} && $result_set->[0]->{id_tva_periode} eq 'trimestrielle' ) ? 'selected' : '' ) . ' value=trimestrielle>trimestrielle</option>
    </select>' ;
    
    	#
		#Début d'exercice :
		#
		my $select_fiscal_year_start = '<select class="login-text" name=fiscal_year_start id=fiscal_year_start>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-01' ) ? 'selected' : '' ) . ' value="01-01">1er Janvier</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-02' ) ? 'selected' : '' ) . ' value="01-02">1er Février</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-03' ) ? 'selected' : '' ) . ' value="01-03">1er Mars</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-04' ) ? 'selected' : '' ) . ' value="01-04">1er Avril</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-05' ) ? 'selected' : '' ) . ' value="01-05">1er Mai</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-06' ) ? 'selected' : '' ) . ' value="01-06">1er Juin</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-07' ) ? 'selected' : '' ) . ' value="01-07">1er Juillet</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-08' ) ? 'selected' : '' ) . ' value="01-08">1er Août</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-09' ) ? 'selected' : '' ) . ' value="01-09">1er Septembre</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-10' ) ? 'selected' : '' ) . ' value="01-10">1er Octobre</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-11' ) ? 'selected' : '' ) . ' value="01-11">1er Novembre</option>
		<option ' . ( ( defined $result_set->[0]->{fiscal_year_start} && $result_set->[0]->{fiscal_year_start} eq '01-12' ) ? 'selected' : '' ) . ' value="01-12">1er Décembre</option>
		</select>
		' ;
    

    for ( @$result_set ) {
		

		
		#formatage des numéros de pièces
		my $padding_zeroes_options = '' ;
		$sql = q { select s.p as value, case when padding_zeroes = s.p then 'selected' else '' end as selected from generate_series(2, 5) s(p), compta_client where id_client = ? } ;
		$option_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $args->{id_client} ) ) ;
		for ( @$option_set ) {
		my $pattern = '%0' . $_->{value} . 'd' ;
		$padding_zeroes_options .= '<option ' . $_->{selected} . ' value="' . $_->{value} . '">A' . sprintf( $pattern, 1)  . ', A' . sprintf( $pattern, 2)  . '...</option>' ;
		}
		my $padding_zeroes_select = '<select class="login-text" name=padding_zeroes id=padding_zeroes>' . $padding_zeroes_options . '</select>' ;


		
		#
		#journal_tva
		#
		$sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
		my @bind_array = ( $args->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
		my $journal_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
		my $journal_tva_select = '<select class="login-text" name=journal_tva id=journal_tva '.$var_id_tva_regime.'>' ;
		for ( @$journal_set ) {
		my $selected = ( $_->[0] eq $result_set->[0]->{journal_tva} ) ? 'selected' : '' ;
		$journal_tva_select .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . '</option>' ;
		}
		$journal_tva_select .= '</select>' ;
		
		my $selected = '';		

				
		
		$fiche_client .= '
		<div class=Titre10>Modification de la société : ' . $_->{etablissement} . '</div>
		<div class="form-int">
        <form action=/'.$r->pnotes('session')->{racine}.'/parametres>
	    <label class="forms para" for="etablissement">Nom de l\'entreprise :</label><input class="login-text" type=text name=etablissement id=etablissement value="' . $_->{etablissement} . '"  required />
		<label class="forms para" for="adresse_1">Adresse :</label><input class="login-text" type=text name=adresse_1 id=adresse_1 value="' . ($_->{adresse_1} || ''). '" />
		<label class="forms para" for="code_postal">Code postal :</label><input class="login-text" type=text name=code_postal id=code_postal value="' . ($_->{code_postal}|| '') . '" />
		<label class="forms para" for="ville">Ville :</label><input class="login-text" type=text name=ville id=ville value="' . ($_->{ville}|| '') . '" />
		<label class="forms para" for="siret">Siret :</label><input class="login-text" type=text name=siret id=siret value="' . ($_->{siret} || ''). '" required />
		<label class="forms para" for="fiscal_year_start">Début d\'exercice :</label>'.$select_fiscal_year_start.'
		<label class="forms para" for="date_debut">Date de début du 1er exercice :</label><input class="login-text" type=text name=date_debut id=date_debut value="' . ($_->{date_debut}|| '') . '" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})"/>
		<label class="forms para" for="date_fin">Date de fin du 1er exercice :</label><input class="login-text" type=text name=date_fin id=date_fin value="' . ($_->{date_fin} || ''). '" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})"/>
		<label class="forms para" for="typecompta">Système comptable :</label>'.$typecompta.'
		<br><label class="forms para" for="submit"></label><input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Valider> <br>		
		
		</div>
		<div class=Titre10>Divers</div>
		<div class="form-int">
		
		<br>
		<label class="forms para" for="padding_zeroes">Numérotation des pièces :</label>' . $padding_zeroes_select . '
		<hr>
		<br><label class="forms para" for="submit"></label><input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Valider> <br>		
		</div>
		<div class=Titre10>TVA</div>
		<div class="form-int">
		<br>
		<label class="forms para" for="id_tva_regime">Régime de TVA :</label>' . $id_tva_regime_select . '
		<label class="forms para" for="id_tva_option" '.$var_id_tva_regime.'>TVA collectée :</label>' . $id_tva_option_select . '
		<label class="forms para" for="id_tva_periode" '.$var_id_tva_regime.'>Périodicité de la TVA :</label>' . $id_tva_periode_select . '
		<label class="forms para" for="padding_zeroes" '.$var_id_tva_regime.'>Journal de TVA :</label>' . $journal_tva_select . '
		<input type=hidden name=societes value=1>
		<input type=hidden name=modification_societe value=1>
		<input type=hidden name=id_client value=' .$args->{id_client}. '>
		<br>
		<label class="forms para" for="submit"></label><input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Valider>
		<br>
   
    	</form></div>
		
		</fieldset>
	
		';
		}
	}
		
		$content .= '<div class="formulaire1" >' . $fiche_client . '</div>' ;

    return $content ;
    
} #sub societes 


#/*—————————————— Page Formulaire modification catégorie de document ——————————————*/
sub form_edit_achats {
	
	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my ( $sql, @bind_array, $content ) ;
		my $categorie_list ;
  
    
	################ Affichage MENU ################
	$content .= display_menu( $r, $args ) ;
	################ Affichage MENU ################
	
	
	#/************ ACTION DEBUT *************/
	
	####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Supprimer' la catégorie		  #
	#######################################################################
    if ( defined $args->{achats} && defined $args->{delete}) {

			#1ère demande de suppression; afficher lien d'annulation/confirmation
			if ( $args->{delete} eq '0' ) {

			my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?achats=0' ;

			my $oui_href = '/'.$r->pnotes('session')->{racine}.'/parametres?achats=0&amp;documents=1&amp;delete=1&amp;libelle=' . $args->{libelle} ;

			$content .= '<h3 class=warning>Vraiment supprimer le mode de paiement ' . $args->{libelle} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;

			} else {

			#demande de suppression confirmée
			$sql = 'DELETE FROM tblconfig_liste WHERE config_libelle = ? AND id_client = ?' ;

			@bind_array = ( $args->{libelle}, $r->pnotes('session')->{id_client} ) ;
			eval {$dbh->do( $sql, undef, @bind_array ) } ;

				if ( $@ ) {
					if ( $@ =~ /NOT NULL/ ) {
					$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
					} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
				} #	if ( $@ ) 
			} #	if ( $args->{delete_doc} eq '0' )

	} #    if ( $args->{delete} ) 
    
    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Ajouter' 					  #
	#######################################################################
    if ( defined $args->{ajouter} && $args->{ajouter} eq '1' ) {
		#on interdit libelle vide
		$args->{libelle} ||= undef ;
	
	    #ajouter une catégorie
	    $sql = 'INSERT INTO tblconfig_liste (config_libelle, config_compte, config_journal, id_client) values (?, ?, ?, ?)' ;
	    @bind_array = ( $args->{libelle}, $args->{select_compte}, $args->{select_journal}, $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>Il faut obligatoirement un libellé</h3>' ;
			} elsif ( $@ =~ /existe/ ) {$content .= '<h3 class=warning>Ce libellé existe déjà</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
    
    ####################################################################### 
	#l'utilisateur a cliqué sur 'Valider' la modification de la catégorie #
	#######################################################################
    if ( defined $args->{modifier} && $args->{modifier} eq '1' ) {
	    
   	    #modifier une catégorie
	    $sql = 'UPDATE tblconfig_liste set config_libelle = ?, config_compte = ?, config_journal = ? where id_client = ? AND config_libelle = ? ' ;
	    @bind_array = ( $args->{libelle}, $args->{select_compte}, $args->{select_journal}, $r->pnotes('session')->{id_client}, $args->{old_libelle} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
	#/************ ACTION FIN *************/
	
	############## MISE EN FORME DEBUT ##############

    $sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? ORDER by config_libelle' ;
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    
	#journal
	$sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_req = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	
    #select_journal
	my $select_journal = '<select class="login-text" name=select_journal id=select_journal>' ;
	$select_journal .= '<option value="" selected>--Sélectionner un journal--</option>' ;
	for ( @$journal_req ) {
	$select_journal .= '<option value="' . $_->[0] . '">' . $_->[0] . '</option>' ;
	}
	$select_journal .= '</select>' ;
		
	#select_compte
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'45\',\'51\',\'53\') ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte = '<select class="login-text" name=select_compte id=select_compte>' ;
	$select_compte .= '<option value="" selected>--Sélectionner un compte--</option>' ;
	for ( @$compte_req ) {
	$select_compte .= '<option value="' . $_->[0] . '">' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte .= '</select>' ;
    
    my $formulaire = '
    <fieldset><legend><h2 style="color: green; background-color: #ddefef;">Configuration du mode de règlement des achats</h2></legend>
    <div class=centrer>
        <div class=Titre10>Ajouter un mode de réglement</div>
		<div class="form-int">
        <form action=/'.$r->pnotes('session')->{racine}.'/parametres>
        <label class="forms para" for="libelle">Libellé :</label><input class="login-text" type=text placeholder="Entrer le libellé" id=libelle name="libelle" value="" required>
        <label class="forms para" for="select_journal">Journal :</label>' . $select_journal . '
		<label class="forms para" for="select_compte">Compte :</label>' . $select_compte . '
		<input type=hidden name="ajouter" value=1>
		<input type=hidden name="achats" value=0>
		<br><br>
		<input type=submit class="btnform1 vert" value=Ajouter>
		</form></div>
		<br>
    <div class=Titre10>Modifier les modes de règlement existants</div>
    <div class="form-int">
    ' ;
    
    
    for ( @$resultat ) {

	my $delete_href = 'parametres&#63;achats=&amp;mode=0&amp;delete=0&amp;libelle=' . URI::Escape::uri_escape_utf8($_->{config_libelle}) ;
	my $delete_link = '<input type="submit" class="btnform1 rouge" formaction="' . $delete_href . '" value="Supprimer" >' ;
	my $valid_href = 'parametres&#63;mode=0&amp;maj=1&amp;delete_doc=0&amp;old_libelle=' . URI::Escape::uri_escape_utf8( $_->{config_libelle} ) ;
	my $disabled = ( $_->{config_libelle} eq 'Temp' ) ? ' disabled' : '' ;
		
	#select_journal
	my $selected_journal = $_->{config_journal};
	my $select_journal = '<select class="login-text" name=select_journal id=select_journal style="width: 25ch;">' ;
	for ( @$journal_req ) {
	my $selected = ( $_->[0] eq $selected_journal) ? 'selected' : '' ;
	$select_journal .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . '</option>' ;
	}
	$select_journal .= '</select>' ;

	#select_compte
	my $selected_compte = $_->{config_compte};
	my $select_compte = '<select class="login-text" name=select_compte id=select_compte style="width: 35ch;">' ;
	for ( @$compte_req ) {
	my $selected = ( $_->[0] eq $selected_compte ) ? 'selected' : '' ;
	$select_compte .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte .= '</select>' ;	

	$formulaire .= '
		<form method=POST>
		<input class="login-text" type=text name=libelle style="width: 25ch;" value="' . $_->{config_libelle} . '" ' . $disabled . '/>
		'.$select_journal.'
		'.$select_compte.'
		<input type=hidden name="achats" value=0>
		<input type=hidden name="old_libelle" value='.$_->{config_libelle}.'>
		<input type=hidden name="modifier" value=1>
		<input type="submit"   class="btnform1 vert" formaction="' . $valid_href . '" value=Valider '.$disabled.'>
		'.$delete_link.'
		</form>
		' ;
	}
	
    $formulaire .= '</div></fieldset>';

	$content .= '<div class="formulaire2">' . $formulaire . '</div>' ;

    return $content ;
    
    ############## MISE EN FORME FIN ##############
    
} #sub form_edit_achats 


#/*—————————————— Page Formulaire modification des loyers ——————————————*/
sub form_edit_loyer {
	
	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my ( $sql, @bind_array, $content ) ;
		my $categorie_list ;
  
    
	################ Affichage MENU ################
	$content .= display_menu( $r, $args ) ;
	################ Affichage MENU ################
	
	
	#/************ ACTION DEBUT *************/
	
	####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Supprimer' la catégorie		  #
	#######################################################################
    if ( defined $args->{loyer} && defined $args->{delete}) {

			#1ère demande de suppression; afficher lien d'annulation/confirmation
			if ( $args->{delete} eq '0' ) {

			my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?loyer=0' ;

			my $oui_href = '/'.$r->pnotes('session')->{racine}.'/parametres?loyer=0&amp;delete=1&amp;libelle=' . $args->{libelle} ;

			$content .= '<h3 class=warning>Voulez-vous vraiment supprimer  ' . $args->{libelle} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;

			} else {

			#demande de suppression confirmée
			$sql = 'DELETE FROM tblloyer_liste WHERE loyer_libelle = ? AND id_client = ?' ;

			@bind_array = ( $args->{libelle}, $r->pnotes('session')->{id_client} ) ;
			eval {$dbh->do( $sql, undef, @bind_array ) } ;

				if ( $@ ) {
					if ( $@ =~ /NOT NULL/ ) {
					$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
					} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
				} #	if ( $@ ) 
			} #	if ( $args->{delete_doc} eq '0' )

	} #    if ( $args->{delete} ) 
    
    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Ajouter' 					  #
	#######################################################################
	#parametres?libelle=Appel+Loyer+Villa+1&select_day=05&montant=780.00&select_compte4=411101&select_compte7=706051&documents=VE2020-MULTI_01_BAIL_VILLA_1_SERRANO_SUSINI.pdf&ajouter=1&loyer=0
    if ( defined $args->{loyer} && defined $args->{ajouter} && $args->{ajouter} eq '1' ) {
		#on interdit libelle vide
		$args->{libelle} ||= undef ;
	
	#mise en forme montant pour enregistrement en bdd
	#ne pas laisser des montants nulls : mettre un zéro
	$args->{montant} ||= '0.00';
	#remplacer la virgule par le point dans les montants soumis
	$args->{montant} =~ s/,/./ ;
	#enlever les espaces de présentation
	$args->{montant} =~ s/\s//g ;
	
	
	    #ajouter une catégorie
	    $sql = 'INSERT INTO tblloyer_liste (loyer_libelle, loyer_date, loyer_montant, loyer_classe4, loyer_classe7, loyer_piece, id_client) values (?, ?, ?, ?, ?, ?, ?)' ;
	    @bind_array = ( $args->{libelle}, $args->{select_day}, $args->{montant}*100, $args->{select_compte4}, $args->{select_compte7}, $args->{documents}, $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>Il faut obligatoirement un libellé</h3>' ;
			} elsif ( $@ =~ /existe/ ) {$content .= '<h3 class=warning>Ce libellé existe déjà</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
    
    ####################################################################### 
	#l'utilisateur a cliqué sur 'Valider' la modification de la catégorie #
	#######################################################################
    if ( defined $args->{loyer} && defined $args->{modifier} && $args->{modifier} eq '1' ) {
	    
	    #ne pas laisser des montants nulls : mettre un zéro
	    $args->{montant} ||= '0.00';
	    #remplacer la virgule par le point dans les montants soumis
	    $args->{montant} =~ s/,/./ ;
	    #enlever les espaces de présentation
	    $args->{montant} =~ s/\s//g ;
	    
	    
   	    #modifier une catégorie
	    $sql = 'UPDATE tblloyer_liste set loyer_libelle = ?, loyer_date = ?, loyer_montant = ? , loyer_classe4 = ? , loyer_classe7 = ? , loyer_piece = ? where id_client = ? AND loyer_libelle = ? ' ;
	    @bind_array = ( $args->{libelle}, $args->{select_day}, $args->{montant}*100, $args->{select_compte4}, $args->{select_compte7}, $args->{documents}, $r->pnotes('session')->{id_client}, $args->{old_libelle} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
	#/************ ACTION FIN *************/
	
	############## MISE EN FORME DEBUT ##############

    $sql = 'SELECT loyer_libelle, loyer_date, loyer_montant/100::numeric as loyer_montant, loyer_classe4, loyer_classe7, loyer_piece FROM tblloyer_liste WHERE id_client = ? ORDER by loyer_libelle' ;
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    
    #select day :
	my $select_day .= '<select style="width: 8ch;" class="forms2_input" style="width: 30ch;" name=select_day id=select_day>
	<option value="01">01</option>
	<option value="02">02</option>
	<option value="03">03</option>
	<option value="04">04</option>
	<option value="05" selected>05</option>
	<option value="06">06</option>
	<option value="07">07</option>
	<option value="08">08</option>
	<option value="09">09</option>
	';
	
	foreach my $i (10..31) {
	$select_day .= '<option value='.$i.'>'.$i.'</option>';
	}
	
	$select_day .= '
	</select>
	' ;
		
	#select_compte4
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 3) IN (\'411\') ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req4 = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte4 = '<select style="width: 30ch;" class="forms2_input" name=select_compte4 id=select_compte4>' ;
	$select_compte4 .= '<option value="" selected>--Sélectionner un compte--</option>' ;
	for ( @$compte_req4 ) {
	$select_compte4 .= '<option value="' . $_->[0] . '">' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte4 .= '</select>' ;
	
	#select_compte7
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'70\') ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req7 = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte7 = '<select style="width: 30ch;" class="forms2_input" name=select_compte7 id=select_compte7>' ;
	$select_compte7 .= '<option value="" selected>--Sélectionner un compte--</option>' ;
	for ( @$compte_req7 ) {
	$select_compte7 .= '<option value="' . $_->[0] . '">' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte7 .= '</select>' ;
	
	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (libelle_cat_doc = \'Inter-exercice\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception
	' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my $id_name;
    
    my $document_select1 = '<select style="width: 45ch;" class="forms2_input" name=documents >
    ' ;

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {

		$document_select1 .= '
		<option value="' . $_->{id_name} . '" >' . $_->{id_name} . '</option>		
		' ;
	    }
		$id_name = $_->{id_name} ;	
    }
    
	$document_select1 .= '<option value="" selected>--Sélectionner le document--</option>' ;	
    $document_select1 .= '</select>' ;

    my $echeance;
    
    my $formulaire = '
    <fieldset class=pretty-box><legend><h2 style="color: green; background-color: #ddefef;">Configuration des appels de loyer</h2></legend>
    <div class=centrer>
        <div class=Titre10>Ajouter un appel de loyer</div>
        <form action=/'.$r->pnotes('session')->{racine}.'/parametres>
		<div class="forms2_row">
		
		<div class="forms2_col">
		<label class="forms2_label" for="libelle">Libellé :</label>
		<input class="forms2_input" style="width: 35ch;" type=text id=libelle name=libelle value="" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist>
		</div>
        <div class="forms2_col">
        <label class="forms2_label" for="select_day">Echéance :</label>' . $select_day . '
        </div>
        <div class="forms2_col">
        <label class="forms2_label" for="montant">Montant :</label><input style="width: 12ch;" class="forms2_input" type=text placeholder="loyer" id=montant name="montant" value="" onchange="format_and_stage(this)" required>
		</div>
		<div class="forms2_col">
		<label class="forms2_label" for="select_compte4">Compte client:</label>' . $select_compte4 . '
		</div>
		<div class="forms2_col">
		<label class="forms2_label" for="select_compte7">Compte produit:</label>' . $select_compte7 . '
		</div>
		<div class="forms2_col">
		<label class="forms2_label" for="documents">Bail :</label>' . $document_select1 . '
		</div>
		<input type=hidden name="ajouter" value=1>
		<input type=hidden name="loyer" value=0>
		<br><br>
		<input type=submit class="btnform1 vert" value=Ajouter>
		</form></div>
		<br>
    <div class=Titre10>Modifier les appels de loyer existants</div>
    <div class="form-int">
        
    ' ;
    
    
    
    for ( @$resultat ) {

	my $delete_href = 'parametres&#63;loyer=&amp;mode=0&amp;delete=0&amp;libelle=' . URI::Escape::uri_escape_utf8($_->{loyer_libelle}) ;
	my $delete_link = '<input type="submit" class="btnform1 rouge" formaction="' . $delete_href . '" value="Supprimer" >' ;
	my $valid_href = 'parametres&#63;mode=0&amp;loyer=&amp;maj=1&amp;old_libelle=' . URI::Escape::uri_escape_utf8( $_->{loyer_libelle} ) ;
	
	my $document = $_->{loyer_piece};
	my $ldate = $_->{loyer_date};
	my $document_select = '<select style="width: 45ch;" class="forms2_input" name=documents >

	' ;
	
	

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
		
		my $selected1 = ( $_->{id_name} eq $document ) ? 'selected' : '' ;	

		$document_select .= '
		<option value="' . $_->{id_name} . '" ' . $selected1 . '>' . $_->{id_name} . '</option>		
		' ;
	    }
		$id_name = $_->{id_name} ;	
    }
    
    	if (not(defined $document)) {
	    $document_select .= '<option value="" selected>--Sélectionner le document--</option>' ;	
		} else {
		$document_select .= '<option value="">--Sélectionner le document--</option>' ;	
		}

    $document_select .= '</select>' ;
    
    
	 #select day :
	my $select_day .= '<select style="width: 8ch;" class="forms2_input" style="width: 30ch;" name=select_day id=select_day>
	<option ' . ( ( defined $ldate && $ldate eq '01' ) ? 'selected' : '' ) . ' value="01">01</option>
	<option ' . ( ( defined $ldate && $ldate eq '02' ) ? 'selected' : '' ) . ' value="02">02</option>
	<option ' . ( ( defined $ldate && $ldate eq '03' ) ? 'selected' : '' ) . ' value="03">03</option>
	<option ' . ( ( defined $ldate && $ldate eq '04' ) ? 'selected' : '' ) . ' value="04">04</option>
	<option ' . ( ( defined $ldate && $ldate eq '05' ) ? 'selected' : '' ) . ' value="05">05</option>
	<option ' . ( ( defined $ldate && $ldate eq '06' ) ? 'selected' : '' ) . ' value="06">06</option>
	<option ' . ( ( defined $ldate && $ldate eq '07' ) ? 'selected' : '' ) . ' value="07">07</option>
	<option ' . ( ( defined $ldate && $ldate eq '08' ) ? 'selected' : '' ) . ' value="08">08</option>
	<option ' . ( ( defined $ldate && $ldate eq '09' ) ? 'selected' : '' ) . ' value="09">09</option>
	';
	
	foreach my $i (10..31) {
	$select_day .= '<option ' . ( ( defined $ldate && $ldate eq ''.$i.'' ) ? 'selected' : '' ) . ' value='.$i.'>'.$i.'</option>';
	}
	
	$select_day .= '
	</select>
	' ;	

	#select_compte4
	my $selected_compte4 = $_->{loyer_classe4};
	my $select_compte4 = '<select class="login-text" name=select_compte4 id=select_compte4 style="width: 35ch;">' ;
	for ( @$compte_req4 ) {
	my $selected = ( $_->[0] eq $selected_compte4 ) ? 'selected' : '' ;
	$select_compte4 .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte4 .= '</select>' ;	
	
		#select_compte4
	my $selected_compte7 = $_->{loyer_classe7};
	my $select_compte7 = '<select class="login-text" name=select_compte7 id=select_compte7 style="width: 35ch;">' ;
	for ( @$compte_req7 ) {
	my $selected = ( $_->[0] eq $selected_compte7 ) ? 'selected' : '' ;
	$select_compte7 .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte7 .= '</select>' ;
	
	 #joli formatage de débit/crédit
    (my $montant = sprintf( "%.2f", $_->{loyer_montant} ) ) =~ s/\B(?=(...)*$)/ /g ;

	$formulaire .= '
		<form method=POST>
		<div class="forms2_row">
		
		<div class="forms2_col">
		<input class="login-text" type=text name=libelle style="width: 25ch;" value="' . $_->{loyer_libelle} . '" />
		</div>
		<div class="forms2_col">
        ' . $select_day . '
        </div>
		<div class="forms2_col">
		<input style="width: 12ch;" class="forms2_input" type=text placeholder="Montant du loyer" id=montant name="montant" value="'.$montant.'" onchange="format_and_stage(this)" required>
		</div>
		<div class="forms2_col">
		' . $select_compte4 . '
		</div>
		<div class="forms2_col">
		'.$select_compte7.'
		</div>
		<div class="forms2_col">
		' . $document_select . '
		</div>
		<input type=hidden name="loyer" value=0>
		<input type=hidden name="old_libelle" value='.$_->{loyer_libelle}.'>
		<input type=hidden name="modifier" value=1>
		<input type="submit"   class="btnform1 vert" formaction="' . $valid_href . '" value=Valider >
		'.$delete_link.'
		</div>
		</form>
		' ;
	}
	
    $formulaire .= '</div></fieldset>';

	$content .= '<div class="wrapper-docs-entry">' . $formulaire . '</div>' ;

    return $content ;
    
    ############## MISE EN FORME FIN ##############
    
} #sub form_edit_loyer 

#/*—————————————— Page Formulaire écritures récurrentes ——————————————*/
sub form_edit_recurrent {
	
	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my ( $sql, @bind_array, $content ) ;
		my $categorie_list ;
  
    
	################ Affichage MENU ################
	$content .= display_menu( $r, $args ) ;
	################ Affichage MENU ################
	
	
	#/************ ACTION DEBUT *************/
	
	####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Supprimer' la catégorie		  #
	#######################################################################
    if ( defined $args->{loyer} && defined $args->{delete}) {

			#1ère demande de suppression; afficher lien d'annulation/confirmation
			if ( $args->{delete} eq '0' ) {

			my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?loyer=0' ;

			my $oui_href = '/'.$r->pnotes('session')->{racine}.'/parametres?loyer=0&amp;delete=1&amp;libelle=' . $args->{libelle} ;

			$content .= '<h3 class=warning>Voulez-vous vraiment supprimer  ' . $args->{libelle} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;

			} else {

			#demande de suppression confirmée
			$sql = 'DELETE FROM tblloyer_liste WHERE loyer_libelle = ? AND id_client = ?' ;

			@bind_array = ( $args->{libelle}, $r->pnotes('session')->{id_client} ) ;
			eval {$dbh->do( $sql, undef, @bind_array ) } ;

				if ( $@ ) {
					if ( $@ =~ /NOT NULL/ ) {
					$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
					} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
				} #	if ( $@ ) 
			} #	if ( $args->{delete_doc} eq '0' )

	} #    if ( $args->{delete} ) 
    
    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Ajouter' 					  #
	#######################################################################
	#parametres?libelle=Appel+Loyer+Villa+1&select_day=05&montant=780.00&select_compte4=411101&select_compte7=706051&documents=VE2020-MULTI_01_BAIL_VILLA_1_SERRANO_SUSINI.pdf&ajouter=1&loyer=0
    #parametres?select_day=05&libre=test&select_journal=ACHATS&select_compte4=401CAR&compte_charge_comptant=616000&calcul_piece3=AC-TEST&libelle=Prlv+Cbp+France+pour+Cardif&debit=&credit=9.12&documents1=AC2020-MULTI_02_Assurance_Emprunt_Cardif_RP.pdf&documents2=&ajouter=1&recurrent=0
    if ( defined $args->{recurrent} && defined $args->{ajouter} && $args->{ajouter} eq '1' ) {
		#on interdit libelle vide
		$args->{libelle} ||= undef ;
	
	#mise en forme montant pour enregistrement en bdd
	#ne pas laisser des montants nulls : mettre un zéro
	$args->{credit} ||= '0.00';
	$args->{debit} ||= '0.00';
	#remplacer la virgule par le point dans les montants soumis
	$args->{credit} =~ s/,/./ ;
	$args->{debit} =~ s/,/./ ;
	#enlever les espaces de présentation
	$args->{credit} =~ s/\s//g ;
	$args->{debit} =~ s/\s//g ;
	
	
	    #ajouter une écriture récurrente
	    $sql = 'INSERT INTO tblrecurrent_liste (recurrent_libelle, recurrent_date, recurrent_debit, recurrent_credit, recurrent_compte1, recurrent_compte2, recurrent_piece, recurrent_libre, recurrent_docs1, recurrent_docs2 ,recurrent_journal, id_client) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)' ;
	    @bind_array = ( $args->{libelle}, $args->{select_day}, $args->{debit}*100, $args->{credit}*100, $args->{select_compte4}, $args->{compte_charge_comptant}, ($args->{calcul_piece3} || undef), ($args->{libre} || undef), ($args->{documents1} || undef), ($args->{documents2} || undef), $args->{select_journal}, $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>Il faut obligatoirement un libellé</h3>' ;
			} elsif ( $@ =~ /existe/ ) {$content .= '<h3 class=warning>Ce libellé existe déjà</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
    
    ####################################################################### 
	#l'utilisateur a cliqué sur 'Valider' la modification de la catégorie #
	#######################################################################
    if ( defined $args->{loyer} && defined $args->{modifier} && $args->{modifier} eq '1' ) {
	    
	    #ne pas laisser des montants nulls : mettre un zéro
	    $args->{montant} ||= '0.00';
	    #remplacer la virgule par le point dans les montants soumis
	    $args->{montant} =~ s/,/./ ;
	    #enlever les espaces de présentation
	    $args->{montant} =~ s/\s//g ;
	    
	    
   	    #modifier une catégorie
	    $sql = 'UPDATE tblloyer_liste set loyer_libelle = ?, loyer_date = ?, loyer_montant = ? , loyer_classe4 = ? , loyer_classe7 = ? , loyer_piece = ? where id_client = ? AND loyer_libelle = ? ' ;
	    @bind_array = ( $args->{libelle}, $args->{select_day}, $args->{montant}*100, $args->{select_compte4}, $args->{select_compte7}, $args->{documents}, $r->pnotes('session')->{id_client}, $args->{old_libelle} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
	#/************ ACTION FIN *************/
	
	############## MISE EN FORME DEBUT ##############

    $sql = 'SELECT recurrent_libelle, recurrent_date, recurrent_debit/100::numeric as recurrent_debit, recurrent_credit/100::numeric as recurrent_credit, recurrent_compte1, recurrent_compte2, recurrent_piece, recurrent_libre, recurrent_docs1, recurrent_docs2 ,recurrent_journal FROM tblrecurrent_liste WHERE id_client = ? ORDER by recurrent_libelle' ;
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    
    #select day :
	my $select_day .= '<select style="width: 8ch;" class="forms2_input" style="width: 30ch;" name=select_day id=select_day>
	<option value="01">01</option>
	<option value="02">02</option>
	<option value="03">03</option>
	<option value="04">04</option>
	<option value="05" selected>05</option>
	<option value="06">06</option>
	<option value="07">07</option>
	<option value="08">08</option>
	<option value="09">09</option>
	';
	
	foreach my $i (10..31) {
	$select_day .= '<option value='.$i.'>'.$i.'</option>';
	}
	
	$select_day .= '
	</select>
	' ;
		
	#de compte
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req4 = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte4 = '<select style="width: 30ch;" class="forms2_input" onchange="select_contrepartie_401(this, \'' . $r->pnotes('session')->{racine} . '\')" name=select_compte4 id=select_compte4>' ;
	$select_compte4 .= '<option value="" selected>--Sélectionner un compte--</option>' ;
	for ( @$compte_req4 ) {
	$select_compte4 .= '<option value="' . $_->[0] . '">' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte4 .= '</select>' ;
	
	#vers compte
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req7 = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte7 = '<select style="width: 30ch;" class="forms2_input" name=compte_charge_comptant1 id=compte_charge_comptant1>' ;
	$select_compte7 .= '<option value="" selected>--Sélectionner un compte--</option>' ;
	for ( @$compte_req7 ) {
	$select_compte7 .= '<option value="' . $_->[0] . '">' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte7 .= '</select>' ;
	
	#journal
	$sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_req = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	
    #select_journal
	my $select_journal = '<select style="width: 30ch;" class="forms2_input" name=select_journal id=select_journal>' ;
	$select_journal .= '<option value="" selected>--Sélectionner un journal--</option>' ;
	for ( @$journal_req ) {
	$select_journal .= '<option value="' . $_->[0] . '">' . $_->[0] . '</option>' ;
	}
	$select_journal .= '</select>' ;
	
	
	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (libelle_cat_doc = \'Inter-exercice\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception
	' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my $id_name;
    
    my $document_select1 = '<select style="width: 45ch;" class="forms2_input" name=documents1 >
    ' ;
    
    my $document_select2 = '<select style="width: 45ch;" class="forms2_input" name=documents2 >
    ' ;

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {

		$document_select1 .= '
		<option value="' . $_->{id_name} . '" >' . $_->{id_name} . '</option>		
		' ;
		
		$document_select2 .= '
		<option value="' . $_->{id_name} . '" >' . $_->{id_name} . '</option>		
		' ;
	    }
		$id_name = $_->{id_name} ;	
    }
    
	$document_select1 .= '<option value="" selected>--Sélectionner le document--</option>' ;	
    $document_select1 .= '</select>' ;
    
    $document_select2 .= '<option value="" selected>--Sélectionner le document--</option>' ;	
    $document_select2 .= '</select>' ;

    my ($calcul_piece3,$libre,$echeance);
    
    my $formulaire = '
    <fieldset class=pretty-box><legend><h2 style="color: green; background-color: #ddefef;">Configuration des écritures récurrentes</h2></legend>
    <div class=centrer>
        <div class=Titre10>Ajouter une écriture récurrente</div>
        <form action=/'.$r->pnotes('session')->{racine}.'/parametres>
		<div class="forms2_row">
		
		<div class="forms2_col">
        <label class="forms2_label" for="select_day">Echéance :</label>' . $select_day . '
        </div>
        
        <div class="forms2_col">
        <label class="forms2_label" for="libre">Libre</label>
        <input class="forms2_input" style="width: 30ch;" type=text id=libre name=libre value="'.($libre || '').'" required/>
		</div>
        
        <div class="forms2_col">
        <label class="forms2_label" for="select_journal">Journal :</label>' . $select_journal . '
        </div>
        
        <div class="forms2_col">
		<label class="forms2_label" for="select_compte4">De :</label>' . $select_compte4 . '
		</div>
		<div class="forms2_col">
		<label class="forms2_label" for="select_compte7">Vers:</label>' . $select_compte7 . '
		</div>
		
        
        <div class="forms2_col">
        <label class="forms2_label" for="calcul_piece3">Pièce</label>
        <input class="forms2_input" style="width: 30ch;" type=text id=calcul_piece3 name=calcul_piece3 value="'.($calcul_piece3 || '').'" required/>
		</div>
		
		
		<div class="forms2_col">
		<label class="forms2_label" for="libelle">Libellé :</label>
		<input class="forms2_input" style="width: 35ch;" type=text id=libelle name=libelle value="" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist>
		</div>
		

        <div class="forms2_col">
        <label class="forms2_label" for="debit">Débit :</label><input style="width: 20ch;" class="forms2_input" type=text placeholder="debit" id=debit name="debit" value="" onchange="format_number(this)" >
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="credit">Crédit :</label><input style="width: 20ch;" class="forms2_input" type=text placeholder="credit" id=credit name="credit" value="" onchange="format_number(this)" >
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="documents1">Doc1 :</label>' . $document_select1 . '
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="documents2">Doc2 :</label>' . $document_select2 . '
		</div>
		
		<input type=hidden name="ajouter" value=1>
		<input type=hidden name="recurrent" value=0>
		<br><br>
		<input type=submit class="btnform1 vert" value=Ajouter>
		</form></div>
		<br>
    <div class=Titre10>Modifier les écritures récurrentes existantes</div>
    <div class="form-int">
        
    ' ;
    
    
    
    for ( @$resultat ) {

	my $delete_href = 'parametres&#63;recurrent=&amp;mode=0&amp;delete=0&amp;libelle=' . URI::Escape::uri_escape_utf8($_->{recurrent_libelle}) ;
	my $delete_link = '<input type="submit" class="btnform1 rouge" formaction="' . $delete_href . '" value="Supprimer" >' ;
	my $valid_href = 'parametres&#63;mode=0&amp;recurrent=&amp;maj=1&amp;old_libelle=' . URI::Escape::uri_escape_utf8( $_->{recurrent_libelle} ) ;
	
	my $document1 = ($_->{recurrent_docs1} ||'');
	my $document2 = ($_->{recurrent_docs2} ||'');
	my $ldate = $_->{recurrent_date};
	my $document_select1 = '<select style="width: 45ch;" class="forms2_input" name=documents1 >' ;
	my $document_select2 = '<select style="width: 45ch;" class="forms2_input" name=documents2 >' ;
	
	

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
		
		my $selected1 = ( $_->{id_name} eq $document1 ) ? 'selected' : '' ;	
		my $selected2 = ( $_->{id_name} eq $document2 ) ? 'selected' : '' ;	

		$document_select1 .= '<option value="' . $_->{id_name} . '" ' . $selected1 . '>' . $_->{id_name} . '</option>';
		$document_select2 .= '<option value="' . $_->{id_name} . '" ' . $selected2 . '>' . $_->{id_name} . '</option>';
	    }
		$id_name = $_->{id_name} ;	
    }
    
    	if (not(defined $document1) || $document1 eq '') {
	    $document_select1 .= '<option value="" selected>--Sélectionner le document--</option>' ;	
		} else {
		$document_select1 .= '<option value="">--Sélectionner le document--</option>' ;	
		}
		
		if (not(defined $document2) || $document2 eq '') {
	    $document_select2 .= '<option value="" selected>--Sélectionner le document--</option>' ;	
		} else {
		$document_select2 .= '<option value="">--Sélectionner le document--</option>' ;	
		}

    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
    
    
	 #select day :
	my $select_day .= '<select style="width: 8ch;" class="forms2_input" style="width: 30ch;" name=select_day id=select_day>
	<option ' . ( ( defined $ldate && $ldate eq '01' ) ? 'selected' : '' ) . ' value="01">01</option>
	<option ' . ( ( defined $ldate && $ldate eq '02' ) ? 'selected' : '' ) . ' value="02">02</option>
	<option ' . ( ( defined $ldate && $ldate eq '03' ) ? 'selected' : '' ) . ' value="03">03</option>
	<option ' . ( ( defined $ldate && $ldate eq '04' ) ? 'selected' : '' ) . ' value="04">04</option>
	<option ' . ( ( defined $ldate && $ldate eq '05' ) ? 'selected' : '' ) . ' value="05">05</option>
	<option ' . ( ( defined $ldate && $ldate eq '06' ) ? 'selected' : '' ) . ' value="06">06</option>
	<option ' . ( ( defined $ldate && $ldate eq '07' ) ? 'selected' : '' ) . ' value="07">07</option>
	<option ' . ( ( defined $ldate && $ldate eq '08' ) ? 'selected' : '' ) . ' value="08">08</option>
	<option ' . ( ( defined $ldate && $ldate eq '09' ) ? 'selected' : '' ) . ' value="09">09</option>
	';
	
	foreach my $i (10..31) {
	$select_day .= '<option ' . ( ( defined $ldate && $ldate eq ''.$i.'' ) ? 'selected' : '' ) . ' value='.$i.'>'.$i.'</option>';
	}
	
	$select_day .= '
	</select>
	' ;	

	#select_compte4
	my $selected_compte4 = $_->{recurrent_compte1};
	my $select_compte4 = '<select class="login-text" name=select_compte4 onchange="select_contrepartie_401(this, \'' . $r->pnotes('session')->{racine} . '\')" id=select_compte4 style="width: 35ch;">' ;
	for ( @$compte_req4 ) {
	my $selected = ( $_->[0] eq $selected_compte4 ) ? 'selected' : '' ;
	$select_compte4 .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte4 .= '</select>' ;	
	
		#select_compte4
	my $selected_compte7 = $_->{recurrent_compte2};
	my $select_compte7 = '<select class="login-text" name=compte_charge_comptant id=compte_charge_comptant style="width: 35ch;">' ;
	for ( @$compte_req7 ) {
	my $selected = ( $_->[0] eq $selected_compte7 ) ? 'selected' : '' ;
	$select_compte7 .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte7 .= '</select>' ;
	
	 #joli formatage de débit/crédit
    (my $montantd = sprintf( "%.2f", $_->{recurrent_debit} ) ) =~ s/\B(?=(...)*$)/ /g ;
    	 #joli formatage de débit/crédit
    (my $montantc = sprintf( "%.2f", $_->{recurrent_credit} ) ) =~ s/\B(?=(...)*$)/ /g ;

	$formulaire .= '
		<form method=POST>
		<div class="forms2_row">
		<div class="forms2_col">
        ' . $select_day . '
        </div>
        
        <div class="forms2_col">
		<input class="login-text" type=text name=libre style="width: 25ch;" value="' . $_->{recurrent_libre} . '" />
		</div>
        
        
		<div class="forms2_col">
		<input class="login-text" type=text name=libelle style="width: 25ch;" value="' . $_->{recurrent_libelle} . '" />
		</div>

		<div class="forms2_col">
		<input style="width: 13ch;" class="forms2_input" type=text placeholder="Débit" id=debit name="recurrent_debit" value="'.$montantd.'" onchange="format_number(this)" required>
		</div>
		
		<div class="forms2_col">
		<input style="width: 13ch;" class="forms2_input" type=text placeholder="Débit" id=credit name="recurrent_debit" value="'.$montantc.'" onchange="format_number(this)" required>
		</div>
		
		<div class="forms2_col">
		' . $select_compte4 . '
		</div>
		<div class="forms2_col">
		'.$select_compte7.'
		</div>
		<div class="forms2_col">
		' . $document_select1 . '
		</div>
		
		<div class="forms2_col">
		' . $document_select2 . '
		</div>
		<input type=hidden name="loyer" value=0>
		<input type=hidden name="old_libelle" value='.$_->{loyer_libelle}.'>
		<input type=hidden name="modifier" value=1>
		<input type="submit"   class="btnform1 vert" formaction="' . $valid_href . '" value=Valider >
		'.$delete_link.'
		</div>
		</form>
		' ;
	}
	
    $formulaire .= '</div></fieldset>';

	$content .= '<div class="wrapper-docs-entry">' . $formulaire . '</div>' ;

    return $content ;
    
    ############## MISE EN FORME FIN ##############
    
} #sub form_edit_recurrent



sub utilisateurs {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;

	######## Affichage MENU display_menu Début ######
	$content .= display_menu( $r, $args ) ;
	######## Affichage MENU display_menu Fin ########
	
    $args->{utilisateurs} ||= 0 ;
    
    #1ère demande de suppression; afficher lien d'annulation/confirmation
	if ( defined $args->{supprimer_utilisateur} && $args->{supprimer_utilisateur} eq '0' ) {
	my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?utilisateurs=0' ;
	my $oui_href = '/'.$r->pnotes('session')->{racine}.'/parametres?utilisateurs=1&amp;supprimer_utilisateur=1&amp;selection_utilisateur=' . $args->{selection_utilisateur} ;
	$content .= '<h3 class=warning>Vraiment supprimer l\'utilisateur ' . $args->{selection_utilisateur} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;
	 }

    #l'utilisateur a cliqué sur le bouton 'Valider', enregistrer les modifications
    if ( $args->{utilisateurs} eq '1' ) {

	#on interdit username/userpass vide
	$args->{username} ||= undef ;
	$args->{userpass} ||= undef ;
	
	if ((defined $args->{selection_utilisateur} && $args->{selection_utilisateur} eq 'superadmin')) {
	$args->{username} = $args->{selection_utilisateur};	
	}
	
	#si le nom n'est pas renseigné, mettre l'e-mail
	$args->{nom} ||= $args->{username} ;

	#suppression d'un utilisateur
	if ( defined $args->{supprimer_utilisateur} && $args->{supprimer_utilisateur} eq '1' ) {
		if (not($args->{selection_utilisateur} eq 'superadmin')) {
		#demande de suppression confirmée
		$sql = 'DELETE FROM compta_user WHERE username = ? ' ;
		@bind_array = ( $args->{selection_utilisateur} ) ;
		eval {$dbh->do( $sql, undef, @bind_array ) } ;
		} else {
		$content .= '<div class=warning><h3>Impossible de supprimer l\'utilisateur superadmin</h3></div>' ;
		}	
		
	} elsif ( defined $args->{old_username} && $args->{old_username} eq '0' ) {
	    if (not($args->{username} eq 'superadmin')) {
	    #ajouter un utilisateur
	    $sql = 'INSERT INTO compta_user (is_main, username, userpass, nom, prenom, preferred_datestyle, id_client, debug, dump) values (0, ?, ?, ?, ?, ?, ?, ?, ?)' ;
	    @bind_array = ( $args->{username}, $args->{userpass}, $args->{nom}, $args->{prenom}, $args->{preferred_datestyle}, $args->{select_client}, $args->{debug}, $args->{dump} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    } else {
		$content = '<div class=warning><h3>l\'utilisateur superadmin existe déjà</h3></div>' ;
		}
	    
	} else {
		if (($args->{selection_utilisateur} eq 'superadmin') && (not($args->{username} eq 'superadmin'))) {
		$content .= '<div class=warning><h3>Impossible de renommer l\'identifiant de superadmin !!!</h3></div>' ;	
		} else {
	    #modifier un utilisateur
	    $sql = 'UPDATE compta_user set username = ?, userpass = ?, preferred_datestyle = ?, nom = ?, prenom = ?, id_client = ? , debug = ? , dump = ? where username = ? ' ;
	    @bind_array = ( $args->{username}, $args->{userpass}, $args->{preferred_datestyle}, $args->{nom}, $args->{prenom}, $args->{select_client}, $args->{debug}, $args->{dump}, $args->{selection_utilisateur}  ) ;
		eval {$dbh->do( $sql, undef, @bind_array ) } ;
		}
	}
	
	if ( $@ ) {

	    if ( $@ =~ /NOT NULL/ ) {

		$content .= '<h3 class=warning>Il faut renseigner E-mail et Mot de passe</h3>' ;

	    } elsif ( $@ =~ /existe/ ){
		
		$content .= '<h3 class=warning>L\'utilisateur existe déjà</h3>' ;
			
		} else {
	    
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;

	    }

	} else {

	    $r->pnotes('session')->{preferred_datestyle} = $args->{preferred_datestyle} || $r->pnotes('session')->{preferred_datestyle} ;
	    
	    $r->pnotes('session')->{dump} = $args->{dump} ;
	    
	    $r->pnotes('session')->{debug} = $args->{debug} ;
	    
	if ($args->{debug} eq 1){
		Base::Site::logs::redirect_sig(1);
	} else {
		Base::Site::logs::redirect_sig(0);
	}
	    
	    freeze_session( $r ) ;
	    
	} #	if ( $@ ) 
	
    } #    if ( $args->{utilisateurs} eq '1' ) 
    
    #SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT#
    my $selected = '';
    #
    #sélection des noms d'utilisateurs
    #											 #
    $sql = 'SELECT username FROM compta_user ORDER BY is_main DESC' ;
    @bind_array = () ;
    my $utilisateurs_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    my $utilisateurs_select = '<select class="login-text" name=selection_utilisateur id=selection_utilisateur>' ;
    for ( @$utilisateurs_set ) {
	if 	(defined $args->{selection_utilisateur}) {
	$selected = ( $_->{username} eq $args->{selection_utilisateur} ) ? 'selected' : '' ;
	} elsif (defined $args->{username}) {
	$selected = ( $_->{username} eq $args->{username} ) ? 'selected' : '' ;
	}
	$utilisateurs_select .= '<option value="' . $_->{username} . '"  ' . $selected . '>' . $_->{username} . '</option>' ;
    }
    $utilisateurs_select .= '</select>' ;

	#
    #sélection des sociétés 
    #
    $sql = 'SELECT etablissement, id_client FROM compta_client' ;
    my $societe_set = $dbh->selectall_arrayref( $sql, { Slice => { } }) ;
    my $societe_select = '<select class="login-text" name=select_client id=select_client>' ;
    for ( @$societe_set ) {
	if 	(defined $args->{id_client}) {
	$selected = ( $_->{id_client} eq $args->{id_client} ) ? 'selected' : '' ;
	} elsif (defined $args->{etablissement}) {
	$selected = ( $_->{etablissement} eq $args->{etablissement} ) ? 'selected' : '' ;
	} 
	$societe_select .= '<option value="' . $_->{id_client} . '" ' . $selected . '>'.$_->{id_client}.' - ' . $_->{etablissement} . '</option>' ;
    }
    $societe_select .= '</select>' ;
    
    #
    #sélection préférence d'affichage des dates 
    #
    my $datestyle_select = '<select class="login-text" name=preferred_datestyle id=preferred_datestyle>
	<option value=iso>AAAA-MM-JJ</option>
	<option value="SQL, dmy">JJ/MM/AAAA</option>
	</select>' ;
	
	#
    #sélection mode debug 
    #
    my $debug_select = '<select class="login-text" name=debug id=debug>
	<option value=1>Oui</option>
	<option value=2>Non</option>
	</select>' ;
	
	#
    #sélection mode dump
    #
    my $dump_select = '<select class="login-text" name=dump id=dump>
	<option value=1>Oui</option>
	<option value=2>Non</option>
	</select>' ;
	#SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT SELECT#
	
    my $delete_href = 'parametres&#63;utilisateurs=0&amp;supprimer_utilisateur=0' ;
	my $valid_href = 'parametres&#63;utilisateurs=0&amp;modification_utilisateur=1' ;
	my $new_href = 'parametres&#63;utilisateurs=0&amp;creation_utilisateur=1' ;
	my $delete_link = '<input type="submit" class="btnform1 rouge" style ="width : 25%;" formaction="' . $delete_href . '" value="Supprimer" >' ;	
	my $new_link = '<input type="submit" class="btnform1 vert" style ="width : 50%;" formaction="' . $new_href . '" value="Créer un nouvel utilisateur" >' ;

    

    
    #
    #construire la table des paramètres
    #
    my $client_list .= '

	<fieldset><legend><h3 style="color: green; background-color: #ddefef;">Gestion des utilisateurs</h3></legend>
    <div class="centrer">

    <div class=Titre10>Ajouter un nouvel utilisateur</div>
     <div class="form-int">
     <form method=POST>
    '.$new_link	.'
    </div>
  
    <div class=Titre10>Modifier un utilisateur existant</div>
    <div class="form-int">
    
    <input type=hidden name=societe value=0>
    '.$utilisateurs_select.'
    <br><br>
    
	<input type=submit class="btnform1 gris" style ="width : 25%;" formaction="' . $valid_href . '" value=Modifier>
	'.$delete_link	.'
	<br><br>
	
	</form></div>
		
	<hr>
	<br>
 	';
 	
 	if ((defined $args->{creation_utilisateur}) && ($args->{creation_utilisateur} eq 1)) {
		#formulaire nouvel utilisateur	
		$client_list .= '
    	<div class=Titre10>Création d\'un nouvel utilisateur</div>
		<div class="form-int">
        <form action=/'.$r->pnotes('session')->{racine}.'/parametres>
        <label class="forms para" for="username">Identifiant :</label>
        <input class="login-text" placeholder="Entrer l\'identifiant" type=text name=username id=username value="" required/>
        <label class="forms para" for="userpass">Mot de passe :</label>
	    <input class="login-text" placeholder="Entrer le mot de passe" type=text name=userpass id=userpass value="" required/>
	    <label class="forms para" for="nom">Nom :</label>
		<input placeholder="Entrer le nom de l\'utilisateur" class="login-text" type=text name=nom id=nom value="" />
		<label class="forms para" for="nom">Prénom :</label>
		<input placeholder="Entrer le prénom de l\'utilisateur" class="login-text" type=text name=prenom id=prenom value="" />
		<label class="forms para" for="preferred_datestyle">Affichage des dates :</label>
		' . $datestyle_select . '
		<label class="forms para" for="preferred_datestyle">Société de rattachement :</label>
		' . $societe_select . '
		<label class="forms para" for="debug">Activer le mode debug log :</label>
		' . $debug_select . '
		<label class="forms para" for="dump">Activer le mode dump :</label>
		' . $dump_select . '
		<input type=hidden name=utilisateurs value=1>
		<input type=hidden name=old_username value=0>
		<br><br>
		<label class="forms para" for="submit"></label>
		<input type=submit id=submit style="width: 50ch;" class="btnform1 vert" value=Ajouter>
		</form>
		<br>
		' ;
	}
	
	if ((defined $args->{modification_utilisateur}) && ($args->{modification_utilisateur} eq 1)) {
    
		$client_list .= '
		<div class=Titre10>Modification de l\'utilisateur : '. $args->{selection_utilisateur}.'</div>
		<div class="form-int">
		' ;

		$sql = 'SELECT id_client, username, userpass, preferred_datestyle, coalesce(nom, \'\') as nom, coalesce(prenom, \'\') as prenom, is_main, debug, dump FROM compta_user WHERE username = ? ' ;

		my $client_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ($args->{selection_utilisateur} ) ) ;

		for ( @$client_set ) {
			#
			#sélection des sociétés 
			#
			$sql = 'SELECT etablissement, id_client FROM compta_client' ;
			my $societe_set = $dbh->selectall_arrayref( $sql, { Slice => { } }) ;
			my $societe_select = '<select class="login-text" name=select_client id=select_client>' ;
			for ( @$societe_set ) {
			$selected = ( $_->{id_client} eq $client_set->[0]->{id_client} ) ? 'selected' : '' ;
			$societe_select .= '<option value="' . $_->{id_client} . '" ' . $selected . '>'.$_->{id_client}.' - ' . $_->{etablissement} . '</option>' ;
			}
			$societe_select .= '</select>' ;

			my $datestyle_select = '<select class="login-text" name=preferred_datestyle id=preferred_datestyle>
			<option ' . ( ( $_->{preferred_datestyle} eq 'iso' ) ? 'selected' : '' ) . ' value=iso>AAAA-MM-JJ</option>
			<option ' . ( ( $_->{preferred_datestyle} eq 'SQL, dmy' ) ? 'selected' : '' ) . ' value="SQL, dmy">JJ/MM/AAAA</option>
			</select>' ;
			
			my $debug_select = '<select class="login-text" name=debug id=debug>
			<option ' . ( ( $_->{debug} eq 1 ) ? 'selected' : '' ) . ' value=1>Oui</option>
			<option ' . ( ( $_->{debug} eq 0 ) ? 'selected' : '' ) . ' value=0>Non</option>
			</select>' ;
			
			#
			#sélection mode dump
			#
			my $dump_select = '<select class="login-text" name=dump id=dump>
			<option ' . ( ( $_->{dump} eq 1 ) ? 'selected' : '' ) . ' value=1>Oui</option>
			<option ' . ( ( $_->{dump} eq 0 ) ? 'selected' : '' ) . ' value=0>Non</option>
			</select>' ;

			my $valid_href = 'parametres&#63;utilisateurs=1' ;

			my $disabled = ( $_->{username} eq 'superadmin' ) ? ' disabled' : '' ;
			
			$client_list .= '<form method=POST>
			<input type=hidden name=selection_utilisateur value="'.$_->{username}.'">
			<input type=hidden name=modification_utilisateur value=1>
			<label class="forms para" for="username">E-mail :</label>
			<input class="login-text" type=text name=username id=username value="' . $_->{username} . '" '.$disabled.'/>
			<label class="forms para" for="userpass">Mot de passe :</label>
			<input class="login-text" type=text name=userpass id=userpass value="' . $_->{userpass} . '" />
			<label class="forms para" for="nom">Nom :</label>
			<input class="login-text" type=text name=nom id=nom value="' . $_->{nom} . '" />
			<label class="forms para" for="prenom">Prénom :</label>
			<input class="login-text" type=text name=prenom id=prenom value="' . $_->{prenom} . '" />
			<label class="forms para" for="preferred_datestyle">Affichage des dates :</label>
			' . $datestyle_select . '
			<label class="forms para" for="preferred_datestyle">Société de rattachement :</label>
			' . $societe_select . '
			<label class="forms para" for="debug">Activer le mode debug log:</label>
			' . $debug_select . '
			<label class="forms para" for="dump">Activer le mode dump :</label>
			' . $dump_select . '
			<br><br>
			<label class="forms para" for="submit"></label>
			<input type=submit id=submit style="width: 50ch;" class="btnform1 vert" formaction="' . $valid_href . '" value=Valider>
			</div>
			</form>
			';
		}
	
	}

    $client_list .= '</div></div></fieldset>';
	$content .= '<div class="formulaire1" >' . $client_list . '</div>' ;

    return $content ;
    
} #sub utilisateurs 

sub freeze_session {

    my $r = shift ;

    my $dbh = $r->pnotes('dbh') ;

    #il faut mettre à jour la session
    my $sql = 'update sessions set serialized_session = ?  where session_id = ?';

    my $serialized = Storable::nfreeze($r->pnotes('session'));

    my $sth = $dbh->prepare($sql);

    $sth->bind_param( 1, $serialized,  { pg_type => DBD::Pg::PG_BYTEA } );

    $sth->bind_param( 2, $r->pnotes('session')->{_session_id} );

    $sth->execute();

}

sub categoriedocuments {

    my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array ) ;

    my $content = '
      <fieldset><legend><h3 style="color: green; background-color: #ddefef;">Catégorie des documents</h3></legend>
    ' ;

    #l'utilisateur a cliqué sur le bouton 'Valider', enregistrer les modifications
    if ( $args->{documents} eq '1' ) {

	#suppression d'une catégorie
	if ( defined $args->{delete_doc} ) {

	    #1ère demande de suppression; afficher lien d'annulation/confirmation
	    if ( $args->{delete_doc} eq '0' ) {

		my $non_href = '/'.$r->pnotes('session')->{racine}.'/parametres?documents=0' ;

		my $oui_href = '/'.$r->pnotes('session')->{racine}.'/parametres?documents=1&amp;delete_doc=1&amp;libelle_cat_doc=' . $args->{libelle_cat_doc} ;

		$content .= '<h3 class=warning>Vraiment supprimer la catégorie ' . $args->{libelle_cat_doc} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;

	    } else {

		#demande de suppression confirmée
		$sql = 'DELETE FROM tbldocuments_categorie WHERE libelle_cat_doc = ? AND id_client = ?' ;

		@bind_array = ( $args->{libelle_cat_doc}, $r->pnotes('session')->{id_client} ) ;
		eval {$dbh->do( $sql, undef, @bind_array ) } ;

		if ( $@ ) {
	    if ( $@ =~ /NOT NULL/ ) {
		$content .= '<h3 class=warning>le nom ne peut être vide</h3>' ;
	    } else {
	    $content .= '<h3 class=warning>' . $@ . '</h3>' ;
	    }
		} #	if ( $@ ) 


	    } #	    if ( $args->{delete_doc} eq '0' )

	} 
	

	} #    if ( $args->{documents} eq '1' ) 
    
    
    #l'utilisateur a cliqué sur le bouton 'Valider', ajouter la catégorie
    if ( $args->{valide_doc} eq '1' ) {
	#on interdit libelle vide
	$args->{libelle_cat_doc} ||= undef ;
	
	    #ajouter une catégorie
	    $sql = 'INSERT INTO tbldocuments_categorie (libelle_cat_doc, id_client) values (?, ?)' ;
	    @bind_array = ( $args->{libelle_cat_doc}, $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
	if ( $@ ) {
	    if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>Il faut renseigner le nom de la nouvelle catégorie de document</h3>' ;
	    } elsif ( $@ =~ /existe/ ) {$content .= '<h3 class=warning>Cette catégorie existe déjà</h3>' ;
	    } else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;   }
		}
    }
    
        #l'utilisateur a cliqué sur le bouton 'Valider', modifier le nom de la catégorie
    if ( $args->{maj_doc} eq '1' ) {
	    
   	    #modifier une catégorie
	    $sql = 'UPDATE tbldocuments_categorie set libelle_cat_doc = ? where id_client = ? AND libelle_cat_doc = ? ' ;
	    @bind_array = ( $args->{new_libelle_cat_doc}, $r->pnotes('session')->{id_client}, $args->{old_libelle_cat_doc} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
	if ( $@ ) {
	    if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>le nom ne peut être vide</h3>' ;
	    } else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;   }
		}
    }

    
    $sql = 'SELECT libelle_cat_doc FROM tbldocuments_categorie WHERE id_client = ?' ;

    my $categorie_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    my $categorie_list = '
		<form action=/'.$r->pnotes('session')->{racine}.'/parametres><section class="left">
		<div class="form-section"><h3>Liste des catégories</h3></div>' ;
 
    for ( @$categorie_set ) {

	$categorie_list .= '
		<form style ="display:inline;">
		<input type=hidden name=maj_doc value=1>
		<label class="forms para" for="new_libelle_cat_doc"></label><input class="login-text" type=text name=new_libelle_cat_doc id=new_libelle_cat_doc value="' . $_->{libelle_cat_doc} . '" />
		<input type=hidden name=old_libelle_cat_doc value="' . $_->{libelle_cat_doc} . '">
		<input type=submit value=Valider>
		</form>
		<form style ="display:inline;">
		<input class="login-text" type=hidden name=documents value=1>
		<input type=hidden name=delete_doc value=0><input type=hidden name=libelle_cat_doc value="' . $_->{libelle_cat_doc} . '"><input type=submit value=Supprimer>
		</form>
		' ;
	}
	
	

    $categorie_list .= '</section></form>';

    #formulaire nouvel catégorie de document
    $categorie_list .= '
		<form action=/'.$r->pnotes('session')->{racine}.'/parametres><section class="right">
		<input class="login-text" type=hidden name=valide_doc value=1>
		<div class="form-section"><h3>Nouvelle catégorie</h3></div>
       <label class="forms para" for="libelle_cat_doc">Nom</label><input class="login-text" type=text name=libelle_cat_doc id=libelle_cat_doc value="" /></div>
		<div class="send-container"><input type=submit value=Ajouter></div>
		</form></section></fieldset>
		' ;
	
    $content .= $categorie_list ;
    return $content ;
} #sub categoriedocuments 

sub logout {
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array ) ;
    my $confirm_logout_href = '/'.$r->pnotes('session')->{racine}.'/logout' ;
	my $deny_logout_href = '/'.$r->pnotes('session')->{racine}.'/compte' ;
    my $message = ( 'Voulez-vous vraiment fermer la session de l\'utilisateur ' . $r->pnotes('session')->{'username'} .' ?') . '<a class=nav href="' . $confirm_logout_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_logout_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
    my $content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . $message . '</h3>' ;	
	return $content ;
}#sub logout

sub logs{
	
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########

	#première demande de purge des logs; réclamer confirmation
	if ( defined $args->{purge} and $args->{purge} eq '0') {
	    my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?logs=&amp;purge=1' ;
	    my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/parametres?logs' ;
	    my $message = ( 'Voulez-vous vraiment purger les logs ?') . '<a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
	    $content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . $message . '</h3>' ;
	} 
		
	my $contenu_web .= '
	

	<fieldset><legend><h2 style="color: green; background-color: #ddefef;">Gestion des logs</h2></legend>
	<div style="width: max-content;">
	<div >
	';
		
	my $file = "/var/www/html/Compta/base/logs/Compta.log";
		
	open my $fh, "<:encoding(UTF-8)", $file or die "Could not open $!\n";
	my $line = <$fh>;

	seek  $fh, -5500, SEEK_END;              # move to the beginning of the file 

	while (my $l = <$fh>) {
    chomp $l;
    $contenu_web .= "<br>$l";
	}
	
	close (FH);

		
	$contenu_web .='</div></div></fieldset>';
		
	$content .= '
		
	<div class="wrapper">' . $contenu_web . '</div>
	
	<div class="wrapper centrer"><a style="width : 50%;" class="btnform1 rouge" href="/'.$r->pnotes('session')->{racine}.'/parametres?logs&amp;purge=0">Purger les logs</a></div>
	'
	;
	
	
		
    return $content ;
    	
	
}

sub display_menu {

	my ( $r, $args ) = @_ ;
    
	unless ( defined $args->{societes} || defined $args->{utilisateurs} || defined $args->{sauvegarde_link} || defined $args->{creation} || defined $args->{logs} || defined $args->{achats} || defined $args->{loyer} || defined $args->{recurrent}) {
	   $args->{societes} = 'societes' ;
    } 	
 	
#########################################	
#Filtrage du Menu - Début				#
#########################################		
	my $societes_link = '<a class=' . ( (defined $args->{societes} && not (defined $args->{utilisateurs} ) && not (defined $args->{sauvegarde} ) && not (defined $args->{creation}) && not (defined $args->{logs}) && not (defined $args->{achats})) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?societes" style="margin-left: 3ch;">Fiche sociétés</a>' ;
	my $sauvegarde_link = '<a class=' . ( defined $args->{sauvegarde}  ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde" style="margin-left: 3ch;">Sauvegarde & restauration</a>' ;
	my $utilisateurs_link = '<a class=' . ( (defined $args->{utilisateurs} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?utilisateurs" style="margin-left: 3ch;">Utilisateurs</a>' ;
	my $achats_link = '<a class=' . ( (defined $args->{achats} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?achats" style="margin-left: 3ch;">Achats</a>' ;
	#my $loyer_link = '<a class=' . ( (defined $args->{loyer} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?loyer" style="margin-left: 3ch;">Loyer</a>' ;
	#my $recurrent_link = '<a class=' . ( (defined $args->{recurrent} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?recurrent" style="margin-left: 3ch;">Récurrent</a>' ;
	my $logs_link = '<a class=' . ( (defined $args->{logs} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/parametres?logs" style="margin-left: 3ch;">Logs</a>' ;
	my $content .= '<div class="menu">' . $societes_link . $utilisateurs_link . $sauvegarde_link . $achats_link . $logs_link .'</div>' ;
#########################################	
#Filtrage du Menu - Fin					#
#########################################
    
    return $content ;

} #sub display_menu

1 ;
