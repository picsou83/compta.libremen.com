package Base::Site::bdd;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
###########################################################################################
######              Module dédié aux interactions avec la base de données            ######
###### Ce module fournit des fonctions pour exécuter des requêtes SQL,               ######
###### récupérer et manipuler les données stockées dans une base de données,         ######
###### et effectuer d'autres opérations liées à la persistance des données.          ######
###### Mémo $info_societe->[0]->{etablissement}										 ######
###########################################################################################
use strict;  # Utilisation stricte des variables
use warnings;  # Activation des avertissements
# Modules externes utilisés dans le script
use Time::Piece;       # Gestion des dates et heures
use utf8;              # Encodage UTF-8
use Encode;            # Encodage de caractères
use Apache2::Const -compile => qw( OK REDIRECT ) ;
use DBI;			   # Connexion à la base de données

# Fonction pour récupérer le nombre d'écritures récurrentes ou les écritures récurrentes par année 
# Pour obtenir le compte en attente ($count_en_attente=>1)
#my $nb_recurrent_count = Base::Site::bdd::get_recurrent_data($r, $dbh, 0, 1);
# Pour obtenir les entrées de l'année courante ($count_en_attente=>0 et $year_offset=>0)
#my $recurrent_courantes = Base::Site::bdd::get_recurrent_data($r, $dbh, 0, 0);
# Pour obtenir les entrées de l'année précédente ($count_en_attente=>0 et $year_offset=>-1)
#my $recurrent_annee_precedente = Base::Site::bdd::get_recurrent_data($r, $dbh, -1, 0);
sub get_recurrent_data {
    my ($r, $dbh, $year_offset, $count_en_attente) = @_;

    my $sql;

    if ($count_en_attente) {
        $sql = '
            WITH t1 AS (
                SELECT id_entry, date_ecriture
                FROM tbljournal
                WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
                GROUP BY id_entry, date_ecriture
            )
            SELECT COUNT(id_entry) FROM t1
        ';
    } else {
        $sql = '
            SELECT id_entry, date_ecriture
            FROM tbljournal
            WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
            GROUP BY id_entry, date_ecriture
        ';
    }

    my $fiscal_year = $r->pnotes('session')->{fiscal_year} + $year_offset;
    my @bind_array = ($r->pnotes('session')->{id_client}, $fiscal_year);

    my $result;

    eval {
        if ($count_en_attente) {
            $result = $dbh->selectall_arrayref($sql, undef, @bind_array)->[0]->[0];
        } else {
            $result = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
        }
    };

    if ($@) {
        Base::Site::logs::logEntry("#### WARNING ####", $r->pnotes('session')->{username}, 'bdd.pm => get_recurrent_data => Erreur lors de la requête SQL : ' . $@ .'. ');
        return undef; # Indiquer une erreur
    }

    return $result;
}

# Fonction pour récupérer les documents
# Exemple d'utilisation :
# my $documents = Base::Site::bdd::get_documents($dbh, $id_client, $fiscal_year);
sub get_documents {
    my ($dbh, $id_client, $fiscal_year) = @_;
    my $sql = 'SELECT id_name, fiscal_year FROM tbldocuments WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception';
    my @bind_array = ($id_client, $fiscal_year, $fiscal_year);
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# Fonction pour récupérer les tblconfig_liste
# Exemple d'utilisation :
# my $query_tblconfig_liste = Base::Site::bdd::get_tblconfig_liste($dbh, $r, 'achats');
# my $query_tblconfig_liste = Base::Site::bdd::get_tblconfig_liste($dbh, $r, 'documents');
sub get_tblconfig_liste {
    my ($dbh, $r, $module) = @_;
    my $sql = 'SELECT * FROM tblconfig_liste WHERE id_client = ? AND module = ? ORDER by config_libelle';
    my @bind_array = ($r->pnotes('session')->{id_client}, $module);
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# Fonction pour récupérer les journaux
# Exemple d'utilisation :
# my $journaux = Base::Site::bdd::get_journaux($dbh, $r);
sub get_journaux {
    my ($dbh, $r) = @_;
    my $sql = 'SELECT * FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal';
    my @bind_array = ($r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year});
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# my $tblbilan = Base::Site::bdd::get_tblbilan($dbh, $r, $where);
sub get_tblbilan {
    my ($dbh, $r, $where) = @_;
    my @bind_array = ($r->pnotes('session')->{id_client});
    my $where_clause = '';
    
    if ($where && $where ne '') {
        $where_clause .= ' and bilan_form = ?';
        push @bind_array, $where;
    }
    
    my $sql = 'SELECT * FROM tblbilan WHERE id_client = ?';
    $sql .= $where_clause;
    $sql .= 'ORDER BY bilan_form';
    
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    
    return $content;
}

# my $tblbilan_code = Base::Site::bdd::get_tblbilan_code($dbh, $r, $args);
sub get_tblbilan_code {
    my ($dbh, $r, $args) = @_;

    my $where_clause = '';
    my @bind_array = ( $r->pnotes('session')->{id_client} );
    
    if ($args && $args->{formulaire}) {
        $where_clause .= ' and formulaire = ?';
        push @bind_array, $args->{formulaire};
    }

    if ($args && $args->{code}) {
        $where_clause .= ' and code = ?';
        push @bind_array, $args->{code};
    }
    
    my $sql = <<'SQL';
    SELECT *,
        COALESCE(
            (SELECT code
             FROM tblbilan_code AS tbl_next
             WHERE tbl_next.id_client = tblbilan_code.id_client
               AND tbl_next.formulaire = tblbilan_code.formulaire
               AND tbl_next.exercice NOT LIKE 'formule%'
               AND tbl_next.exercice <> 'divers'
               AND (
                    tbl_next.style_top > tblbilan_code.style_top
                    OR (tbl_next.style_top = tblbilan_code.style_top AND tbl_next.style_left > tblbilan_code.style_left)
                    OR (tbl_next.style_top = tblbilan_code.style_top AND tbl_next.style_left > tblbilan_code.style_left AND tbl_next.code > tblbilan_code.code)
                   )
             ORDER BY tbl_next.style_top ASC, tbl_next.style_left ASC, tbl_next.code ASC
             LIMIT 1),
        (SELECT code
         FROM tblbilan_code AS tbl_next
         WHERE tbl_next.id_client = tblbilan_code.id_client
           AND tbl_next.formulaire = tblbilan_code.formulaire
           AND tbl_next.exercice NOT LIKE 'formule%'
           AND tbl_next.exercice <> 'divers'
           AND tbl_next.code > tblbilan_code.code
         ORDER BY tbl_next.style_top ASC, tbl_next.style_left ASC, tbl_next.code ASC
         LIMIT 1),
        tblbilan_code.code
        ) AS next_code,
        COALESCE(
            (SELECT code
             FROM tblbilan_code AS tbl_prev
             WHERE tbl_prev.id_client = tblbilan_code.id_client
               AND tbl_prev.formulaire = tblbilan_code.formulaire
               AND tbl_prev.exercice NOT LIKE 'formule%'
               AND tbl_prev.exercice <> 'divers'
               AND (
                    tbl_prev.style_top < tblbilan_code.style_top
                    OR (tbl_prev.style_top = tblbilan_code.style_top AND tbl_prev.style_left < tblbilan_code.style_left)
                    OR (tbl_prev.style_top = tblbilan_code.style_top AND tbl_prev.style_left > tblbilan_code.style_left AND tbl_prev.code < tblbilan_code.code)
                   )
             ORDER BY tbl_prev.style_top DESC, tbl_prev.style_left DESC, tbl_prev.code DESC
             LIMIT 1),
        (SELECT code
         FROM tblbilan_code AS tbl_prev
         WHERE tbl_prev.id_client = tblbilan_code.id_client
           AND tbl_prev.formulaire = tblbilan_code.formulaire
           AND tbl_prev.exercice NOT LIKE 'formule%'
           AND tbl_prev.exercice <> 'divers'
           AND tbl_prev.code < tblbilan_code.code
         ORDER BY tbl_prev.style_top DESC, tbl_prev.style_left DESC, tbl_prev.code DESC
         LIMIT 1),
        tblbilan_code.code
        ) AS previous_code
    FROM tblbilan_code
    WHERE id_client = ? 
SQL

    $sql .= $where_clause;
    $sql .= 'ORDER BY style_top ASC, style_left ASC, code ASC';

    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}


# Fonction pour récupérer les catégories de documents
# my $categorie_document = Base::Site::bdd::get_categorie_document($dbh, $r);
sub get_categorie_document {
    my ($dbh, $r) = @_;
    my $sql = 'SELECT libelle_cat_doc FROM tbldocuments_categorie WHERE id_client= ? ORDER BY 1';
    my @bind_array = ($r->pnotes('session')->{id_client});
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# Requête pour récupérer les informations de la société
# Exemple d'utilisation :
# $info_societe->[0]->{etablissement}
# my $info_societe = Base::Site::bdd::get_info_societe($dbh, $r);
sub get_info_societe {
    my ($dbh, $r) = @_;
    my $sql = 'SELECT * FROM compta_client WHERE id_client = ?' ;
    my @bind_array = ($r->pnotes('session')->{id_client});
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# Fonction pour récupérer les informations de toutes les sociétés
# détecte automatiquement si $args->{id_client} 
# my $all_societe = Base::Site::bdd::get_all_societe($dbh, $r, $args);
sub get_all_societe {
    my ($dbh, $r, $args) = @_;

    my $where_clause = '';
    my @bind_values;

    if ($args && $args->{id_client}) {
        $where_clause = ' WHERE id_client = ?';
        push @bind_values, $args->{id_client};
    }

    my $sql = 'SELECT * FROM compta_client' . $where_clause;
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_values);
    
    return $content;
}

# Fonction pour récupérer les informations email smtp
# my $smtp_get = Base::Site::bdd::get_email_smtp($dbh, $r, $args);
sub get_email_smtp {
    my ($dbh, $r, $args) = @_;

    my @bind_array = ($r->pnotes('session')->{id_client});

    my $sql = 'SELECT * FROM tblsmtp WHERE id_client = ?';
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    
    return $content;
}

# Fonction pour récupérer les informations de toutes les sociétés
# détecte automatiquement si $args->{id_client} 
# my $get_all_user = Base::Site::bdd::get_all_user($dbh, $r, $args);
sub get_all_user {
    my ($dbh, $r, $args) = @_;

    my $where_clause = '';
    my @bind_values;

    if ($args && $args->{username}) {
        $where_clause = ' WHERE username = ?';
        push @bind_values, $args->{username};
    }

    my $sql = 'SELECT * FROM compta_user' . $where_clause;
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_values);
    
    return $content;
}

# Fonction pour récupérer les informations des logements $info_societe->[0]->{etablissement}
# my $info_logement = Base::Site::bdd::get_immobilier_logements($dbh, $r, $archive);
sub get_immobilier_logements {
    my ($dbh, $r, $archive) = @_;

    my $archive_condition = "";
    if ($archive && $archive eq 1) {
        $archive_condition = "AND t1.biens_archive = true";
    } elsif ($archive && $archive eq 2) {
        $archive_condition = "AND t1.biens_archive = false";
    }

    my $sql = '
	SELECT DISTINCT biens_ref, biens_ref, t1.id_client, t1.fiscal_year, t1.biens_ref, t1.biens_nom, t1.biens_adresse, t1.biens_cp, t1.biens_ville, t1.biens_surface, t1.biens_compte, t1.biens_com1, t1.biens_com2, t1.biens_archive, t2.numero_compte, t2.libelle_compte
	FROM tblimmobilier_logement t1 
	LEFT JOIN tblcompte t2 ON t1.id_client = t2.id_client AND t1.biens_compte = t2.numero_compte 
	WHERE t1.id_client = ? '.$archive_condition.'';

    my @bind_array = ($r->pnotes('session')->{id_client});
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}


# Fonction pour récupérer les informations des tags $info_societe->[0]->{etablissement}
# my $info_tags = Base::Site::bdd::get_tags_documents($dbh, $r);
sub get_tags_documents {
    my ($dbh, $r) = @_;
    #my $sql = 'SELECT DISTINCT tags_nom FROM tbldocuments_tags t1 LEFT JOIN tbldocuments t2 ON t1.id_client = t2.id_client AND t1.tags_doc = t2.id_name WHERE t1.id_client = ?' ;
    my $sql = '
    SELECT t1.tags_nom AS tags_nom
	FROM tbldocuments_tags t1
	WHERE t1.id_client = ?
	UNION
	SELECT t3.immo_contrat AS tags_nom
	FROM tblimmobilier t3
	WHERE t3.id_client = ?
	UNION
	SELECT t2.biens_ref AS tags_nom
	FROM tblimmobilier_logement t2
	WHERE t2.id_client = ?
	ORDER BY tags_nom ASC;';
    my @bind_array = ($r->pnotes('session')->{id_client}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{id_client});
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# Fonction pour récupérer les informations des baux 
# my $info_tblimmobilier = Base::Site::bdd::get_immobilier_baux($dbh, $r, $archive, $args);
sub get_immobilier_baux {
    my ($dbh, $r, $archive, $args) = @_;

    my $archive_condition = "";
    if ($archive && $archive eq 1) {
        $archive_condition = "AND t1.immo_archive = true";
    } elsif ($archive && $archive eq 2) {
        $archive_condition = "AND t1.immo_archive = false";
    }
    
    my $where_clause = '';
    my @bind_array = ($r->pnotes('session')->{id_client});
    
    if ($args && $args->{immo_contrat}) {
        $where_clause = ' and immo_contrat = ?';
        push @bind_array, $args->{immo_contrat};
    }
    
    my $sql = 'SELECT * FROM tblimmobilier t1 
	LEFT JOIN tblimmobilier_logement t2 ON t1.id_client = t2.id_client AND t1.immo_logement = t2.biens_ref 
	LEFT JOIN tblcompte t3 ON t1.id_client = t3.id_client AND t1.fiscal_year = t3.fiscal_year AND t1.immo_compte = t3.numero_compte
	WHERE t1.id_client = ? '.$archive_condition.' '.$where_clause.'
	ORDER BY immo_contrat' ;
    
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array);
    return $content;
}

# Fonction pour sélectionner les années fiscales distinctes
# Exemple d'utilisation :
# my $parametres_fiscal_year = Base::Site::bdd::get_parametres_fiscal_year($dbh, $r->pnotes('session')->{id_client});
sub get_parametres_fiscal_year {
    my ($dbh, $id_client) = @_;
	# Requête SQL modifiée pour inclure l'année actuelle si elle n'est pas déjà présente
    my $sql = 'SELECT DISTINCT fiscal_year FROM tbljournal WHERE id_client = ? UNION SELECT ? AS fiscal_year ORDER BY fiscal_year';
    
    # Exécuter la requête avec l'année actuelle et récupérer les résultats sous forme de tableau de hachages
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, $id_client, (localtime())[5] + 1900);
    
    return $content;
}

# Fonction pour sélectionner les paramètres de règlements
# Exemple d'utilisation :
# my $parametres_reglements = Base::Site::bdd::get_parametres_reglements($dbh, $r);
# my ($reglement_journal, $reglement_compte, $libelle_compte) = Base::Site::bdd::get_parametres_reglements($dbh, $r, $libelle_recherche);
sub get_parametres_reglements {
    my ($dbh, $r, $libelle_recherche) = @_;
    my $sql = 'SELECT DISTINCT t1.config_libelle, t1.config_compte, t1.config_journal, t1.module, t1.masquer, t2.libelle_compte FROM tblconfig_liste t1
               LEFT JOIN tblcompte t2 ON t1.id_client = t2.id_client AND t1.config_compte = t2.numero_compte
               AND t2.fiscal_year = ?
               WHERE t1.id_client = ? AND t1.module = \'achats\' AND t1.masquer = \'f\' ORDER BY t1.config_libelle';
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client});

    # Si un libellé de recherche est spécifié, retourne les informations correspondantes
    if (defined $libelle_recherche) {
        for my $row (@$content) {
            if ($row->{config_libelle} eq $libelle_recherche) {
                return ($row->{config_journal}, $row->{config_compte}, $row->{libelle_compte});
            }
        }
    }

    return $content;
}

# Fonction pour récupérer les comptes en fonction des numéros de compte spécifiés
# Exemple d'utilisation :
# my $compte_set = Base::Site::bdd::get_comptes_by_classe($dbh, $r, $compte);
# avec $compte all ou vide pour tout les comptes ou bien sous la forme '706,5' séparé par | ; ou ,
sub get_comptes_by_classe {
    my ($dbh, $r, $comptes) = @_;
    # Si l'argument $comptes est défini comme 'all', récupérer tous les comptes
    if (!$comptes || $comptes eq 'all') {
        my $sql = "SELECT * FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER BY numero_compte, libelle_compte";
        my @params = ($r->pnotes('session')->{id_client},  $r->pnotes('session')->{fiscal_year});
        my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @params);
        return $content;
    }
    # Découper la liste de numéros de compte en une liste d'éléments individuels
    my @compte_numbers = split /[,|;]/, $comptes;
    # Construire une liste de placeholders pour les numéros de compte dans la requête SQL
    my $placeholders = join ',', ('?') x @compte_numbers;
    # Construire la requête SQL avec les placeholders
    my $sql = "SELECT * FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND (";
    $sql .= join(' OR ', map { "substring(numero_compte from 1 for " . length($_) . ") = ?" } @compte_numbers);
    $sql .= ") ORDER by numero_compte, libelle_compte";
    my @params = ($r->pnotes('session')->{id_client},  $r->pnotes('session')->{fiscal_year}, @compte_numbers);
    my $content = $dbh->selectall_arrayref($sql, { Slice => {} }, @params);
    return $content;
}

# Sélectionne dans tbljournal_staging un _token_id
#my $result_gen = Base::Site::bdd::get_token_ids($r, $dbh, '%recurrent%');
sub get_token_ids {
    my ($r, $dbh, $token_like) = @_;
    my $sql = 'SELECT _token_id FROM tbljournal_staging WHERE _token_id LIKE ? AND id_client = ? AND fiscal_year = ?';
    
    my $result_gen = eval {
        $dbh->selectall_arrayref($sql, { Slice => {} }, $token_like, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year});
    };

    if ($@) {
        Base::Site::logs::logEntry("#### WARNING ####", $r->pnotes('session')->{username}, 'bdd.pm => get_token_ids => Erreur lors de la requête SQL : ' . $@ .'. ');
        return undef;
    }

    return $result_gen;
}

######################################################################   
# tbljournal_staging et record_staging								 #
######################################################################  

#Nettoie la table tbljournal_staging
#Base::Site::bdd::clean_tbljournal_staging($dbh, $r->pnotes('session')->{_session_id});
sub clean_tbljournal_staging {
    my ($dbh, $session_id) = @_;
    
    # Requête SQL pour supprimer les données
    my $sql = 'DELETE FROM tbljournal_staging WHERE _session_id = ? AND _token_id NOT LIKE \'%recurrent%\' AND _token_id NOT LIKE \'%csv%\'';
    
    # Exécute la requête SQL avec le session_id en paramètre
    $dbh->do($sql, undef, $session_id);
}

#Supprime des éléments dans la table tbljournal_staging
#Base::Site::bdd::delete_tbljournal_staging($r, $dbh, '%recurrent%');
sub delete_tbljournal_staging {
    my ($r, $dbh, $token_like) = @_;
    #on supprime toutes les données concernant le LIKE dans tbljournal_staging pour cet utilisateur
	my $sql = 'DELETE FROM tbljournal_staging WHERE id_client = ? AND _token_id LIKE ?';
    # Exécute la requête SQL avec le session_id en paramètre
    my @bind_array = ($r->pnotes('session')->{id_client}, $token_like);
	$dbh->do( $sql, undef, @bind_array ) ;
}

#my ($return_entry, $error_message) = Base::Site::bdd::call_record_staging($dbh, $_token_id);
sub call_record_staging {
    my ($dbh, $token_id, $id_entry) = @_;
    # Définir la valeur par défaut de $id_entry à 0 si elle n'est pas définie
    $id_entry //= 0;
    my $sql = 'SELECT record_staging(?, ?)';
    my $error_message;  # Variable pour stocker le message d'erreur
    my $return_identry;    # Variable pour stocker la valeur de retour
    my $content_ref = '';  # Initialiser $content_ref comme une chaîne vide

    # Utilisation de eval pour gérer les erreurs potentielles lors de l'exécution de la requête SQL
    eval {
        $return_identry = $dbh->selectall_arrayref($sql, undef, ($token_id, $id_entry))->[0]->[0];
    };

    if ($@) {
        $error_message = $@;  # Stocker le message d'erreur
    }

    if ($error_message) {
        # Gérer l'erreur en générant le contenu d'erreur dans $content_ref
        if ($error_message =~ / NOT NULL (.*) date_ecriture / ) {
            $content_ref .= 'Il faut une date valide - Enregistrement impossible';
        } elsif ($error_message =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/i ) {
			if ($error_message =~ /(.{7})\) is not present/) {
				my $missing_numero_compte = $1;
				$content_ref .= 'Un numéro de compte est invalide - Enregistrement impossible. Numéro de compte manquant : '.$missing_numero_compte.'';
			} else {
				$content_ref .= 'Un numéro de compte est invalide - Enregistrement impossible';
			}
        } elsif ($error_message =~ /unbalanced/i ) {
            $content_ref .= 'Montants déséquilibrés - Enregistrement impossible';
        } elsif ($error_message =~ /bad fiscal/i) {
            $content_ref .= 'La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible';
        } elsif ($error_message =~ /archived/i ) {
            $content_ref .= 'La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible';
        } elsif ($error_message =~ /null value (.*) "numero_compte"/ )  {
            $content_ref .= 'Il faut un numéro de compte pour chaque ligne';
        } else {
            $content_ref .= '' . $error_message . '';
        }
    }

    # Renvoyer à la fois l'ID d'entrée et le contenu d'erreur sous forme de liste
    return ($return_identry, $content_ref);
}

#my $error_message_1 = Base::Site::bdd::call_insert_staging($dbh, \@bind_array1);
#$content .= "Erreur lors de l'insert_staging 1 : $error_message_1<br>" if $error_message_1;
#my $error_message_2 = Base::Site::bdd::call_insert_staging($dbh, \@bind_array2);
#$content .= "Erreur lors de l'insert_staging 2 : $error_message_2<br>" if $error_message_2;
sub call_insert_staging {
    my ($dbh, $bind_array_ref) = @_;
    my $sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, pointage, debit, credit, id_client, id_facture, id_paiement, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, ?)';
  
    # Utilisation de eval pour gérer les erreurs potentielles lors de l'exécution de la requête SQL
    eval {
        $dbh->do($sql, undef, @$bind_array_ref);
    };

    if ($@) {
        return $@;  # Retourner le message d'erreur en cas d'échec
    }

    return '';  # Retourner une chaîne vide en cas de succès
}

# Fonction pour l'insertion dans la base de données avec record_staging dans tbljournal_staging
#my @bind_array1 = ( 
#$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $args->{calcul_piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $token_id, ($args->{docs1} || undef), ($args->{docs2} || undef), 
#$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_fournisseur}, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $args->{calcul_piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $token_id, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
#my $insertion_1 = Base::Site::bdd::call_insert_record_staging($dbh, \@bind_array1, $token_id);
sub call_insert_record_staging {
    my ($dbh, $bind_array_ref, $token_id) = @_;
    
    my $error_message;  # Variable pour stocker le message d'erreur

	my $error_message_1 = call_insert_staging($dbh, $bind_array_ref);
	
	$error_message .= "Erreur lors de l'insert_staging : $error_message_1 <br>" if $error_message_1;

	my ($return_entry, $call_record_staging) = Base::Site::bdd::call_record_staging($dbh, $token_id);

	$error_message .= "Erreur lors de record_staging : $call_record_staging <br>" if $call_record_staging;
    
    if ($error_message) {
        return $error_message;  # Retourner le message d'erreur en cas d'échec
    }

    return '';  # Retourner une chaîne vide en cas de succès

}

1;
