package Base::Site::bilan;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Time::Piece;
use utf8 ;
use Apache2::Const -compile => qw( OK REDIRECT ) ;

sub handler {

    binmode(STDOUT, ":utf8") ;

    my $r = shift ;
	#utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content ;

    my $req = Apache2::Request->new( $r ) ;

    #récupérer les arguments
    my (%args, @args) ;

    #recherche des paramètres de la requête
    @args = $req->param ;

    for ( @args ) {

	$args{ $_ } = Encode::decode_utf8( $req->param($_) ) ;

	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;

    }
   
########### VARIABLE partagée   ###########  
    our $total_form2033B_CC;
    our $total_33C_BK;
    our $resultat_annee_N;
    our $resultat_annee_N1;
    
    unless ( undef $total_form2033B_CC)  {
		formulaire2033_b( $r, \%args );
	}
	
	unless ( undef $total_33C_BK)  {
		formulaire2033_c( $r, \%args );
	}
	
	unless ( undef $resultat_annee_N) {
		resultat( $r, \%args );
	}
	
	unless ( undef $resultat_annee_N1) {
		resultat( $r, \%args );
	}

	if ( defined $args{liasse2033A} ) {

	    $content = formulaire2033_a( $r, \%args ) ;

	} elsif ( defined $args{liasse2033B}) {

	    $content = formulaire2033_b( $r, \%args ) ;

	} elsif ( defined $args{liasse2033C}) {

	    $content = formulaire2033_c( $r, \%args ) ;
	
	} elsif ( defined $args{bilan}) {

	    $content = bilan( $r, \%args ) ;
	    
	} elsif ( defined $args{resultat}) {

	    $content = resultat( $r, \%args ) ;

	} elsif ( defined $args{analyses}) {

	    $content = form_analyses( $r, \%args ) ;

	} else {
		$content = bilan( $r, \%args ) ;
	}

    $r->no_cache(1) ;
    
    $r->content_type('text/html; charset=utf-8') ;

    print $content ;

    return Apache2::Const::OK ;

}

sub formulaire2033_a {
	
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
    my $numero_compte = '0';
    our $resultat_annee_N;
    our $total_33C_BK;
    my $result_12;
    
    #LECTURE POSITION FORMULAIRE EXCEL
    my $file = '/Compta/images/2033ANM1.csv';
    my $location = $r->document_root() . $file ;
    my %data;
    
    #si le fichier existe
	if (-e $location) {
		open(my $fh, '<', $location) or die "Can't read file '$location' [$!]\n";

		my $header = <$fh>;
		chomp $header;
		my @header = split /,/, $header;
		
		while (my $line = <$fh>) {
		chomp $line;

		my %row;
		@row{@header} = split /,/, $line;
		
		my $key = $row{code};
		$data{$key} = \%row;
		
		#variable sous la forme
		#$data{AA}{code}
		#$data{AA}{top}
		#$data{AA}{left}
		#$data{AA}{width}
		#$data{AA}{height}
		}
	}
	
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'bilan.pm => Le fichier existe : '.$data{AC}{style}.' en : '.$data{AC}{code}.'');
	
######## Affichage MENU display_compte_set Début ######
    $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########


######## Selection année N Début######
    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

#to_char(sum(credit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_credit
#to_char(sum(credit-debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_line), \'999G999G999G990D00\') as solde

    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    # variable
	my $total;
   
    for ( @$result_set ) {
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /401/) {
		$_->{numero_compte} = '401'.$_->{numero_compte};	
		}
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /411/) {
		$_->{numero_compte} = '411'.$_->{numero_compte};	
		}
		
		#AA =>Fonds commercial Débit de :	206	207
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{total_debit});$data{AA}{var} += $total;}

		#AB => Autres immobilisations incorporelles : Débit de : 201	203	204	205	208	232	237
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{total_debit});$data{AB}{var} += $total;}

		#AC =>Immobilisations corporelles Débit de :	21	22	231	238
		if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{total_debit});$data{AC}{var} += $total;}
	
		#AD =>Immobilisations financières : Débit de :	25 à 268	271 à 277 Moins le débit de :	259
		if  (
		(substr( $_->{numero_compte}, 0, 2 ) >= 25 && (substr( $_->{numero_compte}, 0, 3 ) <= 268)) ||
		(substr( $_->{numero_compte}, 0, 3 ) =~ /271|272|273|274|275|276|277/)	&&	
		not(substr( $_->{numero_compte}, 0, 3 ) =~ /259/)
		){ (my $total = $_->{total_debit});$data{AD}{var} += $total;}
	
		#AF => Stocks et en cours " Solde débiteur de :	31 à 36	38 Moins le solde débiteur de :	387
		if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /31|32|33|34|35|36|38/)	&&	
		not(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)){ 
			unless ( $_->{numero_compte} eq $numero_compte ) {
			if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
			#if ($_->{solde_debiteur} > 'O'){
			(my $total = $_->{solde_debiteur});$data{AF}{var} += $total ;
			}}
		}
		
		#AG => Stocks de marchandises " Solde débiteur de :	37	387
		if  (
			(substr( $_->{numero_compte}, 0, 2 ) =~ /37/)	||	
			(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
			){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AG}{var} += $total ;
		}		
		}}
	
		#AH => Avances et acomptes versés sur commandes Solde débiteur de :	4091
		if  (substr( $_->{numero_compte}, 0, 4 ) =~ /4091/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AH}{var} += $total ;
		}		
		}}

		#AJ => Créances clients et comptes rattachés Solde débiteur de :	410 à 418
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /410|411|412|413|414|415|416|417|418/
		){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$data{AJ}{var} += $total ;
		}		
		}}
		
		#AK =>Autres créances Solde débiteur de :	16 à 18	400 à 408	4095 à 4098	42 à 45	460	462	465 à 467 4687 à 476 478 481 488 489
		if  (
		(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17|18|42|43|44|45/) ||
		(substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|404|405|406|407|408|460|462|465|466|467|478|481|488|489/) ||
		(substr( $_->{numero_compte}, 0, 4 ) >= 4687 && substr( $_->{numero_compte}, 0, 3 ) <= 476) ||
		(substr( $_->{numero_compte}, 0, 4 ) =~ /4095|4096|4097|4098/)	
		){ 
			unless ( $_->{numero_compte} eq $numero_compte ) {
			if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
			#if ($_->{solde_debiteur} > 'O'){
			(my $total = $_->{solde_debiteur});$data{AK}{var} += $total ;
			}		
		}}
	
		#AL => Valeurs mobilières de placement Solde débiteur de :	501 à 508
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /501|502|503|504|505|506|507|508/
		){ 
			unless ( $_->{numero_compte} eq $numero_compte ) {
			if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
			#if ($_->{solde_debiteur} > 'O'){
			(my $total = $_->{solde_debiteur});$data{AK}{var} += $total ;
			}		
		}}
		
		
		#AM Solde débiteur de : 511 à 517 5187 à 59
		if  (
		(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
		(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
		){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$data{AM}{var} += $total ;
		}}}	
		
		#AP => Charges constatées d'avance Solde débiteur de :	486
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /486/
		){ 
			unless ( $_->{numero_compte} eq $numero_compte ) {
			if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
			#if ($_->{solde_debiteur} > 'O'){
			(my $total = $_->{solde_debiteur});$data{AP}{var} += $total ;
			}		
		}}
		
		#BA => Fonds commercial amort Crédit de :	2807	2906	2907
		if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2807|2906|2907/) {(my $total = $_->{total_credit});$data{BA}{var} += $total;}

		#BB => Autres immobilisations incorporelles amort Crédit de :	2801 2803 2804 2805 2808 2901 2903 2904 2905 2908 2932
		if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2801|2803|2804|2805|2808|2901|2903|2904|2905|2908|2932/) {(my $total = $_->{total_credit});$data{BB}{var} += $total;}
	
		#BC => Immobilisations corporelles amort Crédit de : 281 291 282 292 2931
		if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/)) { (my $total = $_->{credit});$data{BC}{var} += $total;}

		#BD => Immobilisations financières amort "Crédit de : 295 296 297
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /295|296|297/) { (my $total = $_->{total_credit});$data{BD}{var} += $total;}
	
		#BF => Stocks et en cours amort Solde créditeur de : 390 à 396	398 Moins le solde créditeur de :	3987
		if  (
			(substr( $_->{numero_compte}, 0, 3 ) =~ /390|391|392|393|394|395|396|398/)	&&	
			not(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BF}{var} += $total ;
				}		
			}}
			
		#BG => Stocks de marchandises amort "Solde créditeur de :	397	3987
		if  (
			(substr( $_->{numero_compte}, 0, 3 ) =~ /397/) ||	
			(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)

			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BG}{var} += $total ;
				}		
			}}	

		#BH => Avances et acomptes versés sur commandes amort Solde créditeur de :	49091
		if  (substr( $_->{numero_compte}, 0, 5 ) =~ /49091/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BH}{var} += $total ;
				}		
			}}	
			
		#BJ => Créances clients et comptes rattachés amort Solde créditeur de :	491
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /491/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BJ}{var}  += $total ;
				}		
			}}		
			
		#BK => Autres créances amort Solde créditeur de :	495	496
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /495|496/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BJ}{var} += $total ;
				}		
			}}		
		
		#BL => Valeurs mobilières de placement amort Solde créditeur de :	590
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /590/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BL}{var} += $total ;
				}		
			}}	
			
		#BM =>  Disponibilités : amort Solde créditeur de :	591	594
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /591|594/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$data{BM}{var} += $total ;
				}		
			}}			
	
		#EE Autres dettes Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| (substr( $_->{numero_compte}, 0, 3 ) >= 427 && substr( $_->{numero_compte}, 0, 4 ) <= 4286 && substr( $_->{numero_compte}, 0, 3 ) <= 428)
		|| (substr( $_->{numero_compte}, 0, 3 ) >= 431 && substr( $_->{numero_compte}, 0, 4 ) <= 4386 && substr( $_->{numero_compte}, 0, 3 ) <= 438)
		|| (substr( $_->{numero_compte}, 0, 4 ) >= 4411 && substr( $_->{numero_compte}, 0, 4 ) <= 4487 && substr( $_->{numero_compte}, 0, 3 ) <= 448)
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		#(my $total = $_->{solde_crediteur});$data{EE}{var} += $total ;
		}}}
		
		#EE Solde créditeur de : 455
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /455/) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$data{EE}{var} += ($total - $total2);
		}
		
		#FA Capital social (dont versé :) Solde créditeur de :	101 Crédit de :	108 Moins le solde débiteur de :	109
		if(substr( $_->{numero_compte}, 0, 3 ) =~ /101|108/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FA}{var} += $total ;}}}	
		
		#FB => Ecart de réévaluation Crédit de :	105	107
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /105|107/) {(my $total = $_->{total_credit});$data{FB}{var} += $total;}
		
		#FC Réserve légale Solde créditeur de :	1061
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1061/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FC}{var} += $total ;}}}
		
		#FD Réserves réglementées Solde créditeur de :	1062	1064
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1062|1064/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FD}{var} += $total ;}}}	
		
		#FE Autres réserves Solde créditeur de :	104	1063	1068
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /104/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /1063|1068/)) {
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FE}{var} += $total ;}}}	
		
	    #FF => Report à nouveau Crédit de :	11
		if  (substr( $_->{numero_compte}, 0, 2 ) =~ /11/) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$data{FF}{var} += ($total - $total2);}
		
		#FG => Résultat de l'exercice (Bénéfice ou Perte) CLASSE7 - CLASSE 6
		if	((substr( $_->{numero_compte}, 0, 1) =~ /6|7/) ) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$data{FG}{var} += ($total - $total2);}
		
		#$result_12 => Résultat de l'exercice (Bénéfice ou Perte) 120 ; - 129 D
		if	((substr( $_->{numero_compte}, 0, 2) =~ /12/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /129/)) {
		(my $total = $_->{total_credit} - $_->{total_debit});$data{FG}{var} += $total;}
		
		#FH Provisions réglementées Solde créditeur de :	131 à 138	14 Moins le solde débiteur de :	139
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /131|132|133|134|135|136|137|138/) ||(substr( $_->{numero_compte}, 0, 2 ) =~ /14/)
		&& not(substr( $_->{numero_compte}, 0, 3 ) =~ /139/)){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FH}{var} += $total ;}}}	
		
		#FK Provisions pour risques et charges Solde créditeur de :	15
		if	(substr( $_->{numero_compte}, 0, 2 ) =~ /15/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FK}{var} += $total ;}}}	
		
		#FL Emprunts et dettes assimilées "Solde créditeur de :	16 à 17	426	451	456	458	512 à 517	5181	5186	519 à 58
		if	(((substr( $_->{numero_compte}, 0, 2 ) >= 16) && (substr( $_->{numero_compte}, 0, 2 ) <= 17))
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458|512|513|514|515|516|517/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 2 ) >= 51) && (substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 2 ) <= 58))){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FL}{var} += $total ;}}

		}
		
		#FM Avances et acomptes reçus sur commandes en cours "Solde créditeur de :	4191
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /4191/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FM}{var} += $total ;}}}		
		
		#FN Dettes fournisseurs et comptes rattachés "Solde créditeur de :	400 à 403	408 Moins le solde créditeur de :	4084
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|408/)	&& not(substr( $_->{numero_compte}, 0, 4 ) =~ /4084/)
			){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FN}{var} += $total ;}}}		

		#FP Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| (substr( $_->{numero_compte}, 0, 3 ) >= 427 && substr( $_->{numero_compte}, 0, 4 ) <= 4286 && substr( $_->{numero_compte}, 0, 3 ) <= 428)
		|| (substr( $_->{numero_compte}, 0, 3 ) >= 431 && substr( $_->{numero_compte}, 0, 4 ) <= 4386 && substr( $_->{numero_compte}, 0, 3 ) <= 438)
		|| (substr( $_->{numero_compte}, 0, 4 ) >= 4411 && substr( $_->{numero_compte}, 0, 4 ) <= 4487)
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		#$content .= 'total debit ' . $_->{numero_compte} . ' et ' . $_->{total_debit} . ' solde debiteur ' . $_->{numero_compte} . ' et ' . $_->{solde_debiteur}. ' solde crediteur' . $_->{numero_compte} . ' et ' . $_->{solde_crediteur};
		
		#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'bilan.pm => total debit ' . $_->{numero_compte} . ' et ' . $_->{total_debit} . ' solde debiteur ' . $_->{numero_compte} . ' et ' . $_->{solde_debiteur}. ' solde crediteur' . $_->{numero_compte} . ' et ' . $_->{solde_crediteur} );
			
		#if ($_->{solde_crediteur} > 'O'){
		
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'bilan.pm => Yes total debit ' . $_->{numero_compte} . ' et ' . $_->{total_debit} . ' solde debiteur ' . $_->{numero_compte} . ' et ' . $_->{solde_debiteur}. ' solde crediteur' . $_->{numero_compte} . ' et ' . $_->{solde_crediteur} );
			
		(my $total = $_->{solde_crediteur});$data{FP}{var} += $total ;
		}

	    }}
	    
	    #FQ Produits constatés d'avance Solde créditeur de :	487
		if	(substr( $_->{numero_compte}, 0, 3 ) =~ /487/){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{FQ}{var} += $total ;}}}	
		
		#HC Solde débiteur de : 455
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /455/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{HC}{var} += $total ;
		}		
		}}
		$numero_compte = $_->{numero_compte} ;
	
	} #  fin for ( @$result_set ) {
		
############### ANNEE N #################   

################# ANNEE N-1 #################   

	### Déclaration des variables

    my @actif_N1 = ('0') x 80;
    my @actif_total_N1 = ('0') x 80;
    my @passif_N1 = ('0') x 30;
    my @passif_total_N1 = ('0') x 10;
    my @actif_totaux_N1 = ('0') x 15;
    my @passif_totaux_N1 = ('0') x 10;
    
    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, (($r->pnotes('session')->{fiscal_year} ) -1)) ;
    my $result_set_N1 = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    for ( @$result_set_N1 ) {
	
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /401/) {
		$_->{numero_compte} = '401'.$_->{numero_compte};	
		}
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /411/) {
		$_->{numero_compte} = '411'.$_->{numero_compte};	
		}
################# ACTIF #################	 

		#$actif_N1[0] =>Fonds commercial Débit de :	206	207
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{total_debit});$actif_N1[0] += $total;}
		#$actif_N1[1] => Fonds commercial amort Crédit de :	2807	2906	2907
		if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2807|2906|2907/) {(my $total = $_->{total_credit});$actif_N1[1] += $total;}

		#$actif_N1[2] => Autres immobilisations incorporelles : Débit de : 201	203	204	205	208	232	237
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{total_debit});$actif_N1[2] += $total;}
		#$actif_N1[3] => Autres immobilisations incorporelles amort Crédit de :	2801 2803 2804 2805 2808 2901 2903 2904 2905 2908 2932
		if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2801|2803|2804|2805|2808|2901|2903|2904|2905|2908|2932/) {(my $total = $_->{total_credit});$actif_N1[3] += $total;}
			
		#$actif_N1[4] =>Immobilisations corporelles Débit de :	21	22	231	238
		if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{total_debit});$actif_N1[4] += $total;}
		#$actif_N1[5] => Immobilisations corporelles amort Crédit de : 281 291 282 292 2931
		if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/)) { (my $total = $_->{credit});$actif_N1[5] += $total;}

		#$actif_N1[6] =>Immobilisations financières : Débit de :	25 à 268	271 à 277 Moins le débit de :	259
		if  (
			(substr( $_->{numero_compte}, 0, 2 ) >= 25 && (substr( $_->{numero_compte}, 0, 3 ) <= 268)) ||
			(substr( $_->{numero_compte}, 0, 3 ) =~ /271|272|273|274|275|276|277/)	&&	
			not(substr( $_->{numero_compte}, 0, 3 ) =~ /259/)
			){ (my $total = $_->{total_debit});$actif_N1[6] += $total;}
		#$actif_N1[7] => Immobilisations financières amort "Crédit de : 295 296 297
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /295|296|297/) { (my $total = $_->{total_credit});$actif_N1[7] += $total;}
			

		#$actif_N1[8] => Stocks et en cours " Solde débiteur de :	31 à 36	38 Moins le solde débiteur de :	387
		if  (
			(substr( $_->{numero_compte}, 0, 2 ) =~ /31|32|33|34|35|36|38/)	&&	
			not(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[8] += $total ;
				}		
			}}
		#$actif_N1[9] => Stocks et en cours amort Solde créditeur de : 390 à 396	398 Moins le solde créditeur de :	3987
		if  (
			(substr( $_->{numero_compte}, 0, 3 ) =~ /390|391|392|393|394|395|396|398/)	&&	
			not(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[9] += $total ;
				}		
			}}
			
		#$actif_N1[10] => Stocks de marchandises " Solde débiteur de :	37	387
		if  (
			(substr( $_->{numero_compte}, 0, 2 ) =~ /37/)	||	
			(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[10] += $total ;
				}		
			}}
		#$actif_N1[11] => Stocks de marchandises amort "Solde créditeur de :	397	3987
		if  (
			(substr( $_->{numero_compte}, 0, 3 ) =~ /397/) ||	
			(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)

			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[11] += $total ;
				}		
			}}
			

		#$actif_N1[12] => Avances et acomptes versés sur commandes Solde débiteur de :	4091
		if  (substr( $_->{numero_compte}, 0, 4 ) =~ /4091/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				(my $total = $_->{solde_debiteur});$actif_N1[12] += $total ;
				}		
			}}
		#$actif_N1[13] => Avances et acomptes versés sur commandes amort Solde créditeur de :	49091
		if  (substr( $_->{numero_compte}, 0, 5 ) =~ /49091/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[13] += $total ;
				}		
			}}	
			

		#$actif_N1[14] => Créances clients et comptes rattachés Solde débiteur de :	410 à 418
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /410|411|412|413|414|415|416|417|418/
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[14] += $total ;
				}		
			}}
		#$actif_N1[15] => Créances clients et comptes rattachés amort Solde créditeur de :	491
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /491/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[15] += $total ;
				}		
			}}		
			

		#$actif_N1[16] =>Autres créances Solde débiteur de :	16 à 18	400 à 408	4095 à 4098	42 à 45	460	462	465 à 467 4687 à 476 478 481 488 489
		if  (
			(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17|18|42|43|44|45/) ||
			(substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|404|405|406|407|408|460|462|465|466|467|478|481|488|489/) ||
			(substr( $_->{numero_compte}, 0, 4 ) >= 4687 && (substr( $_->{numero_compte}, 0, 3 ) <= 476)) ||
			(substr( $_->{numero_compte}, 0, 4 ) =~ /4095|4096|4097|4098/)	
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[16] += $total ;
				}		
			}}
		#$actif_N1[17] => Autres créances amort Solde créditeur de :	495	496
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /495|496/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[17] += $total ;
				}		
			}}		

		#$actif_N1[18] => Valeurs mobilières de placement Solde débiteur de :	501 à 508
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /501|502|503|504|505|506|507|508/
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[18] += $total ;
				}		
			}}
		#$actif_N1[19] => Valeurs mobilières de placement amort Solde créditeur de :	590
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /590/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[19] += $total ;
				}		
			}}	
			
		#$actif_N1[20] => Disponibilités : Solde débiteur de :	511 à 517	5187 à 59
		if  (
			(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
			(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[20] += $total ;
				}		
			}}
		#$actif_N1[21] =>  Disponibilités : amort Solde créditeur de :	591	594
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /591|594/	){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
				(my $total = $_->{solde_crediteur});$actif_N1[21] += $total ;
				}		
			}}	

		#$actif_N1[22] => Charges constatées d'avance Solde débiteur de :	486
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /486/
			){ 
				unless ( $_->{numero_compte} eq $numero_compte ) {
				if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
				#if ($_->{solde_debiteur} > 'O'){
				(my $total = $_->{solde_debiteur});$actif_N1[22] += $total ;
				}		
			}}
	
################# ACTIF #################	 

#################PASSIF#################
		#$passif_N1[0] $data{GA}{var} Capital social (dont versé :) Solde créditeur de :	101 Crédit de :	108 Moins le solde débiteur de :	109
		if(substr( $_->{numero_compte}, 0, 3 ) =~ /101/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GA}{var} += $total ;}}}	
		#$passif_N1[0] $data{GA}{var} => Capital social Crédit de :	108
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /108/) {(my $total = $_->{total_credit});$data{GA}{var} += $total;}
		#$passif_N1[0] $data{GA}{var} => Capital social Moins le solde débiteur de :	109
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /109/	){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{GA}{var} -= $total ;}}}	
		
		#$passif_N1[1] $data{GB}{var} => Ecart de réévaluation Crédit de :	105	107
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /105|107/) {(my $total = $_->{total_credit});$data{GB}{var} += $total;}
		
		#$passif_N1[2] $data{GC}{var} Réserve légale Solde créditeur de :	1061
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1061/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GC}{var} += $total ;}}}	
		
		#$passif_N1[3] $data{GD}{var} Réserves réglementées Solde créditeur de :	1062	1064
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1062|1064/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GD}{var} += $total ;}}}	
		
		#$passif_N1[4] $data{GE}{var} Autres réserves Solde créditeur de :	104	1063	1068
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /104/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /1063|1068/)) {
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GE}{var} += $total ;}}}	
		
		#$passif_N1[5] $data{GF}{var} => Report à nouveau Crédit de :	11
		if  (substr( $_->{numero_compte}, 0, 2 ) =~ /11/) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$data{GF}{var} += ($total - $total2);}
		
		
		#GG => Résultat de l'exercice (Bénéfice ou Perte) CLASSE7 - CLASSE 6
		if	((substr( $_->{numero_compte}, 0, 1) =~ /6|7/) ) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$data{GG}{var} += ($total - $total2);}
		
		#$passif_N1[6] $data{GG}{var} => Résultat de l'exercice (Bénéfice ou Perte) 120 ; - 129 D
		if	((substr( $_->{numero_compte}, 0, 2) =~ /12/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /129/)) {
		(my $total = $_->{total_credit} - $_->{total_debit});$data{GG}{var} += $total;}
		

		#$passif_N1[7] $data{GH}{var} Provisions réglementées Solde créditeur de :	131 à 138	14 Moins le solde débiteur de :	139
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /131|132|133|134|135|136|137|138/) ||(substr( $_->{numero_compte}, 0, 2 ) =~ /14/)
		&& not(substr( $_->{numero_compte}, 0, 3 ) =~ /139/)){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GH}{var} += $total ;}}}	

		#$passif_N1[14] $data{GK}{var} Provisions pour risques et charges Solde créditeur de :	15
		if	(substr( $_->{numero_compte}, 0, 2 ) =~ /15/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GK}{var} += $total ;}}}	


	    #$passif_N1[8] $data{GL}{var} Emprunts et dettes assimilées "Solde créditeur de :	16 à 17	426	451	456	458	512 à 517	5181	5186	519 à 58
		if	(((substr( $_->{numero_compte}, 0, 2 ) >= 16) && (substr( $_->{numero_compte}, 0, 2 ) <= 17))
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458|512|513|514|515|516|517/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 2 ) >= 51) && (substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 2 ) <= 58))){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GL}{var} += $total ;}}}	
	    
	    #$passif_N1[9] $data{GM}{var} Avances et acomptes reçus sur commandes en cours "Solde créditeur de :	4191
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /4191/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GM}{var} += $total ;}}}	
	    
	    #$passif_N1[10] $data{GN}{var} Dettes fournisseurs et comptes rattachés "Solde créditeur de :	400 à 403	408 Moins le solde créditeur de :	4084
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|408/)	&& not(substr( $_->{numero_compte}, 0, 4 ) =~ /4084/)
			){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GN}{var} += $total ;}}}		
	    	
		#$passif_N1[11] $data{GP}{var} Autres dettes Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 427) && (substr( $_->{numero_compte}, 0, 4 ) <= 4286) && (substr( $_->{numero_compte}, 0, 3 ) <= 428))
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 431) && (substr( $_->{numero_compte}, 0, 4 ) <= 4386) && (substr( $_->{numero_compte}, 0, 3 ) <= 438))
		||	((substr( $_->{numero_compte}, 0, 4 ) >= 4411) && (substr( $_->{numero_compte}, 0, 4 ) <= 4487) && (substr( $_->{numero_compte}, 0, 3 ) <= 448))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GP}{var} += $total ;}}}
	
	    #$passif_N1[12] $data{GQ}{var} Produits constatés d'avance Solde créditeur de :	487
		if	(substr( $_->{numero_compte}, 0, 3 ) =~ /487/){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{GQ}{var} += $total ;}}}	

#################PASSIF#################

		$numero_compte = $_->{numero_compte} ;
	
		
	}

########## DEBUT AFFICHAGE VALUE SANS ARRONDIES ##########

	
		# Préparation calculs des totaux avec arrondies
		
		foreach my $value_numbers ( 
		#variable
		$data{AA}{var},$data{AB}{var},$data{AC}{var},$data{AD}{var},$data{AF}{var},$data{AG}{var},$data{AH}{var},$data{AJ}{var},$data{AK}{var},$data{AL}{var},$data{AM}{var},$data{AP}{var},
		$data{BA}{var},$data{BB}{var},$data{BC}{var},$data{BD}{var},$data{BF}{var},$data{BG}{var},$data{BH}{var},$data{BJ}{var},$data{BK}{var},$data{BL}{var},$data{BM}{var},$data{BP}{var},
		$data{EE}{var},
		$data{FA}{var},$data{FB}{var},$data{FC}{var},$data{FD}{var},$data{FE}{var},$data{FF}{var},$data{FG}{var},$data{FH}{var},$data{FK}{var},$data{FL}{var},$data{FM}{var},$data{FN}{var},$data{FP}{var},$data{FQ}{var},
		$data{GA}{var},$data{GB}{var},$data{GC}{var},$data{GD}{var},$data{GE}{var},$data{GF}{var},$data{GG}{var},$data{GH}{var},$data{GL}{var},$data{GM}{var},$data{GN}{var},$data{GP}{var},$data{GQ}{var},
		$data{HC}{var},
		$data{JB}{var},$data{JC}{var},
		,@actif_N1,@passif_N1
		) {
		if(  defined ($value_numbers) ) {
		if (($value_numbers=~/\d/) && ($value_numbers > 0) && ( $value_numbers < 999999999999999) ){
		#if( $value_numbers !=  ''){
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; 		
		#$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} elsif (($value_numbers=~/\d/) && ($value_numbers < 0) && ($value_numbers > -999999999999999)) {
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; 	
		} else { $value_numbers = '';}} else {$value_numbers = '';}}
		
    #Récupérations des informations de la société
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, fiscal_year_start, adresse_1, code_postal, ville FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
   
	#calcul nb mois exercice
	my $date_month_start = Time::Piece->strptime( $r->pnotes('session')->{Exercice_debut_YMD}, "%Y-%m-%d" );
	my $date_month_end = Time::Piece->strptime( $r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d" );
	my $dateN1_month_end = Time::Piece->strptime( $r->pnotes('session')->{Exercice_fin_DMY_N1}, "%d/%m/%Y" );
	my $time_diff_month = int((($date_month_end - $date_month_start)->months)+ 0.5);
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'bilan.pm => nbmois : '.$time_diff_month.' en : ');
	
	my $time_diff_month_N1;
	
	if ($parametre_set->[0]->{date_fin} eq $r->pnotes('session')->{Exercice_fin_DMY_N1}) {
	my $date_month_startN1 = Time::Piece->strptime( $parametre_set->[0]->{date_debut}, "%d/%m/%Y" );
	$time_diff_month_N1 = int((($dateN1_month_end - $date_month_startN1)->months)+ 0.5);	
	} else {
	my $time_diff_month_N1 = $time_diff_month;
	}
	
	

		
		$content .= '
		<div class="titre-non-printable">
		<h3 class="page-subtitle">2033-A Bilan simplifié<a class="aperso" href="/Compta/images/2033-NOT-2021.pdf" target="_blank">#notice2033</a> </h3></div>
		<div class="wrapper-forms" style="background-image: url(/Compta/images/2033ANM1.png);width:960px; height:1323px;position:relative">
		<div class="general-info" style="top:86px; left:188px">'.$parametre_set->[0]->{etablissement} . ' - SIRET : ' . $parametre_set->[0]->{siret} . '</div>
		<div title="nb mois exercice" class="general-info" style="top:113px; left:296px">'.($time_diff_month|| '').'</div>
		<div title="nb mois exercice n-1" class="general-info" style="top:113px; left:601px">'.($time_diff_month_N1 || '').'</div>
		<div title="exercice clos le" class="general-info" style="top:166px; left:700px">'.$r->pnotes('session')->{Exercice_fin_DMY}.'</div>
		<div title="exercice n-1 clos le" class="general-info" style="top:166px; left:848px">'.$r->pnotes('session')->{Exercice_fin_DMY_N1}.'</div>
		<div id=AA class=general-value '.$data{AA}{style}.' '.Encode::decode_utf8($data{AA}{title}||'').'>'.$data{AA}{var}.' </div>
		<div id=AB class=general-value '.$data{AB}{style}.' '.Encode::decode_utf8($data{AB}{title}||'').'>'.$data{AB}{var}.' </div>
		<div id=AC class=general-value '.$data{AC}{style}.' '.Encode::decode_utf8($data{AC}{title}||'').'>'.$data{AC}{var}.' </div>
		<div id=AD class=general-value '.$data{AD}{style}.' '.Encode::decode_utf8($data{AD}{title}||'').'>'.$data{AD}{var}.' </div>
		<div id=AF class=general-value '.$data{AF}{style}.' '.Encode::decode_utf8($data{AF}{title}||'').'>'.$data{AF}{var}.' </div>
		<div id=AG class=general-value '.$data{AG}{style}.' '.Encode::decode_utf8($data{AG}{title}||'').'>'.$data{AG}{var}.' </div>
		<div id=AH class=general-value '.$data{AH}{style}.' '.Encode::decode_utf8($data{AH}{title}||'').'>'.$data{AH}{var}.' </div>
		<div id=AJ class=general-value '.$data{AJ}{style}.' '.Encode::decode_utf8($data{AJ}{title}||'').'>'.$data{AJ}{var}.' </div>
		<div id=AK class=general-value '.$data{AK}{style}.' '.Encode::decode_utf8($data{AK}{title}||'').'>'.$data{AK}{var}.' </div>
		<div id=AL class=general-value '.$data{AL}{style}.' '.Encode::decode_utf8($data{AL}{title}||'').'>'.$data{AL}{var}.' </div>
		<div id=AM class=general-value '.$data{AM}{style}.' '.Encode::decode_utf8($data{AM}{title}||'').'>'.$data{AM}{var}.' </div>
		<div id=AP class=general-value '.$data{AP}{style}.' '.Encode::decode_utf8($data{AP}{title}||'').'>'.$data{AP}{var}.' </div>
		<div id=BA class=general-value '.$data{BA}{style}.' '.Encode::decode_utf8($data{BA}{title}||'').'>'.$data{BA}{var}.' </div>
		<div id=BB class=general-value '.$data{BB}{style}.' '.Encode::decode_utf8($data{BB}{title}||'').'>'.$data{BB}{var}.' </div>
		<div id=BC class=general-value '.$data{BC}{style}.' '.Encode::decode_utf8($data{BC}{title}||'').'>'.$data{BC}{var}.' </div>
		<div id=BD class=general-value '.$data{BD}{style}.' '.Encode::decode_utf8($data{BD}{title}||'').'>'.$data{BD}{var}.' </div>
		<div id=BF class=general-value '.$data{BF}{style}.' '.Encode::decode_utf8($data{BF}{title}||'').'>'.$data{BF}{var}.' </div>
		<div id=BG class=general-value '.$data{BG}{style}.' '.Encode::decode_utf8($data{BG}{title}||'').'>'.$data{BG}{var}.' </div>
		<div id=BH class=general-value '.$data{BH}{style}.' '.Encode::decode_utf8($data{BH}{title}||'').'>'.$data{BH}{var}.' </div>
		<div id=BJ class=general-value '.$data{BJ}{style}.' '.Encode::decode_utf8($data{BJ}{title}||'').'>'.$data{BJ}{var}.' </div>
		<div id=BK class=general-value '.$data{BK}{style}.' '.Encode::decode_utf8($data{BK}{title}||'').'>'.$data{BK}{var}.' </div>
		<div id=BL class=general-value '.$data{BL}{style}.' '.Encode::decode_utf8($data{BL}{title}||'').'>'.$data{BL}{var}.' </div>
		<div id=BM class=general-value '.$data{BM}{style}.' '.Encode::decode_utf8($data{BM}{title}||'').'>'.$data{BM}{var}.' </div>
		<div id=EE class=general-value '.$data{EE}{style}.' '.Encode::decode_utf8($data{EE}{title}||'').'>'.$data{EE}{var}.' </div>
		<div id=FA class=general-value '.$data{FA}{style}.' '.Encode::decode_utf8($data{FA}{title}||'').'>'.$data{FA}{var}.' </div>
		<div id=FB class=general-value '.$data{FB}{style}.' '.Encode::decode_utf8($data{FB}{title}||'').'>'.$data{FB}{var}.' </div>
		<div id=FC class=general-value '.$data{FC}{style}.' '.Encode::decode_utf8($data{FC}{title}||'').'>'.$data{FC}{var}.' </div>
		<div id=FD class=general-value '.$data{FD}{style}.' '.Encode::decode_utf8($data{FD}{title}||'').'>'.$data{FD}{var}.' </div>
		<div id=FE class=general-value '.$data{FE}{style}.' '.Encode::decode_utf8($data{FE}{title}||'').'>'.$data{FE}{var}.' </div>
		<div id=FF class=general-value '.$data{FF}{style}.' '.Encode::decode_utf8($data{FF}{title}||'').'>'.$data{FF}{var}.' </div>
		<div id=FG class=general-value '.$data{FG}{style}.' '.Encode::decode_utf8($data{FG}{title}||'').'>'.$data{FG}{var}.' </div>
		<div id=FH class=general-value '.$data{FH}{style}.' '.Encode::decode_utf8($data{FH}{title}||'').'>'.$data{FH}{var}.' </div>
		<div id=FK class=general-value '.$data{FK}{style}.' '.Encode::decode_utf8($data{FK}{title}||'').'>'.$data{FK}{var}.' </div>
		<div id=FL class=general-value '.$data{FL}{style}.' '.Encode::decode_utf8($data{FL}{title}||'').'>'.$data{FL}{var}.' </div>
		<div id=FM class=general-value '.$data{FM}{style}.' '.Encode::decode_utf8($data{FM}{title}||'').'>'.$data{FM}{var}.' </div>
		<div id=FN class=general-value '.$data{FN}{style}.' '.Encode::decode_utf8($data{FN}{title}||'').'>'.$data{FN}{var}.' </div>
		<div id=FP class=general-value '.$data{FP}{style}.' '.Encode::decode_utf8($data{FP}{title}||'').'>'.$data{FP}{var}.' </div>
		<div id=FQ class=general-value '.$data{FQ}{style}.' '.Encode::decode_utf8($data{FQ}{title}||'').'>'.$data{FQ}{var}.' </div>
		<div id=GA class=general-value '.$data{GA}{style}.' '.Encode::decode_utf8($data{GA}{title}||'').'>'.$data{GA}{var}.' </div>
		<div id=GB class=general-value '.$data{GB}{style}.' '.Encode::decode_utf8($data{GB}{title}||'').'>'.$data{GB}{var}.' </div>
		<div id=GC class=general-value '.$data{GC}{style}.' '.Encode::decode_utf8($data{GC}{title}||'').'>'.$data{GC}{var}.' </div>
		<div id=GD class=general-value '.$data{GD}{style}.' '.Encode::decode_utf8($data{GD}{title}||'').'>'.$data{GD}{var}.' </div>
		<div id=GE class=general-value '.$data{GE}{style}.' '.Encode::decode_utf8($data{GE}{title}||'').'>'.$data{GE}{var}.' </div>
		<div id=GF class=general-value '.$data{GF}{style}.' '.Encode::decode_utf8($data{GF}{title}||'').'>'.$data{GF}{var}.' </div>
		<div id=GG class=general-value '.$data{GG}{style}.' '.Encode::decode_utf8($data{GG}{title}||'').'>'.$data{GG}{var}.' </div>
		<div id=GH class=general-value '.$data{GH}{style}.' '.Encode::decode_utf8($data{GH}{title}||'').'>'.$data{GH}{var}.' </div>
		<div id=GL class=general-value '.$data{GL}{style}.' '.Encode::decode_utf8($data{GL}{title}||'').'>'.$data{GL}{var}.' </div>
		<div id=GM class=general-value '.$data{GM}{style}.' '.Encode::decode_utf8($data{GM}{title}||'').'>'.$data{GM}{var}.' </div>
		<div id=GN class=general-value '.$data{GN}{style}.' '.Encode::decode_utf8($data{GN}{title}||'').'>'.$data{GN}{var}.' </div>
		<div id=GP class=general-value '.$data{GP}{style}.' '.Encode::decode_utf8($data{GP}{title}||'').'>'.$data{GP}{var}.' </div>
		<div id=GQ class=general-value '.$data{GQ}{style}.' '.Encode::decode_utf8($data{GQ}{title}||'').'>'.$data{GQ}{var}.' </div>
		<div id=HC class=general-value '.$data{HC}{style}.' '.Encode::decode_utf8($data{HC}{title}||'').'>'.$data{HC}{var}.' </div>
		<div id=JC class=general-value '.$data{JC}{style}.' '.Encode::decode_utf8($data{JC}{title}||'').'>'.$data{JC}{var}.' </div>
		';
	
########## FIN AFFICHAGE VALUE SANS ARRONDIES ##########


		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$data{AA}{var},$data{AB}{var},$data{AC}{var},$data{AD}{var},$data{AF}{var},$data{AG}{var},$data{AH}{var},$data{AJ}{var},$data{AK}{var},$data{AL}{var},$data{AM}{var},$data{AP}{var},
		$data{BA}{var},$data{BB}{var},$data{BC}{var},$data{BD}{var},$data{BF}{var},$data{BG}{var},$data{BH}{var},$data{BJ}{var},$data{BK}{var},$data{BL}{var},$data{BM}{var},$data{BP}{var},
		$data{EE}{var},
		$data{FA}{var},$data{FB}{var},$data{FC}{var},$data{FD}{var},$data{FE}{var},$data{FF}{var},$data{FG}{var},$data{FH}{var},$data{FK}{var},$data{FL}{var},$data{FM}{var},$data{FN}{var},$data{FP}{var},$data{FQ}{var},
		$data{GA}{var},$data{GB}{var},$data{GC}{var},$data{GD}{var},$data{GE}{var},$data{GF}{var},$data{GG}{var},$data{GH}{var},$data{GL}{var},$data{GM}{var},$data{GN}{var},$data{GP}{var},$data{GQ}{var},
		$data{HC}{var},
		$data{JB}{var},$data{JC}{var},
		,@actif_N1,@passif_N1
		) {
		$value_numbers =~ s/\,/\./g;
		if(($value_numbers=~/\d/) && ($value_numbers >= 0) && ($value_numbers < 999999999999999)){
		$value_numbers = int(($value_numbers)+ 0.5) ;
		} elsif (($value_numbers=~/\d/) && ($value_numbers < 0) && ($value_numbers > -999999999999999)) {
		$value_numbers = int(($value_numbers)- 0.5) ;
		} else { 
		$value_numbers = '0';
		}}

		#Calcul des totaux
		################# ANNEE N  #################	
		
		$data{AE}{var} = $data{AA}{var} + $data{AB}{var} + $data{AC}{var} + $data{AD}{var};
		$data{AQ}{var} = $data{AF}{var} + $data{AG}{var} + $data{AH}{var} + $data{AJ}{var} + $data{AK}{var} + $data{AL}{var} + $data{AM}{var} + $data{AP}{var};
		$data{AR}{var} = $data{AE}{var} + $data{AQ}{var} ;
		$data{BE}{var} = $data{BA}{var} + $data{BB}{var} + $data{BC}{var} + $data{BD}{var};
		$data{BQ}{var} = $data{BF}{var} + $data{BG}{var} + $data{BH}{var} + $data{BJ}{var} + $data{BK}{var} + $data{BL}{var} + $data{BM}{var} + $data{BP}{var};
		$data{BR}{var} = $data{BE}{var} + $data{BQ}{var};
		$data{CA}{var} = $data{AA}{var} - $data{BA}{var};
		$data{CB}{var} = $data{AB}{var} - $data{BB}{var};
		$data{CC}{var} = $data{AC}{var} - $data{BC}{var};
		$data{CD}{var} = $data{AD}{var} - $data{BD}{var};
		$data{CE}{var} = $data{AE}{var} - $data{BE}{var};
		$data{CF}{var} = $data{AF}{var} - $data{BF}{var};
		$data{CG}{var} = $data{AG}{var} - $data{BG}{var};
		$data{CH}{var} = $data{AH}{var} - $data{BH}{var};
		$data{CJ}{var} = $data{AJ}{var} - $data{BJ}{var};
		$data{CK}{var} = $data{AK}{var} - $data{BK}{var};
		$data{CL}{var} = $data{AL}{var} - $data{BL}{var};
		$data{CM}{var} = $data{AM}{var} - $data{BM}{var};
		$data{CP}{var} = $data{AP}{var} - $data{BP}{var};
		$data{CQ}{var} = $data{AQ}{var} - $data{BQ}{var};
		$data{CR}{var} = $data{AR}{var} - $data{BR}{var}; 
		$data{FJ}{var} = $data{FA}{var} + $data{FB}{var} + $data{FC}{var} + $data{FD}{var} + $data{FE}{var} + $data{FF}{var} + $data{FG}{var} + $data{FH}{var};
		$data{FR}{var} = $data{FL}{var} + $data{FM}{var} + $data{FN}{var} + $data{FP}{var} + $data{FQ}{var}  ;
		$data{FS}{var} = $data{FJ}{var} + $data{FK}{var} + $data{FR}{var};

		################# ANNEE N  #################
		################# ANNEE N-1#################	
		$data{DA}{var} = $actif_N1[0] - $actif_N1[1];
		$data{DB}{var} = $actif_N1[2] - $actif_N1[3];
		$data{DC}{var} = $actif_N1[4] - $actif_N1[5];
		$data{DD}{var} = $actif_N1[6] - $actif_N1[7];
		$data{DE}{var} = $data{DA}{var} +$data{DB}{var} + $data{DC}{var}+$data{DD}{var};
		$data{DF}{var} = $actif_N1[8] - $actif_N1[9];
		$data{DG}{var} = $actif_N1[10] - $actif_N1[11];
		$data{DH}{var} = $actif_N1[12] - $actif_N1[13];
		$data{DJ}{var} = $actif_N1[14] - $actif_N1[15];
		$data{DK}{var} = $actif_N1[16] - $actif_N1[17];
		$data{DL}{var} = $actif_N1[18] - $actif_N1[19];
		$data{DM}{var} = $actif_N1[20] - $actif_N1[21];
		$data{DP}{var} = $actif_N1[22] - $actif_N1[23];
		$data{DQ}{var} = $data{DF}{var} + $data{DG}{var} + $data{DH}{var} + $data{DJ}{var} + $data{DK}{var} + $data{DL}{var} + $data{DM}{var} + $data{DP}{var};
		$data{DR}{var} = $data{DE}{var} + $data{DQ}{var};
		$actif_totaux_N1[1] = $actif_N1[1] + $actif_N1[3] + $actif_N1[5] + $actif_N1[7] ;
		$actif_totaux_N1[2] = $actif_totaux_N1[0] - $actif_totaux_N1[1];
		$actif_totaux_N1[3] = $actif_N1[8] + $actif_N1[10] + $actif_N1[12] + $actif_N1[14] + $actif_N1[18] + $actif_N1[20];
		$actif_totaux_N1[4] = $actif_N1[9] + $actif_N1[11] + $actif_N1[13] + $actif_N1[15] + $actif_N1[19] + $actif_N1[21];
		$actif_totaux_N1[5] = $actif_totaux_N1[3] - $actif_totaux_N1[4];
		$actif_totaux_N1[9] = $actif_totaux_N1[0] + $actif_totaux_N1[3] + $actif_N1[22];
		$actif_totaux_N1[10] = $actif_totaux_N1[1] + $actif_totaux_N1[4] + $actif_N1[23];
		$actif_totaux_N1[11] = $actif_totaux_N1[9] - $actif_totaux_N1[10];
		
		$data{GJ}{var}= $data{GA}{var} + $data{GB}{var} + $data{GC}{var} + $data{GD}{var} + $data{GE}{var} + $data{GF}{var} +$data{GG}{var} + $data{GH}{var};
		$data{GR}{var}= $data{GL}{var} + $data{GM}{var} + $data{GN}{var} + $data{GP}{var} + $data{GQ}{var};
		$data{GS}{var} = ($data{GJ}{var} || 0) + ( $data{GR}{var} || 0) + ($data{GK}{var} || 0) ;
		$data{JB}{var}= $total_33C_BK ;
		#################ANNEE N-1#################
		
		#Mise en forme affichage du total général
		foreach my $total_numbers ( 
		#variable_totaux
		$data{AE}{var},$data{AQ}{var},$data{AR}{var},
		$data{BE}{var},$data{BP}{var},$data{BQ}{var},$data{BR}{var},
		$data{CA}{var},$data{CB}{var},$data{CC}{var},$data{CD}{var},$data{CE}{var},$data{CF}{var},$data{CG}{var},$data{CH}{var},$data{CJ}{var},$data{CK}{var},$data{CL}{var},$data{CM}{var},$data{CP}{var},$data{CQ}{var},$data{CR}{var},
		$data{DA}{var},$data{DB}{var},$data{DC}{var},$data{DD}{var},$data{DE}{var},$data{DF}{var},$data{DG}{var},$data{DH}{var},$data{DJ}{var},$data{DK}{var},$data{DL}{var},$data{DM}{var},$data{DP}{var},$data{DQ}{var},$data{DR}{var},
		$data{EB}{var},
		$data{FJ}{var},$data{FR}{var},$data{FS}{var},
		$data{GJ}{var},$data{GK}{var},$data{GR}{var},$data{GS}{var},
		$data{HA}{var},$data{HB}{var},
		$data{JA}{var},$data{JB}{var}
		) {
			if((defined $total_numbers && $total_numbers =~/\d/) && ($total_numbers > 0) && (($total_numbers < 999999999999999) || ($total_numbers > 999999999999999))){
			$total_numbers = int($total_numbers+ 0.5) ;
			$total_numbers =~ s/\B(?=(...)*$)/ /g ;
			} elsif ((defined $total_numbers && $total_numbers =~/\d/) && ($total_numbers < 0)){
			$total_numbers = int($total_numbers - 0.5) ;
			} else { 
			$total_numbers = '';
			}	
		}

		$content .= '
		<div id=AE class=general-value '.$data{AE}{style}.' '.Encode::decode_utf8($data{AE}{title}||'').'>'.$data{AE}{var}.' </div>
		<div id=AQ class=general-value '.$data{AQ}{style}.' '.Encode::decode_utf8($data{AQ}{title}||'').'>'.$data{AQ}{var}.' </div>
		<div id=AR class=general-value '.$data{AR}{style}.' '.Encode::decode_utf8($data{AR}{title}||'').'>'.$data{AR}{var}.' </div>
		<div id=BE class=general-value '.$data{BE}{style}.' '.Encode::decode_utf8($data{BE}{title}||'').'>'.$data{BE}{var}.' </div>
		<div id=BP class=general-value '.$data{BP}{style}.' '.Encode::decode_utf8($data{BP}{title}||'').'>'.$data{BP}{var}.' </div>
		<div id=BQ class=general-value '.$data{BQ}{style}.' '.Encode::decode_utf8($data{BQ}{title}||'').'>'.$data{BQ}{var}.' </div>
		<div id=BR class=general-value '.$data{BR}{style}.' '.Encode::decode_utf8($data{BR}{title}||'').'>'.$data{BR}{var}.' </div>
		<div id=CA class=general-value '.$data{CA}{style}.' '.Encode::decode_utf8($data{CA}{title}||'').'>'.$data{CA}{var}.' </div>
		<div id=CB class=general-value '.$data{CB}{style}.' '.Encode::decode_utf8($data{CB}{title}||'').'>'.$data{CB}{var}.' </div>
		<div id=CC class=general-value '.$data{CC}{style}.' '.Encode::decode_utf8($data{CC}{title}||'').'>'.$data{CC}{var}.' </div>
		<div id=CD class=general-value '.$data{CD}{style}.' '.Encode::decode_utf8($data{CD}{title}||'').'>'.$data{CD}{var}.' </div>
		<div id=CE class=general-value '.$data{CE}{style}.' '.Encode::decode_utf8($data{CE}{title}||'').'>'.$data{CE}{var}.' </div>
		<div id=CF class=general-value '.$data{CF}{style}.' '.Encode::decode_utf8($data{CF}{title}||'').'>'.$data{CF}{var}.' </div>
		<div id=CG class=general-value '.$data{CG}{style}.' '.Encode::decode_utf8($data{CG}{title}||'').'>'.$data{CG}{var}.' </div>
		<div id=CH class=general-value '.$data{CH}{style}.' '.Encode::decode_utf8($data{CH}{title}||'').'>'.$data{CH}{var}.' </div>
		<div id=CJ class=general-value '.$data{CJ}{style}.' '.Encode::decode_utf8($data{CJ}{title}||'').'>'.$data{CJ}{var}.' </div>
		<div id=CK class=general-value '.$data{CK}{style}.' '.Encode::decode_utf8($data{CK}{title}||'').'>'.$data{CK}{var}.' </div>
		<div id=CL class=general-value '.$data{CL}{style}.' '.Encode::decode_utf8($data{CL}{title}||'').'>'.$data{CL}{var}.' </div>
		<div id=CM class=general-value '.$data{CM}{style}.' '.Encode::decode_utf8($data{CM}{title}||'').'>'.$data{CM}{var}.' </div>
		<div id=CP class=general-value '.$data{CP}{style}.' '.Encode::decode_utf8($data{CP}{title}||'').'>'.$data{CP}{var}.' </div>
		<div id=CQ class=general-value '.$data{CQ}{style}.' '.Encode::decode_utf8($data{CQ}{title}||'').'>'.$data{CQ}{var}.' </div>
		<div id=CR class=general-value '.$data{CR}{style}.' '.Encode::decode_utf8($data{CR}{title}||'').'>'.$data{CR}{var}.' </div>
		<div id=DA class=general-value '.$data{DA}{style}.' '.Encode::decode_utf8($data{DA}{title}||'').'>'.$data{DA}{var}.' </div>
		<div id=DB class=general-value '.$data{DB}{style}.' '.Encode::decode_utf8($data{DB}{title}||'').'>'.$data{DB}{var}.' </div>
		<div id=DC class=general-value '.$data{DC}{style}.' '.Encode::decode_utf8($data{DC}{title}||'').'>'.$data{DC}{var}.' </div>
		<div id=DD class=general-value '.$data{DD}{style}.' '.Encode::decode_utf8($data{DD}{title}||'').'>'.$data{DD}{var}.' </div>
		<div id=DE class=general-value '.$data{DE}{style}.' '.Encode::decode_utf8($data{DE}{title}||'').'>'.$data{DE}{var}.' </div>
		<div id=DF class=general-value '.$data{DF}{style}.' '.Encode::decode_utf8($data{DF}{title}||'').'>'.$data{DF}{var}.' </div>
		<div id=DG class=general-value '.$data{DG}{style}.' '.Encode::decode_utf8($data{DG}{title}||'').'>'.$data{DG}{var}.' </div>
		<div id=DH class=general-value '.$data{DH}{style}.' '.Encode::decode_utf8($data{DH}{title}||'').'>'.$data{DH}{var}.' </div>
		<div id=DJ class=general-value '.$data{DJ}{style}.' '.Encode::decode_utf8($data{DJ}{title}||'').'>'.$data{DJ}{var}.' </div>
		<div id=DK class=general-value '.$data{DK}{style}.' '.Encode::decode_utf8($data{DK}{title}||'').'>'.$data{DK}{var}.' </div>
		<div id=DL class=general-value '.$data{DL}{style}.' '.Encode::decode_utf8($data{DL}{title}||'').'>'.$data{DL}{var}.' </div>
		<div id=DM class=general-value '.$data{DM}{style}.' '.Encode::decode_utf8($data{DM}{title}||'').'>'.$data{DM}{var}.' </div>
		<div id=DP class=general-value '.$data{DP}{style}.' '.Encode::decode_utf8($data{DP}{title}||'').'>'.$data{DP}{var}.' </div>
		<div id=DQ class=general-value '.$data{DQ}{style}.' '.Encode::decode_utf8($data{DQ}{title}||'').'>'.$data{DQ}{var}.' </div>
		<div id=DR class=general-value '.$data{DR}{style}.' '.Encode::decode_utf8($data{DR}{title}||'').'>'.$data{DR}{var}.' </div>
		<div id=EB class=general-value '.$data{EB}{style}.' '.Encode::decode_utf8($data{EB}{title}||'').'>'.$data{EB}{var}.' </div>
		<div id=FJ class=general-value '.$data{FJ}{style}.' '.Encode::decode_utf8($data{FJ}{title}||'').'>'.$data{FJ}{var}.' </div>
		<div id=FR class=general-value '.$data{FR}{style}.' '.Encode::decode_utf8($data{FR}{title}||'').'>'.$data{FR}{var}.' </div>
		<div id=FS class=general-value '.$data{FS}{style}.' '.Encode::decode_utf8($data{FS}{title}||'').'>'.$data{FS}{var}.' </div>
		<div id=GJ class=general-value '.$data{GJ}{style}.' '.Encode::decode_utf8($data{GJ}{title}||'').'>'.$data{GJ}{var}.' </div>
		<div id=GK class=general-value '.$data{GK}{style}.' '.Encode::decode_utf8($data{GK}{title}||'').'>'.$data{GK}{var}.' </div>
		<div id=GR class=general-value '.$data{GR}{style}.' '.Encode::decode_utf8($data{GR}{title}||'').'>'.$data{GR}{var}.' </div>
		<div id=GS class=general-value '.$data{GS}{style}.' '.Encode::decode_utf8($data{GS}{title}||'').'>'.$data{GS}{var}.' </div>
		<div id=HA class=general-value '.$data{HA}{style}.' '.Encode::decode_utf8($data{HA}{title}||'').'>'.$data{HA}{var}.' </div>
		<div id=HB class=general-value '.$data{HB}{style}.' '.Encode::decode_utf8($data{HB}{title}||'').'>'.$data{HB}{var}.' </div>
		<div id=JA class=general-value '.$data{JA}{style}.' '.Encode::decode_utf8($data{JA}{title}||'').'>'.$data{JA}{var}.' </div>
		<div id=JB class=general-value '.$data{JB}{style}.' '.Encode::decode_utf8($data{JB}{title}||'').'>'.$data{JB}{var}.' </div>
		</div>
		';
   
    return $content ;
    
} #sub formulaire2033a 

sub formulaire2033_b {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
    my $numero_compte = '0';
    
    #LECTURE POSITION FORMULAIRE EXCEL
    my $file = '/Compta/images/2033BNM1P1.csv';
    my $location = $r->document_root() . $file ;
    my %data;
    
    #si le fichier existe
	if (-e $location) {
	open(my $fh, '<', $location) or die "Can't read file '$location' [$!]\n";

	my $header = <$fh>;
	chomp $header;
	my @header = split /,/, $header;
	
	while (my $line = <$fh>) {
    chomp $line;

    my %row;
    @row{@header} = split /,/, $line;
    
    my $key = $row{code};
    $data{$key} = \%row;
    
    #variable sous la forme
    #$data{AA}{code}
    #$data{AA}{top}
    #$data{AA}{left}
    #$data{AA}{width}
    #$data{AA}{height}
	}
	}
     
######## Affichage MENU display_compte_set Début ######
    $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########

############### ANNEE N #################   

    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

#to_char(sum(credit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_credit
#to_char(sum(credit-debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_line), \'999G999G999G990D00\') as solde

    
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    # variable
	my $total;
   
    for ( @$result_set ) {
		
		
		#BA => Ventes de marchandises Crédit de :	707	7097"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /707/) || (substr( $_->{numero_compte}, 0, 4) =~ /7097/) ) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BA}{var} += $total ;}}}
		
		#BB => Production Vendue Crédit de :	701 à 703	7091 à 7093
		if	((substr( $_->{numero_compte}, 0, 3) =~ /701|702|703/) || (substr( $_->{numero_compte}, 0, 4) =~ /7091|7092|7093/)  && not(substr( $_->{numero_compte}, 0, 4) =~ /7097/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BB}{var} += $total ;}}}
		
		#BC Crédit de :704 à 706 708 709   Moins le crédit de : 7091 à 7093 7097
		if	((substr( $_->{numero_compte}, 0, 3) =~ /701|702|703|704|705|706|708|709/) || (substr( $_->{numero_compte}, 0, 4) =~ /7091|7092|7093/)  && not(substr( $_->{numero_compte}, 0, 4) =~ /7097/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BC}{var} += $total ;}}}
		
		#BD => Production Stockée Crédit de :	71" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /71/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BD}{var} += $total ;}}}
		
		#BE => Production Immobilisée Crédit de :	72" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /72/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BE}{var} += $total ;}}}
		
		#BF => Subventions d'exploitation :	74" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /74/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BF}{var} += $total ;}}}
		
		#BG Crédit de : 73	75 781 791
		if	((substr( $_->{numero_compte}, 0, 2) =~ /73|75/) || (substr( $_->{numero_compte}, 0, 3) =~ /781|791/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BG}{var} += $total ;}}}

		
		#BJ => Achats de marchandises "Débit de :	607	6087 6097 60987 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /607/) || (substr( $_->{numero_compte}, 0, 4) =~ /6087|6097/) || (substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BJ}{var} += $total ;}}}
		
		#BK => Variation de stock marchandises Débit de : 6037
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6037/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BK}{var} += $total ;}}}
		
	    #BL => Achats d'approvisionnements  "Débit de : 601 602 6081 6082 6091	6092"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6081|6082|6091|6092/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BL}{var} += $total ;}}}
		
		#BM => Variation de stock matière première approvisionnements  "Débit de :	6030 6031 6032
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6030|6031|6032/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BM}{var} += $total ;}}}

		#BN  => Autres charges externes Débit de :	604 à 606	608	61 à 62	609 Moins le débit de :	6087 6081 6082	6091 6092 6097	60987" 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /604|605|606|608|609/) || (substr( $_->{numero_compte}, 0, 2) =~ /61|62/) && not(substr( $_->{numero_compte}, 0, 4) =~ /6087|6081|6082|6091|6092|6097/) && not(substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BN}{var} += $total ;}}}
		
		#BP => Impôts taxes et versements assimilés Débit de :	63"
		if	(substr( $_->{numero_compte}, 0, 2) =~ /63/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BP}{var} += $total ;}}}
		
		#BQ => Rémunérations du personnel "Débit de : 641 644"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /641|644/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BQ}{var} += $total ;}}}
		
		#BR => Charges sociales "Débit de : 645 à 649"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /645|646|647|648|649/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BR}{var} += $total ;}}}
		
		#BS Débit de : 681 à 6812
		if ((substr( $_->{numero_compte}, 0, 3 ) >= 681) && (substr( $_->{numero_compte}, 0, 4 ) <= 6812)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BS}{var} += $total ;}}}
		
		#BT => Dotations aux provisions Débit de :	6815 à 6817
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6815|6816|6817/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BT}{var} += $total ;}}}
		
		#BU => Autres charges d'exploitation Débit de 65 (sauf 655)
		if	((substr( $_->{numero_compte}, 0, 3) =~ /65/) && not(substr( $_->{numero_compte}, 0, 3) =~ /655/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BU}{var} += $total ;}}}


		#BX => PRODUITS FINANCIERS Crédit de :	76	786	796	
		if	((substr( $_->{numero_compte}, 0, 2) =~ /76/) || (substr( $_->{numero_compte}, 0, 3) =~ /786|796/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BX}{var} += $total ;}}}
		
		#BY => PRODUITS EXEPTIONNEL Crédit de :	77	787	797
		if	((substr( $_->{numero_compte}, 0, 2) =~ /77/) || (substr( $_->{numero_compte}, 0, 3) =~ /787|797/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{BY}{var} += $total ;}}}
		
		#BZ Débit de :	66	686
		if	((substr( $_->{numero_compte}, 0, 2) =~ /66/) || (substr( $_->{numero_compte}, 0, 3) =~ /686/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{BZ}{var} += $total ;}}}
		
		#CA => Charges exceptionnelles "Débit de : 67	687	691"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /687|691/) || (substr( $_->{numero_compte}, 0, 2) =~ /67/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{CA}{var} += $total ;}}}
		
		#CB => Impôts sur les bénéfices Débit de :695 à 698 699"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /695|696|697|698|699/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{CB}{var} += $total ;}}}
		

		$numero_compte = $_->{numero_compte} ;
	
		} #  fin for ( @$result_set ) {

############### ANNEE N #################   

################# ANNEE N-1 #################   

	$sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, (($r->pnotes('session')->{fiscal_year} ) -1)) ;
    my $result_set_N1 = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;

    for ( @$result_set_N1 ) {
		
		
		#DA => Ventes de marchandises Crédit de :	707	7097"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /707/) || (substr( $_->{numero_compte}, 0, 4) =~ /7097/) ) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DA}{var} += $total ;}}}
		
		#DB => Production Vendue Crédit de :	701 à 703	7091 à 7093
		if	((substr( $_->{numero_compte}, 0, 3) =~ /701|702|703/) || (substr( $_->{numero_compte}, 0, 4) =~ /7091|7092|7093/)  && not(substr( $_->{numero_compte}, 0, 4) =~ /7097/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DB}{var} += $total ;}}}
		

		#DC Crédit de :704 à 706 708 709   Moins le crédit de : 7091 à 7093 7097
		if	((substr( $_->{numero_compte}, 0, 3) =~ /701|702|703|704|705|706|708|709/) || (substr( $_->{numero_compte}, 0, 4) =~ /7091|7092|7093/)  && not(substr( $_->{numero_compte}, 0, 4) =~ /7097/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DC}{var} += $total ;}}}
		
		#DD => Production Stockée Crédit de :	71" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /71/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DD}{var} += $total ;}}}
		
		#DE => Production Immobilisée Crédit de :	72" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /72/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DE}{var} += $total ;}}}
		
		#DF => Subventions d'exploitation :	74" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /74/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DF}{var} += $total ;}}}
		
		#DG Crédit de : 73	75 781 791
		if	((substr( $_->{numero_compte}, 0, 2) =~ /73|75/) || (substr( $_->{numero_compte}, 0, 3) =~ /781|791/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DG}{var} += $total ;}}}
		
		#DJ => Achats de marchandises "Débit de :	607	6087 6097 60987 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /607/) || (substr( $_->{numero_compte}, 0, 4) =~ /6087|6097/) || (substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DJ}{var} += $total ;}}}
		
		#DK => Variation de stock marchandises Débit de : 6037
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6037/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DK}{var} += $total ;}}}
		
	    #DL => Achats d'approvisionnements  "Débit de : 601 602 6081 6082 6091	6092"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6081|6082|6091|6092/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DL}{var} += $total ;}}}
		
		#DM => Variation de stock matière première approvisionnements  "Débit de :	6030 6031 6032
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6030|6031|6032/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DM}{var} += $total ;}}}

		#DN  => Autres charges externes Débit de :	604 à 606	608	61 à 62	609 Moins le débit de :	6087 6081 6082	6091 6092 6097	60987" 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /604|605|606|608|609/) || (substr( $_->{numero_compte}, 0, 2) =~ /61|62/) && not(substr( $_->{numero_compte}, 0, 4) =~ /6087|6081|6082|6091|6092|6097/) && not(substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DN}{var} += $total ;}}}
		
		#DP => Impôts taxes et versements assimilés Débit de :	63"
		if	(substr( $_->{numero_compte}, 0, 2) =~ /63/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DP}{var} += $total ;}}}
		
		#DQ => Rémunérations du personnel "Débit de : 641 644"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /641|644/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DQ}{var} += $total ;}}}
		
		#DR => Charges sociales "Débit de : 645 à 649"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /645|646|647|648|649/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DR}{var} += $total ;}}}
		
		#DS Débit de : 681 à 6812
		if ((substr( $_->{numero_compte}, 0, 3 ) >= 681) && (substr( $_->{numero_compte}, 0, 4 ) <= 6812)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DS}{var} += $total ;}}}
		
		#DT => Dotations aux provisions Débit de :	6815 à 6817
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6815|6816|6817/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DT}{var} += $total ;}}}
		
		#DU => Autres charges d'exploitation Débit de 65 (sauf 655)
		if	((substr( $_->{numero_compte}, 0, 3) =~ /65/) && not(substr( $_->{numero_compte}, 0, 3) =~ /655/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DU}{var} += $total ;}}}


		#DX => PRODUITS FINANCIERS Crédit de :	76	786	796	
		if	((substr( $_->{numero_compte}, 0, 2) =~ /76/) || (substr( $_->{numero_compte}, 0, 3) =~ /786|796/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DX}{var} += $total ;}}}
		
		#DY => PRODUITS EXEPTIONNEL Crédit de :	77	787	797
		if	((substr( $_->{numero_compte}, 0, 2) =~ /77/) || (substr( $_->{numero_compte}, 0, 3) =~ /787|797/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$data{DY}{var} += $total ;}}}
		
		#DZ Débit de :	66	686
		if	((substr( $_->{numero_compte}, 0, 2) =~ /66/) || (substr( $_->{numero_compte}, 0, 3) =~ /686/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{DZ}{var} += $total ;}}}
		
		#EA => Charges exceptionnelles "Débit de : 67	687	691"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /687|691/) || (substr( $_->{numero_compte}, 0, 2) =~ /67/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{EA}{var} += $total ;}}}
		
		#EB => Impôts sur les bénéfices Débit de :695 à 698 699"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /695|696|697|698|699/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{EB}{var} += $total ;}}}
		

		$numero_compte = $_->{numero_compte} ;
	
		} #  fin for ( @$result_set ) {


################# ANNEE N-1 #################  

########## DEBUT AFFICHAGE VALUE SANS ARRONDIES ##########

		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$data{AA}{var},$data{AB}{var},$data{AC}{var},$data{AK}{var},$data{AL}{var},$data{AU}{var},$data{AV}{var},
		$data{AN}{var},$data{GN}{var},
		$data{AP}{var},
		$data{BA}{var},$data{BB}{var},$data{BC}{var},$data{BD}{var},$data{BE}{var},$data{BF}{var},$data{BG}{var},$data{BJ}{var},$data{BK}{var},$data{BL}{var},$data{BM}{var},$data{BN}{var},$data{BP}{var},$data{BQ}{var},$data{BR}{var},$data{BS}{var},$data{BT}{var},$data{BU}{var},$data{BX}{var},$data{BY}{var},$data{BZ}{var},
		$data{CA}{var},$data{CB}{var},
		$data{DA}{var},$data{DB}{var},$data{DC}{var},$data{DD}{var},$data{DE}{var},$data{DF}{var},$data{DG}{var},$data{DJ}{var},$data{DK}{var},$data{DL}{var},$data{DM}{var},$data{DN}{var},$data{DP}{var},$data{DQ}{var},$data{DR}{var},$data{DS}{var},$data{DT}{var},$data{DU}{var},$data{DX}{var},$data{DY}{var},$data{DZ}{var},
		$data{EA}{var},$data{EB}{var}
		) {
		if (defined $value_numbers != '0'){
		#if ($value_numbers != ('0' || '')) {
		#if(($num=~/\d/) && ($num >= 0) && ($num < 10))

		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; 		
		#$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}
		
	#
    #Récupérations des informations de la société
    #
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, fiscal_year_start, adresse_1, code_postal, ville FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

#calcul nb mois exercice
	my $date_month_start = Time::Piece->strptime( $r->pnotes('session')->{Exercice_debut_YMD}, "%Y-%m-%d" );
	my $date_month_end = Time::Piece->strptime( $r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d" );
	my $dateN1_month_end = Time::Piece->strptime( $r->pnotes('session')->{Exercice_fin_DMY_N1}, "%d/%m/%Y" );
	my $time_diff_month = int((($date_month_end - $date_month_start)->months)+ 0.5);
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'bilan.pm => nbmois : '.$time_diff_month.' en : ');
	
	my $time_diff_month_N1;
	
	if ($parametre_set->[0]->{date_fin} eq $r->pnotes('session')->{Exercice_fin_DMY_N1}) {
	my $date_month_startN1 = Time::Piece->strptime( $parametre_set->[0]->{date_debut}, "%d/%m/%Y" );
	$time_diff_month_N1 = int((($dateN1_month_end - $date_month_startN1)->months)+ 0.5);	
	} else {
	my $time_diff_month_N1 = $time_diff_month;
	}
   
   
   
	$content .= '
	<div class="titre-non-printable">
	<h3 class="page-subtitle">2033-B Compte de résultat simplifié<a class="aperso" href="/Compta/images/2033-NOT-2021.pdf" target="_blank">#notice2033</a> </h3></div>
	<div class="wrapper-forms" style="background-image: url(/Compta/images/2033BNM1P1.png);width:960px; height:987px;position:relative">
	<div class="general-info" style="top:44px; left:360px">'.$parametre_set->[0]->{etablissement} . ' - SIRET : ' . $parametre_set->[0]->{siret} . '</div>
	<div title="exercice clos le" class="general-info" style="top:73px; left:694px">'.$r->pnotes('session')->{Exercice_fin_DMY}.'</div>
	<div title="exercice n-1 clos le" class="general-info" style="top:73px; left:844px">'.$r->pnotes('session')->{Exercice_fin_DMY_N1}.'</div>
	<div id=AA class=general-value '.$data{AA}{style}.' '.Encode::decode_utf8($data{AA}{title}||'').'>'.$data{AA}{var}.' </div>
	<div id=AB class=general-value '.$data{AB}{style}.' '.Encode::decode_utf8($data{AB}{title}||'').'>'.$data{AB}{var}.' </div>
	<div id=AC class=general-value '.$data{AC}{style}.' '.Encode::decode_utf8($data{AC}{title}||'').'>'.$data{AC}{var}.' </div>
	<div id=AK class=general-value '.$data{AK}{style}.' '.Encode::decode_utf8($data{AK}{title}||'').'>'.$data{AK}{var}.' </div>
	<div id=AL class=general-value '.$data{AL}{style}.' '.Encode::decode_utf8($data{AL}{title}||'').'>'.$data{AL}{var}.' </div>
	<div id=AU class=general-value '.$data{AU}{style}.' '.Encode::decode_utf8($data{AU}{title}||'').'>'.$data{AU}{var}.' </div>
	<div id=AV class=general-value '.$data{AV}{style}.' '.Encode::decode_utf8($data{AV}{title}||'').'>'.$data{AV}{var}.' </div>
	<div id=AN class=general-value '.$data{AN}{style}.' '.Encode::decode_utf8($data{AN}{title}||'').'>'.$data{AN}{var}.' </div>
	<div id=AP class=general-value '.$data{AP}{style}.' '.Encode::decode_utf8($data{AP}{title}||'').'>'.$data{AP}{var}.' </div>
	<div id=BA class=general-value '.$data{BA}{style}.' '.Encode::decode_utf8($data{BA}{title}||'').'>'.$data{BA}{var}.' </div>
	<div id=BB class=general-value '.$data{BB}{style}.' '.Encode::decode_utf8($data{BB}{title}||'').'>'.$data{BB}{var}.' </div>
	<div id=BC class=general-value '.$data{BC}{style}.' '.Encode::decode_utf8($data{BC}{title}||'').'>'.$data{BC}{var}.' </div>
	<div id=BD class=general-value '.$data{BD}{style}.' '.Encode::decode_utf8($data{BD}{title}||'').'>'.$data{BD}{var}.' </div>
	<div id=BE class=general-value '.$data{BE}{style}.' '.Encode::decode_utf8($data{BE}{title}||'').'>'.$data{BE}{var}.' </div>
	<div id=BF class=general-value '.$data{BF}{style}.' '.Encode::decode_utf8($data{BF}{title}||'').'>'.$data{BF}{var}.' </div>
	<div id=BG class=general-value '.$data{BG}{style}.' '.Encode::decode_utf8($data{BG}{title}||'').'>'.$data{BG}{var}.' </div>
	<div id=BJ class=general-value '.$data{BJ}{style}.' '.Encode::decode_utf8($data{BJ}{title}||'').'>'.$data{BJ}{var}.' </div>
	<div id=BK class=general-value '.$data{BK}{style}.' '.Encode::decode_utf8($data{BK}{title}||'').'>'.$data{BK}{var}.' </div>
	<div id=BL class=general-value '.$data{BL}{style}.' '.Encode::decode_utf8($data{BL}{title}||'').'>'.$data{BL}{var}.' </div>
	<div id=BM class=general-value '.$data{BM}{style}.' '.Encode::decode_utf8($data{BM}{title}||'').'>'.$data{BM}{var}.' </div>
	<div id=BN class=general-value '.$data{BN}{style}.' '.Encode::decode_utf8($data{BN}{title}||'').'>'.$data{BN}{var}.' </div>
	<div id=BP class=general-value '.$data{BP}{style}.' '.Encode::decode_utf8($data{BP}{title}||'').'>'.$data{BP}{var}.' </div>
	<div id=BQ class=general-value '.$data{BQ}{style}.' '.Encode::decode_utf8($data{BQ}{title}||'').'>'.$data{BQ}{var}.' </div>
	<div id=BR class=general-value '.$data{BR}{style}.' '.Encode::decode_utf8($data{BR}{title}||'').'>'.$data{BR}{var}.' </div>
	<div id=BS class=general-value '.$data{BS}{style}.' '.Encode::decode_utf8($data{BS}{title}||'').'>'.$data{BS}{var}.' </div>
	<div id=BT class=general-value '.$data{BT}{style}.' '.Encode::decode_utf8($data{BT}{title}||'').'>'.$data{BT}{var}.' </div>
	<div id=BU class=general-value '.$data{BU}{style}.' '.Encode::decode_utf8($data{BU}{title}||'').'>'.$data{BU}{var}.' </div>
	<div id=BX class=general-value '.$data{BX}{style}.' '.Encode::decode_utf8($data{BX}{title}||'').'>'.$data{BX}{var}.' </div>
	<div id=BY class=general-value '.$data{BY}{style}.' '.Encode::decode_utf8($data{BY}{title}||'').'>'.$data{BY}{var}.' </div>
	<div id=BZ class=general-value '.$data{BZ}{style}.' '.Encode::decode_utf8($data{BZ}{title}||'').'>'.$data{BZ}{var}.' </div>
	<div id=CA class=general-value '.$data{CA}{style}.' '.Encode::decode_utf8($data{CA}{title}||'').'>'.$data{CA}{var}.' </div>
	<div id=CB class=general-value '.$data{CB}{style}.' '.Encode::decode_utf8($data{CB}{title}||'').'>'.$data{CB}{var}.' </div>
	<div id=GN class=general-value '.$data{GN}{style}.' '.Encode::decode_utf8($data{GN}{title}||'').'>'.$data{GN}{var}.' </div>
	<div id=DA class=general-value '.$data{DA}{style}.' '.Encode::decode_utf8($data{DA}{title}||'').'>'.$data{DA}{var}.' </div>
	<div id=DB class=general-value '.$data{DB}{style}.' '.Encode::decode_utf8($data{DB}{title}||'').'>'.$data{DB}{var}.' </div>
	<div id=DC class=general-value '.$data{DC}{style}.' '.Encode::decode_utf8($data{DC}{title}||'').'>'.$data{DC}{var}.' </div>
	<div id=DD class=general-value '.$data{DD}{style}.' '.Encode::decode_utf8($data{DD}{title}||'').'>'.$data{DD}{var}.' </div>
	<div id=DE class=general-value '.$data{DE}{style}.' '.Encode::decode_utf8($data{DE}{title}||'').'>'.$data{DE}{var}.' </div>
	<div id=DF class=general-value '.$data{DF}{style}.' '.Encode::decode_utf8($data{DF}{title}||'').'>'.$data{DF}{var}.' </div>
	<div id=DG class=general-value '.$data{DG}{style}.' '.Encode::decode_utf8($data{DG}{title}||'').'>'.$data{DG}{var}.' </div>
	<div id=DJ class=general-value '.$data{DJ}{style}.' '.Encode::decode_utf8($data{DJ}{title}||'').'>'.$data{DJ}{var}.' </div>
	<div id=DK class=general-value '.$data{DK}{style}.' '.Encode::decode_utf8($data{DK}{title}||'').'>'.$data{DK}{var}.' </div>
	<div id=DL class=general-value '.$data{DL}{style}.' '.Encode::decode_utf8($data{DL}{title}||'').'>'.$data{DL}{var}.' </div>
	<div id=DM class=general-value '.$data{DM}{style}.' '.Encode::decode_utf8($data{DM}{title}||'').'>'.$data{DM}{var}.' </div>
	<div id=DN class=general-value '.$data{DN}{style}.' '.Encode::decode_utf8($data{DN}{title}||'').'>'.$data{DN}{var}.' </div>
	<div id=DP class=general-value '.$data{DP}{style}.' '.Encode::decode_utf8($data{DP}{title}||'').'>'.$data{DP}{var}.' </div>
	<div id=DQ class=general-value '.$data{DQ}{style}.' '.Encode::decode_utf8($data{DQ}{title}||'').'>'.$data{DQ}{var}.' </div>
	<div id=DR class=general-value '.$data{DR}{style}.' '.Encode::decode_utf8($data{DR}{title}||'').'>'.$data{DR}{var}.' </div>
	<div id=DS class=general-value '.$data{DS}{style}.' '.Encode::decode_utf8($data{DS}{title}||'').'>'.$data{DS}{var}.' </div>
	<div id=DT class=general-value '.$data{DT}{style}.' '.Encode::decode_utf8($data{DT}{title}||'').'>'.$data{DT}{var}.' </div>
	<div id=DU class=general-value '.$data{DU}{style}.' '.Encode::decode_utf8($data{DU}{title}||'').'>'.$data{DU}{var}.' </div>
	<div id=DX class=general-value '.$data{DX}{style}.' '.Encode::decode_utf8($data{DX}{title}||'').'>'.$data{DX}{var}.' </div>
	<div id=DY class=general-value '.$data{DY}{style}.' '.Encode::decode_utf8($data{DY}{title}||'').'>'.$data{DY}{var}.' </div>
	<div id=DZ class=general-value '.$data{DZ}{style}.' '.Encode::decode_utf8($data{DZ}{title}||'').'>'.$data{DZ}{var}.' </div>
	<div id=EA class=general-value '.$data{EA}{style}.' '.Encode::decode_utf8($data{EA}{title}||'').'>'.$data{EA}{var}.' </div>
	<div id=EB class=general-value '.$data{EB}{style}.' '.Encode::decode_utf8($data{EB}{title}||'').'>'.$data{EB}{var}.' </div>
	';
	
########## FIN AFFICHAGE VALUE SANS ARRONDIES ##########

		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$data{AA}{var},$data{AB}{var},$data{AC}{var},$data{AK}{var},$data{AL}{var},$data{AU}{var},$data{AV}{var},
		$data{AN}{var},$data{GN}{var},
		$data{AP}{var},
		$data{BA}{var},$data{BB}{var},$data{BC}{var},$data{BD}{var},$data{BE}{var},$data{BF}{var},$data{BG}{var},$data{BJ}{var},$data{BK}{var},$data{BL}{var},$data{BM}{var},$data{BN}{var},$data{BP}{var},$data{BQ}{var},$data{BR}{var},$data{BS}{var},$data{BT}{var},$data{BU}{var},$data{BX}{var},$data{BY}{var},$data{BZ}{var},
		$data{CA}{var},$data{CB}{var},
		$data{DA}{var},$data{DB}{var},$data{DC}{var},$data{DD}{var},$data{DE}{var},$data{DF}{var},$data{DG}{var},$data{DJ}{var},$data{DK}{var},$data{DL}{var},$data{DM}{var},$data{DN}{var},$data{DP}{var},$data{DQ}{var},$data{DR}{var},$data{DS}{var},$data{DT}{var},$data{DU}{var},$data{DX}{var},$data{DY}{var},$data{DZ}{var},
		$data{EA}{var},$data{EB}{var}
		) {
		$value_numbers =~ s/\,/\./g;
		if(($value_numbers=~/\d/) && ($value_numbers >= 0) && ($value_numbers < 999999999999999)){
		$value_numbers = int(($value_numbers)+ 0.5) ;
		} elsif (($value_numbers=~/\d/) && ($value_numbers < 0) && ($value_numbers > -999999999999999)) {
		$value_numbers = int(($value_numbers)- 0.5) ;
		} else { 
		$value_numbers = '0';
		}}
		
		#Calcul des totaux
		#ANNEE N
		$data{BH}{var} = $data{BA}{var} + $data{BB}{var} + $data{BC}{var} + $data{BD}{var} + $data{BE}{var} + $data{BF}{var} + $data{BG}{var};
		$data{BV}{var} = $data{BJ}{var} + $data{BK}{var} + $data{BL}{var} + $data{BM}{var} + $data{BN}{var} + $data{BP}{var} + $data{BQ}{var} + $data{BR}{var} + $data{BS}{var} + $data{BT}{var} + $data{BU}{var} ;
		$data{BW}{var} = int($data{BH}{var}+ 0.5) - int($data{BV}{var}+ 0.5);
		#ANNEE N-1
		$data{DH}{var} = $data{DA}{var} + $data{DB}{var} + $data{DC}{var} + $data{DD}{var} + $data{DE}{var} + $data{DF}{var} + $data{DG}{var};
		$data{DV}{var} = $data{DJ}{var} + $data{DK}{var} + $data{DL}{var} + $data{DM}{var} + $data{DN}{var} + $data{DP}{var} + $data{DQ}{var} + $data{DR}{var} + $data{DS}{var} + $data{DT}{var} + $data{DU}{var} ;
		$data{DW}{var} = int($data{DH}{var}+ 0.5) - int($data{DV}{var}+ 0.5);
		
		our $total_form2033B_CC = $data{CC}{var} = int($data{BH}{var}+ 0.5) - int($data{BV}{var}+ 0.5) - int($data{BZ}{var} + 0.5) ;
		
		$data{EC}{var} = int($data{DH}{var}+ 0.5) - int($data{DV}{var}+ 0.5) - int($data{DZ}{var} + 0.5) ;


		if ($data{CC}{var} > 0) {
		$data{CD}{var} = $data{CC}{var} ;	
		} else {
		$data{ED}{var} = $data{CC}{var} * -1 ;	
		}
		
		
		
		$data{EM}{var} = $data{ED}{var};
		$data{ER}{var} = $data{EM}{var};
		
		
		
		#Mise en forme affichage du total général
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		$data{BH}{var},$data{BV}{var},$data{BW}{var},
		$data{DH}{var},$data{DV}{var},$data{DW}{var},
		$data{CC}{var},$data{CD}{var},
		$data{EC}{var},$data{ED}{var}
		) {
			if((defined $total_numbers && $total_numbers =~/\d/) && ($total_numbers > 0) && (($total_numbers < 999999999999999) || ($total_numbers > 999999999999999))){
			$total_numbers = int($total_numbers+ 0.5) ;
			$total_numbers =~ s/\B(?=(...)*$)/ /g ;
			} elsif ((defined $total_numbers && $total_numbers =~/\d/) && ($total_numbers < 0)){
			$total_numbers = int($total_numbers - 0.5) ;
			$total_numbers =~ s/\B(?=(...)*$)/ /g ;
			} else { 
			$total_numbers = '';
			}	
		}

	$content .= '
	<div id=BH class=general-value '.$data{BH}{style}.' '.Encode::decode_utf8($data{BH}{title}||'').'>'.$data{BH}{var}.' </div>
	<div id=BV class=general-value '.$data{BV}{style}.' '.Encode::decode_utf8($data{BV}{title}||'').'>'.$data{BV}{var}.' </div>
	<div id=BW class=general-value '.$data{BW}{style}.' '.Encode::decode_utf8($data{BW}{title}||'').'>'.$data{BW}{var}.' </div>
	<div id=CC class=general-value '.$data{CC}{style}.' '.Encode::decode_utf8($data{CC}{title}||'').'>'.$data{CC}{var}.' </div>
	<div id=CD class=general-value '.$data{CD}{style}.' '.Encode::decode_utf8($data{CD}{title}||'').'>'.$data{CD}{var}.' </div>
	<div id=EC class=general-value '.$data{EC}{style}.' '.Encode::decode_utf8($data{EC}{title}||'').'>'.$data{EC}{var}.' </div>
	<div id=ED class=general-value '.$data{ED}{style}.' '.Encode::decode_utf8($data{ED}{title}||'').'>'.$data{ED}{var}.' </div>
	<div id=DH class=general-value '.$data{DH}{style}.' '.Encode::decode_utf8($data{DH}{title}||'').'>'.$data{DH}{var}.' </div>
	<div id=DV class=general-value '.$data{DV}{style}.' '.Encode::decode_utf8($data{DV}{title}||'').'>'.$data{DV}{var}.' </div>
	<div id=DW class=general-value '.$data{DW}{style}.' '.Encode::decode_utf8($data{DW}{title}||'').'>'.$data{DW}{var}.' </div>
	</div>
	<div id="form-page2" class="wrapper-forms" style="background-image: url(/Compta/images/2021/2033BNM1P2.png);width:960px; height:578px;position:relative">
	</div>
	';

    return $content ;
    
} #sub formulaire2033b 

sub formulaire2033_c {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
    my $numero_compte = '0';
    
    #LECTURE POSITION FORMULAIRE EXCEL
    my $file = '/Compta/images/2021/2033C.csv';
    my $location = $r->document_root() . $file ;
    my %data;
    
    #si le fichier existe
	if (-e $location) {
	open(my $fh, '<', $location) or die "Can't read file '$location' [$!]\n";

	my $header = <$fh>;
	chomp $header;
	my @header = split /,/, $header;
	
	while (my $line = <$fh>) {
    chomp $line;

    my %row;
    @row{@header} = split /,/, $line;
    
    my $key = $row{code};
    $data{$key} = \%row;
    
    #variable sous la forme
    #$data{AA}{code}
    #$data{AA}{title}
    #$data{AA}{style}
    #$data{AA}{var}
	}
	}
     
######## Affichage MENU display_compte_set Début ######
    $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########

    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, libelle_journal, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, t1.libelle_journal, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    # variable
	my ($total);
   
    for ( @$result_set ) {
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /401/) {
		$_->{numero_compte} = '401'.$_->{numero_compte};	
		}
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /411/) {
		$_->{numero_compte} = '411'.$_->{numero_compte};	
		}
		
		#AA	title="Solde débiteur de : A-nouveaux 206 à 207"
		if ($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 3) =~ /206|207/)) { 
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AA}{var} += $total ;}}
		
		#AB	title="Solde débiteur de : A-nouveaux 20 A-nouveaux 232 A-nouveaux 237"
		if ($_->{libelle_journal} =~ /NOUVEAUX/ && ((substr( $_->{numero_compte}, 0, 2) =~ /20/) ||(substr( $_->{numero_compte}, 0, 3) =~ /232|237/))) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AB}{var} += $total ;}}
		
		#AC	title="Solde débiteur de : A-nouveaux 211 A-nouveaux 212 A-nouveaux 221 A-nouveaux 222 A-nouveaux 2312 A-nouveaux 2382"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && ((substr( $_->{numero_compte}, 0, 3) =~ /211|212|221|222/) ||(substr( $_->{numero_compte}, 0, 4) =~ /2312|2382/))) {
		(my $total = $_->{solde_debiteur});$data{AC}{var} += $total ;}
		
		#AD	title="Solde débiteur de : A-nouveaux 213 A-nouveaux 214 A-nouveaux 224 A-nouveaux 223 A-nouveaux 2313 A-nouveaux 2383"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (((substr( $_->{numero_compte}, 0, 3) =~ /213|214|223|224/) ||(substr( $_->{numero_compte}, 0, 4) =~ /2313|2383/)))) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AD}{var} += $total ;}}
		
		#AE	title="Solde débiteur de : A-nouveaux 215 A-nouveaux 225 A-nouveaux 2315 A-nouveaux 2385"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (((substr( $_->{numero_compte}, 0, 3) =~ /215|225/) ||(substr( $_->{numero_compte}, 0, 4) =~ /2315|2385/)))) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AE}{var} += $total ;}}
		
		#AF	title="Solde débiteur de : A-nouveaux 2181 A-nouveaux 2281 A-nouveaux 23181 A-nouveaux 23881"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (((substr( $_->{numero_compte}, 0, 4) =~ /2181|2281/) ||(substr( $_->{numero_compte}, 0, 5) =~ /23181|23881/)))) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AF}{var} += $total ;}}
		
		#AG	title="Solde débiteur de : A-nouveaux 2182 A-nouveaux 2282 A-nouveaux 23182 A-nouveaux 23882"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (((substr( $_->{numero_compte}, 0, 4) =~ /2182|2282/) ||(substr( $_->{numero_compte}, 0, 5) =~ /23182|23882/)))) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AG}{var} += $total ;}}
		
		#AH	title="Solde débiteur de : A-nouveaux 21 A-nouveaux 22 A-nouveaux 231 A-nouveaux 238"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (((substr( $_->{numero_compte}, 0, 3) =~ /231|238/)))) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AH}{var} += $total ;}}
		
		#AJ	title="Solde débiteur de : A-nouveaux 25 à 27"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 2) =~ /25|27/)) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$data{AJ}{var} += $total ;}}
		
		
		#BA	title="Variation au débit de : 206 à 207"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/)
			)){(my $total = $_->{debit});$data{BA}{var} += $total ;}
		
		#BB	title="Variation au débit de : 20 232 237 Moins la variation au débit de : 206 à 207"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /232|237/)
		|| (substr( $_->{numero_compte}, 0, 2 ) =~ /20/) &&	
		not(substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/)
			)){(my $total = $_->{debit});$data{BB}{var} += $total ;}
	
		#BC	title="Variation au débit de : 211 212 221 222 2312 2382"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /211|212|221|222/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /2312|2382/)
			)){(my $total = $_->{debit});$data{BC}{var} += $total ;}

		
		#BD	title="Variation au débit de : 213 214 223 224 2313 2383"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /213|214|223|224/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /2313|2383/)
			)){(my $total = $_->{debit});$data{BD}{var} += $total ;}
		
		#BE	title="Variation au débit de : 215 225 2315 2385"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /215|225/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /2315|2385/)
			)){(my $total = $_->{debit});$data{BE}{var} += $total ;}
		
		#BF	title="Variation au débit de : 2181 2281 23181 23881"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 4 ) =~ /2181|2281/)
		|| (substr( $_->{numero_compte}, 0, 5 ) =~ /23181|23881/)
			)){(my $total = $_->{debit});$data{BF}{var} += $total ;}

		#BG	title="Variation au débit de : 2182 2282 23182 23882"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 4 ) =~ /2182|2282/)
		|| (substr( $_->{numero_compte}, 0, 5 ) =~ /23182|23882/)
			)){(my $total = $_->{debit});$data{BG}{var} += $total ;}
		
		#BH	title="Variation au débit de : 21 22 231 238"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		 (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)
			)){(my $total = $_->{debit});$data{BH}{var} += $total ;}

		#BJ	title="Variation au débit de : 25 à 27 Moins la variation au débit de : 269 279 259"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 2 ) =~ /25|26|27/) &&	
		not(substr( $_->{numero_compte}, 0, 3 ) =~ /269|279|259/)
			)){(my $total = $_->{debit});$data{BJ}{var} += $total ;}
	    
	    #CA	title="Variation au crédit de : 206 à 207"
	    if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/)
			)){(my $total = $_->{credit});$data{CA}{var} += $total ;}
	    
	    #CB	title="Variation au crédit de : 20 232 237 Moins la variation au crédit de : 206 à 207"
	    if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 2 ) =~ /20|232|237/) &&	
		not(substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/)
			)){(my $total = $_->{credit});$data{CB}{var} += $total ;}
	    
	    #CC	title="Variation au crédit de : 211 212 221 222 2312 2382"
	    if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /211|212|221|222/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /2312|2382/)
			)){(my $total = $_->{credit});$data{CC}{var} += $total ;}
	    
		#CD	title="Variation au crédit de : 213 214 223 224 2313 2383"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /213|214|223|224/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /2313|2383/)
			)){(my $total = $_->{credit});$data{CD}{var} += $total ;}
	    
		#CE	title="Variation au crédit de : 215 225 2315 2385"
		 if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 3 ) =~ /215|225/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /2315|2385/)
			)){(my $total = $_->{credit});$data{CE}{var} += $total ;}
	    	    
		#CF	title="Variation au crédit de : 2181 2281 23181 23881"
		 if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 4 ) =~ /2181|2281/)
		|| (substr( $_->{numero_compte}, 0, 5 ) =~ /23181|23881/)
			)){(my $total = $_->{credit});$data{CF}{var} += $total ;}
		
		#CG	title="Variation au crédit de : 2182 2282 23182 23882"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 4 ) =~ /2182|2282/)
		|| (substr( $_->{numero_compte}, 0, 5 ) =~ /23182|23882/)
			)){(my $total = $_->{credit});$data{CG}{var} += $total ;}
		
		#CH	title="Variation au crédit de : 21 22 231 238"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)
			)){(my $total = $_->{credit});$data{CH}{var} += $total ;}
		
		#CJ	title="Variation au crédit de : 25 à 27 Moins la variation au crédit de : 269 279 259"
		 if	($_->{libelle_journal} !~ /NOUVEAUX/ && (
		(substr( $_->{numero_compte}, 0, 2 ) =~ /25|26|27/) &&	
		not(substr( $_->{numero_compte}, 0, 3 ) =~ /269|279|259/)
			)){ 
		(my $total = $_->{credit});$data{CJ}{var} += $total ;}

		#FA	title="Solde créditeur de : A-nouveaux 280"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 3) =~ /280/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FA}{var} += $total ;}
		
		#FB	title="Solde créditeur de : A-nouveaux 2811 à 2812 A-nouveaux 2821 à 2822"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 4) =~ /2811|2812|2821|2822/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FB}{var} += $total ;}
		
		#FC	title="Solde créditeur de : A-nouveaux 2813 A-nouveaux 2814 A-nouveaux 2823 A-nouveaux 2824"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 4) =~ /2813|2814|2823|2824/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FC}{var} += $total ;}

		#FD	title="Solde créditeur de : A-nouveaux 2815 A-nouveaux 2825"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 4) =~ /2815|2825/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FD}{var} += $total ;}
		
		#FE	title="Solde créditeur de : A-nouveaux 28181 A-nouveaux 28281"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 5) =~ /28181|28281/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FE}{var} += $total ;}
		
		#FF	title="Solde créditeur de : A-nouveaux 28182 A-nouveaux 28282"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 5) =~ /28182|28282/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FF}{var} += $total ;}
		
		#FG	title="Solde créditeur de : A-nouveaux 28183 à 28187 à 282"
		if	($_->{libelle_journal} =~ /NOUVEAUX/ && (substr( $_->{numero_compte}, 0, 5) =~ /28183|28283|28184|28284|28185|28285|28186|28286|28187|28287/) ) {
		(my $total = $_->{credit} - $_->{debit});$data{FG}{var} += $total ;}
		
		#GA	title="Variation au crédit de : 280"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 3) =~ /280/)){
		(my $total = $_->{credit});$data{GA}{var} += $total ;}
		
		#GB	title="Variation au crédit de : 2811 à 2812 2821 à 2822"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 3) =~ /2811|2812|2821|2822/)){
		(my $total = $_->{credit});$data{GB}{var} += $total ;}
		
		#GC	title="Variation au crédit de : 2813 2814 2823 2824"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 4) =~ /2813|2814|2823|2824/)){
		(my $total = $_->{credit});$data{GC}{var} += $total ;}

		#GD	title="Variation au crédit de : 2815 2825"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 4) =~ /2815|2825/)){
		(my $total = $_->{credit});$data{GD}{var} += $total ;}
		
		#GE	title="Variation au crédit de : 28181 28281"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 5) =~ /28181|28281/)){
		(my $total = $_->{credit});$data{GE}{var} += $total ;}
		
		#GF	title="Variation au crédit de : 28182 28282"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 5) =~ /28182|28282/)){
		(my $total = $_->{credit});$data{GF}{var} += $total ;}
		
		#GG	title="Variation au crédit de : 28183 à 28187"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 5) =~ /28183|28184|28185|28186|28187/)){
		(my $total = $_->{credit});$data{GG}{var} += $total ;}
		
		#HA	title="Variation au débit de : 280"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 3) =~ /280/)){
		(my $total = $_->{debit});$data{HA}{var} += $total ;}
		
		#HB	title="Variation au débit de : 2811 à 2812 2821 à 2822"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 4) =~ /2811|2812|2821|2822/)){
		(my $total = $_->{debit});$data{HB}{var} += $total ;}
		
		#HC	title="Variation au débit de : 2813 2814 2823 2824"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 4) =~ /2813|2814|2823|2824/)){
		(my $total = $_->{debit});$data{HC}{var} += $total ;}
		
		#HD	title="Variation au débit de : 2815 2825"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 4) =~ /2815|2825/)){
		(my $total = $_->{debit});$data{HD}{var} += $total ;}
		
		#HE	title="Variation au débit de : 28181 28281"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 5) =~ /28181|28281/)){
		(my $total = $_->{debit});$data{HE}{var} += $total ;}
		
		#HF	title="Variation au débit de : 28182 28282"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 5) =~ /28182|28282/)){
		(my $total = $_->{debit});$data{HF}{var} += $total ;}
		
		#HG	title="Variation au débit de : 28183 à 28187"
		if	($_->{libelle_journal} !~ /NOUVEAUX/ && (substr($_->{numero_compte}, 0, 5) =~ /28183|28184|28185|28186|28187/)){
		(my $total = $_->{debit});$data{HG}{var} += $total ;}
		
		$numero_compte = $_->{numero_compte} ;
		} #  fin for ( @$result_set ) {

########## DEBUT AFFICHAGE VALUE SANS ARRONDIES ##########


		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$data{AA}{var}, $data{AB}{var}, $data{AC}{var}, $data{AD}{var}, $data{AE}{var}, $data{AF}{var}, $data{AG}{var}, $data{AH}{var}, $data{AJ}{var},
		$data{BA}{var}, $data{BB}{var}, $data{BC}{var}, $data{BD}{var}, $data{BE}{var}, $data{BF}{var}, $data{BG}{var}, $data{BH}{var}, $data{BJ}{var}, 
		$data{CA}{var}, $data{CB}{var}, $data{CC}{var}, $data{CD}{var}, $data{CE}{var}, $data{CF}{var}, $data{CG}{var}, $data{CH}{var}, $data{CJ}{var}, 
		$data{FA}{var}, $data{FB}{var}, $data{FC}{var}, $data{FD}{var}, $data{FE}{var}, $data{FF}{var}, $data{FG}{var},
		$data{GA}{var}, $data{GB}{var}, $data{GC}{var}, $data{GD}{var}, $data{GE}{var}, $data{GF}{var}, $data{GG}{var},
		$data{HA}{var}, $data{HB}{var}, $data{HC}{var}, $data{HD}{var}, $data{HE}{var}, $data{HF}{var}, $data{HG}{var}
		) {
		if(  defined ($value_numbers) ) {
		if (($value_numbers=~/\d/) && ($value_numbers > 0) && ( $value_numbers < 999999999999999) ){
		#if( $value_numbers !=  ''){
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; 		
		#$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} elsif (($value_numbers=~/\d/) && ($value_numbers < 0) && ($value_numbers > -999999999999999)) {
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; 	
		} else { $value_numbers = '';}} else {$value_numbers = '';}}	


    #
    #Récupérations des informations de la société
    #
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, fiscal_year_start, adresse_1, code_postal, ville FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
	
	$content .= '
	<div class="titre-non-printable">
	<h3 class="page-subtitle">2033-C Immobilisations amortissements plus & moins values<a class="aperso" href="/assets/images/2021/2033-NOT-2021.pdf" target="_blank">#notice2033</a> </h3></div>
	<div class="wrapper-forms" style="background: url(/Compta/images/2021/2033C.png);width:960px; height:1361px;position:relative">
	<div class="general-info" style="top:77px; left:393px">'.$parametre_set->[0]->{etablissement} . ' - SIRET : ' . $parametre_set->[0]->{siret} . '</div>
	<div id=AA class=general-value '.$data{AA}{style}.' '.Encode::decode_utf8($data{AA}{title}||'').'>'.$data{AA}{var}.' </div>
	<div id=AB class=general-value '.$data{AB}{style}.' '.Encode::decode_utf8($data{AB}{title}||'').'>'.$data{AB}{var}.' </div>
	<div id=AC class=general-value '.$data{AC}{style}.' '.Encode::decode_utf8($data{AC}{title}||'').'>'.$data{AC}{var}.' </div>
	<div id=AD class=general-value '.$data{AD}{style}.' '.Encode::decode_utf8($data{AD}{title}||'').'>'.$data{AD}{var}.' </div>
	<div id=AE class=general-value '.$data{AE}{style}.' '.Encode::decode_utf8($data{AE}{title}||'').'>'.$data{AE}{var}.' </div>
	<div id=AF class=general-value '.$data{AF}{style}.' '.Encode::decode_utf8($data{AF}{title}||'').'>'.$data{AF}{var}.' </div>
	<div id=AG class=general-value '.$data{AG}{style}.' '.Encode::decode_utf8($data{AG}{title}||'').'>'.$data{AG}{var}.' </div>
	<div id=AH class=general-value '.$data{AH}{style}.' '.Encode::decode_utf8($data{AH}{title}||'').'>'.$data{AH}{var}.' </div>
	<div id=AJ class=general-value '.$data{AJ}{style}.' '.Encode::decode_utf8($data{AJ}{title}||'').'>'.$data{AJ}{var}.' </div>
	<div id=BA class=general-value '.$data{BA}{style}.' '.Encode::decode_utf8($data{BA}{title}||'').'>'.$data{BA}{var}.' </div>
	<div id=BB class=general-value '.$data{BB}{style}.' '.Encode::decode_utf8($data{BB}{title}||'').'>'.$data{BB}{var}.' </div>
	<div id=BC class=general-value '.$data{BC}{style}.' '.Encode::decode_utf8($data{BC}{title}||'').'>'.$data{BC}{var}.' </div>
	<div id=BD class=general-value '.$data{BD}{style}.' '.Encode::decode_utf8($data{BD}{title}||'').'>'.$data{BD}{var}.' </div>
	<div id=BE class=general-value '.$data{BE}{style}.' '.Encode::decode_utf8($data{BE}{title}||'').'>'.$data{BE}{var}.' </div>
	<div id=BF class=general-value '.$data{BF}{style}.' '.Encode::decode_utf8($data{BF}{title}||'').'>'.$data{BF}{var}.' </div>
	<div id=BG class=general-value '.$data{BG}{style}.' '.Encode::decode_utf8($data{BG}{title}||'').'>'.$data{BG}{var}.' </div>
	<div id=BH class=general-value '.$data{BH}{style}.' '.Encode::decode_utf8($data{BH}{title}||'').'>'.$data{BH}{var}.' </div>
	<div id=BJ class=general-value '.$data{BJ}{style}.' '.Encode::decode_utf8($data{BJ}{title}||'').'>'.$data{BJ}{var}.' </div>
	<div id=CA class=general-value '.$data{CA}{style}.' '.Encode::decode_utf8($data{CA}{title}||'').'>'.$data{CA}{var}.' </div>
	<div id=CB class=general-value '.$data{CB}{style}.' '.Encode::decode_utf8($data{CB}{title}||'').'>'.$data{CB}{var}.' </div>
	<div id=CC class=general-value '.$data{CC}{style}.' '.Encode::decode_utf8($data{CC}{title}||'').'>'.$data{CC}{var}.' </div>
	<div id=CD class=general-value '.$data{CD}{style}.' '.Encode::decode_utf8($data{CD}{title}||'').'>'.$data{CD}{var}.' </div>
	<div id=CE class=general-value '.$data{CE}{style}.' '.Encode::decode_utf8($data{CE}{title}||'').'>'.$data{CE}{var}.' </div>
	<div id=CF class=general-value '.$data{CF}{style}.' '.Encode::decode_utf8($data{CF}{title}||'').'>'.$data{CF}{var}.' </div>
	<div id=CG class=general-value '.$data{CG}{style}.' '.Encode::decode_utf8($data{CG}{title}||'').'>'.$data{CG}{var}.' </div>
	<div id=CH class=general-value '.$data{CH}{style}.' '.Encode::decode_utf8($data{CH}{title}||'').'>'.$data{CH}{var}.' </div>
	<div id=CJ class=general-value '.$data{CJ}{style}.' '.Encode::decode_utf8($data{CJ}{title}||'').'>'.$data{CJ}{var}.' </div>
	<div id=FA class=general-value '.$data{FA}{style}.' '.Encode::decode_utf8($data{FA}{title}||'').'>'.$data{FA}{var}.' </div>
	<div id=FB class=general-value '.$data{FB}{style}.' '.Encode::decode_utf8($data{FB}{title}||'').'>'.$data{FB}{var}.' </div>
	<div id=FC class=general-value '.$data{FC}{style}.' '.Encode::decode_utf8($data{FC}{title}||'').'>'.$data{FC}{var}.' </div>
	<div id=FD class=general-value '.$data{FD}{style}.' '.Encode::decode_utf8($data{FD}{title}||'').'>'.$data{FD}{var}.' </div>
	<div id=FE class=general-value '.$data{FE}{style}.' '.Encode::decode_utf8($data{FE}{title}||'').'>'.$data{FE}{var}.' </div>
	<div id=FF class=general-value '.$data{FF}{style}.' '.Encode::decode_utf8($data{FF}{title}||'').'>'.$data{FF}{var}.' </div>
	<div id=FG class=general-value '.$data{FG}{style}.' '.Encode::decode_utf8($data{FG}{title}||'').'>'.$data{FG}{var}.' </div>
	<div id=GA class=general-value '.$data{GA}{style}.' '.Encode::decode_utf8($data{GA}{title}||'').'>'.$data{GA}{var}.' </div>
	<div id=GB class=general-value '.$data{GB}{style}.' '.Encode::decode_utf8($data{GB}{title}||'').'>'.$data{GB}{var}.' </div>
	<div id=GC class=general-value '.$data{GC}{style}.' '.Encode::decode_utf8($data{GC}{title}||'').'>'.$data{GC}{var}.' </div>
	<div id=GD class=general-value '.$data{GD}{style}.' '.Encode::decode_utf8($data{GD}{title}||'').'>'.$data{GD}{var}.' </div>
	<div id=GE class=general-value '.$data{GE}{style}.' '.Encode::decode_utf8($data{GE}{title}||'').'>'.$data{GE}{var}.' </div>
	<div id=GF class=general-value '.$data{GF}{style}.' '.Encode::decode_utf8($data{GF}{title}||'').'>'.$data{GF}{var}.' </div>
	<div id=GG class=general-value '.$data{GG}{style}.' '.Encode::decode_utf8($data{GG}{title}||'').'>'.$data{GG}{var}.' </div>
	<div id=HA class=general-value '.$data{HA}{style}.' '.Encode::decode_utf8($data{HA}{title}||'').'>'.$data{HA}{var}.' </div>
	<div id=HB class=general-value '.$data{HB}{style}.' '.Encode::decode_utf8($data{HB}{title}||'').'>'.$data{HB}{var}.' </div>
	<div id=HC class=general-value '.$data{HC}{style}.' '.Encode::decode_utf8($data{HC}{title}||'').'>'.$data{HC}{var}.' </div>
	<div id=HD class=general-value '.$data{HD}{style}.' '.Encode::decode_utf8($data{HD}{title}||'').'>'.$data{HD}{var}.' </div>
	<div id=HE class=general-value '.$data{HE}{style}.' '.Encode::decode_utf8($data{HE}{title}||'').'>'.$data{HE}{var}.' </div>
	<div id=HF class=general-value '.$data{HF}{style}.' '.Encode::decode_utf8($data{HF}{title}||'').'>'.$data{HF}{var}.' </div>
	<div id=HG class=general-value '.$data{HG}{style}.' '.Encode::decode_utf8($data{HG}{title}||'').'>'.$data{HG}{var}.' </div>
	';
	
########## FIN AFFICHAGE VALUE SANS ARRONDIES ##########

		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$data{AA}{var}, $data{AB}{var}, $data{AC}{var}, $data{AD}{var}, $data{AE}{var}, $data{AF}{var}, $data{AG}{var}, $data{AH}{var}, $data{AJ}{var},
		$data{BA}{var}, $data{BB}{var}, $data{BC}{var}, $data{BD}{var}, $data{BE}{var}, $data{BF}{var}, $data{BG}{var}, $data{BH}{var}, $data{BJ}{var}, 
		$data{CA}{var}, $data{CB}{var}, $data{CC}{var}, $data{CD}{var}, $data{CE}{var}, $data{CF}{var}, $data{CG}{var}, $data{CH}{var}, $data{CJ}{var}, 
		$data{FA}{var}, $data{FB}{var}, $data{FC}{var}, $data{FD}{var}, $data{FE}{var}, $data{FF}{var}, $data{FG}{var},
		$data{GA}{var}, $data{GB}{var}, $data{GC}{var}, $data{GD}{var}, $data{GE}{var}, $data{GF}{var}, $data{GG}{var},
		$data{HA}{var}, $data{HB}{var}, $data{HC}{var}, $data{HD}{var}, $data{HE}{var}, $data{HF}{var}, $data{HG}{var}
		) {
		$value_numbers =~ s/\,/\./g;
		if(($value_numbers=~/\d/) && ($value_numbers >= 0) && ($value_numbers < 999999999999999)){
		$value_numbers = int(($value_numbers)+ 0.5) ;
		} elsif (($value_numbers=~/\d/) && ($value_numbers < 0) && ($value_numbers > -999999999999999)) {
		$value_numbers = int(($value_numbers)- 0.5) ;
		} else { 
		$value_numbers = '0';
		}}

		#Calcul des totaux
		$data{DA}{var} = $data{AA}{var} + $data{BA}{var} - $data{CA}{var};
		$data{DB}{var} = $data{AB}{var} + $data{BB}{var} - $data{CB}{var};
		$data{DC}{var} = $data{AC}{var} + $data{BC}{var} - $data{CC}{var};
		$data{DD}{var} = $data{AD}{var} + $data{BD}{var} - $data{CD}{var};
		$data{DE}{var} = $data{AE}{var} + $data{BE}{var} - $data{CE}{var};
		$data{DF}{var} = $data{AF}{var} + $data{BF}{var} - $data{CF}{var};
		$data{DG}{var} = $data{AG}{var} + $data{BG}{var} - $data{CG}{var};
		$data{DH}{var} = $data{AH}{var} + $data{BH}{var} - $data{CH}{var};
		$data{DJ}{var} = $data{AJ}{var} + $data{BJ}{var} - $data{CJ}{var};
		
		$data{JA}{var} = $data{FA}{var} + $data{GA}{var} - $data{HA}{var};
		$data{JB}{var} = $data{FB}{var} + $data{GB}{var} - $data{HB}{var};
		$data{JC}{var} = $data{FC}{var} + $data{GC}{var} - $data{HC}{var};
		$data{JD}{var} = $data{FD}{var} + $data{GD}{var} - $data{HD}{var};
		$data{JE}{var} = $data{FE}{var} + $data{GE}{var} - $data{HE}{var};
		$data{JF}{var} = $data{FF}{var} + $data{GF}{var} - $data{HF}{var};
		$data{JG}{var} = $data{FG}{var} + $data{GG}{var} - $data{HG}{var};
		
		$data{FH}{var} = $data{FA}{var} + $data{FB}{var} + $data{FC}{var} + $data{FD}{var} + $data{FE}{var} + $data{FF}{var} + $data{FG}{var};
		$data{GH}{var} = $data{GA}{var} + $data{GB}{var} + $data{GC}{var} + $data{GD}{var} + $data{GE}{var} + $data{GF}{var} + $data{GG}{var};
		$data{HH}{var} = $data{HA}{var} + $data{HB}{var} + $data{HC}{var} + $data{HD}{var} + $data{HE}{var} + $data{HF}{var} + $data{HG}{var};
		
		
		$data{AK}{var} = $data{AA}{var} + $data{AB}{var} + $data{AC}{var} + $data{AD}{var} + $data{AE}{var} + $data{AF}{var} + $data{AG}{var} + $data{AH}{var} + $data{AJ}{var};	
		$data{BK}{var} = $data{BA}{var} + $data{BB}{var} + $data{BC}{var} + $data{BD}{var} + $data{BE}{var} + $data{BF}{var} + $data{BG}{var} + $data{BH}{var} + $data{BJ}{var};	
		$data{CK}{var} = $data{CA}{var} + $data{CB}{var} + $data{CC}{var} + $data{CD}{var} + $data{CE}{var} + $data{CF}{var} + $data{CG}{var} + $data{CH}{var} + $data{CJ}{var};
		$data{DK}{var} = $data{AK}{var} + $data{BK}{var} - $data{CK}{var};
		
		$data{JH}{var} = $data{FH}{var} + $data{GH}{var} - $data{HH}{var};
		
		our $total_33C_BK = $data{BK}{var};
		
		#Mise en forme affichage du total général
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		$data{DA}{var},$data{DB}{var},$data{DC}{var},$data{DD}{var},$data{DE}{var},$data{DF}{var},$data{DG}{var},$data{DH}{var},$data{DJ}{var},$data{DK}{var},
		$data{JA}{var},$data{JB}{var},$data{JC}{var},$data{JD}{var},$data{JE}{var},$data{JF}{var},$data{JG}{var},
		$data{AK}{var},$data{BK}{var},$data{CK}{var},
		$data{FH}{var},$data{GH}{var},$data{HH}{var},$data{JH}{var}
		) {
			if((defined $total_numbers && $total_numbers =~/\d/) && ($total_numbers > 0) && (($total_numbers < 999999999999999) || ($total_numbers > 999999999999999))){
			$total_numbers = int($total_numbers+ 0.5) ;
			$total_numbers =~ s/\B(?=(...)*$)/ /g ;
			} elsif ((defined $total_numbers && $total_numbers =~/\d/) && ($total_numbers < 0)){
			$total_numbers = int($total_numbers - 0.5) ;
			} else { 
			$total_numbers = '';
			}	
		}

			


    
	$content .= '
	<div id=AK class=general-value '.$data{AK}{style}.' '.Encode::decode_utf8($data{AK}{title}||'').'>'.$data{AK}{var}.' </div>
	<div id=BK class=general-value '.$data{BK}{style}.' '.Encode::decode_utf8($data{BK}{title}||'').'>'.$data{BK}{var}.' </div>
	<div id=CK class=general-value '.$data{CK}{style}.' '.Encode::decode_utf8($data{CK}{title}||'').'>'.$data{CK}{var}.' </div>
	<div id=DK class=general-value '.$data{DK}{style}.' '.Encode::decode_utf8($data{DK}{title}||'').'>'.$data{DK}{var}.' </div>
	
	<div id=JA class=general-value '.$data{JA}{style}.' '.Encode::decode_utf8($data{JA}{title}||'').'>'.$data{JA}{var}.' </div>
	<div id=JB class=general-value '.$data{JB}{style}.' '.Encode::decode_utf8($data{JB}{title}||'').'>'.$data{JB}{var}.' </div>
	<div id=JC class=general-value '.$data{JC}{style}.' '.Encode::decode_utf8($data{JC}{title}||'').'>'.$data{JC}{var}.' </div>
	<div id=JD class=general-value '.$data{JD}{style}.' '.Encode::decode_utf8($data{JD}{title}||'').'>'.$data{JD}{var}.' </div>
	<div id=JE class=general-value '.$data{JE}{style}.' '.Encode::decode_utf8($data{JE}{title}||'').'>'.$data{JE}{var}.' </div>
	<div id=JF class=general-value '.$data{JF}{style}.' '.Encode::decode_utf8($data{JF}{title}||'').'>'.$data{JF}{var}.' </div>
	<div id=JG class=general-value '.$data{JG}{style}.' '.Encode::decode_utf8($data{JG}{title}||'').'>'.$data{JG}{var}.' </div>
	
	<div id=DA class=general-value '.$data{DA}{style}.' '.Encode::decode_utf8($data{DA}{title}||'').'>'.$data{DA}{var}.' </div>
	<div id=DB class=general-value '.$data{DB}{style}.' '.Encode::decode_utf8($data{DB}{title}||'').'>'.$data{DB}{var}.' </div>
	<div id=DC class=general-value '.$data{DC}{style}.' '.Encode::decode_utf8($data{DC}{title}||'').'>'.$data{DC}{var}.' </div>
	<div id=DD class=general-value '.$data{DD}{style}.' '.Encode::decode_utf8($data{DD}{title}||'').'>'.$data{DD}{var}.' </div>
	<div id=DE class=general-value '.$data{DE}{style}.' '.Encode::decode_utf8($data{DE}{title}||'').'>'.$data{DE}{var}.' </div>
	<div id=DF class=general-value '.$data{DF}{style}.' '.Encode::decode_utf8($data{DF}{title}||'').'>'.$data{DF}{var}.' </div>
	<div id=DG class=general-value '.$data{DG}{style}.' '.Encode::decode_utf8($data{DG}{title}||'').'>'.$data{DG}{var}.' </div>
	<div id=DH class=general-value '.$data{DH}{style}.' '.Encode::decode_utf8($data{DH}{title}||'').'>'.$data{DH}{var}.' </div>
	<div id=DJ class=general-value '.$data{DJ}{style}.' '.Encode::decode_utf8($data{DJ}{title}||'').'>'.$data{DJ}{var}.' </div>
	
	<div id=FH class=general-value '.$data{FH}{style}.' '.Encode::decode_utf8($data{FH}{title}||'').'>'.$data{FH}{var}.' </div>
	<div id=GH class=general-value '.$data{GH}{style}.' '.Encode::decode_utf8($data{GH}{title}||'').'>'.$data{GH}{var}.' </div>
	<div id=HH class=general-value '.$data{HH}{style}.' '.Encode::decode_utf8($data{HH}{title}||'').'>'.$data{HH}{var}.' </div>
	<div id=JH class=general-value '.$data{JH}{style}.' '.Encode::decode_utf8($data{JH}{title}||'').'>'.$data{JH}{var}.' </div>
	</div>
	';
   
   
    return $content ;
    
} #sub formulaire2033c

sub bilan {
	
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
    my $numero_compte = '0';
    my $date = localtime->strftime('%d/%m/%Y');
    our $resultat_annee_N;
    our $resultat_annee_N1;

######## Affichage MENU display_compte_set Début ######
    $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########

	### Déclaration des variables
	my @actif = ('0') x 80;
    my @actif_N1 = ('0') x 80;
    my @actif_total = ('0') x 80;
    my @actif_total_N1 = ('0') x 80;
    my @passif = ('0') x 30;
    my @passif_N1 = ('0') x 30;
    my @passif_total = ('0') x 10;
    my @passif_total_N1 = ('0') x 10;
    my @actif_totaux = ('0') x 15;
    my @actif_totaux_N1 = ('0') x 15;
    my @passif_totaux = ('0') x 10;
    my @passif_totaux_N1 = ('0') x 10;
    
#####################################       
# Préparation à l'impression		#
#####################################   
    #Récupérations des informations de la société
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, adresse_1, code_postal, ville, journal_tva FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

	$content .= '
		<div class="printable">
		<div style="float: left ">
		<address><strong>'.$parametre_set->[0]->{etablissement} . '</strong><br>
		' . ($parametre_set->[0]->{adresse_1} || '') . ' <br> ' . ($parametre_set->[0]->{code_postal} || ''). ' ' . ($parametre_set->[0]->{ville} || '').'<br>
		SIRET : ' . $parametre_set->[0]->{siret} . '<br>
		</address></div>
		<div style="float: right; text-align: right;">
		Imprimé le ' . $date . '<br>
		<div>
		Exercice du '.$r->pnotes('session')->{Exercice_debut_DMY}.' 
		</div>
		au '.$r->pnotes('session')->{Exercice_fin_DMY}.'<br>
		</div>
		<div style="width: 100%; text-align: center;"><h1>Bilan au '.$r->pnotes('session')->{Exercice_fin_DMY}.'</h1>
		<div >
		Etat exprimé en Euros</div>
		</div><br></div>' ;

################# ANNEE N #################   
    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ?  AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    for ( @$result_set ) {
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /401/) {
		$_->{numero_compte} = '401'.$_->{numero_compte};	
		}
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /411/) {
		$_->{numero_compte} = '411'.$_->{numero_compte};	
		}
	    
################# ACTIF #################	 

#$actif[0] =>Fonds commercial Débit de :	206	207
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{total_debit});$actif[0] += $total;}
#$actif[1] => Fonds commercial amort Crédit de :	2807	2906	2907
if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2807|2906|2907/) {(my $total = $_->{total_credit});$actif[1] += $total;}

#$actif[2] => Autres immobilisations incorporelles : Débit de : 201	203	204	205	208	232	237
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{total_debit});$actif[2] += $total;}
#$actif[3] => Autres immobilisations incorporelles amort Crédit de :	2801 2803 2804 2805 2808 2901 2903 2904 2905 2908 2932
if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2801|2803|2804|2805|2808|2901|2903|2904|2905|2908|2932/) {(my $total = $_->{total_credit});$actif[3] += $total;}
	
#$actif[4] =>Immobilisations corporelles Débit de :	21	22	231	238
if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{total_debit});$actif[4] += $total;}
#$actif[5] => Immobilisations corporelles amort Crédit de : 281 291 282 292 2931
if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/)) { (my $total = $_->{credit});$actif[5] += $total;}

#$actif[6] =>Immobilisations financières : Débit de :	25 à 268	271 à 277 Moins le débit de :	259
if  (
	(substr( $_->{numero_compte}, 0, 2 ) >= 25 && (substr( $_->{numero_compte}, 0, 3 ) <= 268) && (substr( $_->{numero_compte}, 0, 2 ) <= 26)) ||
	(substr( $_->{numero_compte}, 0, 3 ) =~ /271|272|273|274|275|276|277/)	&&	
	not(substr( $_->{numero_compte}, 0, 3 ) =~ /259/)
	){ (my $total = $_->{total_debit});$actif[6] += $total;}
#$actif[7] => Immobilisations financières amort "Crédit de : 295 296 297
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /295|296|297/) { (my $total = $_->{total_credit});$actif[7] += $total;}
	

#$actif[8] => Stocks et en cours " Solde débiteur de :	31 à 36	38 Moins le solde débiteur de :	387
if  (
	(substr( $_->{numero_compte}, 0, 2 ) =~ /31|32|33|34|35|36|38/)	&&	
	not(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[8] += $total ;
		}		
	}}
#$actif[9] => Stocks et en cours amort Solde créditeur de : 390 à 396	398 Moins le solde créditeur de :	3987
if  (
	(substr( $_->{numero_compte}, 0, 3 ) =~ /390|391|392|393|394|395|396|398/)	&&	
	not(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[9] += $total ;
		}		
	}}
	
#$actif[10] => Stocks de marchandises " Solde débiteur de :	37	387
if  (
	(substr( $_->{numero_compte}, 0, 2 ) =~ /37/)	||	
	(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[10] += $total ;
		}		
	}}
#$actif[11] => Stocks de marchandises amort "Solde créditeur de :	397	3987
if  (
	(substr( $_->{numero_compte}, 0, 3 ) =~ /397/) ||	
	(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)

	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[11] += $total ;
		}		
	}}
	

#$actif[12] => Avances et acomptes versés sur commandes Solde débiteur de :	4091
if  (substr( $_->{numero_compte}, 0, 4 ) =~ /4091/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$actif[12] += $total ;
		}		
	}}
#$actif[13] => Avances et acomptes versés sur commandes amort Solde créditeur de :	49091
if  (substr( $_->{numero_compte}, 0, 5 ) =~ /49091/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[13] += $total ;
		}		
	}}	
	

#$actif[14] => Créances clients et comptes rattachés Solde débiteur de :	410 à 418
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /410|411|412|413|414|415|416|417|418/
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[14] += $total ;
		}		
	}}
#$actif[15] => Créances clients et comptes rattachés amort Solde créditeur de :	491
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /491/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[15] += $total ;
		}		
	}}		
	

#$actif[16] =>Autres créances Solde débiteur de :	16 à 18	400 à 408	4095 à 4098	42 à 45	460	462	465 à 467 4687 à 476 478 481 488 489
if  (
	(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17|18|42|43|44|45/) ||
	(substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|404|405|406|407|408|460|462|465|466|467|478|481|488|489/) ||
	(substr( $_->{numero_compte}, 0, 3 ) >= 468 && substr( $_->{numero_compte}, 0, 4 ) >= 4687 && (substr( $_->{numero_compte}, 0, 3 ) <= 476)) ||
	(substr( $_->{numero_compte}, 0, 4 ) =~ /4095|4096|4097|4098/)	
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[16] += $total ;
		}		
	}}
#$actif[17] => Autres créances amort Solde créditeur de :	495	496
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /495|496/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[17] += $total ;
		}		
	}}		

#$actif[18] => Valeurs mobilières de placement Solde débiteur de :	501 à 508
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /501|502|503|504|505|506|507|508/
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[18] += $total ;
		}		
	}}
#$actif[19] => Valeurs mobilières de placement amort Solde créditeur de :	590
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /590/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[19] += $total ;
		}		
	}}	
	
#$actif[20] => Disponibilités : Solde débiteur de :	511 à 517	5187 à 59
if  (
	(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
	(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[20] += $total ;
		}		
	}}
#$actif[21] =>  Disponibilités : amort Solde créditeur de :	591	594
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /591|594/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif[21] += $total ;
		}		
	}}	

#$actif[22] => Charges constatées d'avance Solde débiteur de :	486
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /486/
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif[22] += $total ;
		}		
	}}
	
################# ACTIF #################	 

#################PASSIF#################

		#$passif[0] Capital social (dont versé :) Solde créditeur de :	101 Crédit de :	108 Moins le solde débiteur de :	109
		if(substr( $_->{numero_compte}, 0, 3 ) =~ /101/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[0] += $total ;}}}	
		#$passif[0] => Capital social Crédit de :	108
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /108/) {(my $total = $_->{total_credit});$passif[0] += $total;}
		#$passif[0] => Capital social Moins le solde débiteur de :	109
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /109/	){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$passif[0] -= $total ;}}}	
		
		#$passif[1] => Ecart de réévaluation Crédit de :	105	107
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /105|107/) {(my $total = $_->{total_credit});$passif[1] += $total;}
		
		#$passif[2] Réserve légale Solde créditeur de :	1061
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1061/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[2] += $total ;}}}	
		
		#$passif[3] Réserves réglementées Solde créditeur de :	1062	1064
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1062|1064/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[3] += $total ;}}}	
		
		#$passif[4] Autres réserves Solde créditeur de :	104	1063	1068
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /104/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /1063|1068/)) {
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[4] += $total ;}}}	
		
		#$passif[5] => Report à nouveau Crédit de :	11
		if  (substr( $_->{numero_compte}, 0, 2 ) =~ /11/) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$passif[5] += ($total - $total2);}
		
		#$passif[15] calcul resultat compte classe 7 - classe 6
		if	((substr( $_->{numero_compte}, 0, 1) =~ /6|7/)) {
		(my $total = $_->{total_credit} - $_->{total_debit});$passif[15] += $total;}
		
		
		#$passif[6] => Résultat de l'exercice (Bénéfice ou Perte) CLASSE7 - CLASSE 6
		if	((substr( $_->{numero_compte}, 0, 1) =~ /6|7/) ) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$passif[6] += ($total - $total2);}
		
		#$passif[6] => Résultat de l'exercice (Bénéfice ou Perte) 120 ; - 129 D
		if	((substr( $_->{numero_compte}, 0, 2) =~ /12/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /129/)) {
		(my $total = $_->{total_credit} - $_->{total_debit});$passif[6] += $total;}
		
		
		#$passif[7] Provisions réglementées Solde créditeur de :	131 à 138	14 Moins le solde débiteur de :	139
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /131|132|133|134|135|136|137|138/) ||(substr( $_->{numero_compte}, 0, 2 ) =~ /14/)
		&& not(substr( $_->{numero_compte}, 0, 3 ) =~ /139/)){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[7] += $total ;}}}	

		#$passif[14] Provisions pour risques et charges Solde créditeur de :	15
		if	(substr( $_->{numero_compte}, 0, 2 ) =~ /15/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[14] += $total ;}}}	


	    #$passif[8] Emprunts et dettes assimilées "Solde créditeur de :	16 à 17	426	451	456	458	512 à 517	5181	5186	519 à 58
		if	(((substr( $_->{numero_compte}, 0, 2 ) >= 16) && (substr( $_->{numero_compte}, 0, 2 ) <= 17))
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458|512|513|514|515|516|517/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 2 ) >= 51) && (substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 2 ) <= 58))){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[8] += $total ;}}}	
	    
	    #$passif[9] Avances et acomptes reçus sur commandes en cours "Solde créditeur de :	4191
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /4191/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[9] += $total ;}}}	
	    
	    #$passif[10] Dettes fournisseurs et comptes rattachés "Solde créditeur de :	400 à 403	408 Moins le solde créditeur de :	4084
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|408/)	&& not(substr( $_->{numero_compte}, 0, 4 ) =~ /4084/)
			){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[10] += $total ;}}}		
	    	
		#$passif[11] Autres dettes Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 427) && (substr( $_->{numero_compte}, 0, 4 ) <= 4286) && (substr( $_->{numero_compte}, 0, 3 ) <= 428))
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 431) && (substr( $_->{numero_compte}, 0, 4 ) <= 4386) && (substr( $_->{numero_compte}, 0, 3 ) <= 438))
		||	((substr( $_->{numero_compte}, 0, 4 ) >= 4411) && (substr( $_->{numero_compte}, 0, 4 ) <= 4487) && (substr( $_->{numero_compte}, 0, 3 ) <= 448))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[11] += $total ;}}}
	
	    #$passif[12] Produits constatés d'avance Solde créditeur de :	487
		if	(substr( $_->{numero_compte}, 0, 3 ) =~ /487/){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif[12] += $total ;}}}	

#################PASSIF#################

			$numero_compte = $_->{numero_compte} ;
		} #  fin for ( @$result_set ) {
################# ANNEE N #################   

################# ANNEE N-1 #################   
    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, (($r->pnotes('session')->{fiscal_year} ) -1)) ;
    my $result_set_N1 = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    for ( @$result_set_N1 ) {
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /401/) {
		$_->{numero_compte} = '401'.$_->{numero_compte};	
		}
		
		# correction warning  isn't numeric in numeric ge (>=)
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /411/) {
		$_->{numero_compte} = '411'.$_->{numero_compte};	
		}
################# ACTIF #################	 

#$actif_N1[0] =>Fonds commercial Débit de :	206	207
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{total_debit});$actif_N1[0] += $total;}
#$actif_N1[1] => Fonds commercial amort Crédit de :	2807	2906	2907
if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2807|2906|2907/) {(my $total = $_->{total_credit});$actif_N1[1] += $total;}

#$actif_N1[2] => Autres immobilisations incorporelles : Débit de : 201	203	204	205	208	232	237
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{total_debit});$actif_N1[2] += $total;}
#$actif_N1[3] => Autres immobilisations incorporelles amort Crédit de :	2801 2803 2804 2805 2808 2901 2903 2904 2905 2908 2932
if  (substr( $_->{numero_compte}, 0, 4 ) =~ /2801|2803|2804|2805|2808|2901|2903|2904|2905|2908|2932/) {(my $total = $_->{total_credit});$actif_N1[3] += $total;}
	
#$actif_N1[4] =>Immobilisations corporelles Débit de :	21	22	231	238
if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{total_debit});$actif_N1[4] += $total;}
#$actif_N1[5] => Immobilisations corporelles amort Crédit de : 281 291 282 292 2931
if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/)) { (my $total = $_->{credit});$actif_N1[5] += $total;}

#$actif_N1[6] =>Immobilisations financières : Débit de :	25 à 268	271 à 277 Moins le débit de :	259
if  (
	(substr( $_->{numero_compte}, 0, 2 ) >= 25 && (substr( $_->{numero_compte}, 0, 3 ) <= 268)) ||
	(substr( $_->{numero_compte}, 0, 3 ) =~ /271|272|273|274|275|276|277/)	&&	
	not(substr( $_->{numero_compte}, 0, 3 ) =~ /259/)
	){ (my $total = $_->{total_debit});$actif_N1[6] += $total;}
#$actif_N1[7] => Immobilisations financières amort "Crédit de : 295 296 297
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /295|296|297/) { (my $total = $_->{total_credit});$actif_N1[7] += $total;}
	

#$actif_N1[8] => Stocks et en cours " Solde débiteur de :	31 à 36	38 Moins le solde débiteur de :	387
if  (
	(substr( $_->{numero_compte}, 0, 2 ) =~ /31|32|33|34|35|36|38/)	&&	
	not(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[8] += $total ;
		}		
	}}
#$actif_N1[9] => Stocks et en cours amort Solde créditeur de : 390 à 396	398 Moins le solde créditeur de :	3987
if  (
	(substr( $_->{numero_compte}, 0, 3 ) =~ /390|391|392|393|394|395|396|398/)	&&	
	not(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[9] += $total ;
		}		
	}}
	
#$actif_N1[10] => Stocks de marchandises " Solde débiteur de :	37	387
if  (
	(substr( $_->{numero_compte}, 0, 2 ) =~ /37/)	||	
	(substr( $_->{numero_compte}, 0, 3 ) =~ /387/)
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[10] += $total ;
		}		
	}}
#$actif_N1[11] => Stocks de marchandises amort "Solde créditeur de :	397	3987
if  (
	(substr( $_->{numero_compte}, 0, 3 ) =~ /397/) ||	
	(substr( $_->{numero_compte}, 0, 4 ) =~ /3987/)

	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[11] += $total ;
		}		
	}}
	

#$actif_N1[12] => Avances et acomptes versés sur commandes Solde débiteur de :	4091
if  (substr( $_->{numero_compte}, 0, 4 ) =~ /4091/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$actif_N1[12] += $total ;
		}		
	}}
#$actif_N1[13] => Avances et acomptes versés sur commandes amort Solde créditeur de :	49091
if  (substr( $_->{numero_compte}, 0, 5 ) =~ /49091/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[13] += $total ;
		}		
	}}	
	

#$actif_N1[14] => Créances clients et comptes rattachés Solde débiteur de :	410 à 418
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /410|411|412|413|414|415|416|417|418/
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[14] += $total ;
		}		
	}}
#$actif_N1[15] => Créances clients et comptes rattachés amort Solde créditeur de :	491
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /491/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[15] += $total ;
		}		
	}}		
	

#$actif_N1[16] =>Autres créances Solde débiteur de :	16 à 18	400 à 408	4095 à 4098	42 à 45	460	462	465 à 467 4687 à 476 478 481 488 489
if  (
	(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17|18|42|43|44|45/) ||
	(substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|404|405|406|407|408|460|462|465|466|467|478|481|488|489/) ||
	(substr( $_->{numero_compte}, 0, 3 ) >= 468 && substr( $_->{numero_compte}, 0, 4 ) >= 4687 && (substr( $_->{numero_compte}, 0, 3 ) <= 476)) ||
	(substr( $_->{numero_compte}, 0, 4 ) =~ /4095|4096|4097|4098/)	
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[16] += $total ;
		}		
	}}
#$actif_N1[17] => Autres créances amort Solde créditeur de :	495	496
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /495|496/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[17] += $total ;
		}		
	}}		

#$actif_N1[18] => Valeurs mobilières de placement Solde débiteur de :	501 à 508
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /501|502|503|504|505|506|507|508/
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[18] += $total ;
		}		
	}}
#$actif_N1[19] => Valeurs mobilières de placement amort Solde créditeur de :	590
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /590/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[19] += $total ;
		}		
	}}	
	
#$actif_N1[20] => Disponibilités : Solde débiteur de :	511 à 517	5187 à 59
if  (
	(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
	(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[20] += $total ;
		}		
	}}
#$actif_N1[21] =>  Disponibilités : amort Solde créditeur de :	591	594
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /591|594/	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$actif_N1[21] += $total ;
		}		
	}}	

#$actif_N1[22] => Charges constatées d'avance Solde débiteur de :	486
if  (substr( $_->{numero_compte}, 0, 3 ) =~ /486/
	){ 
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		#if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$actif_N1[22] += $total ;
		}		
	}}
	
################# ACTIF #################	 

#################PASSIF#################
		#$passif_N1[0] Capital social (dont versé :) Solde créditeur de :	101 Crédit de :	108 Moins le solde débiteur de :	109
		if(substr( $_->{numero_compte}, 0, 3 ) =~ /101/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[0] += $total ;}}}	
		#$passif_N1[0] => Capital social Crédit de :	108
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /108/) {(my $total = $_->{total_credit});$passif_N1[0] += $total;}
		#$passif_N1[0] => Capital social Moins le solde débiteur de :	109
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /109/	){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$passif_N1[0] -= $total ;}}}	
		
		#$passif_N1[1] => Ecart de réévaluation Crédit de :	105	107
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /105|107/) {(my $total = $_->{total_credit});$passif_N1[1] += $total;}
		
		#$passif_N1[2] Réserve légale Solde créditeur de :	1061
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1061/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[2] += $total ;}}}	
		
		#$passif_N1[3] Réserves réglementées Solde créditeur de :	1062	1064
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /1062|1064/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[3] += $total ;}}}	
		
		#$passif_N1[4] Autres réserves Solde créditeur de :	104	1063	1068
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /104/) || (substr( $_->{numero_compte}, 0, 4 ) =~ /1063|1068/)) {
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[4] += $total ;}}}	
				
		#$passif_N1[5] => Report à nouveau Crédit de :	11
		if  (substr( $_->{numero_compte}, 0, 2 ) =~ /11/) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$passif_N1[5] += ($total - $total2);}
		
		
		#GG => Résultat de l'exercice (Bénéfice ou Perte) CLASSE7 - CLASSE 6
		if	((substr( $_->{numero_compte}, 0, 1) =~ /6|7/) ) {
		(my $total = $_->{credit});(my $total2 = $_->{debit});$passif_N1[6] += ($total - $total2);}
		
		#$passif_N1[6] => Résultat de l'exercice (Bénéfice ou Perte) 120 ; - 129 D
		if	((substr( $_->{numero_compte}, 0, 2) =~ /12/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /129/)) {
		(my $total = $_->{total_credit} - $_->{total_debit});$passif_N1[6] += $total;}
		
		#$passif_N1[7] Provisions réglementées Solde créditeur de :	131 à 138	14 Moins le solde débiteur de :	139
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /131|132|133|134|135|136|137|138/) ||(substr( $_->{numero_compte}, 0, 2 ) =~ /14/)
		&& not(substr( $_->{numero_compte}, 0, 3 ) =~ /139/)){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[7] += $total ;}}}	

		#$passif_N1[14] Provisions pour risques et charges Solde créditeur de :	15
		if	(substr( $_->{numero_compte}, 0, 2 ) =~ /15/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[14] += $total ;}}}	


	    #$passif_N1[8] Emprunts et dettes assimilées "Solde créditeur de :	16 à 17	426	451	456	458	512 à 517	5181	5186	519 à 58
		if	(((substr( $_->{numero_compte}, 0, 2 ) >= 16) && (substr( $_->{numero_compte}, 0, 2 ) <= 17))
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458|512|513|514|515|516|517/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 2 ) >= 51) && (substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 2 ) <= 58))){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[8] += $total ;}}}	
	    
	    #$passif_N1[9] Avances et acomptes reçus sur commandes en cours "Solde créditeur de :	4191
		if	(substr( $_->{numero_compte}, 0, 4 ) =~ /4191/){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[9] += $total ;}}}	
	    
	    #$passif_N1[10] Dettes fournisseurs et comptes rattachés "Solde créditeur de :	400 à 403	408 Moins le solde créditeur de :	4084
		if	((substr( $_->{numero_compte}, 0, 3 ) =~ /400|401|402|403|408/)	&& not(substr( $_->{numero_compte}, 0, 4 ) =~ /4084/)
			){unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[10] += $total ;}}}		
	    	
		#$passif_N1[11] Autres dettes Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 427) && (substr( $_->{numero_compte}, 0, 4 ) <= 4286) && (substr( $_->{numero_compte}, 0, 3 ) <= 428))
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 431) && (substr( $_->{numero_compte}, 0, 4 ) <= 4386) && (substr( $_->{numero_compte}, 0, 3 ) <= 438))
		||	((substr( $_->{numero_compte}, 0, 4 ) >= 4411) && (substr( $_->{numero_compte}, 0, 4 ) <= 4487) && (substr( $_->{numero_compte}, 0, 3 ) <= 448))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[11] += $total ;}}}
	
	    #$passif_N1[12] Produits constatés d'avance Solde créditeur de :	487
		if	(substr( $_->{numero_compte}, 0, 3 ) =~ /487/){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$passif_N1[12] += $total ;}}}	

#################PASSIF#################

			$numero_compte = $_->{numero_compte} ;
		} #  fin for ( @$result_set ) {
################# ANNEE N-1 #################   


		# Calculs des arrondies pour @actif et @passif
		foreach my $value_numbers ( 
		#variable
		@actif,@passif,@actif_N1,@passif_N1
		) {
		#$value_numbers =~ s/\,/\./g;
		if(($value_numbers=~/\d/) && ($value_numbers >= 0) && ($value_numbers < 999999999999999)){
		$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} elsif (($value_numbers=~/\d/) && ($value_numbers <= 0) && ($value_numbers > -999999999999999)){
		$value_numbers = int(($value_numbers/100)- 0.5) ;	
		}
		
		

	} 

#Calcul des totaux
################# ANNEE N#################	
$actif_total[0] = $actif[0] - $actif[1];
$actif_total[2] = $actif[2] - $actif[3];
$actif_total[4] = $actif[4] - $actif[5];
$actif_total[6] = $actif[6] - $actif[7];
$actif_total[8] = $actif[8] - $actif[9];
$actif_total[10] = $actif[10] - $actif[11];
$actif_total[12] = $actif[12] - $actif[13];
$actif_total[14] = $actif[14] - $actif[15];
$actif_total[16] = $actif[16] - $actif[17];
$actif_total[18] = $actif[18] - $actif[19];
$actif_total[20] = $actif[20] - $actif[21];
$actif_totaux[8] = $actif[22] - $actif[23];
$actif_totaux[0] = $actif[0] + $actif[2] + $actif[4] + $actif[6] ;
$actif_totaux[1] = $actif[1] + $actif[3] + $actif[5] + $actif[7] ;
$actif_totaux[2] = $actif_totaux[0] - $actif_totaux[1];
$actif_totaux[3] = $actif[8] + $actif[10] + $actif[12] + $actif[14] + $actif[16] + $actif[18] + $actif[20];
$actif_totaux[4] = $actif[9] + $actif[11] + $actif[13] + $actif[15] + $actif[17] + $actif[19] + $actif[21];
$actif_totaux[5] = $actif_totaux[3] - $actif_totaux[4];
$actif_totaux[9] = $actif_totaux[0] + $actif_totaux[3] + $actif[22];
$actif_totaux[10] = $actif_totaux[1] + $actif_totaux[4] + $actif[23];
$actif_totaux[11] = $actif_totaux[9] - $actif_totaux[10];

#if ($passif[6] == 0) {$passif[6] = $resultat_annee_N;} else { $passif[6] =  $passif[6] + $passif[15];}
$passif_totaux[0]= $passif[0] + $passif[1] + $passif[2] + $passif[3] + $passif[4] + $passif[5] +$passif[6] + $passif[7] ;
$passif_totaux[1]= $passif[8] +$passif[9] + $passif[10] + $passif[11];
$passif_totaux[2] = $passif_totaux[0] + $passif_totaux[1] + $passif[12] + $passif[14];
#################ANNEE N#################
################# ANNEE N-1#################	
$actif_total_N1[0] = $actif_N1[0] - $actif_N1[1];
$actif_total_N1[2] = $actif_N1[2] - $actif_N1[3];
$actif_total_N1[4] = $actif_N1[4] - $actif_N1[5];
$actif_total_N1[6] = $actif_N1[6] - $actif_N1[7];
$actif_total_N1[8] = $actif_N1[8] - $actif_N1[9];
$actif_total_N1[10] = $actif_N1[10] - $actif_N1[11];
$actif_total_N1[12] = $actif_N1[12] - $actif_N1[13];
$actif_total_N1[14] = $actif_N1[14] - $actif_N1[15];
$actif_total_N1[16] = $actif_N1[16] - $actif_N1[17];
$actif_total_N1[18] = $actif_N1[18] - $actif_N1[19];
$actif_total_N1[20] = $actif_N1[20] - $actif_N1[21];
$actif_totaux_N1[8] = $actif_N1[22] - $actif_N1[23];
$actif_totaux_N1[0] = $actif_N1[0] + $actif_N1[2] + $actif_N1[4] + $actif_N1[6] ;
$actif_totaux_N1[1] = $actif_N1[1] + $actif_N1[3] + $actif_N1[5] + $actif_N1[7] ;
$actif_totaux_N1[2] = $actif_totaux_N1[0] - $actif_totaux_N1[1];
$actif_totaux_N1[3] = $actif_N1[8] + $actif_N1[10] + $actif_N1[12] + $actif_N1[14] + $actif_N1[18] + $actif_N1[20];
$actif_totaux_N1[4] = $actif_N1[9] + $actif_N1[11] + $actif_N1[13] + $actif_N1[15] + $actif_N1[19] + $actif_N1[21];
$actif_totaux_N1[5] = $actif_totaux_N1[3] - $actif_totaux_N1[4];
$actif_totaux_N1[9] = $actif_totaux_N1[0] + $actif_totaux_N1[3] + $actif_N1[22];
$actif_totaux_N1[10] = $actif_totaux_N1[1] + $actif_totaux_N1[4] + $actif_N1[23];
$actif_totaux_N1[11] = $actif_totaux_N1[9] - $actif_totaux_N1[10];
if ($passif_N1[6] == 0) {$passif_N1[6] = $resultat_annee_N1 ;}
$passif_totaux_N1[0]= $passif_N1[0] + $passif_N1[1] + $passif_N1[2] + $passif_N1[3] + $passif_N1[4] + $passif_N1[5] +$passif_N1[6] + $passif_N1[7];
$passif_totaux_N1[1]= $passif_N1[8] +$passif_N1[9] + $passif_N1[10] + $passif_N1[11];
$passif_totaux_N1[2] = $passif_totaux_N1[0] + $passif_totaux_N1[1] + $passif_N1[12] + $passif_N1[14];
#################ANNEE N-1#################

		# Calculs des arrondies pour @actif_total et @actif_total_classe
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		@actif_total,@passif_total,@actif_totaux,@passif_totaux
		) {
		if ($total_numbers > 0) {
		$total_numbers = int($total_numbers+ 0.5) ;
		} elsif ($total_numbers < 0) {
		$total_numbers = int($total_numbers - 0.5) ;
		}
		#$total_numbers =~ s/\B(?=(...)*$)/ /g ;
		}
		
		my $colour_resultat_N = '';
		my $colour_resultat_N1 = '';
		
		if ($resultat_annee_N > 0 || $passif[6] > 0) {
		$colour_resultat_N = 'style="color: green;"'}
		elsif ($resultat_annee_N < 0 || $passif[6] < 0) {
		$colour_resultat_N = 'style="color: red;"'}
		
		if ($resultat_annee_N1 > 0 || $passif_N1[6] > 0) {
		$colour_resultat_N1 = 'style="color: green;"'}
		elsif ($resultat_annee_N1 < 0 || $passif_N1[6] < 0) {
		$colour_resultat_N1 = 'style="color: red;"'}
		
		# Mise en forme affichage pour tout le monde et on cache les 0
		foreach my $affichage_numbers ( 
		#variable
		@actif,@actif_total,@actif_total_N1,@passif_total_N1,
		@passif,@passif_total,@passif_N1,@actif_totaux,@passif_totaux,@actif_totaux_N1,@passif_totaux_N1
		) {
		if ($affichage_numbers == '0' ){
		$affichage_numbers = '&nbsp;';
		} else {
		$affichage_numbers =~ s/\B(?=(...)*$)/ /g ;
		}
		}	
		
		#lien vers le contenu du compte
		my $compte_href = '/'.$r->pnotes('session')->{racine}.'/compte?numero_compte=&amp;libelle_compte=' ;
		
		#&emsp;
		my $compte_list .= '
	 
		<fieldset class="pretty-box"><legend><h3>BILAN</h3></legend>

		<div class=flex-table><div class=spacer></div>
		<div class="bilan bilan_niveau0_actif"><div class=bilan_rubriques_actif><h2>ACTIF</h2></div><div class=data_titre_actif_bilan ><h4>Brut</h4></div><div class=data_titre_actif_bilan><h4>Amort.<br>prov.</h4></div><div class=data_titre_actif_bilan ><h4>'.$r->pnotes('session')->{Exercice_fin_DMY}.'<br>Net</h4></div><div class=data_titre_actif_bilan ><h4>'.$r->pnotes('session')->{Exercice_fin_DMY_N1}.'<br>Net</h4></div></div>
		<div class="bilan bilan_niveau0_passif"><div class=bilan_rubriques_passif><h2>PASSIF</h2></div><div class=data_titre_passif_bilan  ><h4>'.$r->pnotes('session')->{Exercice_fin_DMY}.'</h4></div><div class=data_titre_passif_bilan ><h4>'.$r->pnotes('session')->{Exercice_fin_DMY_N1}.'</h4></div></div></div>
	
		<div class=flex-table><div class=spacer></div>
		<div class="bilan bilan_niveau1_actif"><div class=bilan_rubriques_actif><h4>ACTIF IMMOBILISÉ</h4></div></div>
		<div class="bilan bilan_niveau1_passif"><div class=bilan_rubriques_passif><h4>CAPITAUX PROPRES</h4></div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Immobilisations incorporelles :</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="font-weight: bold;">Capital social</div><div class=data_passif_bilan>'.$passif[0].'</div><div class=data_passif_bilan>'.$passif_N1[0].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="padding-left: 5px;">- Fonds commercial</div><div class=data_actif_bilan>'.$actif[0].'</div><div class=data_actif_bilan>'.$actif[1].'</div><div class=data_actif_bilan>'.$actif_total[0].'</div><div class=data_actif_bilan>'.$actif_total_N1[0].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>Ecart de réévaluation</div><div class=data_passif_bilan>'.$passif[1].'</div><div class=data_passif_bilan>'.$passif_N1[1].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="padding-left: 5px;">- Autres immobilisations incorporelles</div><div class=data_actif_bilan>'.$actif[2].'</div><div class=data_actif_bilan>'.$actif[3].'</div><div class=data_actif_bilan>'.$actif_total[2].'</div><div class=data_actif_bilan>'.$actif_total_N1[2].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="font-weight: bold;">Réserves :</div><div class=data_passif_bilan>&nbsp;</div><div class=data_passif_bilan>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Immobilisations corporelles</div><div class=data_actif_bilan>'.$actif[4].'</div><div class=data_actif_bilan>'.$actif[5].'</div><div class=data_actif_bilan>'.$actif_total[4].'</div><div class=data_actif_bilan>'.$actif_total_N1[4].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="padding-left: 5px;">- Réserve légale</div><div class=data_passif_bilan>'.$passif[2].'</div><div class=data_passif_bilan>'.$passif_N1[2].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Immobilisations financières</div><div class=data_actif_bilan>'.$actif[6].'</div><div class=data_actif_bilan>'.$actif[7].'</div><div class=data_actif_bilan>'.$actif_total[6].'</div><div class=data_actif_bilan>'.$actif_total_N1[6].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="padding-left: 5px;">- Réserves réglementées</div><div class=data_passif_bilan>'.$passif[3].'</div><div class=data_passif_bilan>'.$passif_N1[3].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="padding-left: 5px;">- Autres réserves</div><div class=data_passif_bilan>'.$passif[4].'</div><div class=data_passif_bilan>'.$passif_N1[4].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>Report à nouveau</div><div class=data_passif_bilan>'.$passif[5].'</div><div class=data_passif_bilan>'.$passif_N1[5].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="font-weight: bold;">Résultat de l\'exercice (Bénéfice ou Perte)</div><div class=data_passif_bilan '.$colour_resultat_N.'>'.($passif[6]).'</div><div class=data_passif_bilan '.$colour_resultat_N1.'>'.$passif_N1[6].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="font-weight: bold;">Provisions réglementées</div><div class=data_passif_bilan>'.$passif[7].'</div><div class=data_passif_bilan>'.$passif_N1[7].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan bilan_total1_actif"><div class=bilan_rubriques_actif style="text-align: right; font-weight: bold;  padding-right: 5px;">TOTAL I</div><div class=data_actif_bilan>'.$actif_totaux[0].'</div><div class=data_actif_bilan>'.$actif_totaux[1].'</div><div class=data_actif_bilan>'.$actif_totaux[2].'</div><div class=data_actif_bilan>'.$actif_totaux_N1[2].'</div></div>
		<div class="bilan bilan_total1_passif"><div class=bilan_rubriques_passif style="text-align: right; font-weight: bold; padding-right: 5px;">TOTAL I</div><div class=data_passif_bilan>'.$passif_totaux[0].'</div><div class=data_passif_bilan>'.$passif_totaux_N1[0].'</div></div></div>

		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="font-weight: bold;">Provisions pour risques et charges (II)</div><div class=data_passif_bilan>'.$passif[14].'</div><div class=data_passif_bilan>'.$passif_N1[14].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan bilan_niveau1_actif"><div class=bilan_rubriques_actif><h4>ACTIF CIRCULANT</h4></div></div>
		<div class="bilan bilan_niveau1_passif"><div class=bilan_rubriques_passif><h4>DETTES</h4></div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Stocks et en cours</div><div class=data_actif_bilan>'.$actif[8].'</div><div class=data_actif_bilan>'.$actif[9].'</div><div class=data_actif_bilan>'.$actif_total[8].'</div><div class=data_actif_bilan>'.$actif_total_N1[8].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>Emprunts et dettes assimilées</div><div class=data_passif_bilan>'.$passif[8].'</div><div class=data_passif_bilan>'.$passif_N1[8].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Stocks de marchandises</div><div class=data_actif_bilan>'.$actif[10].'</div><div class=data_actif_bilan>'.$actif[11].'</div><div class=data_actif_bilan>'.$actif_total[10].'</div><div class=data_actif_bilan>'.$actif_total_N1[10].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>Avances, acomptes reçus sur commandes en cours</div><div class=data_passif_bilan>'.$passif[9].'</div><div class=data_passif_bilan>'.$passif_N1[9].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Avances et acomptes versés sur commandes</div><div class=data_actif_bilan>'.$actif[12].'</div><div class=data_actif_bilan>'.$actif[13].'</div><div class=data_actif_bilan>'.$actif_total[12].'</div><div class=data_actif_bilan>'.$actif_total_N1[12].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>Dettes fournisseurs et comptes rattachés</div><div class=data_passif_bilan>'.$passif[10].'</div><div class=data_passif_bilan>'.$passif_N1[10].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Créances :</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>'.$actif_total_N1[14].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>Autres dettes</div><div class=data_passif_bilan>'.$passif[11].'</div><div class=data_passif_bilan>'.$passif_N1[11].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="padding-left: 5px;">- Créances clients et comptes rattachés</div><div class=data_actif_bilan>'.$actif[14].'</div><div class=data_actif_bilan>'.$actif[15].'</div><div class=data_actif_bilan>'.$actif_total[14].'</div><div class=data_actif_bilan>'.$actif_total_N1[14].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>&nbsp;</div><div class=data_passif_bilan>'.$passif[12].'</div><div class=data_passif_bilan>'.$passif_N1[12].'</div></div></div>

		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="padding-left: 5px;">- Autres créances </div><div class=data_actif_bilan>'.$actif[16].'</div><div class=data_actif_bilan>'.$actif[17].'</div><div class=data_actif_bilan>'.$actif_total[16].'</div><div class=data_actif_bilan>'.$actif_total_N1[16].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>&nbsp;</div><div class=data_passif_bilan>'.$passif[13].'</div><div class=data_passif_bilan>'.$passif_N1[13].'</div></div></div>
				
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Valeurs mobilières de placement</div><div class=data_actif_bilan>'.$actif[18].'</div><div class=data_actif_bilan>'.$actif[19].'</div><div class=data_actif_bilan>'.$actif_total[18].'</div><div class=data_actif_bilan>'.$actif_total_N1[18].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>&nbsp;</div><div class=data_passif_bilan>&nbsp;</div><div class=data_passif_bilan>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Disponibilités</div><div class=data_actif_bilan>'.$actif[20].'</div><div class=data_actif_bilan>'.$actif[21].'</div><div class=data_actif_bilan>'.$actif_total[20].'</div><div class=data_actif_bilan>'.$actif_total_N1[20].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif>&nbsp;</div><div class=data_passif_bilan>&nbsp;</div><div class=data_passif_bilan>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan bilan_total1_actif"><div class=bilan_rubriques_actif style="text-align: right; font-weight: bold; padding-right: 5px;">TOTAL II</div><div class=data_actif_bilan>'.$actif_totaux[3].'</div><div class=data_actif_bilan>'.$actif_totaux[4].'</div><div class=data_actif_bilan>'.$actif_totaux[5].'</div><div class=data_actif_bilan>'.$actif_totaux_N1[5].'</div></div>
		<div class="bilan bilan_total1_passif"><div class=bilan_rubriques_passif style="text-align: right; font-weight: bold; padding-right: 5px;">TOTAL III</div><div class=data_passif_bilan>'.$passif_totaux[1].'</div><div class=data_passif_bilan>'.$passif_totaux_N1[1].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="bilan fenetre_bilan_data_actif"><div class=bilan_rubriques_actif style="font-weight: bold;">Charges constatées d\'avance (III)</div><div class=data_actif_bilan>'.$actif[22].'</div><div class=data_actif_bilan>&nbsp;</div><div class=data_actif_bilan>'.$actif_totaux[8].'</div><div class=data_actif_bilan>'.$actif_totaux_N1[8].'</div></div>
		<div class="bilan fenetre_bilan_data_passif"><div class=bilan_rubriques_passif style="font-weight: bold;">Produits constatés d\'avance (IV)</div><div class=data_passif_bilan>'.$passif[12].'</div><div class=data_passif_bilan>'.$passif_N1[12].'</div></div></div>
	
		<div class=flex-table><div class=spacer></div>
		<div class="bilan bilan_total2_actif"><div class=bilan_rubriques_actif style="text-align: right; font-weight: bold; padding-right: 5px;">TOTAL GENERAL (I+II+III)</div><div class=data_actif_bilan>'.$actif_totaux[9].'</div><div class=data_actif_bilan>'.$actif_totaux[10].'</div><div class=data_actif_bilan>'.$actif_totaux[11].'</div><div class=data_actif_bilan>'.$actif_totaux_N1[11].'</div></div>
		<div class="bilan bilan_total2_passif"><div class=bilan_rubriques_passif style="text-align: right; font-weight: bold; padding-right: 5px;">TOTAL GENERAL (I+II+III+IV)</div><div class=data_passif_bilan>'.$passif_totaux[2].'</div><div class=data_passif_bilan>'.$passif_totaux_N1[2].'</div></div></div>

		</fieldset>
		';

#style="color: green;" style="color: red;"

	$content .= '<div class="wrapper">' . $compte_list . '</div>' ;
   
    return $content ;
	
} #sub bilan 

sub resultat {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
    my $numero_compte = '0';
    
    our $resultat_annee_N;
    our $resultat_annee_N1;
     
	######## Affichage MENU display_compte_set Début ######
    $content .= display_menu_formulaire( $r, $args ) ;
	######## Affichage MENU display_compte_set Fin ########

	### Déclaration des variables
    my @charges = ('0') x 80;
    my @charges_N1 = ('0') x 80;
    my @produits = ('0') x 80;
    my @produits_N1 = ('0') x 80;
    my @charges_total = ('0') x 10;
    my @charges_total_N1 = ('0') x 10;
    my @produits_total = ('0') x 10;
    my @produits_total_N1 = ('0') x 10;
    
    
#####################################       
# Préparation à l'impression		#
#####################################   
	my $date = localtime->strftime('%d/%m/%Y');

    #paramètres généraux du client
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, adresse_1, code_postal, ville, journal_tva FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;


	$content .= '
			<div class="printable">
			<div style="float: left ">
		<address><strong>'.$parametre_set->[0]->{etablissement} . '</strong><br>
		' . ($parametre_set->[0]->{adresse_1} || '') . ' <br> ' . ($parametre_set->[0]->{code_postal} || ''). ' ' . ($parametre_set->[0]->{ville} || '').'<br>
		SIRET : ' . $parametre_set->[0]->{siret} . '<br>
			</address></div>
			<div style="float: right; text-align: right;">
			Imprimé le ' . $date . '<br>
			<div>
			Exercice du '.$r->pnotes('session')->{Exercice_debut_DMY}.' 
			</div>
			au '.$r->pnotes('session')->{Exercice_fin_DMY}.'<br>
			</div>
			<div style="width: 100%; text-align: center;"><h1>Compte de Résultat au '.$r->pnotes('session')->{Exercice_fin_DMY}.'</h1>
			<div >
			Etat exprimé en Euros</div>
			</div><br></div>' ;

			
######## Selection année N Début######
    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    for ( @$result_set ) {
	    #$charges[0] => Achats de marchandises "Débit de :	607	6087 6097 60987 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /607/) || (substr( $_->{numero_compte}, 0, 4) =~ /6087|6097/) || (substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[0] += $total ;}}}
		
		#$charges[1] => Variation de stock marchandises Débit de : 6037
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6037/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[1] += $total ;}}}
		
	    #$charges[2] => Achats d'approvisionnements  "Débit de : 601 602 6081 6082 6091	6092"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6081|6082|6091|6092/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[2] += $total ;}}}
		
		#$charges[3] => Variation de stock matière première approvisionnements  "Débit de :	6030 6031 6032
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6030|6031|6032/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[3] += $total ;}}}
		
		#$charges[4] => Autres charges externes 
		# "Débit de :	604 à 606	608	61 à 62	609 Moins le débit de :	6087 6081 6082	6091 6092 6097	60987" 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /604|605|606|608|609/) || (substr( $_->{numero_compte}, 0, 2) =~ /61|62/) && not(substr( $_->{numero_compte}, 0, 4) =~ /6087|6081|6082|6091|6092|6097/) && not(substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[4] += $total ;}}}
		
		#$charges[5] => Impôts taxes et versements assimilés Débit de :	63"
		if	(substr( $_->{numero_compte}, 0, 2) =~ /63/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[5] += $total ;}}}
		
		#$charges[6] => Rémunérations du personnel "Débit de : 641 644"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /641|644/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[6] += $total ;}}}
		
		#$charges[7] => Charges sociales "Débit de : 645 à 649"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /645|646|647|648|649/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[7] += $total ;}}}
		
		#$charges[8] => Dotations aux Amortissements Débit de :	681 à 6812"
		if ((substr( $_->{numero_compte}, 0, 3 ) >= 681) && (substr( $_->{numero_compte}, 0, 4 ) <= 6812)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[8] += $total ;}}}
		
		#$charges[9] => Dotations aux provisions Débit de :	6815 à 6817
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6815|6816|6817/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[9] += $total ;}}}
		
		#$charges[10] => Autres charges d'exploitation Débit de 65 (sauf 655)
		if	((substr( $_->{numero_compte}, 0, 3) =~ /65/) && not(substr( $_->{numero_compte}, 0, 3) =~ /655/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[10] += $total ;}}}
		
		#$charges[11] => Charges financières "Débit de :66	686
		if	((substr( $_->{numero_compte}, 0, 2) =~ /66/) || (substr( $_->{numero_compte}, 0, 3) =~ /686/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[11] += $total ;}}}
		
		#$charges[12] => Charges exceptionnelles "Débit de : 67	687	691"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /687|691/) || (substr( $_->{numero_compte}, 0, 2) =~ /67/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[12] += $total ;}}}
		
		#$charges[13] => Impôts sur les bénéfices Débit de :695 à 698 699"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /695|696|697|698|699/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges[13] += $total ;}}}
		
		#$produits[0] => Ventes de marchandises Crédit de :	707	7097"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /707/) || (substr( $_->{numero_compte}, 0, 4) =~ /7097/) ) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[0] += $total ;}}}
		
		#$produits[1] => Production Vendue Crédit de :	701 à 703	7091 à 7093
		# Crédit de :	704 à 706	708	709 Moins le crédit de :	7091 à 7093	7097" 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /701|702|703|704|705|706|708|709/) || (substr( $_->{numero_compte}, 0, 4) =~ /7091|7092|7093/)  && not(substr( $_->{numero_compte}, 0, 4) =~ /7097/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[1] += $total ;}}}
		
		#$produits[2] => Production Stockée Crédit de :	71" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /71/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[2] += $total ;}}}
			
		#$produits[3] => Production Immobilisée Crédit de :	72" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /72/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[3] += $total ;}}}
		
		#$produits[4] => Subventions d'exploitation :	74" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /74/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[4] += $total ;}}}
		
		#$produits[5] => Crédit de :	73	75	781	791" 	
		if	((substr( $_->{numero_compte}, 0, 2) =~ /73|75/) || (substr( $_->{numero_compte}, 0, 3) =~ /781|791/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[5] += $total ;}}}
		
		#$produits[11] => PRODUITS FINANCIERS Crédit de :	76	786	796	
		if	((substr( $_->{numero_compte}, 0, 2) =~ /76/) || (substr( $_->{numero_compte}, 0, 3) =~ /786|796/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[11] += $total ;}}}
		
		#$produits[12] => PRODUITS EXEPTIONNEL Crédit de :	77	787	797
		if	((substr( $_->{numero_compte}, 0, 2) =~ /77/) || (substr( $_->{numero_compte}, 0, 3) =~ /787|797/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits[12] += $total ;}}}

			$numero_compte = $_->{numero_compte} ;
		} #  fin for ( @$result_set ) {
######## Selection année N Fin######



######## Selection année N-1 Début######
    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit FROM tbljournal WHERE id_client = ? and fiscal_year = ? AND libelle_journal NOT LIKE \'%CLOTURE%\'
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit::numeric as debit, credit::numeric as credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

    @bind_array = ( $r->pnotes('session')->{id_client}, ($r->pnotes('session')->{fiscal_year} - 1)) ;
   my $result_set_N1 = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    for ( @$result_set_N1 ) {
	    #$charges_N1[0] => Achats de marchandises "Débit de :	607	6087 6097 60987 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /607/) || (substr( $_->{numero_compte}, 0, 4) =~ /6087|6097/) || (substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[0] += $total ;}}}
		
		#$charges_N1[1] => Variation de stock marchandises Débit de : 6037
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6037/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[1] += $total ;}}}
		
	    #$charges_N1[2] => Achats d'approvisionnements  "Débit de : 601 602 6081 6082 6091	6092"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6081|6082|6091|6092/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[2] += $total ;}}}
		
		#$charges_N1[3] => Variation de stock matière première approvisionnements  "Débit de :	6030 6031 6032
		if	((substr( $_->{numero_compte}, 0, 3) =~ /601|602/) || (substr( $_->{numero_compte}, 0, 4) =~ /6030|6031|6032/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[3] += $total ;}}}
		
		#$charges_N1[4] => Autres charges externes 
		# "Débit de :	604 à 606	608	61 à 62	609 Moins le débit de :	6087 6081 6082	6091 6092 6097	60987" 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /604|605|606|608|609/) || (substr( $_->{numero_compte}, 0, 2) =~ /61|62/) && not(substr( $_->{numero_compte}, 0, 4) =~ /6087|6081|6082|6091|6092|6097/) && not(substr( $_->{numero_compte}, 0, 5) =~ /60987/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[4] += $total ;}}}
		
		#$charges_N1[5] => Impôts taxes et versements assimilés Débit de :	63"
		if	(substr( $_->{numero_compte}, 0, 2) =~ /63/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[5] += $total ;}}}
		
		#$charges_N1[6] => Rémunérations du personnel "Débit de : 641 644"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /641|644/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[6] += $total ;}}}
		
		#$charges_N1[7] => Charges sociales "Débit de : 645 à 649"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /645|646|647|648|649/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[7] += $total ;}}}
		
		#$charges_N1[8] => Dotations aux Amortissements Débit de :	681 à 6812"
		if ((substr( $_->{numero_compte}, 0, 3 ) >= 681) && (substr( $_->{numero_compte}, 0, 4 ) <= 6812)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[8] += $total ;}}}
		
		#$charges_N1[9] => Dotations aux provisions Débit de :	6815 à 6817
		if	(substr( $_->{numero_compte}, 0, 4) =~ /6815|6816|6817/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[9] += $total ;}}}
		
		#$charges_N1[10] => Autres charges d'exploitation Débit de 65 (sauf 655)
		if	((substr( $_->{numero_compte}, 0, 3) =~ /65/) && not(substr( $_->{numero_compte}, 0, 3) =~ /655/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[10] += $total ;}}}
		
		#$charges_N1[11] => Charges financières "Débit de :66	686
		if	((substr( $_->{numero_compte}, 0, 2) =~ /66/) || (substr( $_->{numero_compte}, 0, 3) =~ /686/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[11] += $total ;}}}
		
		#$charges_N1[12] => Charges exceptionnelles "Débit de : 67	687	691"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /687|691/) || (substr( $_->{numero_compte}, 0, 2) =~ /67/))  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[12] += $total ;}}}
		
		#$charges_N1[13] => Impôts sur les bénéfices Débit de :695 à 698 699"
		if	(substr( $_->{numero_compte}, 0, 3) =~ /695|696|697|698|699/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_debiteur}=~/\d/) && ($_->{solde_debiteur} >= 0) && ($_->{solde_debiteur} < 999999999999999)){
		(my $total = $_->{solde_debiteur});$charges_N1[13] += $total ;}}}
		
		#$produits_N1[0] => Ventes de marchandises Crédit de :	707	7097"
		if	((substr( $_->{numero_compte}, 0, 3) =~ /707/) || (substr( $_->{numero_compte}, 0, 4) =~ /7097/) ) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[0] += $total ;}}}
		
		#$produits_N1[1] => Production Vendue Crédit de :	701 à 703	7091 à 7093
		# Crédit de :	704 à 706	708	709 Moins le crédit de :	7091 à 7093	7097" 
		if	((substr( $_->{numero_compte}, 0, 3) =~ /701|702|703|704|705|706|708|709/) || (substr( $_->{numero_compte}, 0, 4) =~ /7091|7092|7093/)  && not(substr( $_->{numero_compte}, 0, 4) =~ /7097/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[1] += $total ;}}}
		
		#$produits_N1[2] => Production Stockée Crédit de :	71" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /71/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[2] += $total ;}}}
			
		#$produits_N1[3] => Production Immobilisée Crédit de :	72" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /72/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[3] += $total ;}}}
		
		#$produits_N1[4] => Subventions d'exploitation :	74" 	
		if	(substr( $_->{numero_compte}, 0, 2) =~ /74/)  {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[4] += $total ;}}}
		
		#$produits_N1[5] => Crédit de :	73	75	781	791" 	
		if	((substr( $_->{numero_compte}, 0, 2) =~ /73|75/) || (substr( $_->{numero_compte}, 0, 3) =~ /781|791/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[5] += $total ;}}}
		
		#$produits_N1[11] => PRODUITS FINANCIERS Crédit de :	76	786	796	
		if	((substr( $_->{numero_compte}, 0, 2) =~ /76/) || (substr( $_->{numero_compte}, 0, 3) =~ /786|796/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[11] += $total ;}}}
		
		#$produits_N1[12] => PRODUITS EXEPTIONNEL Crédit de :	77	787	797
		if	((substr( $_->{numero_compte}, 0, 2) =~ /77/) || (substr( $_->{numero_compte}, 0, 3) =~ /787|797/)) {unless ( $_->{numero_compte} eq $numero_compte ) {
		if(($_->{solde_crediteur}=~/\d/) && ($_->{solde_crediteur} >= 0) && ($_->{solde_crediteur} < 999999999999999)){
		(my $total = $_->{solde_crediteur});$produits_N1[12] += $total ;}}}

			$numero_compte = $_->{numero_compte} ;
		} #  fin for ( @$result_set_N1 ) {
######## Selection année N-1 Fin######







		# Calculs des arrondies pour @actif et @passif
		foreach my $value_numbers ( 
		#variable
		@charges,@produits,@charges_N1,@produits_N1
		) {
		#$value_numbers =~ s/\,/\./g;
		if(($value_numbers=~/\d/) && ($value_numbers >= 0) && ($value_numbers < 999999999999999)){
		$value_numbers = int(($value_numbers/100)+ 0.5) ;
		}

	} 


################# Calcul des totaux Année N #################	
$charges_total[0] = $charges[0] + $charges[1] + $charges[2] + $charges[3] + $charges[4] + $charges[5] + $charges[6] + $charges[7] + $charges[8] + $charges[9] + $charges[10]; 
$produits_total[0] = $produits[0] + $produits[1] + $produits[2] + $produits[3] + $produits[4] + $produits[5] ;
$charges_total[1] = $produits_total[0] - $charges_total[0];
$produits_total[1] = $charges_total[0] - $produits_total[0];
$charges_total[2] = $produits[11] - $charges[11];
$produits_total[2] = $charges[11] - $produits[11];
if ($charges_total[1] >= 0) {$produits_total[1] = 0;} else {$charges_total[1] = 0;}
if ($charges_total[2] >= 0) {$produits_total[2] = 0;} else {$charges_total[2] = 0;}
$produits_total[3] = $produits_total[1] + $produits_total[2] - $charges_total[1] - $charges_total[2];
$charges_total[3] = $charges_total[1] + $charges_total[2] - $produits_total[1] - $produits_total[2];
if ($charges_total[3] >= 0) {$produits_total[3] = 0;} else {$charges_total[3] = 0;}
$charges_total[5] = $charges_total[0] + $charges[11] + $charges[12] + $charges[13];
$produits_total[5] = $produits_total[0] + $produits[11] + $produits[12] + $produits[13];
$charges_total[6] = $produits_total[5] - $charges_total[5];
$produits_total[6] = $charges_total[5] - $produits_total[5];
if ($charges_total[6] >= 0) {$produits_total[6] = 0;} else {$charges_total[6] = 0;}
$resultat_annee_N = $produits_total[5] - $charges_total[5];
$charges_total[7] = $charges_total[5] + $charges_total[6] ;
$produits_total[7] = $produits_total[5] + $produits_total[6] ;
################# Calcul des totaux Année N#################	

################# Calcul des totaux Année N-1 #################	
$charges_total_N1[0] = $charges_N1[0] + $charges_N1[1] + $charges_N1[2] + $charges_N1[3] + $charges_N1[4] + $charges_N1[5] + $charges_N1[6] + $charges_N1[7] + $charges_N1[8] + $charges_N1[9] + $charges_N1[10]; 
$produits_total_N1[0] = $produits_N1[0] + $produits_N1[1] + $produits_N1[2] + $produits_N1[3] + $produits_N1[4] + $produits_N1[5] ;
$charges_total_N1[1] = $produits_total_N1[0] - $charges_total_N1[0];
$produits_total_N1[1] = $charges_total_N1[0] - $produits_total_N1[0];
$charges_total_N1[2] = $produits_N1[11] - $charges_N1[11];
$produits_total_N1[2] = $charges_N1[11] - $produits_N1[11];
if ($charges_total_N1[1] >= 0) {$produits_total_N1[1] = 0;} else {$charges_total_N1[1] = 0;}
if ($charges_total_N1[2] >= 0) {$produits_total_N1[2] = 0;} else {$charges_total_N1[2] = 0;}
$produits_total_N1[3] = $produits_total_N1[1] + $produits_total_N1[2] - $charges_total_N1[1] - $charges_total_N1[2];
$charges_total_N1[3] = $charges_total_N1[1] + $charges_total_N1[2] - $produits_total_N1[1] - $produits_total_N1[2];
if ($charges_total_N1[3] >= 0) {$produits_total_N1[3] = 0;} else {$charges_total_N1[3] = 0;}
$charges_total_N1[5] = $charges_total_N1[0] + $charges_N1[11] + $charges_N1[12] + $charges_N1[13];
$produits_total_N1[5] = $produits_total_N1[0] + $produits_N1[11] + $produits_N1[12] + $produits_N1[13];
$charges_total_N1[6] = $produits_total_N1[5] - $charges_total_N1[5];
$produits_total_N1[6] = $charges_total_N1[5] - $produits_total_N1[5];
if ($charges_total_N1[6] >= 0) {$produits_total_N1[6] = 0;} else {$charges_total_N1[6] = 0;}
$resultat_annee_N1 = $produits_total_N1[5] - $charges_total_N1[5];
$charges_total_N1[7] = $charges_total_N1[5] + $charges_total_N1[6] ;
$produits_total_N1[7] = $produits_total_N1[5] + $produits_total_N1[6] ;
################# Calcul des totaux Année N-1#################	
		
		# Calculs des arrondies pour @actif_total et @actif_total_classe
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		@charges_total,@produits_total,@charges_total_N1,@produits_total_N1
		) {
		if ($total_numbers > 0) {
		$total_numbers = int($total_numbers+ 0.5) ;
		} elsif ($total_numbers < 0) {
		$total_numbers = int($total_numbers - 0.5) ;
		}
		#$total_numbers =~ s/\B(?=(...)*$)/ /g ;
		}
		


		# Mise en forme affichage pour tout le monde et on cache les 0
		foreach my $affichage_numbers ( 
		@charges,@produits,@charges_N1,@produits_N1,@charges_total,@produits_total,@charges_total_N1,@produits_total_N1

		) {
		if ($affichage_numbers == '0' ){
		$affichage_numbers = '&nbsp;';
		} else {
		$affichage_numbers =~ s/\B(?=(...)*$)/ /g ;
		}
		}	

		#lien vers le contenu du compte
		my $compte_href = '/'.$r->pnotes('session')->{racine}.'/compte?numero_compte=&amp;libelle_compte=' ;
		
		my $compte_list .= '
	 
		<fieldset class="pretty-box"><legend><h3>COMPTE DE RESULTAT</h3></legend>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat titre_0_resultat"><div class=data_title_resultat><h3>CHARGES</h3></div><div class=data_resultat><h3>'.$r->pnotes('session')->{Exercice_fin_DMY}.'</h3></div><div class=data_resultat><h3>'.$r->pnotes('session')->{Exercice_fin_DMY_N1}.'</h3></div></div>
		<div class="resultat titre_0_resultat" style="float : right;"><div class=data_title_resultat><h3>PRODUITS</h3></div><div class=data_resultat><h3>'.$r->pnotes('session')->{Exercice_fin_DMY}.'</h3></div><div class=data_resultat><h3>'.$r->pnotes('session')->{Exercice_fin_DMY_N1}.'</h3></div></div></div>
	
		<div class=flex-table><div class=spacer></div>
		<div class="resultat titre_1_resultat"><div class=rubriques_resultat><h4>CHARGES D\'EXPLOITATION</h4></div></div>
		<div class="resultat titre_1_resultat" style="float : right;"><div class=rubriques_resultat><h4>PRODUITS D\'EXPLOITATION</h4></div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Achats de marchandises</div><div class=data_resultat>'.$charges[0].'</div><div class=data_resultat>'.$charges_N1[0].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Ventes de marchandises</div><div class=data_resultat>'.$produits[0].'</div><div class=data_resultat>'.$produits_N1[0].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>		
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Variations de stocks de marchandises</div><div class=data_resultat>'.$charges[1].'</div><div class=data_resultat>'.$charges_N1[1].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Production Vendue</div><div class=data_resultat>'.$produits[1].'</div><div class=data_resultat>'.$produits_N1[1].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Achats d\'approvisionnements</div><div class=data_resultat>'.$charges[2].'</div><div class=data_resultat>'.$charges_N1[2].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Production Stockée</div><div class=data_resultat>'.$produits[2].'</div><div class=data_resultat>'.$produits_N1[2].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Variations de stocks d\'Approvisionnements</div><div class=data_resultat>'.$charges[3].'</div><div class=data_resultat>'.$charges_N1[3].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Production Immobilisée</div><div class=data_resultat>'.$produits[3].'</div><div class=data_resultat>'.$produits_N1[3].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Autres charges externes</div><div class=data_resultat>'.$charges[4].'</div><div class=data_resultat>'.$charges_N1[4].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Subventions d\'exploitation</div><div class=data_resultat>'.$produits[4].'</div><div class=data_resultat>'.$produits_N1[4].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Impôts taxes et versements assimilés</div><div class=data_resultat>'.$charges[5].'</div><div class=data_resultat>'.$charges_N1[5].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Autres produits d\'exploitation</div><div class=data_resultat>'.$produits[5].'</div><div class=data_resultat>'.$produits_N1[5].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Rémunérations du personnel</div><div class=data_resultat>'.$charges[6].'</div><div class=data_resultat>'.$charges_N1[6].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Charges sociales</div><div class=data_resultat>'.$charges[7].'</div><div class=data_resultat>'.$charges_N1[7].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Dotations aux Amortissements et Dépréciations</div><div class=data_resultat>'.$charges[8].'</div><div class=data_resultat>'.$charges_N1[8].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Dotations aux provisions</div><div class=data_resultat>'.$charges[9].'</div><div class=data_resultat>'.$charges_N1[9].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Autres charges d\'exploitation</div><div class=data_resultat>'.$charges[10].'</div><div class=data_resultat>'.$charges_N1[10].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat>Total charges d\'exploitation</div><div class=data_resultat>'.$charges_total[0].'</div><div class=data_resultat>'.$charges_total_N1[0].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat>Total produits d\'exploitation</div><div class=data_resultat>'.$produits_total[0].'</div><div class=data_resultat>'.$produits_total_N1[0].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat>Résultat d\'exploitations (excédent)</div><div class=data_resultat style="color: green;">'.$charges_total[1].'</div><div class=data_resultat style="color: green;">'.$charges_total_N1[1].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat>Résultat d\'exploitations (déficit)</div><div class=data_resultat style="color: red;">'.$produits_total[1].'</div><div class=data_resultat style="color: red;">'.$produits_total_N1[1].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat titre_1_resultat"><div class=rubriques_resultat><h4>CHARGES FINANCIERES</h4></div></div>
		<div class="resultat titre_1_resultat" style="float : right;"><div class=rubriques_resultat><h4>PRODUITS FINANCIERS</h4></div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Charges financières</div><div class=data_resultat>'.$charges[11].'</div><div class=data_resultat>'.$charges_N1[11].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Produits financiers</div><div class=data_resultat>'.$produits[11].'</div><div class=data_resultat>'.$produits_N1[11].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat>Résultat financier (excédent)</div><div class=data_resultat style="color: green;">'.$charges_total[2].'</div><div class=data_resultat style="color: green;">'.$charges_total_N1[2].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat>Résultat financier (déficit)</div><div class=data_resultat style="color: red;">'.$produits_total[2].'</div><div class=data_resultat style="color: red;">'.$produits_total_N1[2].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat>Résultat courant avant impôts (excédent)</div><div class=data_resultat style="color: green;">'.$charges_total[3].'</div><div class=data_resultat style="color: green;">'.$charges_total_N1[3].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat>Résultat courant avant impôts (déficit)</div><div class=data_resultat style="color: red;">'.$produits_total[3].'</div><div class=data_resultat style="color: red;">'.$produits_total_N1[3].'</div></div></div>

		<div class=flex-table><div class=spacer></div>
		<div class="resultat titre_1_resultat"><div class=rubriques_resultat><h4>CHARGES EXCEPTIONNELLES</h4></div></div>
		<div class="resultat titre_1_resultat" style="float : right;"><div class=rubriques_resultat><h4>PRODUITS EXCEPTIONNELS</h4></div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Charges exceptionnelles</div><div class=data_resultat>'.$charges[12].'</div><div class=data_resultat>'.$charges_N1[12].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>Produits exceptionnels</div><div class=data_resultat>'.$produits[12].'</div><div class=data_resultat>'.$produits_N1[12].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat>Résultat exceptionnel (excédent)</div><div class=data_resultat style="color: green;">'.$charges_total[4].'</div><div class=data_resultat style="color: green;">'.$charges_total_N1[4].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat>Résultat exceptionnel (déficit)</div><div class=data_resultat style="color: red;">'.$produits_total[4].'</div><div class=data_resultat style="color: red;">'.$produits_total_N1[4].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat fenetre_data_resultat"><div class=rubriques_resultat>Impôts sur les bénéfices</div><div class=data_resultat>'.$charges[13].'</div><div class=data_resultat>'.$charges_N1[13].'</div></div>
		<div class="resultat fenetre_data_resultat" style="float : right;"><div class=rubriques_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
	
		<div class=flex-table><div class=spacer></div>
		<div class="resultat titre_1_resultat"><div class=rubriques_resultat><h4>&nbsp;</h4></div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div>
		<div class="resultat titre_1_resultat" style="float : right;"><div class=rubriques_resultat><h4>&nbsp;</h4></div><div class=data_resultat>&nbsp;</div><div class=data_resultat>&nbsp;</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat>Total des charges</div><div class=data_resultat>'.$charges_total[5].'</div><div class=data_resultat>'.$charges_total_N1[5].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat>Total des produits</div><div class=data_resultat>'.$produits_total[5].'</div><div class=data_resultat>'.$produits_total_N1[5].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_3_resultat"><div class=rubriques_resultat >Résultat général (excédent)</div><div class=data_resultat style="color: green;">'.$charges_total[6].'</div><div class=data_resultat style="color: green;">'.$charges_total_N1[6].'</div></div>
		<div class="resultat total_3_resultat" style="float : right;"><div class=rubriques_resultat >Résultat général (déficit)</div><div class=data_resultat style="color: red;">'.$produits_total[6].'</div><div class=data_resultat style="color: red;">'.$produits_total_N1[6].'</div></div></div>
		
		<div class=flex-table><div class=spacer></div>
		<div class="resultat total_4_resultat"><div class=rubriques_resultat style="text-align: right;"><h4>TOTAL GENERAL</h4></div><div class=data_resultat><h4>'.$charges_total[7].'</h4></div><div class=data_resultat><h4>'.$charges_total_N1[7].'</h4></div></div>
		<div class="resultat total_4_resultat" style="float : right;"><div class=rubriques_resultat style="text-align: right;"><h4>TOTAL GENERAL</h4></div><div class=data_resultat><h4>'.$produits_total[7].'</h4></div><div class=data_resultat><h4>'.$produits_total_N1[7].'</h4></div></div></div>

		</fieldset>
		';

#style="color: green;" style="color: red;"

 	
	$content .= '<div class="wrapper">' . $compte_list . '</div>' ;

   
    return $content ;
    
} #sub resultat 

#/*—————————————— Page analyses ——————————————*/
sub form_analyses {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
    
	################ Affichage MENU ################
	$content .= display_menu_formulaire( $r, $args ) ;
	################ Affichage MENU ################
	
	#####################################       
	# Menu chekbox
	#####################################   
	#définition des variables
	my @checked = ('0') x 15;
	my @dispcheck = ('0') x 15;
	
	my $forms_check15 = '<div class="card"> '.forms_check15( $r, $args ).'</div>' ;
	my $forms_check1 = '<div class="card"> '.forms_check1( $r, $args ).'</div>' ; 
	my $forms_check2 = '<div class="card"> '.forms_check2( $r, $args ).'</div>' ; 
	my $forms_check3 = '<div class="card"> '.forms_check3( $r, $args ).'</div>' ; 
	my $forms_check4 = '<div class="card"> '.forms_check4( $r, $args ).'</div>' ; 
	my $forms_check5 = '<div class="card"> '.forms_check5( $r, $args ).'</div>' ; 
	my $forms_check6 = '<div class="card"> '.forms_check6( $r, $args ).'</div>' ; 
	my $forms_check7 = '<div class="card"> '.forms_check7( $r, $args ).'</div>' ; 
	my $forms_check8 = '<div class="card"> '.forms_check8( $r, $args ).'</div>' ; 
	my $forms_check9 = '<div class="card"> '.forms_check9( $r, $args ).'</div>' ; 
	my $forms_check10 = '<div class="card"> '.forms_check10( $r, $args ).'</div>' ; 
	my $forms_check11 = '<div class="card"> '.forms_check11( $r, $args ).'</div>' ;
	my $forms_check12 = '<div class="card"> '.forms_check12( $r, $args ).'</div>' ;
	my $forms_check13 = '<div class="card"> '.forms_check13( $r, $args ).'</div>' ;
	my $forms_check14 = '<div class="card"> '.forms_check14( $r, $args ).'</div>' ;
    
	if (defined $args->{menu1} && $args->{menu1} eq 1) {$checked[1] = 'checked';} else {$checked[1] = '';}
	if (defined $args->{menu2} && $args->{menu2} eq 1) {$checked[2] = 'checked';} else {$checked[2] = '';}
	if (defined $args->{menu3} && $args->{menu3} eq 1) {$checked[3] = 'checked';} else {$checked[3] = '';}
	if (defined $args->{menu4} && $args->{menu4} eq 1) {$checked[4] = 'checked';} else {$checked[4] = '';}
	if (defined $args->{menu5} && $args->{menu5} eq 1) {$checked[5] = 'checked';} else {$checked[5] = '';}
	if (defined $args->{menu6} && $args->{menu6} eq 1) {$checked[6] = 'checked';} else {$checked[6] = '';}
	if (defined $args->{menu7} && $args->{menu7} eq 1) {$checked[7] = 'checked';} else {$checked[7] = '';}
	if (defined $args->{menu8} && $args->{menu8} eq 1) {$checked[8] = 'checked';} else {$checked[8] = '';}
	if (defined $args->{menu9} && $args->{menu9} eq 1) {$checked[9] = 'checked';} else {$checked[9] = '';}
	if (defined $args->{menu10} && $args->{menu10} eq 1) {$checked[10] = 'checked';} else {$checked[10] = '';}
	if (defined $args->{menu11} && $args->{menu11} eq 1) {$checked[11] = 'checked';} else {$checked[11] = '';}
	if (defined $args->{menu12} && $args->{menu12} eq 1) {$checked[12] = 'checked';} else {$checked[12] = '';}
	if (defined $args->{menu13} && $args->{menu13} eq 1) {$checked[13] = 'checked';} else {$checked[13] = '';}
	if (defined $args->{menu14} && $args->{menu14} eq 1) {$checked[14] = 'checked';} else {$checked[14] = '';}
	if (defined $args->{menu15} && $args->{menu15} eq 1) {$checked[15] = 'checked';} else {$checked[15] = '';}
	
	my $hiden_menu ='
	<input type=hidden name="menu1" value="' . ($args->{menu1} || '') . '">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || '') . '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	<input type=hidden name="menu10" value="' . ($args->{menu10} || ''). '">
	<input type=hidden name="menu11" value="' . ($args->{menu11} || ''). '">
	<input type=hidden name="menu12" value="' . ($args->{menu12} || ''). '">
	<input type=hidden name="menu13" value="' . ($args->{menu13} || ''). '">
	<input type=hidden name="menu14" value="' . ($args->{menu14} || ''). '">
	<input type=hidden name="menu15" value="' . ($args->{menu15} || ''). '">
	';
	
	my $filtre .= '
	<div class=centrer>
	<div class="formflexN2">
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check15" class="forms2_label">Rupture numéro</label>
	<input id="check15" type="checkbox" class="demo5" '.$checked[15].' onchange="submit()" name="menu15" value=1>
	<label for="check15" class="forms2_label"></label>
	<input type=hidden name="menu15" value=0 >
	'.$hiden_menu.'
	</form>

	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check1" class="forms2_label">PieceRef ≠ doc</label>
	<input id="check1" type="checkbox" class="demo5" '.$checked[1].' onchange="submit()" name="menu1" value=1>
	<label for="check1" class="forms2_label"></label>
	<input type=hidden name="menu1" value=0 >
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check9" class="forms2_label">PieceRef vide ?</label>
	<input id="check9" type="checkbox" class="demo5" '.$checked[9].' onchange="submit()" name="menu9" value=1>
	<label for="check9" class="forms2_label"></label>
	<input type=hidden name="menu9" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check2" class="forms2_label">58 soldé ?</label>
	<input id="check2" type="checkbox" class="demo5" '.$checked[2].' onchange="submit()" name="menu2" value=1>
	<label for="check2" class="forms2_label"></label>
	<input type=hidden name="menu2" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check4" class="forms2_label">47 soldé ?</label>
	<input id="check4" type="checkbox" class="demo5" '.$checked[4].' onchange="submit()" name="menu4" value=1>
	<label for="check4" class="forms2_label"></label>
	<input type=hidden name="menu4" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check5" class="forms2_label">12 soldé ?</label>
	<input id="check5" type="checkbox" class="demo5" '.$checked[5].' onchange="submit()" name="menu5" value=1>
	<label for="check5" class="forms2_label"></label>
	<input type=hidden name="menu5" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check3" class="forms2_label">lettrage déséquilibré</label>
	<input id="check3" type="checkbox" class="demo5" '.$checked[3].' onchange="submit()" name="menu3" value=1>
	<label for="check3" class="forms2_label"></label>
	<input type=hidden name="menu3" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check8" class="forms2_label">6063 > 500€</label>
	<input id="check8" type="checkbox" class="demo5" '.$checked[8].' onchange="submit()" name="menu8" value=1>
	<label for="check8" class="forms2_label"></label>
	<input type=hidden name="menu8" value=0>
	'.$hiden_menu.'
	</form>
	

	
	
	</div>	
	
	<div class="formflexN2">
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check10" class="forms2_label">caisse > 1000€</label>
	<input id="check10" type="checkbox" class="demo5" '.$checked[10].' onchange="submit()" name="menu10" value=1>
	<label for="check10" class="forms2_label"></label>
	<input type=hidden name="menu10" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check11" class="forms2_label">6* créditeur ?</label>
	<input id="check11" type="checkbox" class="demo5" '.$checked[11].' onchange="submit()" name="menu11" value=1>
	<label for="check11" class="forms2_label"></label>
	<input type=hidden name="menu11" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check12" class="forms2_label">7* débiteur ?</label>
	<input id="check12" type="checkbox" class="demo5" '.$checked[12].' onchange="submit()" name="menu12" value=1>
	<label for="check12" class="forms2_label"></label>
	<input type=hidden name="menu12" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check13" class="forms2_label">455 débiteur ?</label>
	<input id="check13" type="checkbox" class="demo5" '.$checked[13].' onchange="submit()" name="menu13" value=1>
	<label for="check13" class="forms2_label"></label>
	<input type=hidden name="menu13" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check14" class="forms2_label">51* créditeur ?</label>
	<input id="check14" type="checkbox" class="demo5" '.$checked[14].' onchange="submit()" name="menu14" value=1>
	<label for="check14" class="forms2_label"></label>
	<input type=hidden name="menu14" value=0>
	'.$hiden_menu.'
	</form>

	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check6" class="forms2_label">PieceDate <= EcritureDate</label>
	<input id="check6" type="checkbox" class="demo5" '.$checked[6].' onchange="submit()" name="menu6" value=1>
	<label for="check6" class="forms2_label"></label>
	<input type=hidden name="menu6" value=0>
	'.$hiden_menu.'
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check7" class="forms2_label">PieceDate ≠ exercice</label>
	<input id="check7" type="checkbox" class="demo5" '.$checked[7].' onchange="submit()" name="menu7" value=1>
	<label for="check7" class="forms2_label"></label>
	<input type=hidden name="menu7" value=0>
	'.$hiden_menu.'
	</form>
	
	</div>
	
	';
	
	if (defined $args->{menu1} && $args->{menu1} eq 1) {$dispcheck[1] = $forms_check1;} else {$dispcheck[1] = '';}
	if (defined $args->{menu2} && $args->{menu2} eq 1) {$dispcheck[2] = $forms_check2;} else {$dispcheck[2] = '';}
	if (defined $args->{menu3} && $args->{menu3} eq 1) {$dispcheck[3] = $forms_check3;} else {$dispcheck[3] = '';}
	if (defined $args->{menu4} && $args->{menu4} eq 1) {$dispcheck[4] = $forms_check4;} else {$dispcheck[4] = '';}
	if (defined $args->{menu5} && $args->{menu5} eq 1) {$dispcheck[5] = $forms_check5;} else {$dispcheck[5] = '';}
	if (defined $args->{menu6} && $args->{menu6} eq 1) {$dispcheck[6] = $forms_check6;} else {$dispcheck[6] = '';}
	if (defined $args->{menu7} && $args->{menu7} eq 1) {$dispcheck[7] = $forms_check7;} else {$dispcheck[7] = '';}
	if (defined $args->{menu8} && $args->{menu8} eq 1) {$dispcheck[8] = $forms_check8;} else {$dispcheck[8] = '';}
	if (defined $args->{menu9} && $args->{menu9} eq 1) {$dispcheck[9] = $forms_check9;} else {$dispcheck[9] = '';}
	if (defined $args->{menu10} && $args->{menu10} eq 1) {$dispcheck[10] = $forms_check10;} else {$dispcheck[10] = '';}
	if (defined $args->{menu11} && $args->{menu11} eq 1) {$dispcheck[11] = $forms_check11;} else {$dispcheck[11] = '';}
	if (defined $args->{menu12} && $args->{menu12} eq 1) {$dispcheck[12] = $forms_check12;} else {$dispcheck[12] = '';}
	if (defined $args->{menu13} && $args->{menu13} eq 1) {$dispcheck[13] = $forms_check13;} else {$dispcheck[13] = '';}
	if (defined $args->{menu14} && $args->{menu14} eq 1) {$dispcheck[14] = $forms_check14;} else {$dispcheck[14] = '';}
	if (defined $args->{menu15} && $args->{menu15} eq 1) {$dispcheck[15] = $forms_check15;} else {$dispcheck[15] = '';}
	
	
	$content .= '	
		
		<div class="wrapper-docs-entry">
			<fieldset class="pretty-box"><legend><h3 class="Titre09">Analyses des données comptables</h3></legend>
			'.$filtre.'
				<div class=centrer>
				' . $dispcheck[15] . $dispcheck[1] . $dispcheck[9] . $dispcheck[2] . $dispcheck[4]. $dispcheck[3] . $dispcheck[5] . $dispcheck[8] . $dispcheck[10] . $dispcheck[11] . $dispcheck[12] . $dispcheck[13] . $dispcheck[14] . $dispcheck[6] . $dispcheck[7] .'
				</div>
			</fieldset>
		</div>
	' ;
	
    return $content ;
    
} #sub form_analyses 

#Rupture Séquence écritures
sub forms_check15 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;

	# Requête Plusieurs références de pièces dans un seul document ##############
	$sql = q {
	WITH numbered_entries AS (
  SELECT
    id_entry,
    id_facture,
    date_ecriture,
    fiscal_year,
    id_client,
    num_mouvement,
    id_export,
    libelle_journal,
    ROW_NUMBER() OVER (ORDER BY num_mouvement::bigint) AS row_num
  FROM
    tbljournal
  WHERE
    id_client = ?
    AND fiscal_year = ?
    AND num_mouvement <> ''
  GROUP BY
    id_entry,
    id_facture,
    date_ecriture,
    fiscal_year,
    id_client,
    num_mouvement,
    id_export,
    libelle_journal
),
expected_sequences AS (
  SELECT
    MIN(row_num::bigint) AS min_num,
    MAX(row_num::bigint) AS max_num
  FROM
    numbered_entries
)
SELECT
  gs.number::text AS missing_sequence
FROM
  expected_sequences
  CROSS JOIN generate_series(min_num, max_num) AS gs(number)
LEFT JOIN
  numbered_entries ne ON gs.number::text = ne.num_mouvement
WHERE
  ne.num_mouvement IS NULL
ORDER BY
  gs.number::text;
			} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ) };
    if (!defined $args->{menu15} && scalar(@$resultat1) > 0) {$args->{menu15} = '1';}

	my $formlist .='<div class=Titre10>Vérification de rupture dans la numérotation des écritures</div>
	';
	


	if (scalar(@$resultat1) > 0) {
	$content .=	$formlist;
	foreach my $element (@{$resultat1}) {
    # Parcours du hachage et affichage des paires clé-valeur
    foreach my $cle (keys %{$element}) {
        my $valeur = $element->{$cle};
        $content .= '<br><div >!!! Attention rupture dans la numérotation : il manque le numéro '.$valeur.' !!!</div>';
    }
	}
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}
	
    return $content ;

} #sub forms_check1


#Mauvaise référence de pièce dans le document<
sub forms_check1 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;

	# Requête Plusieurs références de pièces dans un seul document ##############
	$sql = q {
select distinct * from tbljournal t1
WHERE  t1.fiscal_year = ?  and t1.id_client = ? and  t1.documents1 not like '%' || t1.id_facture || '%' 
order by date_ecriture
			} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu1} && scalar(@$resultat1) > 0) {$args->{menu1} = '1';}

	my $formlist .='<div class=Titre10>Mauvaise référence de pièce dans le document</div>
	<span class="memoinfo">La référence Pièce de l\'écriture ne correspond pas à celle contenu dans le nom du document1</span>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}
	
    return $content ;

} #sub forms_check1

#Le compte 58 est apuré
sub forms_check2 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Le compte 58 est apuré ##############
	$sql = q {
with t1 as (select fiscal_year, id_client, numero_compte
from tbljournal where fiscal_year = ? and id_client = ? and substring(numero_compte from 1 for 2) IN ('58')
group by fiscal_year, id_client, numero_compte
having sum(credit-debit) != 0)
select distinct * from t1
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.numero_compte = t2.numero_compte
			} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu2} && scalar(@$resultat1) > 0) {$args->{menu2} = '1';}

	my $formlist .='<div class=Titre10>Contrôler les comptes de virements internes (58) qui doivent être soldés</div>';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check2

#écritures lettrées et non équilibrées
sub forms_check3 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête écritures lettrées et non équilibrées ##############
	$sql = q {
		SELECT distinct * FROM tbljournal t1
LEFT JOIN tblexport t2 on t1.id_client = t2.id_client and t1.fiscal_year = t2.fiscal_year and t1.id_export = t2.id_export
INNER JOIN tblcompte t3 ON t1.id_client = t3.id_client AND t1.fiscal_year = t3.fiscal_year AND t1.numero_compte = t3.numero_compte
WHERE t1.id_client = ? AND t1.fiscal_year = ? AND t1.lettrage is not null
AND lettrage IN (SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? group by lettrage having sum(credit-debit) != 0)
ORDER BY t1.date_ecriture
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} )) };
    if (!defined $args->{menu3} && scalar(@$resultat1) > 0) {$args->{menu3} = '1';}

	my $formlist .='<div class=Titre10>Contrôler les écritures lettrées et non équilibrées</div>';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check3

#Les comptes 471 à 475 sont apurés
sub forms_check4 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Les comptes 471 à 475 sont apurés ##############
	$sql = q {
with t1 as (select fiscal_year, id_client, numero_compte
from tbljournal where fiscal_year = ? and id_client = ? and substring(numero_compte from 1 for 3) IN ('471','472','473','474','475')
group by fiscal_year, id_client, numero_compte
having sum(credit-debit) != 0)
select distinct * from t1
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.numero_compte = t2.numero_compte
			} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu4} && scalar(@$resultat1) > 0) {$args->{menu4} = '1';}

	my $formlist .='<div class=Titre10>Contrôler les comptes d’attente (471 à 475) qui doivent être soldés</div>';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check4

#Les comptes 120 et 129 sont apurés
sub forms_check5 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Les comptes 120 et 129 sont apurés ##############
	$sql = q {
with t1 as (select fiscal_year, id_client, numero_compte
from tbljournal where fiscal_year = ? and id_client = ? and substring(numero_compte from 1 for 3) IN ('120','129') AND libelle_journal NOT LIKE '%CLOTURE%'
group by fiscal_year, id_client, numero_compte
having sum(credit-debit) != 0)
select distinct * from t1
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.numero_compte = t2.numero_compte
			} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu4} && scalar(@$resultat1) > 0) {$args->{menu5} = '1';}

	my $formlist .='<div class=Titre10>Les comptes de résultats de l\'exercice (120 et 129) doivent être soldés</div>
	<span class="memoinfo">Les comptes 120 et 129 doivent être remis à zéro (soldés) pour recevoir le résultat de l\'exercice en cours</span>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check5

#PieceDate <= EcritureDate
sub forms_check6 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête PieceDate <= EcritureDate ##############
	$sql = q {
SELECT * FROM tbljournal t1
INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
LEFT JOIN tbldocuments t3 on t1.id_client = t3.id_client and t1.documents1 = t3.id_name
LEFT JOIN tbljournal_liste t4 on t1.id_client = t4.id_client and t1.fiscal_year = t4.fiscal_year and t1.libelle_journal = t4.libelle_journal
LEFT JOIN tblexport t5 on t1.id_client = t5.id_client and t1.fiscal_year = t5.fiscal_year and t1.id_export = t5.id_export
WHERE t1.fiscal_year = ? and t1.id_client = ?AND t1.libelle_journal NOT LIKE '%CLOTURE%' and date_reception::date > date_ecriture::date 
ORDER BY length(t1.num_mouvement), t1.num_mouvement, t1.date_ecriture
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu6} && scalar(@$resultat1) > 0) {$args->{menu6} = '1';}

	my $formlist .='<div class=Titre10>La date d\'écriture est antérieure à celle de la pièce (date du document)</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check6

#PieceDate ≠ exercice
sub forms_check7 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête PieceDate ≠ exercice ##############
	$sql = q {
SELECT * FROM tbljournal t1
INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
LEFT JOIN tbldocuments t3 on t1.id_client = t3.id_client and t1.documents1 = t3.id_name
LEFT JOIN tbljournal_liste t4 on t1.id_client = t4.id_client and t1.fiscal_year = t4.fiscal_year and t1.libelle_journal = t4.libelle_journal
LEFT JOIN tblexport t5 on t1.id_client = t5.id_client and t1.fiscal_year = t5.fiscal_year and t1.id_export = t5.id_export
WHERE t1.fiscal_year = ? and t1.id_client = ?AND t1.libelle_journal NOT LIKE '%CLOTURE%' and (date_reception::date > ? or date_reception::date < ?)
ORDER BY length(t1.num_mouvement), t1.num_mouvement, t1.date_ecriture
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{Exercice_fin_YMD}, $r->pnotes('session')->{Exercice_debut_YMD}) ) };
    if (!defined $args->{menu7} && scalar(@$resultat1) > 0) {$args->{menu7} = '1';}

	my $formlist .='<div class=Titre10>La date de la pièce (date du document) n\'appartient pas à l\'exercice '.$r->pnotes('session')->{fiscal_year}.'</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check7

#Présence en 6063 "petit équipement" d'écritures > 500 euros HT
sub forms_check8 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête PieceDate ≠ exercice ##############
	$sql = q {
with t1 as (select * from tbljournal where fiscal_year = ? and id_client = ? and substring(numero_compte from 1 for 4) IN ('6063') AND libelle_journal NOT LIKE '%CLOTURE%'
and debit > 50000)
select distinct * from t1
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.id_entry = t2.id_entry
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu8} && scalar(@$resultat1) > 0) {$args->{menu8} = '1';}

	my $formlist .='<div class=Titre10>Présence en 6063 "petit équipement" d\'écritures > 500 euros HT</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check8

#Présence d'une référence de pièce pour chaque écriture
sub forms_check9 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Présence d'une référence de pièce pour chaque écriture ##############
	$sql = q {
select * from tbljournal where fiscal_year = ? AND id_client = ? AND id_facture IS NULL
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu9} && scalar(@$resultat1) > 0) {$args->{menu9} = '1';}

	my $formlist .='<div class=Titre10>Liste des écritures sans référence de pièce</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check9

#Présence d'écriture correspondant potientiellement à un encaissement ou à un paiement en espèce supérieur à 1000€
sub forms_check10 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Présence d'écriture correspondant potientiellement à un encaissement ou à un paiement en espèce supérieur à 1000€ ##############
	$sql = q {
with t1 as (select * from tbljournal where fiscal_year = ? and id_client = ? and substring(numero_compte from 1 for 2) IN ('53') AND libelle_journal NOT LIKE '%CLOTURE%'
and (credit > 100000 or debit > 100000))
select distinct * from t1
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.id_entry = t2.id_entry
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu10} && scalar(@$resultat1) > 0) {$args->{menu10} = '1';}

	my $formlist .='<div class=Titre10>Encaissement ou paiement en espèce supérieur à 1000€</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check10

#Pas de compte 6*  avec un solde créditeur.
sub forms_check11 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Pas de compte 6*  avec un solde créditeur. ##############
	$sql = q {
with t1 as(SELECT fiscal_year, id_client, id_entry, (sum(credit-debit) over (PARTITION BY id_entry))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY id_entry))::numeric as solde_debiteur FROM tbljournal
WHERE fiscal_year = ? and id_client = ? AND libelle_journal NOT LIKE '%CLOTURE%' 
and substring(numero_compte from 1 for 1) IN ('6')
ORDER BY numero_compte, date_ecriture, id_line)
select * from t1 
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.id_entry = t2.id_entry
where solde_crediteur > 0
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu11} && scalar(@$resultat1) > 0) {$args->{menu11} = '1';}

	my $formlist .='<div class=Titre10>Écriture avec un compte de charge (6*) présentant un solde créditeur.</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check11

#Pas de compte 7*  avec un solde débiteur.
sub forms_check12 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Pas de compte 7*  avec un solde débiteur. ##############
	$sql = q {
with t1 as(SELECT fiscal_year, id_client, id_entry, (sum(credit-debit) over (PARTITION BY id_entry))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY id_entry))::numeric as solde_debiteur FROM tbljournal
WHERE fiscal_year = ? and id_client = ? AND libelle_journal NOT LIKE '%CLOTURE%' 
and substring(numero_compte from 1 for 1) IN ('7')
ORDER BY numero_compte, date_ecriture, id_line)
select * from t1 
INNER JOIN tbljournal t2 ON t1.fiscal_year = t2.fiscal_year and t1.id_client = t2.id_client and t1.id_entry = t2.id_entry
where solde_debiteur > 0
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{id_client}) ) };
    if (!defined $args->{menu12} && scalar(@$resultat1) > 0) {$args->{menu12} = '1';}

	my $formlist .='<div class=Titre10>Écriture avec un compte de produit (7*) présentant un solde débiteur.</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	$content .= Template_1 ($r, $args, $dbh, $resultat1, $formlist );
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check12

#Pas de listes de comptes bancaires avec un solde créditeur pour les comptes 51*
sub forms_check14 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Pas de listes de comptes bancaires avec un solde créditeur pour les comptes 51* ##############
	$sql = q {
with t1 as (select * from calcul_balance(?, ?, ?, ?, ?, 'FM999G999G999G990D00') 
WHERE solde_debit NOT SIMILAR TO '0,00' OR solde_credit NOT SIMILAR TO '0,00' OR debit NOT SIMILAR TO '0,00' OR credit NOT SIMILAR TO '0,00')
select * from t1 where substring(numero_compte from 1 for 2) IN ('51') and solde_credit NOT SIMILAR TO '0,00'
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{Exercice_fin_YMD},$r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ) };
    if (!defined $args->{menu14} && scalar(@$resultat1) > 0) {$args->{menu14} = '1';}

	my $formlist .='<div class=Titre10>Écriture avec un compte bancaire (51*) présentant un solde créditeur.</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	for ( @$resultat1 ) {
	$content .= $formlist.'<br><div class="intro3">Attention le compte "' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '" présente un solde créditeur de ' . $_->{solde_credit} . '€ !!!</div>';
	}
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check14

#Pas de compte 455* présentant un solde débiteur.
sub forms_check13 {
   	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	# Requête Pas de compte 455* présentant un solde débiteur. ##############
	$sql = q {
with t1 as (select * from calcul_balance(?, ?, ?, ?, ?, 'FM999G999G999G990D00') 
WHERE solde_debit NOT SIMILAR TO '0,00' OR solde_credit NOT SIMILAR TO '0,00' OR debit NOT SIMILAR TO '0,00' OR credit NOT SIMILAR TO '0,00')
select * from t1 where substring(numero_compte from 1 for 3) IN ('455') and solde_debit NOT SIMILAR TO '0,00'
} ;
    my $resultat1 = eval { $dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{Exercice_fin_YMD},$r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ) };
    if (!defined $args->{menu13} && scalar(@$resultat1) > 0) {$args->{menu13} = '1';}

	my $formlist .='<div class=Titre10>Écriture avec un compte d\'associés (455*) présentant un solde débiteur.</div>
	';
	
	if (scalar(@$resultat1) > 0) {
	for ( @$resultat1 ) {
	$content .= $formlist.'<br><div class="intro3">Attention le compte "' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '" présente un solde débiteur de ' . $_->{solde_debit} . '€ !!!</div>';
	}
	} else {
	$content .= $formlist.'<br><div class="intro2"><h3>Conforme</h3></div>';	
	}

    return $content ;

} #sub forms_check13


#/*—————————————— Modéle 1 ——————————————*/
sub Template_1 {
   	# définition des variables
	my ( $r, $args, $dbh, $resultat1, $formlist ) = @_ ;

	############## ligne d'en-têtes ##############	
    my $entry_list .= '
    <br>
    <ul class="wrapper style1">
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=headerspan style="width: 7.5%;">Date</span>
	<span class=headerspan style="width: 7.5%;">Journal</span>
	<span class=headerspan style="width: 7.5%;">Libre</span>
	<span class=headerspan style="width: 7.5%;">Compte</span>
	<span class=headerspan style="width: 10%;">Pièce</span>
	<span class=headerspan style="width: 29.9%;">Libellé</span>
	<span class=headerspan style="width: 7.5%; text-align: right;">Débit</span>
	<span class=headerspan style="width: 7.5%; text-align: right;">Crédit</span>
	<span class=headerspan style="width: 1%;">&nbsp;</span>
	<span class=headerspan style="width: 6%;">Lettrage</span>
	<span class=headerspan style="width: 1%;">&nbsp;</span>
	<span class=headerspan style="width: 3%;">&nbsp;</span>
	<span class=headerspan style="width: 3%;">&nbsp;</span>
	<span class=headerspan style="width: 1%; text-align: right;">&nbsp;</span>
	<div class=spacer></div></div></li>
	' ;
	
	my $id_entry = '';

    for ( @$resultat1 ) {
	#si on est dans une nouvelle entrée, clore la précédente et ouvrir la suivante
		unless ($_->{id_entry} eq $id_entry ) {

			#lien de modification de l'entrée
			my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;

			#cas particulier de la première entrée de la liste : pas de liste précédente
			unless ( $id_entry ) {
				$entry_list .= '<li class=listitem>' ;
			} else {
				$entry_list .= '</a></li><li class=listitem>'
			} #	    unless ( $id_entry ) 

		} #	unless ( $_->{id_entry} eq $id_entry )

	#marquer l'entrée en cours
	$id_entry = $_->{id_entry} ;
	
	my $http_link_documents1 = '<span class=blockspan style="width: 2%; text-align: center;"><img id="documents_'.$_->{id_line}.'" class="line_icon_hidden" height="16" width="16" title="Ouvrir le document1" src="/Compta/style/icons/documents.png" alt="document1"></span>';
	my $http_link_documents2 = '<span class=blockspan style="width: 2%; text-align: center;"><img id="releve_'.$_->{id_line}.'" class="line_icon_hidden" height="16" width="16" title="Ouvrir le document2" src="/Compta/style/icons/releve-bancaire.png" alt="releve-bancaire"></span>';
	#Affichage lien docs1 si docs1
	if ( ($_->{documents1} || '') =~ /docx|odt|pdf|jpg/) { 
		my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
		my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents1} ) ;
		if ($id_name_documents->[0]->{id_name} || '') {
		$http_link_documents1 = '<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.($id_name_documents->[0]->{id_name} || '').'">				
		<span class=blockspan style="width: 3%; text-align: center;"><img id="documents_'.$_->{id_line}.'" class="line_icon_visible" height="16" width="16" title="Ouvrir le document1" src="/Compta/style/icons/documents.png" alt="document1"></span></a>';
		}
	} 	
	#Affichage lien docs2 si docs2
	if ( ($_->{documents2} || '') =~ /docx|odt|pdf|jpg/) { 
	    my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
		my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents2} ) ;
		if ($id_name_documents->[0]->{id_name} || '') {
		$http_link_documents2= '<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.($id_name_documents->[0]->{id_name} || '').'">				
		<span class=blockspan style="width: 3%; text-align: center;"><img id="releve_'.$_->{id_line}.'" class="line_icon_visible" height="16" width="16" title="Ouvrir le document2" src="/Compta/style/icons/releve-bancaire.png" alt="releve-bancaire"></span></a>';	
		}
	} 	
	
	#joli formatage de débit/crédit
	( my $debit = sprintf( "%.2f", $_->{debit}/100 ) ) =~ s/\./\,/g; 
	$debit =~ s/\B(?=(...)*$)/ /g ;
	( my $credit = sprintf( "%.2f", $_->{credit}/100 ) ) =~ s/\./\,/g; 
	$credit =~ s/\B(?=(...)*$)/ /g ;
	
	#lien de modification de l'entrée
	my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;
	
	$entry_list .= '
	<div class=flex-table><div class=spacer></div><a href="' . $id_entry_href . '">
	<span class=displayspan style="width: 7.5%;">' . $_->{date_ecriture} . '</span>
	<span class=displayspan style="width: 7.5%;">' . $_->{libelle_journal} .'</span>
	<span class=displayspan style="width: 7.5%;">' . ($_->{id_paiement} || '&nbsp;') . '</span>
	<span class=displayspan style="width: 7.5%;">' . $_->{numero_compte} . '</span>
	<span class=displayspan style="width: 10%;">' . ($_->{id_facture} || '&nbsp;') . '</span>
	<span class=displayspan style="width: 29.9%;">' . $_->{libelle} . '</span>
	<span class=displayspan style="width: 7.5%; text-align: right;">' . $debit . '</span>
	<span class=displayspan style="width: 7.5%; text-align: right;">' .  $credit . '</span>
	<span class=displayspan style="width: 1%;">&nbsp;</span>
	<span class=displayspan style="width: 6%;">' . ($_->{lettrage} || '&nbsp;') . '</span>
	<span class=displayspan style="width: 1%;">&nbsp;</span>
	'.$http_link_documents1.'
	'.$http_link_documents2.'
	<span class=displayspan style="width: 1%; text-align: right;">&nbsp;</span>
	</a>
	<div class=spacer></div></div>
	' ;

	}
	
	#on clot la liste s'il y avait au moins une entrée dans le journal
    $entry_list .= '</a></li>' if ( @$resultat1 ) ;
	
    $formlist .= ''. $entry_list.'</ul>';

    return $formlist ;

} #sub forms_check1


sub display_menu_formulaire {

    my ( $r, $args ) = @_ ;
    
   unless ( defined $args->{liasse2033A} || defined $args->{liasse2033B} || defined $args->{liasse2033C} || defined $args->{bilan} || defined $args->{resultat} || defined $args->{analyses} ) {
	    $args->{bilan} = '' ;
    } 	
 	    
#########################################	
#Filtrage des formulaires - Début		#
#########################################		
	#lien d'analyses de datas comptables
	my $analyses_class = ( (defined $args->{analyses} ) ? 'selecteditem' : 'nav' );
	my $analyses_link = '<a class=' . $analyses_class . ' href="/'.$r->pnotes('session')->{racine}.'/bilan?analyses" style="margin-left: 3ch;">Analyses</a>' ;
	
	my $print_link ='<a class="btn btn-success nav" href="#" style="margin-left: 3ch;" onClick="window.print();return false" >Print</a>' ;
	my $liasse2033A_link = '<a class=' . ( (defined $args->{liasse2033A} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033A" style="margin-left: 3ch;">2033A</a>' ;
	my $liasse2033B_link = '<a class=' . ( (defined $args->{liasse2033B} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033B" style="margin-left: 3ch;">2033B</a>' ;
	my $liasse2033C_link = '<a class=' . ( (defined $args->{liasse2033C} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033C" style="margin-left: 3ch;">2033C</a>' ;
	my $bilan_link = '<a class=' . ( (defined $args->{bilan} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/bilan?bilan" style="margin-left: 3ch;">Bilan</a>' ;
	my $resultat_link = '<a class=' . ( (defined $args->{resultat} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/bilan?resultat" style="margin-left: 3ch;">Compte de résultat</a>' ;
	my $content .= '<div class="menu">' . $bilan_link . $resultat_link . $liasse2033A_link . $liasse2033B_link . $liasse2033C_link . $analyses_link . $print_link . '</div>' ;

#########################################	
#Filtrage des formulaires - Fin			#
#########################################
    
    return $content ;

} #sub display_menu_formulaire 

1 ;
