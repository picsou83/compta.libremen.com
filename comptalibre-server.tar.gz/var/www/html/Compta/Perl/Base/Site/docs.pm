package Base::Site::docs;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use utf8 ;
use Apache2::Const -compile => qw( OK REDIRECT ) ;
use Apache2::Upload;
use File::Path 'mkpath' ;
use Time::Piece;

#/*—————————————— Action principale ——————————————*/
sub handler {
	
	binmode(STDOUT, ":utf8") ;
    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content ;
    my $req = Apache2::Request->new($r) ;
	#récupérer les arguments
    my ( %args, @args, $sql, @bind_values ) ;
	#recherche des paramètres de la requête
    @args = $req->param ;
    my $id_client = $r->pnotes('session')->{id_client} ;
    my $message ;
    my $dbh = $r->pnotes('dbh') ;
    
    for (@args) {
	$args{$_} = Encode::decode_utf8( $req->param($_) ) ;
	#nix those sql injection/htmlcode attacks!
	$args{$_} =~ tr/<>;/-/ ;
	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;
    }

	if ( defined $args{categorie} ) {
		
	$content = form_categorie( $r, \%args ) ;
	
	} elsif ( defined $args{nouveau} ) {
		
	$content = form_new_docs( $r, \%args ) ;
	
	} else {
		
	$content .= visualize( $r, \%args ) ;	
	
	}  

	$r->no_cache(1) ;
	$r->content_type('text/html; charset=utf-8') ;
	print $content ;
	return Apache2::Const::OK ;

}

#/*—————————————— Page principale des documents ——————————————*/
sub visualize {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	my $id_client = $r->pnotes('session')->{id_client} ;
	my @search = ('0') x 15;
	my @checked = ('0') x 10;
	my $line = "1"; 
    
	################ Affichage MENU ################
	$content .= display_menu_docs( $r, $args ) ;
	################ Affichage MENU ################
    
    #les documents sont placés dans /var/www/html/Compta/base/documents/*id_client*/*fiscal_year*/
	my $repository = $r->document_root() . '/Compta/base/documents/' . $r->pnotes('session')->{id_client}.'/'.$r->pnotes('session')->{fiscal_year} .'/';

	my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
	my @bind_array_2 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}, $args->{docscategorie}) ;

	#appliquer le filtre Catégorie si $args->{docscategorie}<>0
    my ($filter_categorie_dest) = (  $args->{docscategorie} && ($args->{docscategorie} !~ /Tous/) ) ? (' AND libelle_cat_doc = ?') : ( '', '' ) ;
    @bind_array = (  $args->{docscategorie} && ($args->{docscategorie} !~ /Tous/)) ? (@bind_array_2) : (@bind_array_1) ;
   
    my $search_date = ( defined $args->{search_date} && $args->{search_date} ne '' && $args->{search_date} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) ? ' AND date_reception = ?' : '' ;
    my $search_montant = ( defined $args->{search_montant} && $args->{search_montant} ne '') ? ' AND montant::TEXT ILIKE ? ' : '' ;
    my $search_categorie = ( defined $args->{search_categorie} && $args->{search_categorie} ne '' ) ? ' AND libelle_cat_doc ILIKE ?' : '' ;
	my $search_name = ( defined $args->{search_name} && $args->{search_name} ne '' ) ? ' AND id_name ILIKE ?' : '' ;
	my $search_check = ( defined $args->{search_check} && $args->{search_check} eq 1) ? ' AND check_banque = \'t\'' : '' ;
    my $search_multi = ( defined $args->{search_multi} && $args->{search_multi} eq 1) ? ' AND multi = \'t\'' : '' ;
    
	#Requête tbldocuments => Recherche de la liste des documents enregistrés
	$sql = '
	SELECT id_name, date_reception, multi, check_banque, to_char(montant/100::numeric, \'999G999G999G990D00\') as montant, libelle_cat_doc, fiscal_year, to_char((sum(montant/100) over())::numeric, \'999G999G999G990D00\') as total_montant
	FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) '.$filter_categorie_dest.' '.$search_date.' '.$search_montant.' '.$search_categorie.' '.$search_name.' '.$search_check.' '.$search_multi.'
	ORDER BY date_reception, id_name
	' ;
	
	#Filtrage
	if (defined $args->{search_date} && $args->{search_date} ne '' && $args->{search_date} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
	$search[9] = $args->{search_date};
	push @bind_array, $search[9] unless ( $args->{search_date} eq '') ;
	}
	
	if (defined $args->{search_date} && $args->{search_date} ne '' && not($args->{search_date} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/)) {
	$search[10] = '%' . $args->{search_date} . '%' ;
	push @bind_array, $search[10] unless ( $args->{search_date} eq '') ;
	}
	
	if (defined $args->{search_montant} && $args->{search_montant} ne ''){
	$search[4] = '%' . $args->{search_montant} . '%' ;
	push @bind_array, $search[4] unless ( $args->{search_montant} eq '') ;
	}
	
	if (defined $args->{search_categorie} && $args->{search_categorie} ne ''){
	$search[5] = '%' . $args->{search_categorie} . '%' ;
	push @bind_array, $search[5] unless ( $args->{search_categorie} eq '') ;
	}
  
  	if (defined $args->{search_name} && $args->{search_name} ne ''){
	$search[5] = '%' . $args->{search_name} . '%' ;
	push @bind_array, $search[5] unless ( $args->{search_name} eq '') ;
	}
	
	if (defined $args->{search_check} && $args->{search_check} eq 1){
	$checked[1] = 'checked';
	} else {
	$checked[1] = '';
	}
	
	if (defined $args->{search_multi} && $args->{search_multi} eq 1){
	$checked[2] = 'checked';
	} else {
	$checked[2] = '';	
	}	
	
	my $array_of_documents;	

    eval { $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array )} ;

	#/************ ACTION DEBUT *************/

	#######################################################################  
	#l'utilisateur a cliqué sur le bouton 'Supprimer' 					  #
	####################################################################### 
    if ( defined $args->{supprimer} and $args->{supprimer} eq '0' ) {
		my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/docs?docscategorie='.$args->{docscategorie}.'&amp;id_client=' . ${id_client} . '&amp;id_name=' . $args->{id_name} . '&amp;supprimer=1' ;
		my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/docs?docscategorie='.$args->{docscategorie}.'' ;
		my $message = ( 'Voulez-vous vraiment supprimer le document ' . $args->{id_name} .' ?') . '<a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . $message . '</h3>' ;
    } elsif ( defined $args->{supprimer} and $args->{supprimer} eq '1' ) {

		$sql = 'DELETE FROM tbldocuments WHERE id_name = ? AND id_client = ?' ;
		my $rows_deleted ;
		eval { $rows_deleted = $dbh->do( $sql, { }, ( $args->{id_name}, $r->pnotes('session')->{id_client} ) ) } ;

		#si un problème est survenu ou aucun enregistrement n'a été supprimé, ne pas toucher au ficher 
		if ( $@ or !( $rows_deleted ) ) {
			if ( $@ =~ /viole la contrainte|violates/ ) {
				$content = '<h3 class=warning>Impossible de supprimer le document, celui-ci est référencé sur une écriture</h3>' ;
			} else {
				$content = '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . Encode::decode_utf8( $@ ) . '</h3>' ;
			}
		} else {
			#la suppression de la référence du document dans tbldocuments a réussi, supprimer le fichier
			my $base_dir = $r->document_root() . '/Compta/base/documents' ;
			my $archive_dir = '' ;
			
			$archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$r->pnotes('session')->{fiscal_year}. '/' ;

			my $archive_file = $archive_dir . $args->{id_name} ;
			#suppression du fichier
			unlink $archive_file ;
		
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Supression du document '.$args->{id_name}.'');
			$args->{restart} = 'docs?docscategorie='.($args->{docscategorie}||'').'';
			$content .= restart( $r, $args ) ;	
		}

	} #	if ( defined $args{supprimer} and $args{supprimer} eq '1' )

    ############## MISE EN FORME DEBUT ##############
    
	############## Formulaire Liste des documents ##############	
	my $entry_list .= '

		<li class="listitem centrer">
		<div class="spacer"></div>
		<span class=headerspan style="width: 0.5%;">&nbsp;</span>
		<span class=headerspan style="width: 10%;">Date</span>
		<span class=headerspan style="width: 55%;">Name</span>
		<span class=headerspan style="width: 14%;">Catégorie</span>
		<span class=headerspan style="width: 10%;">Montant</span>
		<span class=headerspan style="width: 2%;">&nbsp;</span>
		<span class=headerspan style="width: 2%;">&nbsp;</span>
		<span class=headerspan style="width: 2%;">&nbsp;</span>
		<span class=headerspan style="width: 2%;">&nbsp;</span>
		<span class=headerspan style="width: 2%;">&nbsp;</span>
		<span class=headerspan style="width: 0.5%;">&nbsp;</span>
		<div class="spacer"></div>
		</li>
		
		<li class="style1"><div class=headerspan2 style="padding-left: 0px;">  
		<form id="myForm" method=POST>
		<div class=spacer></div>
		<span class=displayspan_search style="width: 0.5%;">&nbsp;</span>
		<span class=displayspan_search style="width: 10%;"><input class=search type=text name="search_date" id="search_date" value="' . ($args->{search_date} || ''). '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\');submit()" ></span>
		<span class=displayspan_search style="width: 55%;"><input class=search type=text name="search_name" id="search_name" value="' . ($args->{search_name} || ''). '" onchange="submit()"></span>
		<span class=displayspan_search style="width: 14%;"><input class=search type=text name="search_categorie" id="search_categorie" value="' . ($args->{search_categorie} || ''). '" onchange="submit()" ></span>
		<span class=displayspan_search style="width: 10%; text-align: right;"><input class=search type=text name="search_montant" id="search_montant" value="' . ($args->{search_montant} || ''). '" onchange="submit()"></span>
		<span class=displayspan_search style="width: 2%;">&nbsp;</span>
		<span class=displayspan_search style="width: 2%; text-align: center;"> </span>
		<span class=displayspan_search style="width: 2%; text-align: center;"> </span>
		<span class=displayspan_search style="width: 2%; text-align: center;"><input type=checkbox name="search_check" id="search_check" title="Afficher les documents pointés" value=1  onchange="submit()" '.$checked[1].'></span>
		<span class=displayspan_search style="width: 2%; text-align: center;"><input type=checkbox name="search_multi" id="search_multi" title="Afficher les documents multi-exercice" value=1  onchange="submit()" '.$checked[2].'></span>
		<span class=displayspan_search style="width: 0.5%;">&nbsp;</span>
		<div class=spacer></div>
		</form></div></li>
	' ;

    if ( @{ $array_of_documents } ) {
		
		for ( @{ $array_of_documents } ) {
			my $reqline = ($line ++);	
			
			my $http_link_banque_valide = '<img class="redimmage nav" title="Validée le '. (defined $_->{date_validation}).'" style="border: 0;" src="/Compta/style/icons/cadena.png" alt="valide">' ;
			my $check_value = ( $_->{check_banque} eq 'f' ) ? '<span class="displayspan" style="width: 2%; text-align: center;"><img class="line_icon_hidden" id="statut_'.$reqline.'" title="Check complet" src="/Compta/style/icons/icone-valider.png" height="16" width="16" alt="check_value"></span>' : '<span class="displayspan" style="width: 2%; text-align: center;"><img id="statut_'.$reqline.'" title="Check complet" src="/Compta/style/icons/icone-valider.png" height="16" width="16" alt="check_value"></span>' ;
			my $check_multi = ( $_->{multi} eq 'f' ) ? '<span class="displayspan" style="width: 2%; text-align: center;"><img id="multi_'.$reqline.'" class="line_icon_hidden" title="documents multi-exercice" src="/Compta/style/icons/multi.png" height="16" width="16" alt="check_multi"></span>' : '<span class="displayspan" style="width: 2%; text-align: center;"><img id="multi_'.$reqline.'" title="documents multi-exercice" src="/Compta/style/icons/multi.png" height="16" width="16" alt="check_multi"></span>' ;

			#lien de modification de l'entrée
			my $id_name_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $_->{id_name} ;
			my $suppress_href = '';
			my $suppress_link = '<span class=blockspan style="width: 2%; text-align: center;"><img id="supprimer_'.$reqline.'" class="line_icon_hidden" height="16" width="16" title="Supprimer" src="/Compta/style/icons/delete.png" alt="supprimer"></span>';
			my $download_href = '/Compta/base/documents/' . $r->pnotes('session')->{id_client} . '/'.$_->{fiscal_year}.'/'. $_->{id_name}  ;
			my $img_link = '<a class=nav href="' . $download_href . '"><span class=blockspan style="width: 2%; text-align: center;"><img id="visualiser_'.$reqline.'" class="line_icon_visible" height="16" width="16" title="Visualiser le document" src="/Compta/style/icons/documents.png" alt="visualiser"></span></a>';
			
			if ($r->pnotes('session')->{Exercice_Cloture} ne 1 && $_->{multi} eq 'f') {
			$suppress_href = '/'.$r->pnotes('session')->{racine}.'/docs?docscategorie='.$args->{docscategorie}.'&amp;id_name=' . ( URI::Escape::uri_escape_utf8( $_->{id_name} ) || '' ) . '&amp;supprimer=0' ;
			$suppress_link = '<a class=nav href="' . $suppress_href . '"><span class=blockspan style="width: 2%; text-align: center;"><img id="supprimer_'.$reqline.'" class="line_icon_visible" height="16" width="16" title="Supprimer" src="/Compta/style/icons/delete.png" alt="supprimer"></span></a>';
			}
			
			#ligne d'en-têtes
			$entry_list .= '
				<li class=listitem><a href="' . $id_name_href . '">
				<div class=spacer></div>
				<span class=blockspan style="width: 0.5%;">&nbsp;</span>
				<span class=blockspan style="width: 10%;">' . $_->{date_reception} . '</span>
				<span class=blockspan style="width: 55%;">' . ( $_->{id_name} || '&nbsp;' ) . '</span>
				<span class=blockspan style="width: 14%;">' . ( $_->{libelle_cat_doc} || '&nbsp;') . '</span>
				<span class=blockspan style="width: 10%; text-align: right;">' . ( $_->{montant} || '&nbsp;') . '</span>
				<span class=blockspan style="width: 2%;">&nbsp;</span>
				' . $img_link . '
				' . $suppress_link . '
				' . $check_value . '
				' . $check_multi . '
				<span class=blockspan style="width: 0.5%;">&nbsp;</span>
				<div class=spacer></div>
				</a></li>
			' ;
		}

		$entry_list .=  '
		<li class=listitem><hr></li>
		<li class=listitem>
		<div class=spacer></div>
		<span class=blockspan style="width: 0.5%;">&nbsp;</span>
		<span class=blockspan style="width: 79%; text-align: right;">Total</span>
		<span class=blockspan style="width: 10%; text-align: right;">' . ( $array_of_documents->[0]->{total_montant} || 0 ) . '</span>
		<span class=blockspan style="width: 10%;">&nbsp;</span>
		<span class=blockspan style="width: 0.5%;">&nbsp;</span>
		<div class=spacer></div>
		</li>' ;
    
		$content .= '<ul class=wrapper-docs>' . $entry_list . '</ul>' ;

	} else {

		#repository absent, aucun fichier n'a été créé
		$content .= '
		<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . ( 'Aucun document enregistré' ) . '</h3>' ;

	} #    if ( @( $array_of_files ) )
	############## MISE EN FORME FIN ##############
		
} #sub visualize

#/*—————————————— Page Formulaire modification catégorie de document ——————————————*/
sub form_categorie {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	my $categorie_list ;
	$args->{restart} = 'docs?categorie';
	my $line = "1"; 
    
	################ Affichage MENU ################
	$content .= display_menu_docs( $r, $args ) ;
	################ Affichage MENU ################

	#/************ ACTION DEBUT *************/
	
	####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Supprimer' la catégorie		  #
	#######################################################################
	#1ère demande de suppression; afficher lien d'annulation/confirmation
    if ( defined $args->{categorie} && defined $args->{supprimer} && $args->{supprimer} eq '0' ) {
		my $non_href = '/'.$r->pnotes('session')->{racine}.'/docs?categorie' ;
		my $oui_href = '/'.$r->pnotes('session')->{racine}.'/docs?categorie&amp;supprimer=1&amp;libelle_cat_doc=' . ($args->{libelle_cat_doc} || '') ;
		$content .= '<h3 class=warning>Vraiment supprimer la catégorie ' . $args->{libelle_cat_doc} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;
	} elsif ( defined $args->{categorie} && defined $args->{supprimer} && $args->{supprimer} eq '1' ) {
		#demande de suppression confirmée
		$sql = 'DELETE FROM tbldocuments_categorie WHERE libelle_cat_doc = ? AND id_client = ?' ;
		@bind_array = ( $args->{libelle_cat_doc}, $r->pnotes('session')->{id_client} ) ;
		eval {$dbh->do( $sql, undef, @bind_array ) } ;

		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {
			$content .= '<h3 class=warning>le nom ne peut être vide</h3>' ;
			} elsif ( $@ =~ /toujours|referenced/ ) {
			$content .= '<h3 class=warning>Suppression impossible : la catégorie '.$args->{libelle_cat_doc}.' est encore utilisée dans un document </h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		} else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Suppression de la catégorie de document '.$args->{libelle_cat_doc}.'');
		}
	}
    
    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Ajouter' la catégorie		  #
	#######################################################################
    if ( defined $args->{categorie} && defined $args->{valide_doc} && $args->{valide_doc} eq '1' ) {
		#on interdit libelle vide
		$args->{libelle_cat_doc} ||= undef ;
	
	    #ajouter une catégorie
	    $sql = 'INSERT INTO tbldocuments_categorie (libelle_cat_doc, id_client) values (?, ?)' ;
	    @bind_array = ( $args->{libelle_cat_doc}, $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>Il faut renseigner le nom de la nouvelle catégorie de document</h3>' ;
			} elsif ( $@ =~ /existe|already exists/ ) {$content .= '<h3 class=warning>Cette catégorie existe déjà</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		} else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Ajout de la catégorie de document '.$args->{libelle_cat_doc}.'');
			$content .= restart( $r, $args ) ;	
		}
    }
    
    ####################################################################### 
	#l'utilisateur a cliqué sur 'Valider' la modification de la catégorie #
	#######################################################################
    if ( defined $args->{categorie} && defined $args->{modifier} && $args->{modifier} eq '1' ) {
	    
   	    #modifier une catégorie
	    $sql = 'UPDATE tbldocuments_categorie set libelle_cat_doc = ? where id_client = ? AND libelle_cat_doc = ? ' ;
	    @bind_array = ( $args->{new_libelle_cat_doc}, $r->pnotes('session')->{id_client}, $args->{old_libelle_cat_doc} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>le nom ne peut être vide</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		}
    }
	
	#/************ ACTION FIN *************/
	
	############## MISE EN FORME DEBUT ##############

    $sql = 'SELECT libelle_cat_doc FROM tbldocuments_categorie WHERE id_client = ?' ;

    my $categorie_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
	
    my $doc_list = '

    <fieldset  class="pretty-box"><legend><h3 class="Titre09">Gestion des catégories de documents</h3></legend>
    <div class=centrer>
    
        <div class=Titre10>Ajouter une nouvelle catégorie</div>
		<div class="form-int">
			<form method=POST action=/'.$r->pnotes('session')->{racine}.'/docs?categorie>
			<input class="login-text" type=text placeholder="Entrer le libellé de la catégorie" name="libelle_cat_doc" value="" style="width: 40ch;" required >
			<input type=hidden name="valide_doc" value=1>
			<input type=submit class="btn btn-vert" value=Ajouter style="width: 15%;">
			</form>
		</div>
    
		<br>
    
		<div class=Titre10>Modifier une catégorie existante</div>
		
    ' ;
    
    #ligne des en-têtes
    $doc_list .= '
		<ul class=wrapper10><li class="lineflex1">   
		<div class=spacer></div>
		<span class=headerspan style="width: 0.3%;">&nbsp;</span>
		<span class=headerspan style="width: 30%; text-align: center;">Libellé</span>
		<span class=headerspan style="width: 4%;">&nbsp;</span>
		<span class=headerspan style="width: 4%;">&nbsp;</span>
		<span class=headerspan style="width: 0.3%;">&nbsp;</span>
		<div class=spacer></div></li>
	' ;
    
    for ( @$categorie_set ) {
		my $reqline = ($line ++);
		
		my $delete_href = 'docs&#63;categorie&amp;supprimer=0&amp;libelle_cat_doc=' . URI::Escape::uri_escape_utf8($_->{libelle_cat_doc}) ;
	
		my $delete_link = ( $_->{libelle_cat_doc} eq 'Temp' ) ? '<span class="blockspan" style="width: 4%; text-align: center;"></span>' : 
		'<span class="blockspan" style="width: 4%; text-align: center;"><input type="image" formaction="' . $delete_href . '" title="Supprimer" src="/Compta/style/icons/delete.png" type="submit" height="24" width="24" alt="supprimer"></span>' ;

		my $valid_href = 'docs&#63;categorie&amp;modifier=1&amp;old_libelle_cat_doc=' . URI::Escape::uri_escape_utf8( $_->{libelle_cat_doc} ) ;
		my $disabled = ( $_->{libelle_cat_doc} eq 'Temp' ) ? ' disabled' : '' ;
		
		$doc_list .= '
		<li id="line_'.$reqline.'" class="style1">  
		<form class=flex1 method=POST action=/'.$r->pnotes('session')->{racine}.'/docs?categorie>
		<span class=displayspan style="width: 0.3%;">&nbsp;</span>
		<span class=displayspan style="width: 30%;"><input onkeypress="findModif(this,'.$reqline.');" class="formMinDiv4" type=text name=new_libelle_cat_doc value="' . $_->{libelle_cat_doc} . '" ' . $disabled . ' /></span>
		<span class="displayspan" style="width: 4%; text-align: center;"><input id="valid_'.$reqline.'" class=line_icon_hidden type="image" formaction="' . $valid_href . '" title="Valider" src="/Compta/style/icons/valider.png" type="submit" height="24" width="24" alt="valider" '.$disabled.'></span>
		'.$delete_link.'
		<span class=displayspan style="width: 0.3%;">&nbsp;</span>
		</form>
		</li>
		' ;
	}
    
    $doc_list .= '</ul></fieldset>';
		
	$content .= '<div class="formulaire1">' . $doc_list . '</div>' ;

    return $content ;
    
    ############## MISE EN FORME FIN ##############
    
} #sub form_categorie 

#/*—————————————— Page Formulaire nouveau document ——————————————*/
sub form_new_docs {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $req = Apache2::Request->new($r) ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	my $line = "1"; 
	$args->{restart} = 'docs?nouveau';
    
	################ Affichage MENU ################
	$content .= display_menu_docs( $r, $args ) ;
	################ Affichage MENU ################
	
	############## Formulaire Ajout d'un document ##############
	my $formlist .='
		<div class=Titre10>Ajout d\'un document</div>
			<div class="form-int">
				<form action="/'.$r->pnotes('session')->{racine}.'/docs" method=POST enctype="multipart/form-data">
					<label class="bold" for="recupdate">Récupérer date dans le nom du fichier au format yyyy_mm_dd ou dd_mm_yyyy ?</label>
					<input type="checkbox" style ="width : 19%;" id="recupdate" name="recupdate" value=1 checked>
					<br><br>
					<input type=file name=document>	
					<input type=hidden name=nouveau value=1>
					<input type=hidden name=id_client value="' . $r->pnotes('session')->{id_client} . '">
					<input type=hidden name=fiscal_year value="'.$r->pnotes('session')->{fiscal_year}.'">
					<input type=submit class="btn btn-vert" value=Valider style ="width : 10%;">
				</form>
			</div>
	';
	
	#/************ ACTION DEBUT *************/
	
	################################################################       
	#l'utilisateur a envoyé un nouveau document à enregistrer	   #
	################################################################    
	if ( defined $args->{nouveau} and $args->{nouveau} eq '1'  ) {
	
		#envoi d'un fichier par l'utilisateur
	    unless ( $args->{document} ) {
			#pas de fichier!
			$content .= '<h3 class=warning>Fichier absent!</h3>' ;
	    } else {
	
			#file handle du document uploadé
			my $upload = $req->upload("document") or warn $! ;
			my $upload_fh = $upload->fh() ;
	
			#ne conserver que l'extension pour le nom du fichier
			$args->{document} =~ m/\.([^.]+$)/ ;
			#on met en minuscule l'extension; s'il n'y en a pas, on met 'inconnu'; on supprime les caractères bizarres, non alphanumériques
			( $args->{extension} = lc( $1 || 'inconnu' ) ) =~ s/[^a-zA-Z0-9]//g ;
			
			my $doc_categorie = 'Temp';
			my $doc_date = '';
			my $id_compte = '';
	
			#Requête tblconfig_liste
			$sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? AND module = \'documents\' ORDER by config_libelle' ;
			my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) );
			
			for ( @$resultat ) {
			if ( $args->{document} =~ $_->{config_libelle}) { $doc_categorie = $_->{config_journal}; $id_compte = $_->{config_compte}} 
			}
	
			my $fmt1 = '(?<y>\d\d\d\d)_(?<m>\d\d)_(?<d>\d\d)';
			my $fmt2 = '(?<d>\d\d)_(?<m>\d\d)_(?<y>\d\d\d\d)';
		
			#vérification si une date au format yyyy-mm-dd est dans le nom du fichier et si recupdate est coché
			if ( $args->{document} =~ m{$fmt2} && (defined $args->{recupdate} && $args->{recupdate} eq '1')){
				$doc_date =  "$+{y}-$+{m}-$+{d}\n";
			} elsif ( $args->{document} =~ m{$fmt1} && (defined $args->{recupdate} && $args->{recupdate} eq '1') ){
				$doc_date =  "$+{y}-$+{m}-$+{d}\n";
			} else {
				#date par défaut du document=date du jour si pas de date fournie
				$doc_date = $dbh->selectall_arrayref('SELECT CURRENT_DATE')->[0]->[0] ;
			}
	
			#insertion dans la table
			$sql = 'INSERT INTO tbldocuments ( id_client, id_name, fiscal_year, libelle_cat_doc, date_reception, date_upload, id_compte ) VALUES ( ? , ? , ? , ?, ?, CURRENT_DATE, ?) RETURNING id_name' ;
			my $sth = $dbh->prepare($sql) ;
			eval { $sth->execute( $args->{id_client}, $args->{document} , $args->{fiscal_year}, $doc_categorie, $doc_date, $id_compte )} ;

			#afficher l'erreur si l'insertion ne se fait pas
			if ( $@ ) {
				if ( $@ =~ /existe|already exists/ ) {
					$content .= '<h3 class=warning>Un document existe avec le même nom - Enregistrement impossible</h3>' ;
				} else {
					$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . Encode::decode_utf8( $@ ) . '&'.$args->{id_client}.'&'.$args->{document}.'&date'.$doc_date.'</h3>' ;
				}
			} else {

				#contient l'id_name document nouvellement enregistré
				my $returned_record = $sth->fetchrow_hashref ;

				$args->{id_client} =~ /(\d+)/ ;

				my $id_client = $1 ;
				my $archive_dir = '';
				
				my $base_dir = $r->document_root() . '/Compta/base/documents/' ;
				chdir $base_dir ;

				$archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$r->pnotes('session')->{fiscal_year}. '/' ;

				unless ( -d $archive_dir ) {
				#créer archive_dir
				mkpath $archive_dir or die "can't do mkpath : $!" ;
				}

				#fichier de stockage = archive_dir/id_name.extension
				my $archive_file = $archive_dir . '/' .  $args->{document};
				
				open (my $fh, ">", $archive_file) or die "Impossible d'ouvrir le fichier $archive_file : $!" ;

				#récupération des données du fichier
				while ( my $data = <$upload_fh> ) {
				print $fh $data ;
				}

				close $fh ;

				#l'enregistrement s'est bien passé, on peut retourner à la liste des documents
				undef $args->{nouveau} ;

				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Ajout du document '.$args->{document}.' ');
				$args->{restart} = 'docs?docscategorie='.$doc_categorie.'';
				$content .= restart( $r, $args ) ;	

			}
		}
    }
    
	####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Supprimer' 					  #
	#######################################################################
    if ( defined $args->{nouveau} && defined $args->{delete} ) {
		
		#1ère demande de suppression; afficher lien d'annulation/confirmation
		if ( defined $args->{nouveau} && defined $args->{delete} && $args->{delete} eq '0' ) {
			my $non_href = '/'.$r->pnotes('session')->{racine}.'/docs?nouveau' ;
			my $oui_href = '/'.$r->pnotes('session')->{racine}.'/docs?nouveau&amp;documents=1&amp;delete=1&amp;libelle=' . $args->{libelle} ;
			$content .= '<h3 class=warning>Vraiment supprimer la régle ' . $args->{libelle} . '?<a href="' . $oui_href . '" style="margin-left: 3ch;">Oui</a><a href="' . $non_href . '" style="margin-left: 3ch;">Non</a></h3>' ;
		} elsif ( defined $args->{nouveau} && defined $args->{delete} && $args->{delete} eq '1' ) {
			#demande de suppression confirmée
			$sql = 'DELETE FROM tblconfig_liste WHERE config_libelle = ? AND id_client = ? AND module = \'documents\'' ;
			@bind_array = ( $args->{libelle}, $r->pnotes('session')->{id_client} ) ;
			eval {$dbh->do( $sql, undef, @bind_array ) } ;
			if ( $@ ) {
				if ( $@ =~ /NOT NULL/ ) {
				$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
				} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
			} else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Suppression de la règle contenant le mot '.$args->{libelle}.'');
			$content .= restart( $r, $args ) ;
			}
		}    	
	
	} #    if ( $args->{delete} ) 
    
    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Ajouter' 					  #
	#######################################################################
    if ( defined $args->{nouveau} && defined $args->{ajouter} && $args->{ajouter} eq '1' ) {
		#on interdit libelle vide
		$args->{libelle1} ||= undef ;
	
	    #ajouter une catégorie
	    $sql = 'INSERT INTO tblconfig_liste (config_libelle, config_compte, config_journal, id_client, module) values (?, ?, ?, ?, \'documents\')' ;
	    @bind_array = ( $args->{libelle1}, ($args->{select_compte} || undef), ($args->{select_journal} || undef), $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>Il faut obligatoirement un libellé</h3>' ;
			} elsif ( $@ =~ /existe|already exists/ ) {$content .= '<h3 class=warning>Ce libellé existe déjà</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		} else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Ajout de la règle contenant le mot '.$args->{libelle1}.'');
			$content .= restart( $r, $args ) ;	
		}
	 }
    
    ####################################################################### 
	#l'utilisateur a cliqué sur 'Valider' la modification de la catégorie #
	#######################################################################
    if ( defined $args->{nouveau} && defined $args->{modifier} && $args->{modifier} eq '1' ) {
   	    #modifier une catégorie
	    $sql = 'UPDATE tblconfig_liste set config_libelle = ?, config_compte = ?, config_journal = ? where id_client = ? AND config_libelle = ? AND module = \'documents\'' ;
	    @bind_array = ( $args->{libelle}, $args->{select_compte}, $args->{select_journal}, $r->pnotes('session')->{id_client}, $args->{old_libelle} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
	    
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= '<h3 class=warning>le libellé ne peut être vide</h3>' ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		} else {
		#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Modification de la règle contenant le mot '.$args->{libelle}.'');
   		$content .= restart( $r, $args ) ;		
		}
	 }
	
	#/************ ACTION FIN *************/
	
	#####################################       
	# Récupérations d'informations		#
	##################################### 
	
	#Requête tblconfig_liste
	$sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? AND module = \'documents\' ORDER by config_libelle' ;
    my $resultat;
    eval {$resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) };
    
	#Requête catégories de documents
    $sql = 'SELECT libelle_cat_doc FROM tbldocuments_categorie WHERE id_client= ? ORDER BY libelle_cat_doc' ;
    @bind_array = ( $r->pnotes('session')->{id_client} ) ;
	my $journal_req = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	
	#Formulaire Sélectionner une catégorie
	my $select_journal = '<select class="login-text" style="width: 25%;" name=select_journal id=select_journal1 required
	onchange="if(this.selectedIndex == 0){document.location.href=\'docs?categorie\'}">' ;
	$select_journal .= '<option class="opt1" value="">Créer une catégorie</option>' ;
	$select_journal .= '<option value="" selected>--Sélectionner une catégorie--</option>' ;
	for ( @$journal_req ) {
	$select_journal .= '<option value="' . $_->[0] . '">' . $_->[0] . '</option>' ;
	}
	$select_journal .= '</select>' ;

	#Formulaire Sélectionner un compte
	$sql = 'SELECT numero_compte, libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'51\',\'46\') ORDER BY 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $compte_req = $dbh->selectall_arrayref( $sql, { }, @bind_array ) ;
	my $select_compte = '<select class="login-text" style="width: 25%;" name=select_compte id=select_compte1
	onchange="if(this.selectedIndex == 0){document.location.href=\'compte?configuration\'}">' ;
	$select_compte .= '<option class="opt1" value="">Créer un compte</option>' ;
	$select_compte .= '<option value="" selected>--Sélectionner un compte--</option>' ;
	for ( @$compte_req ) {
	$select_compte .= '<option value="' . $_->[0] . '">' . $_->[0] . ' - ' .$_->[1].'</option>' ;
	}
	$select_compte .= '</select>' ;
		
	############## Formulaire ajout d'une règle automatique ##############	
	$formlist .='
			
		<div class=Titre10>Configuration des règles automatiques</div>
		<div class="form-int">
			<form method="post">
			<div class=formflexN2>
			<input class="login-text" style="width: 25%;" type=text placeholder="Valeur à rechercher" id=libelle name="libelle1" value="" required>
			' . $select_journal . '
			' . $select_compte . '
			<input type=hidden name="ajouter" value=1>
			<input type=hidden name=nouveau value=>
			<input type=submit class="btn btn-vert" style ="width : 10%;" value=Ajouter>
			</div>
			</form>
		</div>
		<hr>
	';	
	
	#ligne des en-têtes
    $formlist .= '
		<ul class=wrapper10><li class="lineflex1">   
		<div class=spacer></div>
		<span class=headerspan style="width: 0.3%;">&nbsp;</span>
		<span class=headerspan style="width: 25%; text-align: center;">Mot à rechercher</span>
		<span class=headerspan style="width: 25%; text-align: center;">Catégorie</span>
		<span class=headerspan style="width: 25%; text-align: center;">Compte</span>
		<span class=headerspan style="width: 4%;">&nbsp;</span>
		<span class=headerspan style="width: 4%;">&nbsp;</span>
		<span class=headerspan style="width: 0.3%;">&nbsp;</span>
		<div class=spacer></div></li>
	' ;
	
	############## génération des formulaires modifications des règles automatiques ##############	
    for ( @$resultat ) {
		my $reqline = ($line ++);	
		my $delete_href = 'docs&#63;nouveau&amp;delete=0&amp;libelle=' . URI::Escape::uri_escape_utf8($_->{config_libelle}) ;
		my $valid_href = 'docs&#63;nouveau&amp;maj=1&amp;modifier=1&amp;supprimer=0&amp;old_libelle=' . URI::Escape::uri_escape_utf8( $_->{config_libelle} ) ;
		my $delete_link = '<span class="blockspan" style="width: 4%; text-align: center;"><input type="image" formaction="' . $delete_href . '" title="Supprimer" src="/Compta/style/icons/delete.png" type="submit" height="24" width="24" alt="supprimer"></span>';
	
		#Sélectionner une catégorie
		my $selected_journal = ($_->{config_journal} || 'azertyuiop');;
		my $select_journal = '<select onchange="findModif(this,'.$reqline.');if(this.selectedIndex == 0){document.location.href=\'docs?categorie\'};" class="formMinDiv4" name=select_journal id=select_journal_'.$reqline.'>' ;
		$select_journal .= '<option class="opt1" value="">Créer une catégorie</option>' ;
		$select_journal .= '<option value="">--Sélectionner une catégorie--</option>' ;
		for ( @$journal_req ) {
		my $selected = ( $_->[0] eq $selected_journal) ? 'selected' : '' ;
		$select_journal .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . '</option>' ;
		}
		if (!($_->{config_journal})) {
		$select_journal .= '<option value="" selected>--Sélectionner une catégorie--</option>' ;
		}
		$select_journal .= '</select>' ;

		#Sélectionner un compte
		my $selected_compte = ($_->{config_compte} || 'azertyuiop');
		my $select_compte = '<select onchange="findModif(this,'.$reqline.');if(this.selectedIndex == 0){document.location.href=\'compte?configuration\'};" class="formMinDiv4" name=select_compte id=select_compte_'.$reqline.'>' ;
		$select_compte .= '<option class="opt1" value="">Créer un compte</option>' ;
		$select_compte .= '<option value="">--Sélectionner un compte--</option>' ;
		for ( @$compte_req ) {
		my $selected = ( $_->[0] eq $selected_compte ) ? 'selected' : '' ;
		$select_compte .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . ' - ' .$_->[1].'</option>' ;
		}
		if (!($_->{config_compte})) {
		$select_compte .= '<option value="" selected>--Sélectionner un compte--</option>' ;
		}
		$select_compte .= '</select>' ;

		$formlist .= '
		<li id="line_'.$reqline.'" class="style1">  
		<form class=flex1 method="post">
		<span class=displayspan style="width: 0.3%;">&nbsp;</span>
		<span class=displayspan style="width: 25%;"><input onkeypress="findModif(this,'.$reqline.');" class="formMinDiv4" type=text name=libelle value="' . $_->{config_libelle} . '" /></span>
		<span class=displayspan style="width: 25%;">'.$select_journal.'</span>
		<span class=displayspan style="width: 25%;">'.$select_compte.'</span>
		<span class="displayspan" style="width: 4%; text-align: center;"><input id="valid_'.$reqline.'" class=line_icon_hidden type="image" formaction="' . $valid_href . '" title="Valider" src="/Compta/style/icons/valider.png" type="submit" height="24" width="24" alt="valider"></span>
		'.$delete_link.'
		<input type=hidden name="old_libelle" value='.$_->{config_libelle}.'>
		<input type=hidden name=nouveau value=>
		<span class=displayspan style="width: 0.3%;">&nbsp;</span>
		</form>
		</li>
		' ;
	}
	
    $formlist .= '</ul></fieldset></div>';

	$content .= '	
		<div class="formulaire2">
			<fieldset class="pretty-box"><legend><h3 class="Titre09">Enregistrement d\'un nouveau document</h3></legend>
				<div class=centrer>
				' . $formlist . '
				</div>
			</fieldset>
		</div>
	' ;

    return $content ;
    
} #sub form_new_docs 

sub restart {
	my ( $r, $args ) = @_ ;
	my $location = '/'.$r->pnotes('session')->{racine}.'/'.($args->{restart} || '').'' ;
	$r->headers_out->set(Location => $location) ;
	$r->status(Apache2::Const::REDIRECT) ;
	return Apache2::Const::REDIRECT ;  
} #sub sub_restart

#/*—————————————— Menu des catégories de document ——————————————*/
sub display_menu_docs {

	#définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	unless ( defined $args->{docscategorie} ) {
		$args->{docscategorie} = 'Tous%20documents' ;
	}
	my $libelle_cat_doc ||= 0 ;
	my ($content, $categorie_list) = '' ;

	#########################################	
	#définition des liens					#
	#########################################		
	#lien vers la catégorie "Tous les documents"
	my $all_doc_class = (($args->{docscategorie} =~ /Tous/ && not(defined $args->{categorie}) && not(defined $args->{nouveau})) ? 'selecteditem' : 'nav' );
	my $all_doc_link = '<a class=' . $all_doc_class  . ' href="/'.$r->pnotes('session')->{racine}.'/docs?docscategorie=Tous" style="margin-left: 3ch;">Tous&nbsp;les&nbsp;documents</a>' ;
		
	#lien vers la création d'un nouveau document
	my $new_doc_class = ( defined $args->{nouveau} ) ? 'selecteditem' : 'nav' ;
	my $new_doc_link = '<a class='.$new_doc_class.' href="/'.$r->pnotes('session')->{racine}.'/docs?nouveau" style="margin-left: 3ch;">Nouveau Documents</a>' ;
		
	#Requête de la liste des Catégories de documents
	my $sql = 'SELECT libelle_cat_doc FROM tbldocuments_categorie WHERE id_client= ? ORDER BY 1' ;
	my $cat_docs = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

	for ( @{$cat_docs} ) {
		my $categorie_href = '/'.$r->pnotes('session')->{racine}.'/docs?docscategorie=' . URI::Escape::uri_escape_utf8( $_->{libelle_cat_doc} ) ;
		my $categorie_class = ( ($args->{docscategorie} eq URI::Escape::uri_escape_utf8( $_->{libelle_cat_doc} ) || $args->{docscategorie} eq  $_->{libelle_cat_doc} ) ? 'selecteditem' : 'nav' );
		$categorie_list .= '<a class=' . $categorie_class . ' href="' . $categorie_href . '" style="margin-left: 3ch;">' . $_->{libelle_cat_doc} . '</a>' ;
	} #    for ( @$cat_docs ) {	
	
	#lien de modification des catégories de document
	my $cat_docs_edit_class = ( (defined $args->{categorie} ) ? 'selecteditem' : 'nav' );
	my $cat_docs_edit_link = '<a class=' . $cat_docs_edit_class . ' href="/'.$r->pnotes('session')->{racine}.'/docs?categorie" style="margin-left: 3ch;">Modifier&nbsp;la&nbsp;liste</a>' ;

	#########################################	
	#génération du menu						#
	#########################################
	if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {	
	$content .= '<div class="menu">' . $new_doc_link . $cat_docs_edit_link . $all_doc_link . ($categorie_list || '') . '</div>' ;
	} else {
	$content .= '<div class="menu">' . $all_doc_link . ($categorie_list || '') . '</div>' ;
	}

    return $content ;

} #sub display_menu_docs 

1 ;
