package Base::Site::docsentry ;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict;  # Utilisation stricte des variables
use warnings;  # Activation des avertissements
use Base::Site::util;  # Utilitaires généraux et Génération d'éléments HTML de formulaire
use Base::Site::bdd;   # Interaction avec la base de données (SQL)
use utf8;              # Encodage UTF-8 pour le script
use Base::Site::menu;  # Module Menu
use Base::Site::docs;  # Module Documents
use Apache2::Const -compile => qw( OK REDIRECT );  # Importation de constantes Apache
use URI::Escape;       # Encodage et décodage d'URLs

sub handler {

    my $r = shift;
    
    binmode(STDOUT, ":utf8");
    
    # Utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    
    my $req = Apache2::Request->new( $r ) ;

    # Récupération des paramètres de la requête
    my %args;

    for my $param ($req->param) {
        my $value = Encode::decode_utf8($req->param($param));
        # Remplacez les double-quotes et les <> par des guillemets simples
        $value =~ tr/<>"/'/;
        $args{$param} = $value;
    }

    my $content = visualize($r, \%args);
    
    $r->no_cache(1) ;
    $r->content_type('text/html; charset=utf-8') ;
    $r->print($content);
    return Apache2::Const::OK ;
}

sub visualize {

    my ($r, $args) = @_ ;
    #récupérer les arguments
    my (%args, @args) ;
    my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	my $reqid = Base::Site::util::generate_reqline();
	
   	################ Affichage MENU ################
    $content .= Base::Site::docs::display_menu_docs( $r, $args ) ;
	################ Affichage MENU ################
	
	#Fonction pour générer le débogage des variables $args et $r->args si dump == 1  
	if ($r->pnotes('session')->{dump} == 1) {$content .= Base::Site::util::debug_args($args, $r->args);}

	#Requête tbldocuments => Recherche de la liste des documents enregistrés
    $sql = 'SELECT id_name, date_reception, montant/100::numeric as montant, libelle_cat_doc, fiscal_year, check_banque, multi, last_fiscal_year, id_compte FROM tbldocuments WHERE id_name = ? AND id_client = ?' ;
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $args->{id_name}, $r->pnotes('session')->{id_client} ) ;
    
    #Empêcher id_name vide ou existe pas
	if (!$args->{id_name} || !$array_of_documents->[0]->{id_name}){
		$content .= '
		<section class="wrapper centrer">
			<div class="four_zero_four_bg">
				<h1>OOPS!</h1>
			</div>
		
			<div class="contant_box_404">
				<h3 class="h2">La référence recherchée n\'existe pas</h3>
				<p>Pour accéder à la documentation cliquer ci-dessous!</p>
				<a href="/'.$r->pnotes('session')->{racine}.'/" class="link_404">Menu</a>
			</div>
		</section>' ;
		return $content ;
	}
    
	my $libelle_cat_doc ||= 0 ;
	my $categorie_list = '' ;

	#/************ ACTION DEBUT *************/
	
	#######################################################################  
	#première demande de renommer le document via référence pièce	      #
	####################################################################### 
	if ( defined $args->{id_name} && defined $args->{renommer} and $args->{renommer} eq '0' ) {
		my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $args->{id_name} . '&amp;fiscal_year='.$args->{fiscal_year}.'&amp;renommer=1' ;
		my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $args->{id_name} . '' ;
		$content .= Base::Site::util::generate_error_message('Voulez-vous renommer le document ' . $args->{id_name} .' ?<br><a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">Oui</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">Non</a>') ;
    } elsif ( defined $args->{id_name} && defined $args->{renommer} and $args->{renommer} eq '1' && $args->{id_name} ne '' ) {
	
		#requête nombre id_facture
		my $docs_count = '';
		$sql = '
		with t1 as ( SELECT id_facture FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND (documents1 = ?) GROUP BY id_facture)
		SELECT count(id_facture) as count FROM t1' ;
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $array_of_documents->[0]->{id_name} ) ;
		eval { $docs_count = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) } ;
		
		# si aucune référence	
		if ($docs_count->[0]->{count} eq '0') {
			$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">Impossible car il n\'existe aucune écriture ayant pour référence ce document.</h3>' ;
		#si il y a qu'une référence renommage possible
		} elsif ($docs_count->[0]->{count} eq '1') {
				
				my $id_facture;
				$sql = '
				with t1 as ( SELECT id_facture FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND (documents1 = ?) GROUP BY id_facture)
				SELECT id_facture FROM t1
				' ;
				@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $array_of_documents->[0]->{id_name} ) ;
				eval { $id_facture = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] } ;
				
				if ($args->{id_name} =~ /$id_facture/ ) {
					$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">Le nom du document '.$args->{id_name}.' contient déjà le numéro de pièce '.$id_facture.' </h3>' ;	
				} else {
					my $new_name = $args->{id_name};
					# Vérification et remplacement du numéro de pièce dans le nom du document
				  if ($new_name =~ /^(.*?)(\d{4})-(\d{2})_(\d{2})_(.*?)\.pdf$/) {
						# Extraire les parties du nom du document
						my ($prefix, $annee, $mois, $numero, $nom) = ($1, $2, $3, $4, $5);
						# Construire le nouveau nom du document avec le nouveau numéro de pièce
						$new_name = $id_facture . '_' . $nom . '.pdf';
					} else {
						# Si le format n'est pas conforme, ajouter simplement le numéro de pièce
						$new_name = $id_facture . '_' . $new_name;
					}
					#Requête numéro piéce
					$sql = 'UPDATE tbldocuments set id_name = ? WHERE id_client = ? AND id_name = ? ' ;
					@bind_array = ( $new_name, $r->pnotes('session')->{id_client}, $args->{id_name} ) ;
					eval { $dbh->do( $sql, undef, ( @bind_array) ) } ;
			
					if ( $@ ) {
						$content .= '<h3 class=warning>' . $@ . '</h3>' ;
					} else {
						#la modification de la référence du document dans tbldocuments a réussi, renommer le fichier
						my $base_dir = $r->document_root() . '/Compta/base/documents' ;
						my $archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$args->{fiscal_year}. '/' ;
						my $archive_file = $archive_dir . $args->{id_name} ;
						my $newarchive_file = $archive_dir . $new_name ;
						#renommer le fichier
						rename $archive_file, $newarchive_file;
			
						#Redirection
						$args->{restart} = 'docsentry?id_name='. $new_name .'';
						Base::Site::util::restart($r, $args);  # Appeler la fonction restart du module utilitaire
						return Apache2::Const::OK;  # Indique que le traitement est terminé
					}
				}
		# si plusieurs références		
		} else {
			$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">Impossible car '.$docs_count->[0]->{count} .' références existent pour ce document.</h3>' ;	
		}
	}
    
    ####################################################################### 
	#l'utilisateur a cliqué sur le bouton 'Ajouter' un tag				  #
	#######################################################################
    if ( defined $args->{id_name} && defined $args->{add_tag} && $args->{add_tag} eq '1' ) {
		
		my $lib = $args->{tags_nom} || undef ;
		Base::Site::util::formatter_libelle(\$lib);

		if (defined $args->{tags_nom} && $lib eq '') {
			$content .= Base::Site::util::generate_error_message('Impossible le nom du tag est vide !');
		} elsif ((defined $args->{id_name} && $args->{id_name} eq '') || !defined $args->{id_name}) {
			$content .= Base::Site::util::generate_error_message('Impossible il faut sélectionner un document !');
		} else {
	
	    #ajouter une catégorie
	    $sql = 'INSERT INTO tbldocuments_tags (tags_nom, tags_doc, id_client) values (?, ?, ?)' ;
	    @bind_array = ( $args->{tags_nom}, $args->{id_name}, $r->pnotes('session')->{id_client} ) ;
	    eval {$dbh->do( $sql, undef, @bind_array ) } ;
		if ( $@ ) {
			if ( $@ =~ /NOT NULL/ ) {$content .= Base::Site::util::generate_error_message('Il faut renseigner le nom du nouveau tag de document') ;
			} elsif ( $@ =~ /existe|already exists/ ) {$content .= Base::Site::util::generate_error_message('Le tag "'.$args->{tags_nom}.'" existe déjà pour ce document') ;
			} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
		} else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Ajout du tag "'.$args->{tags_nom}.'" pour le document '.$args->{id_name}.'');
			#$args->{restart} = 'docsentry?id_name='. $id_name .'';
			#Base::Site::util::restart($r, $args);  # Appeler la fonction restart du module utilitaire
			#return Apache2::Const::OK;  # Indique que le traitement est terminé	
		}
		}
    }
  
	#######################################################################  
	#première demande de suppression d'un document; réclamer confirmation #
	####################################################################### 
    if ( defined $args->{id_name} && defined $args->{supprimer} and $args->{supprimer} eq '0' ) {
		my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $args->{id_name} . '&amp;supprimer=1' ;
		my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $args->{id_name} . '' ;
		$content .= Base::Site::util::generate_error_message('Voulez-vous  supprimer le document ' . $args->{id_name} .' ?<br><a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">Oui</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">Non</a>') ;
    } elsif ( defined $args->{id_name} && defined $args->{supprimer} and $args->{supprimer} eq '1' ) {
		
		#Requête tbldocuments => Recherche si le document existe dans une écriture
		$sql = 'SELECT id_entry, libelle_journal FROM tbljournal WHERE id_client = ? AND (documents1 = ? OR documents2 = ?) GROUP BY id_entry, libelle_journal' ;
		my $verify_entry_doc = $dbh->selectall_arrayref( $sql, { Slice => { } }, $r->pnotes('session')->{id_client}, $args->{id_name}, $args->{id_name} ) ;
    
		#Empêcher id_name vide ou existe pas
		if ($verify_entry_doc->[0]->{id_entry}){
		$content .= '<h3 class="warning centrer">Impossible de supprimer le document, celui-ci est référencé sur une écriture !!
		<br>Liste des enregistrements concernés : ';
		for ( @{ $verify_entry_doc } ) {
		$content .= ' <a class=nav href="entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&id_entry=' . $_->{id_entry}.'">' . $_->{id_entry}.'</a> ' ;	
		}
		$content .= '</h3>' ;	

		} else {
		
			$sql = 'DELETE FROM tbldocuments WHERE id_name = ? AND id_client = ?' ;
			my $rows_deleted ;
			eval { $rows_deleted = $dbh->do( $sql, { }, ( $args->{id_name}, $r->pnotes('session')->{id_client} ) ) } ;

			#si un problème est survenu ou aucun enregistrement n'a été supprimé, ne pas toucher au ficher 
			if ( $@ or !( $rows_deleted ) ) {
				if ( $@ =~ /viole la contrainte|violates/ ) {
					$content = '<h3 class=warning>Impossible de supprimer le document, celui-ci est référencé sur une écriture</h3>' ;
				} else {
					$content = '<h3 class=warning style="margin: 2.5em; padding: 2.5em;">' . Encode::decode_utf8( $@ ) . '</h3>' ;
				}
			} else {
				#la suppression de la référence du document dans tbldocuments a réussi, supprimer le fichier
				my $base_dir = $r->document_root() . '/Compta/base/documents' ;
				my $archive_dir = '' ;
				
				$archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$r->pnotes('session')->{fiscal_year}. '/' ;

				my $archive_file = $archive_dir . $args->{id_name} ;
				#suppression du fichier
				unlink $archive_file ;
			
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Supression du document '.$args->{id_name}.'');
				#Redirection
				$args->{restart} = 'docs?docscategorie='.($args->{docscategorie}||'').'';
				Base::Site::util::restart($r, $args);  # Appeler la fonction restart du module utilitaire
				return Apache2::Const::OK;  # Indique que le traitement est terminé
			}
		}
	}
      
    #######################################################################  
	#première demande de suppression d'un document; réclamer confirmation #
	####################################################################### 
    if ( defined $args->{id_name} && defined $args->{supprimer_tag} and $args->{supprimer_tag} eq '0' ) {
		my $confirm_delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $args->{id_name} . '&amp;supprimer_tag=1&amp;tags_nom=' . ($args->{tags_nom} || '').'' ;
		my $deny_delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . $args->{id_name} . '' ;
		$content .= Base::Site::util::generate_error_message('Voulez-vous  supprimer le tag ' . ($args->{tags_nom} || '').' ?<br><a class=nav href="' . $confirm_delete_href . '" style="margin-left: 3em;">Oui</a><a class=nav href="' . $deny_delete_href . '" style="margin-left: 3em;">Non</a>') ;
    } elsif ( defined $args->{id_name} && defined $args->{supprimer_tag} and $args->{supprimer_tag} eq '1' ) {
		
		if ( defined $args->{id_name} && $args->{id_name} ne '') {
			#demande de suppression confirmée
			$sql = 'DELETE FROM tbldocuments_tags WHERE tags_nom = ? AND id_client = ? and tags_doc = ?' ;
			@bind_array = ( $args->{tags_nom}, $r->pnotes('session')->{id_client}, $args->{id_name} ) ;
			eval {$dbh->do( $sql, undef, @bind_array ) } ;

			if ( $@ ) {
				if ( $@ =~ /NOT NULL/ ) {
				$content .= '<h3 class=warning>le nom ne peut être vide</h3>' ;
				} elsif ( $@ =~ /toujours|referenced/ ) {
				$content .= '<h3 class=warning>Suppression impossible : le tag '.$args->{tags_nom}.' est encore utilisé dans un document </h3>' ;
				} else {$content .= '<h3 class=warning>' . $@ . '</h3>' ;}
			} else {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'doc.pm => Supression du tag "'.$args->{tags_nom}.'" pour le document '.$args->{id_name}.'');
				#$args->{restart} = 'docsentry?id_name=' . $args->{id_name} . '';
				#Base::Site::util::restart($r, $args);  # Appeler la fonction restart du module utilitaire
				#return Apache2::Const::OK;  # Indique que le traitement est terminé	
			}
		}
	}
         
	################################################################################### 
	# l'utilisateur a cliqué sur le bouton 'Valider', enregistrer les modifications	  #
	###################################################################################
    if ( defined $args->{id_name} && defined $args->{modifier} and $args->{modifier} eq '1' ) {
			
		Base::Site::util::formatter_montant_et_libelle(\$args->{montant}, undef);
		
		my $erreur = Base::Site::util::verifier_args_obligatoires($r, $args, [18, $args->{montant}]);
		
		if ($erreur) {
				$content .= Base::Site::util::generate_error_message($erreur);  # Affichez le message d'erreur
		} else {

			if (defined $args->{new_last_fiscal_year} && $args->{new_last_fiscal_year} eq '') {$args->{new_last_fiscal_year} = undef ;}
			if (defined $args->{compte_comptant} && $args->{compte_comptant} eq '') {$args->{compte_comptant} = undef ;}
			if (defined $args->{check_banque} && $args->{check_banque} eq '1') {
			$args->{check_banque} = 't';
			} else {$args->{check_banque} = 'f';}
			
			#si checkbox multi est on $args->{multi} eq '1' donc true || si off disabled de fiscal_year
			if ((defined $args->{multi} && $args->{multi} eq '1') || ((defined $args->{old_multi} && $args->{old_multi} eq 't') && ($args->{fiscal_year} ne $r->pnotes('session')->{fiscal_year} ))) {
			$args->{multi} = 't';
			} else {$args->{multi} = 'f';} 
			

			$sql = 'UPDATE tbldocuments set id_name = ?, date_reception = ?, montant = ?, libelle_cat_doc = ?, last_fiscal_year = ? , check_banque = ?, multi = ?, id_compte = ? WHERE id_client = ? AND id_name = ? ' ;
			@bind_array = ( $args->{new_id_name}, $args->{date_reception}, $args->{montant}*100, $args->{libelle}, $args->{new_last_fiscal_year}, $args->{check_banque}, $args->{multi}, $args->{compte_comptant}, $r->pnotes('session')->{id_client}, $args->{old_id_name} ) ;
			eval { $dbh->do( $sql, undef, ( @bind_array) ) } ;
			
			#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'docsentry.pm => Mise à jour du document : '.$args->{old_id_name}.' en : '.$args->{new_id_name}.'');
		
			if ( $@ ) {
			if ( $@ =~ / NOT NULL (.*) date_reception / ) {
			 $content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /duplicate/ ) {
				$content .= '<h3 class=warning>Enregistrement impossible car un fichier existe déjà avec le même nom</h3>' ;
			} else {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}
			} else {
			
			#la modification de la référence du document dans tbldocuments a réussi, renommer le fichier
			my $base_dir = $r->document_root() . '/Compta/base/documents' ;
			my $archive_dir = '' ;
			
				if (defined $args->{multi} && $args->{multi} eq 't' ) {
				$archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$args->{fiscal_year}. '/' ;
				} else {
				$archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$r->pnotes('session')->{fiscal_year}. '/' ;
				}
			
			my $archive_file = $archive_dir . $args->{old_id_name} ;
			my $newarchive_file = $archive_dir . $args->{new_id_name} ;
			#renommer le fichier
			rename $archive_file, $newarchive_file;
			
			#Redirection
			$args->{restart} = 'docsentry?id_name='. $args->{new_id_name} .'';
			Base::Site::util::restart($r, $args);  # Appeler la fonction restart du module utilitaire
			return Apache2::Const::OK;  # Indique que le traitement est terminé
			}
		}
	    

	}  
	
	#/************ ACTION FIN *************/
	
	############## MISE EN FORME DEBUT ##############
	my ($new_entree_docs1_href, $new_entree_docs2_href, $new_href );
	
	#désactivation modifications des documents multi-exercice
   	my $disabled_link = ( $array_of_documents->[0]->{fiscal_year} eq $r->pnotes('session')->{fiscal_year} ) ? '' : 'disabled' ;
  	my $readonly_link = ( $array_of_documents->[0]->{fiscal_year} eq $r->pnotes('session')->{fiscal_year} ) ? '' : 'readonly' ;
   	my $disabled_link2 = ( ($array_of_documents->[0]->{fiscal_year} eq $r->pnotes('session')->{fiscal_year}) || $array_of_documents->[0]->{multi} eq 'f') ? '' : 'disabled' ;
   	
	my $message_exercice_cloture = '';
	if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {
		$new_entree_docs1_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=BANQUE&amp;mois=0&amp;id_entry=0&amp;nouveau&amp;docs1='.$array_of_documents->[0]->{id_name}.'' ;
		$new_entree_docs2_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=BANQUE&amp;mois=0&amp;id_entry=0&amp;nouveau&amp;docs2='.$array_of_documents->[0]->{id_name}.'' ;
		$new_href = '/'.$r->pnotes('session')->{racine}.'/docs?new_document=0' ;
	} else {
		$new_entree_docs1_href = '#' ;
		$new_entree_docs2_href = '#' ;
		$new_href = '#' ;
		$disabled_link = 'disabled';
		$readonly_link = 'readonly';
		$message_exercice_cloture = '<br><div class="flex-table submit"><span class=displayspan style="width: 100%; text-align: center; color: red; font-weight : bold;">Modification du nom et de la date impossible car il existe des enregistrements liés exportés</span><br></div><br>';
	}
	
	my $retour_href = 'javascript:history.go(-1)';
	
	my $compte1 = Base::Site::bdd::get_comptes_by_classe($dbh, $r, '51,46');
	my ($selected1, $form_name1, $form_id1)  = (($args->{compte_comptant} || $array_of_documents->[0]->{id_compte}), 'compte_comptant', 'compte_comptant');
	my $onchange1 = 'onchange="if(this.selectedIndex == 0){document.location.href=\'compte?configuration\'};"';
	my $compte_comptant = Base::Site::util::generate_compte_selector($compte1, $reqid, $selected1, $form_name1, $form_id1, $onchange1, 'class="forms2_input"', 'style="width: 14%;"');
	
    #liste des Catégories de documents
    $sql = 'SELECT libelle_cat_doc FROM tbldocuments_categorie WHERE id_client= ? ORDER BY libelle_cat_doc' ;
    @bind_array = ( $r->pnotes('session')->{id_client} ) ;
    my $categorie_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
    my $categorie_select = '<select class="forms2_input" style="width: 12%;" name=libelle id=libelle 
    onchange="if(this.selectedIndex == 0){document.location.href=\'docs?categorie\'}">' ;
	$categorie_select .= '<option class="opt1" value="">Créer une catégorie</option>' ;
    for ( @$categorie_set  ) {
	my $selected = ( $_->[0] eq $array_of_documents->[0]->{libelle_cat_doc} ) ? 'selected' : '' ;
	$categorie_select .= '<option value="' . $_->[0] . '" ' . $selected . '>' . $_->[0] . '</option>' ;
    }
    $categorie_select .= '</select>' ;
    
    #
    #construire la table des paramètres
    #
    #joli formatage de débit/crédit
    (my $montant = sprintf( "%.2f", $array_of_documents->[0]->{montant} ) ) =~ s/\B(?=(...)*$)/ /g ;

	#####################################       
	#Sélection des entrées du journal
	#####################################    

	$sql = '
	with t1 as ( SELECT id_entry FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND (documents1 = ? OR documents2 = ?) GROUP BY id_entry)
	SELECT count(id_entry) FROM t1
	' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $array_of_documents->[0]->{id_name}, $array_of_documents->[0]->{id_name} ) ;
	my $docs_count = '';
	eval { $docs_count = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] } ;
	
	$sql = '
	SELECT t1.id_entry, t1.id_line, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, t3.libelle_compte, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit, id_export, to_char((sum(credit-debit) over(PARTITION BY t1.numero_compte ORDER BY date_ecriture, libelle, libelle_journal, id_paiement, id_entry, id_line))/100::numeric, \'999G999G999G990D00\') as solde, lettrage, pointage
	FROM tbljournal t1
	INNER JOIN tblcompte t3 ON t1.id_client = t3.id_client AND t1.fiscal_year = t3.fiscal_year AND t1.numero_compte = t3.numero_compte
	WHERE t1.id_client = ? AND t1.fiscal_year = ? AND (t1.documents1 = ? OR t1.documents2 = ?)
	ORDER BY date_ecriture, id_facture, libelle, libelle_journal, id_paiement, id_entry, id_line
	' ;

	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $array_of_documents->[0]->{id_name}, $array_of_documents->[0]->{id_name} ) ;
	my $result_set = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;
    
    my ( $lettrage_href, $lettrage_link, $lettrage_input, $lettrage_base ) ;
    my ( $pointage_href, $pointage_link, $pointage_input, $pointage_base ) ;
    
    #on ne doit pas modifier des écritures exportées
    my $do_not_edit = ( $result_set->[0]->{id_export} ) ? 1 : 0 ;
        	
	if ( $do_not_edit eq 1 ) {
	$disabled_link = 'disabled' ;
   	$readonly_link = 'readonly' ;
	} 
    
    #####################################       
	# Menu chekbox
	#####################################   
	#définition des variables
	my @checked = ('0') x 15;
	my @dispcheck = ('0') x 15;
	my @actions;
    
    #checked par défault label1 et 2
    unless (defined $args->{label1}) {$args->{label1} = 1;}
	unless (defined $args->{label2}) {$args->{label2} = 1;}
	unless (defined $args->{label9}) {$args->{label9} = 1;}
	
	#Référence
	if (defined $args->{label1} && $args->{label1} eq 1) {$checked[1] = 'checked';} else {$checked[1] = '';}
	#Affichage
	if (defined $args->{label2} && $args->{label2} eq 1) {$checked[2] = 'checked';} else {$checked[2] = '';}
	#Rechercher
	if (defined $args->{label3} && $args->{label3} eq 1) {$checked[3] = 'checked';} else {$checked[3] = '';}
	#Saisie Rapide
	if ((defined $args->{label4} && $args->{label4} eq 1) || defined $args->{saisie_rapide}) {$checked[4] = 'checked';} else {$checked[4] = '';}
	#doc1
	if (defined $args->{label8} && $args->{label8} eq 1) {$checked[8] = 'checked';} else {$checked[8] = '';}
	#doc2
	if (defined $args->{label9} && $args->{label9} eq 1) {$checked[9] = 'checked';} else {$checked[9] = '';}
	#Ecritures récurrentes
	if ((defined $args->{label10} && $args->{label10} eq 1) || defined $args->{ecriture_recurrente}) {$checked[10] = 'checked';} else {$checked[10] = '';}
	#Ecritures csv
	if ((defined $args->{label11} && $args->{label11} eq 1) || defined $args->{csv}) {$checked[11] = 'checked';} else {$checked[11] = '';}

	# Tableau associatif pour les actions et les libellés quand l'exercice n'est pas clôturé
	if ($r->pnotes('session')->{Exercice_Cloture} ne '1') {		
		@actions = (
		{ label => 'Référence', name => 'label1', index => 1 },
		{ label => 'Affichage', name => 'label2', index => 2 },
		{ label => 'Rechercher', name => 'label3', index => 3 },
		{ label => 'Saisie Rapide', name => 'label4', index => 4 },
		{ label => 'doc1', name => 'label8', index => 8 },
		{ label => 'doc2', name => 'label9', index => 9 },
		{ label => 'Écr. récurrentes', name => 'label10', index => 10 },
		{ label => 'CSV/OFX/OCR', name => 'label11', index => 11 },
		);
	# Tableau associatif pour les actions et les libellés quand l'exercice est clôturé	
	} else {
		@actions = (
		{ label => 'Référence', name => 'label1', index => 1 },
		{ label => 'Affichage', name => 'label2', index => 2 },
		{ label => 'Rechercher', name => 'label3', index => 3 },
		);
	}

	my $fiche_client .= '
	<fieldset class=pretty-box>
		<legend style="display: flex; align-items:center; ">
			<h3 class="Titre09">Gestion des documents</h3>
			<a title="Création d\'une nouvelle entrée en doc1" class="aperso" href="' . $new_entree_docs1_href . '">#new_entrée_docs1</a>
			<a title="Création d\'une nouvelle entrée en doc2" class="aperso" href="' . $new_entree_docs2_href . '">#new_entrée_docs2</a>
			<a title="Retour arrière" class="aperso" href="' . $retour_href . '">#retour</a>
		</legend>
		
		<div class=centrer>
			<div class="flex-checkbox">
	';
	
	# Ajout des champs cachés pour toutes les actions
	foreach my $action (@actions) {
		$fiche_client .= '<input type=hidden name="' . $action->{name} . '" value="' . ($args->{$action->{name}} || '') . '">';
	}

	foreach my $action (@actions) {
		$fiche_client .= '
		<form method="post" action=/'.$r->pnotes('session')->{racine}.'/docsentry?id_name=' . ($args->{id_name} || '') . '>
			<label for="check' . $action->{index} . '" class="forms2_label">' . $action->{label} . '</label>
			<input id="check' . $action->{index} . '" type="checkbox" class="demo5" '.$checked[$action->{index}].' onchange="submit()" name="' . $action->{name} . '" value=1>
			<label for="check' . $action->{index} . '" class="forms2_label"></label>
			<input type=hidden name="' . $action->{name} . '" value=0 >';
		
		foreach my $other_action (@actions) {
			if ($other_action->{name} ne $action->{name}) {
				$fiche_client .= '<input type=hidden name="' . $other_action->{name} . '" value="' . ($args->{$other_action->{name}} || '') . '">';
			}
		}
		$fiche_client .= '</form>';
	}

	$fiche_client .= '</div><div class=Titre10>Modification du document <a class=nav2 href="docsentry?id_name='.($args->{id_name} || '').'">'.$args->{id_name}.'</a> (Exercice '.$array_of_documents->[0]->{fiscal_year}.')</div>';

    #####################################       
	#Formulaire du document
	#####################################    
    
    #gestion des options checkcheck_banque
	my $check_value = ( $array_of_documents->[0]->{check_banque} eq 't' ) ? 'checked' : '' ;
	my $check_value_multi = ( $array_of_documents->[0]->{multi} eq 't' ) ? 'checked' : '' ;
    
    #Gestion des écritures Multi-exercice
    my $display_last_exercice = '' ;
    my $display_label_exercice = '' ;
    if ( $array_of_documents->[0]->{multi} eq 't' ) {
		$display_last_exercice  = '<input class="forms2_input" style="width: 8%;" type=text id=new_last_fiscal_year name=new_last_fiscal_year value="' . ($array_of_documents->[0]->{last_fiscal_year} || '') . '" />';
		$display_label_exercice = '<label style="width: 8%;" class="forms2_label" for="new_last_fiscal_year">Last Exercice</label>';
	}
	
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'docsentry.pm => id_name : '.$array_of_documents->[0]->{id_name}.' multi '.$array_of_documents->[0]->{multi}.' check_banque '.$array_of_documents->[0]->{check_banque}.'');
	
	my $delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='. ($array_of_documents->[0]->{id_name} || '') .'&amp;supprimer=0' ;
	my $valid_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='. ($array_of_documents->[0]->{id_name} || '') .'&amp;modifier=1' ;
	my $rename_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='. ($array_of_documents->[0]->{id_name} || '') .'&amp;renommer=0' ;

	my $submit_delete = '';
	my $submit_rename = '';
	if ($array_of_documents->[0]->{fiscal_year} eq $r->pnotes('session')->{fiscal_year} ) {
		$submit_delete = '<input type="submit" class="btn btn-rouge" style="width: 15%;" formaction="' . $delete_href . '" value="Supprimer" >';
		$submit_rename = '<input type="submit" class="btn btn-orange" style ="width : 15%;" title="Renommer le fichier pour prendre en compte le numéro de pièce" formaction="' . $rename_href .'" value="Renommer">';
	}
	
	# Requête pour récupérer la liste des tags du document
	$sql = 'SELECT t2.tags_nom FROM tbldocuments t1
			   LEFT JOIN tbldocuments_tags t2 ON t1.id_client = t2.id_client AND t1.id_name = t2.tags_doc
			   WHERE t1.id_client = ? AND t1.id_name = ? and t2.tags_nom is not null
			   GROUP BY t2.tags_nom
			   ORDER BY t2.tags_nom';
	my $array_of_documents_tags;
	my @bind_array_1 = ($r->pnotes('session')->{id_client},  $args->{id_name});
	eval { $array_of_documents_tags = $dbh->selectall_arrayref($sql, { Slice => {} }, @bind_array_1) };
	my $add_tag_href = '';
	if (defined $args->{ajouter_tag} && $args->{ajouter_tag} eq 0) {
		$add_tag_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='. ($array_of_documents->[0]->{id_name} || '') .'' ;
	} else {
		$add_tag_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='. ($array_of_documents->[0]->{id_name} || '') .'&amp;ajouter_tag=0' ;
	}
	my $tag_list .= '<div class="tag-list">
	<span class="tag-item2"><a class="men men1" href="' . $add_tag_href . '">Ajouter un #Tag</a></span>' ;
	if ( @{$array_of_documents_tags}) {
		for ( @{$array_of_documents_tags} ) {
			my $categorie_href= '/'.$r->pnotes('session')->{racine}.'/docs?tags=' . URI::Escape::uri_escape_utf8( $_->{tags_nom}  ) ;
			my $delete_href = '/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='. ($array_of_documents->[0]->{id_name} || '') .'&amp;supprimer_tag=0&amp;tags_nom=' . URI::Escape::uri_escape_utf8( $_->{tags_nom}  ) ;
			$tag_list .= '
				<span class="tag-item">
					<a class="men men2" href="' . $categorie_href . '">' . $_->{tags_nom} . '</a>
					<a class="delete-tag" href="' . $delete_href . '" title="Supprimer le Tag ' . $_->{tags_nom} . '">Supprimer</a>
				</span>';
		}
	}
	$tag_list .= '</div>';
	
	$fiche_client .= '
	<form class=wrapper10 method="post" action=/'.$r->pnotes('session')->{racine}.'/docsentry>
	
	<div class=formflexN2>
		<label style="width: 3%;" class="forms2_label" for="check_banque">OK</label>
		<label style="width: 6.5%;" class="forms2_label" for="date_reception">Date</label>
		<label style="width: 36%;" class="forms2_label" for="new_id_name">Nom</label>
		<label style="width: 12%;" class="forms2_label" for="libelle">Catégorie</label>
		<label style="width: 6.5%;" class="forms2_label" for="montant">Montant</label>
		<label style="width: 14%;" class="forms2_label" for="compte_comptant">Compte</label>
		<label style="width: 3%;" class="forms2_label" for="multi">Multi</label>
		'.$display_label_exercice.'
	</div>
	
	<div class=formflexN2>
        <input class="forms2_input" style="width: 3%; height: 4ch; " type="checkbox" id="check_banque" name="check_banque" value="1" '.$check_value.' '.$disabled_link.'>
    	<input class="forms2_input" style="width: 6.5%;" type="text" id=date_reception name=date_reception value="' . ($array_of_documents->[0]->{date_reception} || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" '.$readonly_link.' />
		<input class="forms2_input" style="width: 36%;" type=text id=new_id_name name=new_id_name value="' . ($array_of_documents->[0]->{id_name} || '') . '" '.$readonly_link.' />
		' . $categorie_select . '
        <input class="forms2_input" style="width: 6.5%;" type=text id=montant name=montant value="' . $montant . '" onchange="format_number(this);" '.$readonly_link.'/>
		' .  $compte_comptant . '
        <input class="forms2_input" style="width: 3%; height: 4ch; " type="checkbox" id="multi" name="multi" value="1" '.$check_value_multi.' '.$disabled_link2.'>
		'.$display_last_exercice.'
    </div>
            
	<div class=formflexN3>
		<input type="submit" id=submit class="btn btn-vert" style="width: 15%;" formaction="' . $valid_href . '" value="Valider">
		'.$submit_delete.'
		'.$submit_rename.'
	</div>
		
    <input type=hidden name=old_id_name value="'. ($array_of_documents->[0]->{id_name}  || '').'" >
    <input type=hidden name=fiscal_year value="'. ($array_of_documents->[0]->{fiscal_year}  || '').'" >
    <input type=hidden name="old_multi" value="' . ($array_of_documents->[0]->{multi}  || ''). '">
    <input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value="' . ($args->{label2} || ''). '">
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label8" value="' . ($args->{label8} || ''). '">
	<input type=hidden name="label9" value="' . ($args->{label9} || ''). '">
	<input type=hidden name="label10" value="' . ($args->{label10} || ''). '">
	<input type=hidden name="label11" value="' . ($args->{label11} || ''). '">
   
    <br>
    '.$message_exercice_cloture.' 
	</form> 
	'.$tag_list.'
	' ;	

    #####################################       
	#Affichage des références comptables
	#####################################   
    
    my $disp_ndf = Base::Site::util::disp_lien_tag($args, $dbh, $r);

 	#ligne d'en-têtes
    my $entry_list .= '
    <div class=Titre10>Référence</div>
	'.$disp_ndf.'
	<br>
    <ul class="wrapper style1">
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=headerspan style="width: 7.5%;">Date</span>
	<span class=headerspan style="width: 7.5%;">Journal</span>
	<span class=headerspan style="width: 7.5%;">Libre</span>
	<span class=headerspan style="width: 7.5%;">Compte</span>
	<span class=headerspan style="width: 11.5%;">Pièce</span>
	<span class=headerspan style="width: 29.9%;">Libellé</span>
	<span class=headerspan style="width: 7.5%; text-align: right;">Débit</span>
	<span class=headerspan style="width: 7.5%; text-align: right;">Crédit</span>
	<span class=headerspan style="width: 7%;">Pointage</span>
	<span class=headerspan style="width: 2%; text-align: center;">&nbsp;</span>
	<span class=headerspan style="width: 2%; text-align: center;">&nbsp;</span>
	<span class=headerspan style="width: 2%; text-align: center;">&nbsp;</span>
	<div class=spacer></div></div></li>' ;

	my $id_entry = '' ;
	
	if ($docs_count != '0') {
    
		for ( @$result_set ) {

			#si on est dans une nouvelle entrée, clore la précédente et ouvrir la suivante
			unless ($_->{id_entry} eq $id_entry ) {

				#lien de modification de l'entrée
				my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry}.'&amp;docs='.$array_of_documents->[0]->{id_name} ;

				#cas particulier de la première entrée de la liste : pas de liste précédente
				unless ( $id_entry ) {
					$entry_list .= '<li class=listitem3>' ;
				} else {
					$entry_list .= '</a></li><li class=listitem3>'
				} #	    unless ( $id_entry ) 

			} #	unless ( $_->{id_entry} eq $id_entry )

			#marquer l'entrée en cours
			$id_entry = $_->{id_entry} ;
			
			#pour le journal général, ajouter la colonne libelle_journal
			#my $libelle_journal = ( $args->{open_journal} eq 'Journal général' ) ? '<span class=blockspan style="width: 25ch;">' . $_->{libelle_journal} . '</span>' : '' ;

			my $http_link_documents1 = '';
			my $http_link_documents2 = '';
			if ( $_->{documents1} =~ /docx|odt|pdf|jpg/) { 
				my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
				my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents1} ) ;
				if ($id_name_documents->[0]->{id_name} || '') {
					$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img class=redimmage style="border: 0;" src="/Compta/style/icons/documents.png" alt="documents"></a>' ;
				} else {
					$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
				} 
			} 	
					 
			if ( $_->{documents2} =~ /docx|odt|pdf|jpg/) { 
				my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
				my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents2} ) ;
				if ($id_name_documents->[0]->{id_name} || '') {
					$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img class=redimmage style="border: 0;" src="/Compta/style/icons/releve-bancaire.png" alt="releve-bancaire"></a>' ;	
				} else {
					$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
				} 
			} 	
			
			#lien de modification de l'entrée
			my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry}.'&amp;docs='.$array_of_documents->[0]->{id_name} ;

			my $lettrage_pointage = '&nbsp;' ;
			
			if ($_->{numero_compte} eq ($array_of_documents->[0]->{id_compte} || '')) {
				$pointage_base = '<input type=checkbox id=id value=value style="vertical-align: middle;" onchange="location.reload()" onclick="pointage(this, \'' . ($_->{numero_compte} || '&nbsp;'). '\')">' ;
				$lettrage_base = '<input type=text id=id style="margin-left: 0.5em; padding: 0; width: 7ch; height: 1em; text-align: right;" value=value placeholder=&rarr; oninput="lettrage(this, \'' . ($_->{numero_compte} || '&nbsp;') . '\')">' ;
				
				#l'id_line de la checkox de pointage commence par pointage_ pour être différente de id_line sur l'input de lettrage
				my $pointage_id = 'id=pointage_' . $_->{id_line} ;
				( $pointage_input = $pointage_base ) =~ s/id=id/$pointage_id/ ;
				my $pointage_value = ( $_->{pointage} eq 't' ) ? 'checked' : '' ;
				$pointage_input =~ s/value=value/$pointage_value/ ;
				
				$sql = 'SELECT id_client FROM tbllocked_month 
				WHERE id_client = ? and ( id_month = to_char(?::date, \'MM\') ) AND fiscal_year = ?';
				@bind_array = ( $r->pnotes('session')->{id_client}, $_->{date_ecriture}, $r->pnotes('session')->{fiscal_year}) ;
				my $result_block = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
				
				#Modifier le pointage que si le mois n'est pas bloqué
				if (defined $result_block && $result_block eq $r->pnotes('session')->{id_client}) {
				$lettrage_pointage = ( $_->{pointage} eq 't' ) ? '<img class="redimmage nav" title="Check complet" src="/Compta/style/icons/icone-valider.png" alt="valide">' : '&nbsp;' ;
				} else {
				$lettrage_pointage = $pointage_input ;
				}
				
				my $lettrage_id = 'id=' . $_->{id_line} ;
				( $lettrage_input = $lettrage_base ) =~ s/id=id/$lettrage_id/ ;
				my $lettrage_value = ( $_->{lettrage} ) ? 'value=' . $_->{lettrage} : '' ;
				$lettrage_input =~ s/value=value/$lettrage_value/ ;
				#$lettrage_pointage .= $lettrage_input ;
			}
		
			$entry_list .= '
			<div class=flex-table><div class=spacer></div><a href="' . $id_entry_href . '">
			<span class=displayspan style="width: 7.5%;">' . $_->{date_ecriture} . '</span>
			<span class=displayspan style="width: 7.5%;">' . $_->{libelle_journal} .'</span>
			<span class=displayspan style="width: 7.5%;">' . ($_->{id_paiement} || '&nbsp;') . '</span>
			<span class=displayspan style="width: 7.5%;" title="'. $_->{libelle_compte} .'">' . $_->{numero_compte} . '</span>
			<span class=displayspan style="width: 11.5%;">' . $_->{id_facture} . '</span>
			<span class=displayspan style="width: 29.9%;">' . $_->{libelle} . '</span>
			<span class=displayspan style="width: 7.5%; text-align: right;">' . $_->{debit} . '</span>
			<span class=displayspan style="width: 7.5%; text-align: right;">' .  $_->{credit} . '</span>
			</a>
			<span class=displayspan style="width: 5%;">' . $lettrage_pointage . '</span>
			<span style="width: 2%; margin-left : 1%;">' . ($http_link_documents1 || '<a><img class=redimmage style="border: 0;" src="/Compta/style/icons/vide.png" alt="" height="16" width="16"></a>' ) . '</span>
			<span style="width: 2%; margin-left : 0.5%;">' . ($http_link_documents2 || '<img class=redimmage style="border: 0;" src="/Compta/style/icons/vide.png" alt="" height="16" width="16">' ) . '</span>
			<div class=spacer></div></div>';
		} #    for ( @$result_set )
	}
	
    #on clot la liste s'il y avait au moins une entrée dans le journal
    $entry_list .= '</a></li>' if ( @$result_set ) ;

    $entry_list .=  '<li class=style1><hr></li>
    <li class=style1><div class=flex-table><div class=spacer></div>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 11.5%;">&nbsp;</span>
	<span class=displayspan style="width: 29.9%; text-align: right;">Total</span>
	<span class=displayspan style="width: 7.5%; text-align: right;">' . ( $result_set->[0]->{total_debit} || 0 ) . '</span>
	<span class=displayspan style="width: 7.5%; text-align: right;">' . ( $result_set->[0]->{total_credit} || 0 ) . '</span>
	<div class=spacer></div></li>' ;

	$sql = '
	SELECT t1.id_entry, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit
	FROM tbljournal t1
	WHERE pointage = \'t\' AND numero_compte = ? AND t1.id_client = ? AND t1.fiscal_year = ? AND (t1.documents1 = ? OR t1.documents2 = ?)
	' ;
	my @bind_array2 = ( $array_of_documents->[0]->{id_compte}, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $array_of_documents->[0]->{id_name}, $array_of_documents->[0]->{id_name} ) ;
	my $result_set512 = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array2 ) ;
 
    $entry_list .=  '<li class=style1><br></li>
    <li class=style1><div class=flex-table><div class=spacer></div>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 7.5%;">&nbsp;</span>
	<span class=displayspan style="width: 11.5%;">&nbsp;</span>
	<span class=displayspan style="width: 29.9%; text-align: right; font-weight: bold;">Total Pointé</span>
	<span class=displayspan style="width: 7.5%; text-align: right; font-weight: bold;">' . ( $result_set512->[0]->{total_debit} || 0 ) . '</span>
	<span class=displayspan style="width: 7.5%; text-align: right; font-weight: bold;">' . ( $result_set512->[0]->{total_credit} || 0 ) . '</span>
	</span><div class=spacer></div></li></ul>' ;

	#####################################       
	#Affichage du document
	#####################################    
    my $display_doc = '<div class=Titre10>Affichage du document</div>' ;
    
    #<span class="memoinfo">Mémo: Deux écritures compte vers 580 et 580 vers compte de destination</span>
    #<span class="memoinfo">Mémo: total débit du relevé = total credit du 512 et total crédit du relevé => total débit du 512</span>
		$display_doc .= '
		<br>
		<iframe src="/Compta/base/documents/' . $r->pnotes('session')->{id_client}.'/'.$array_of_documents->[0]->{fiscal_year} .'/'.$array_of_documents->[0]->{id_name}.'" width="1280" height="1280" style="border:1px solid #CCC; border-width:1px; margin-bottom:5px; max-width: 100%; " allowfullscreen> </iframe>
		' ; 	
	
	#id="pdf-js-viewer" src="/pdf/web/viewer.html?file=/Compta/base/documents/
	

	#passage de variable aus formulaires Base::Site::menu::forms_
	$args->{date_doc_entry} ||= $array_of_documents->[0]->{date_reception};
	$args->{montant_doc_entry} ||= $montant;
	$args->{docs_doc_entry} ||= $array_of_documents->[0]->{id_name};
	
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'docsentry.pm => date $array_of_documents->[0]->{montant}: '.$montant );

	my $forms_saisie_rapide .= '<fieldset class="pretty-box centrer">'.Base::Site::menu::forms_paiement_saisie( $r, $args, $dbh ).'</fieldset><br>';
	my $forms_search .= '<fieldset class="pretty-box centrer">'.Base::Site::menu::forms_search( $r, $args ).'</fieldset><br>';
	my $forms_ecri_rec .= '<fieldset class="pretty-box centrer">'.Base::Site::menu::forms_ecri_rec( $r, $args ).'</fieldset><br>';
	my $forms_importer .= '<fieldset class="pretty-box centrer">'.Base::Site::menu::forms_importer( $r, $args ).'</fieldset><br>';
	my $forms_tag .= '<fieldset class="pretty-box centrer">'.forms_tag( $r, $args ).'</fieldset><br>';
	
	if (defined $args->{label1} && $args->{label1} eq 1) {$dispcheck[1] = $entry_list;} else {$dispcheck[1] = '';}
	if (defined $args->{label2} && $args->{label2} eq 1) {$dispcheck[2] = $display_doc;} else {$dispcheck[2] = '';}
	#if (defined $args->{label3} && $args->{label3} eq 1) {$dispcheck[3] = $search_entry . $propo_list;} else {$dispcheck[3] = '';}
	if (defined $args->{label3} && $args->{label3} eq 1) {$dispcheck[3] = $forms_search;} else {$dispcheck[3] = '';}
	if (defined $args->{label4} && $args->{label4} eq 1 || defined $args->{saisie_rapide}) {$dispcheck[4] = $forms_saisie_rapide;} else {$dispcheck[4] = '';}
	if ((defined $args->{label10} && $args->{label10} eq 1) || defined $args->{ecriture_recurrente}) {$dispcheck[10] = $forms_ecri_rec;} else {$dispcheck[10] = '';}
	if ((defined $args->{label11} && $args->{label11} eq 1) || defined $args->{csv}) {$dispcheck[11] = $forms_importer;} else {$dispcheck[11] = '';}
	if ((defined $args->{label12} && $args->{label12} eq 1) || defined $args->{ajouter_tag}) {$dispcheck[12] = $forms_tag;} else {$dispcheck[12] = '';}
	
    $content .= '<div class="wrapper-docs-entry">' . $fiche_client . $dispcheck[12] . $dispcheck[3] . $dispcheck[10] . $dispcheck[11] . $dispcheck[4] . $dispcheck[1] .  $dispcheck[2] .'</div>' ;
 
    return $content ;
    
} #sub visualize 

#/*—————————————— Formulaire Ajout de Tag ——————————————*/
sub forms_tag {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, @errors) ;
	my ($content, $id_entry, $contenu_web_ecri_rec) = ('', '', '');
	my $reqid = Base::Site::util::generate_reqline();
	my $confirm_add_href = 'docsentry?id_name=' . $args->{id_name} . '' ;

	# Formulaire de génération des écritures récurrentes 	
	my $tag_list = '
    <div class=centrer>
        <div class=Titre10>Ajouter un nouveau tag</div>
		<form method=POST action=/'.$r->pnotes('session')->{racine}.'/'.$confirm_add_href.'>
		<div class="respform" style="justify-content: center;">
			<div class="flex-25"><input class="respinput" type=text placeholder="Entrer ou sélectionner le nom du tag" name="tags_nom" value="" required onclick="liste_search_tag(this.value)" list="taglist"><datalist id="taglist"></datalist></span></div>
			<input type=hidden name="add_tag" value=1>
			<div class="flex-21"><input type=submit class="respbtn btn-vert" value=Ajouter ></div>
		</div>
		</form>
	</div>
    ' ;
		
	$content .= ($tag_list || '') ;

	return $content ;

}#sub forms_tag 

1 ;
