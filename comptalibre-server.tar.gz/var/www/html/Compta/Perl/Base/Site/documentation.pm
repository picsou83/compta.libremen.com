package Base::Site::documentation;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Apache2::URI ();
use utf8 ;
use Apache2::Const -compile => qw( OK REDIRECT ) ;

sub handler {

    binmode(STDOUT, ":utf8") ;
    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content ;
	my $req = Apache2::Request->new( $r ) ;

    #récupérer les arguments
    my (%args, @args) ;

    #recherche des paramètres de la requête
    @args = $req->param ;

    for ( @args ) {

	$args{ $_ } = Encode::decode_utf8( $req->param($_) ) ;

	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;

    }
    
    if ( defined $args{menu1} ) {

	    $content = menu1( $r, \%args ) ;

	} elsif ( defined $args{menu2}) {

	    $content = menu2( $r, \%args ) ;

	} elsif ( defined $args{menu3}) {

	    $content = menu3( $r, \%args ) ;
	
	} elsif ( defined $args{menu4}) {

	    $content = menu4( $r, \%args ) ;
	    
	} elsif ( defined $args{menu5}) {

	    $content = menu5( $r, \%args ) ;
	    
	} else {
		$content = menu1( $r, \%args ) ;
	}

  
   
    $r->no_cache(1) ;
    
    $r->content_type('text/html; charset=utf-8') ;

    print $content ;

    return Apache2::Const::OK ;

}


sub menu1 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   #$content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########
	
	#my $menu1 = (($r->args  =~ /top/ ) ? 'nav-link2' : 'nav-link' );
	# By <a href='#' class='post-author'>Tilo Mitra</a> under 
	#onclick='myFunctionchildren(event)'
	#<a href='#'><div class='tag_name blue'>Salary &amp; Benefit</div></a>
	#<p class='hashtag'>#webdevelopment #frontend</p> 
	#	<a class='post-category post-category-design' href='#'>Premiers pas</a> <a class='post-category post-category-pure' href='#'>Pure</a>
  	#définition des variables

	my @hidden = ('0') x 40;
	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/documentation"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/documentation?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/documentation?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/documentation?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/documentation?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/documentation?cat5=1"> '; 
 
	
	#checked par défault label1 et 2
    unless (defined $args->{cat1} || defined $args->{cat2} || defined $args->{cat3} || defined $args->{cat4} || defined $args->{cat5}) {$args->{cat1} = 1; $args->{cat2} = 1; $args->{cat3} = 1; $args->{cat4} = 1; $args->{cat5} = 1;}

	

	$hidden[21] = "
		<div>
		<a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>
	";
	
	$hidden[22] = "
		<div>
		<a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>
	";
	
	$hidden[23] = "
		<div>
		<a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>
	";
	
	$hidden[24] = "
		<div>
		<a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>
	";
	
	$hidden[25] = "
		<div>
		<a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>
	";
	
	$hidden[20] = "

		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>
	";



	my $side_bar1 .= "
		<li class='titre-link'>Premiers pas</li>
  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#top\"' id='b_dashboard' name='menu' checked>
		<label class='menu-doc' for='b_dashboard'>Fonctionnement général</label><i id='1' class='fa fa-th-large' aria-hidden='true'>
		</i></span></li>

		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#journaux\"' id='b_journaux' name='menu'>
		<label class='menu-doc' for='b_journaux'>Journaux</label><i class='fa fa-envelope' aria-hidden='true'>
		</i></span></li>
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#comptes\"' id='b_comptes' name='menu'>
		<label class='menu-doc' for='b_comptes'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Comptes</label></span></li>
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#format\"' id='b_format' name='menu'>
		<label class='menu-doc' for='b_format'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Format des dates d'écriture</label></span></li>
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#lettrage\"' id='b_lettrage' name='menu'>
		<label class='menu-doc' for='b_lettrage'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Lettrage et Pointage</label></span></li>
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#parametres\"' id='b_parametres' name='menu'>
		<label class='menu-doc' for='b_parametres'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Paramètres</label></span></li>      

		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#raccourcis_clavier\"' id='b_raccourcis_clavier' name='menu'>
		<label class='menu-doc' for='b_raccourcis_clavier'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Raccourcis clavier</label></span></li>  

		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#tva\"' id='b_tva' name='menu'>
		<label class='menu-doc' for='b_tva'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Déclaration de TVA</label></span></li>  
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#liasse_fiscale\"' id='b_liasse' name='menu'>
		<label class='menu-doc' for='b_liasse'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Liasse fiscale</label></span></li>   
		 
		 ";
  
  #Courant
   my $side_bar2 .= "
   <li class='titre-link' >Courant</li>
  
		<li><span class='nav-link courant'><input type='radio' onClick='location.href=\"#paiementcheque\"' id='b_pcheque' name='menu'>
		<label class='menu-doc' for='b_pcheque'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Paiement Chèque</label></span></li> 
		
		<li><span class='nav-link courant'><input type='radio' onClick='location.href=\"#paiementespece\"' id='b_pespece' name='menu'>
		<label class='menu-doc' for='b_pespece'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Paiement Espèce</label></span></li> 
		
		<li><span class='nav-link courant'><input type='radio' onClick='location.href=\"#ecarts\"' id='b_ecarts' name='menu'>
		<label class='menu-doc' for='b_ecarts'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Ecarts de règlement</label></span></li> 
  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#travaux_periodiques\"' id='b_traperio' name='menu'>
		<label class='menu-doc' for='b_traperio'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Travaux periodiques</label></span></li> 
   ";
   
   #Utilitaires
   my $side_bar3 .= "
   <li class='titre-link'>Utilitaires</li>        
  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#exportations\"' id='b_export' name='menu'>
		<label class='menu-doc' for='b_export'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Exportations</label></span></li> 
                        
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#importations\"' id='b_import' name='menu'>
		<label class='menu-doc' for='b_import'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Importations</label></span></li> 
   ";
   
      #Utilitaires Fin d'exercice
   my $side_bar4 .= "
   <li class='titre-link'>Fin d'exercice</li> 
  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#calcul_du_bilan\"' id='b_calcul_du_bilan' name='menu'>
		<label class='menu-doc' for='b_calcul_du_bilan'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Opérations de calcul du bilan</label></span></li>  
   
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#cloture\"' id='b_cloture' name='menu'>
		<label class='menu-doc' for='b_cloture'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Clôture</label></span></li>  
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#reports\"' id='b_reports' name='menu'>
		<label class='menu-doc' for='b_reports'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Reports à nouveaux</label></span></li>  
		  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#reconduite\"' id='b_reconduite' name='menu'>
		<label class='menu-doc' for='b_reconduite'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Reconduite du plan comptable</label></span></li>  
   ";
   
   #Utilitaires Fin d'exercice
   my $side_bar5 .= "
   <li class='titre-link'>Paramétrage</li> 
  
		<li><span class='nav-link'><input type='radio' onClick='location.href=\"#version\"' id='b_version' name='menu'>
		<label class='menu-doc' for='b_version'><i class='fa fa-envelope' aria-hidden='true'>
		</i>Gestion des versions</label></span></li>  
   ";
		
	if (defined $args->{cat1} && $args->{cat1} eq 1) {$hidden[11] = $side_bar1 } else {$hidden[11] = '';}
	if (defined $args->{cat2} && $args->{cat2} eq 1) {$hidden[12] = $side_bar2 } else {$hidden[12] = '';}
	if (defined $args->{cat3} && $args->{cat3} eq 1) {$hidden[13] = $side_bar3 } else {$hidden[13] = '';}
	if (defined $args->{cat4} && $args->{cat4} eq 1) {$hidden[14] = $side_bar4 } else {$hidden[14] = '';}
	if (defined $args->{cat5} && $args->{cat5} eq 1) {$hidden[15] = $side_bar5 } else {$hidden[15] = '';}
  
	my $side_bar .= "
        
    <div class='sidebar'><nav class='docs-sidebar'><ul class='nav' style='padding: 0px; list-style-type: none;'>
	
	".$hidden[11]."
    ".$hidden[12]."
    ".$hidden[13]."
    ".$hidden[14]."
    ".$hidden[15]."

	</nav></ul></nav></div>
        
    <main class='content' id='main-doc'>    
    
    <input style='position: sticky; top: 65px; background-color: #fff; width: 100%; '
	class='login-text' type='text' id='Search' onkeyup='searchFunction()'
	placeholder='Saisissez le terme de recherche..' title='Rechercher' autofocus>	
	
	<div style='position: sticky; top: 110px; background-color: #fff;     text-align: center; padding-top: 5px;
    padding-bottom: 1%;'>
	".$hidden[20]."
	
	<div class='posts'>
    
    <!-- A single blog post -->
    
        "; 
		

        
         
    #cat_1 premier pas
    my $cat_1 .= "
        
    <section id='introduction' class='main-section'>
		<header class='header'><h3>Fonctionnement général</h3></header><hr class='hrperso'>
			<p>
			compta.libremen.com est un outil d\'enregistrement et de restitution d\'écritures comptables. Son utilisation suppose que l\'utilisateur possède les connaissances minimales d\'un aide-comptable
			</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='journaux' class='main-section'>
			<header class='header'><h3>Journaux</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Toutes les écritures sont inscrites dans les journaux auxiliaires, en utilisant le lien 'Nouvelle entrée' en haut à gauche de chaque journal; le Journal Général est constitué de l'ensemble des écritures des journaux auxiliaires</p>
			<p>L'utilisateur peut créer autant de journaux qu'il le souhaite</p>
			<p>Les journaux de type 'Fournisseurs' et 'Ventes' offrent une fonction d'enregistrement automatique des paiements dans le journal de banque, avec reprise des dates, des libellés et des montants de débit/crédit inversés; pour cela, cliquer dans l'écriture et utiliser le lien 'Règlement' du formulaire de saisie . L'intitulé peut être raccourci en 'Fourn' (ex 'Fourn. Europe', 'Fourn. US'...), ou modifié en e.g. 'Ventes France', 'Ventes Export'</p>
			<p>Les écritures peuvent être déplacées d'un journal à un autre via le lien 'Déplacer' du formulaire de saisie; elles peuvent également être extournées via le lien 'Extourner' du même formulaire</p>
			<p>Seul le journal des OD est obligatoire et non modifiable</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='comptes' class='main-section'>
			<header class='header'><h3>Comptes</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>La liste des comptes peut être importée depuis un fichier texte contenant pour chaque ligne deux valeurs séparées par un point virgule (1ère valeur = numéro de compte, 2ème valeur = libellé du compte). <strong>Le fichier doit être encodé en UTF-8</strong>, sans en-tête. Exemple :</p>
			<pre>
			401PUBN;PUBLICATIONS
			401FDIV;F DIVERS
			401PAPE;PAPETERIE
			</pre>
			<p>Les comptes peuvent comporter autant de décimales que souhaité</p>
			<p>La liste peut être reconduite chaque année via le Menu Comptes -> Modifier la liste -> Reconduire (lien en haut de page); cette opération reconduit également les réglages du menu <a href=\"index.html#liasse_fiscale\">Liasse Fiscale</a> sur le nouvel exercice</p>
			<p>Les soldes des comptes de bilan sont reportables sur le nouvel exercice via le Menu Comptes -> Reports</p>
			<p>Balance et Grand Livre sont disponibles via les liens en haut de page</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
                
    </div>
            
	<section id='format' class='main-section'>
		<header class='header'><h3>Format des dates d'écriture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Il est possible de régler le format d'affichage des dates dans le menu 'Paramètres' ( AAAA-MM-JJ ou JJ/MM/AAAA)</p>
		<p>Pour la saisie, plusieurs formats et séparateurs sont acceptés : 2020-02-25 ou 25/02/2020 ou 25#02#2020 ou 2020 02 25. L'année doit être écrite sur 4 chiffres</p>
		<p>Voir les <a href=\"index.html#raccourcis_clavier\">raccourcis clavier</a> pour une saisie rapide</p>
		<p><strong>N.B.</strong>: il existe une séparation physique entre les exercices. Le changement d'exercice se fait en cliquant sur le titre 'Exercice XXXX', en haut de page. L'utilisateur peut travailler sur plusieurs onglets à la fois (en utilisant Click-droit ou Ctrl-Click) mais toujours dans le même exercice.<br>
		Si l'utilisateur souhaite travailler sur deux exercices différents en même temps, il doit utiliser deux navigateurs différents, un pour chaque exercice</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
  
	<section id='lettrage' class='main-section'>
		<header class='header'><h3>Lettrage et Pointage</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Tous les comptes peuvent être pointés, lettrés et rapprochés</p> 
		<div>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='parametres' class='main-section'>
		<header class='header'><h3>Paramètres</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Le calcul des numéros de pièces peut être formaté sur 2 à 5 décimales (A01, A001, ..., A00001)</p>
		<p>Il existe deux options de calcul de la TVA due : débits ou encaissements; voir le chapitre <a href=\"index.html#ca3\">Déclaration de TVA (formulaire CA3)</a>; la période de calcul peut être mensuelle ou trimestrielle</p>
		<p>L'option 'Journal de TVA' permet de sélectionner le journal d'enregistrement des écritures résultant du calcul de la TVA due</p>
		<p>L'option 'Activer les règlements par défaut' permet de sélectionner automatiquement le journal et le numéro de compte à utiliser pour l'enregistrement des règlements/paiements; les enregistrements des factures émises ou reçues sont reprises automatiquement, les montants des débits/crédits étant affectés au compte sélectionné</p>
		<p>Il existe deux options pour le format d'affichage des dates : le format classique (JJ/MM/AAAA) et le format ISO 8601 (AAAA-MM-JJ); le format est paramétrable pour chaque utilisateur du compte</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>	
  
 	<section id='raccourcis_clavier' class='main-section'>
		<header class='header'><h3>Raccourcis clavier du formulaire de saisie d'une écriture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<img src=\"/Compta/images/saisie.png\" alt=\"Formulaire de saisie d'une écriture\">
		<p>Date : il est possible de taper par exemple \"0225\" (JJMM, sans les guillemets); la date sera alors complétée avec l'année en cours et formatée pour obtenir 2020-02-25 ou 05/02/2020, suivant l'option d'affichage sélectionnée par l'utilisateur dans le menu 'Paramètres'</p>
		<p>Les cases au fond grisé reproduisent automatiquement la valeur de la ligne précédente</p>
		<p>Compte : taper les premiers chiffres pour obtenir une fenêtre déroulante affichant les comptes disponibles. Seuls les comptes enregistrés dans le menu 'Comptes' pour l'exercice en cours sont acceptés</p>
		<p>Pièce : le symbole '&rarr;' indique un calcul automatique du numéro; taper \"Espace\"; les factures fournisseurs sont au format \"MD...D\" où M est la lettre du mois (janvier = A, février = B...) et D...D le numéro de la pièce pour le mois (01, 02...); le numéro de pièce peut comporter jusqu'à 5 décimales (voir le menu 'Paramètres'). Pour les factures de ventes, le numéro est une séquence pluriannuelle continue qui ajoute 1 à la dernière valeur enregistrée</p>
		<p>Libellé : le symbole '&rarr;' indique une recopie automatique de la ligne précédente; taper \"Espace\"</p>
		<p>Les lignes dont le débit et le crédit valent O (zéro) sont ignorées lors de la validation</p>
		<p>Les signes '+' et '-' sur les côtés du formulaire permettent respectivement d'ajouter et de retirer une ligne</p>
	".$hidden[21]."
	".$hidden[20]."
	</section> 
  
	<section id='tva' class='main-section'>
		<header class='header'><h3>Déclaration de TVA (formulaire CA3)</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Dans le menu TVA, sélectionner la période à déclarer puis cliquer sur 'Valider'; le logiciel affiche alors une réplique partielle du formulaire 3310CA3 (visible sur impots.gouv.fr), avec un calcul des champs principaux à renseigner. <strong>Les périodes de déclaration correspondent à la période en cours et celles de l'année qui précède</strong>. Le formulaire ne peut donc pas être utilisé pour les dates antérieures de plus de 12 mois à la date du jour, mais il est possible d'enregistrer manuellement des écritures antérieures</p>
		<p>En cliquant sur 'Valider' en bas du formulaire, les écritures à passer sont affichées dans le formulaire de saisie d'une écriture et peuvent y être modifiées si besoin</p>
		<p>Le calcul de la TVA exigible est fait à partir des montants enregistrés dans les comptes de classe 7, pour lesquels on paramètre le pourcentage de TVA applicable. Ce calcul peut être fait sur les débits ou sur les encaissements</p>
		<p>Si l'option choisie est <strong>'TVA sur encaissements'</strong>, le logiciel calcule la TVA collectée sur la période à partir des comptes 7 qui sont lettrés et non pointés; il faut donc dans ce cas, pour obtenir une déclaration conforme :</p>
		<ul>
		<li>Lettrer les comptes clients après encaissement de la facture; le lettrage est enregistré dans la ligne des comptes 7 concernés par l'écriture lettrée</li>
		<li>Calculer la TVA due et enregistrer les écritures</li>
		<li>Pointer les écritures des comptes de classe 7 précédemment lettrées, pour qu'elles n'apparaissent plus dans les déclarations suivantes</li>
		</ul>
		<p>L'option <strong>'TVA sur débits'</strong> calcule la TVA due sur l'ensemble des factures enregistrées dans la période considérée<p>
		<p>Il est possible dans ce cas d'enregistrer des ventes de services (TVA exigible à l'encaissement), en utilisant des comptes d'attente :</p>
		<ul>
		<li>Créer un ou plusieurs compte 418 'Ventes non taxables', un compte 44578 'tva collectée non exigible', et un ou plusieurs comptes 7 paramétrés à 0% de TVA et terminés par '*'</li>
		<li>Enregistrer les ventes dans ces comptes</li>
		<li>Lors du règlement, extourner l'écriture initiale, puis enregistrer la vente dans les comptes 411, 4457 et les comptes de classe 7 normaux à la date du règlement</li>
		<li>Calculer la TVA due pour la période</li>
		</ul> 
	".$hidden[21]."
	".$hidden[20]."
	</section>  
  
  	<section id='liasse_fiscale' class='main-section'>
			<header class='header'><h3>Liasse fiscale</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Le menu \"Liasse fiscale\" est actuellement limité au calcul des lignes du document 2033-B Compte de résultats simplifié, formulaire Cerfa n°2</p>
			<p>Mode d'utilisation : <br>
		  Cliquer sur le lien 'Gérer' (en haut de page) permettant de régler les cases du formulaire que l'on souhaite calculer. Dans cette page, utiliser le formulaire 'Ajouter une case' pour taper les numéros des cases. Attention de sélectionner la valeur appropriée pour 'Charges' ou 'Produits'<br>
		  Pour chacune de ces cases, ajouter les comptes à inclure dans le calcul avec le formulaire 'Ajouter un compte' accolé à chaque numéro de case<br>
		  La liste située en bas de la page affiche les comptes qui n'ont pas été inclus dans les calculs, ainsi que leur solde<br>
		  Les réglages du calcul sont reportés automatiquement dans l'exercice suivant, lorsque l'utilisateur reconduit les comptes de l'année précédente dans le menu Comptes -> Modifier la liste -> Reconduire <i>exercice précédent</i>
			</p> 
	".$hidden[21]."
	".$hidden[20]."
	</section>
        
        
        ";
        
                
		
	#cat_2 Courant section paiementcheque
	my $cat_2 .= "
	<section id='paiementcheque' class='main-section'>
	<header class='header'><h3>Paiement Chèque</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
	<details class=warningdoc open><summary ><h3>Comptabilisation en tant que vendeur => Réglement du client par chèque</h3></summary>
	<hr class=mainPageTutoriel>
	<p class=classp>Cas avec utilisation directe du compte 512 banque</p>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'>Montant chèque</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant chèque</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas avec utilisation du compte intermédiaire 5112 chèques à encaisser</p>
	
	<p>D’abord : À chaque fois que l’entreprise réceptionne le chèque d’un client</p>
		
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD (ou de chèque à encaisser) / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>5112</div>
		  <div class='cell' data-title='Intitulé'>Chèque à encaisser</div>
		  <div class='cell' data-title='Libellé'>N° du chèque de client</div>
		  <div class='cell' data-title='Débit'>Montant chèque</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>N° du chèque de client</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant chèque</div>
		</div>
	</div></div>

	<p>Ensuite : Lors de la remise en banque d’un ensemble de chèques reçus des clients</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de remise des chèques</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'>Total remise</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>5112</div>
		  <div class='cell' data-title='Intitulé'>Chèques à encaisser</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Total remise</div>
		</div>
	</div></div><hr class=mainPageTutoriel>
	
	</details>
	
	<details class=alerte open><summary ><h3>Comptabilisation en tant qu'acheteur => Réglement au fournisseur par chèque</h3></summary>
	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° de chèque</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de chèque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	
		
	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

		";
		
	#cat_2 Courant section paiementespece DEBUT
	$cat_2 .= "
	<section id='paiementespece' class='main-section'>
	<header class='header'><h3>Paiement Espèce</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
	<details class=warningdoc open><summary ><h3>Comptabilisation en tant que vendeur => Réglement du client en espèce</h3></summary>
	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de caisse</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>530</div>
		  <div class='cell' data-title='Intitulé'>Caisse</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details class=alerte open><summary ><h3>Comptabilisation en tant qu'acheteur => Réglement au fournisseur en espèce</h3></summary>
	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de caisse</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>530</div>
		  <div class='cell' data-title='Intitulé'>Caisse</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

	";	#cat_2 Courant section paiementespece FIN
		
	

	
		#cat_2 Courant section ecarts de reglement DEBUT
	$cat_2 .= "
	<section id='ecarts' class='main-section'>
	<header class='header'><h3>Ecarts de règlement</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
	<details class=warningdoc open><summary ><h3>Ecarts de règlement positifs</h3></summary>
	<hr class=mainPageTutoriel>
	<p>
	La différence de règlement, lorsqu’elle est en faveur de l’entreprise, est dite positive. Il pourra s’agir des cas suivants :
	<p> une entreprise reçoit sur son compte bancaire une somme plus importante de la part de son client</p>	
	<p> une entreprise paie à son fournisseur un montant moindre que celui figurant sur la facture</p>	
	<p> une entreprise s’acquitte de ses cotisations sociales pour une somme légèrement inférieure à celle figurant dans ses comptes (de
l’ordre de quelques centimes).</p>	
	</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401/411</div>
		  <div class='cell' data-title='Intitulé'>Fournisseurs/Clients</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'>écart</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>758</div>
		  <div class='cell' data-title='Intitulé'>Produits divers gestion courante</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>écart</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details class=alerte open><summary ><h3>Ecarts de règlement négatifs</h3></summary>
	<hr class=mainPageTutoriel>
	<p>
	A l’inverse, lorsque les différences de règlement sont en la défaveur de l’entreprise, ils sont négatifs. Il s’agit principalement des cas
suivants :
<p>une entreprise perçoit de la part de son client une somme moindre que celle figurant sur la facture de vente,</p>
<p>une entreprise règle une somme plus importante à son fournisseur que celui figurant sur la facture d’achat,</p>
<p>une entreprise s’acquitte de ses cotisations sociales pour une somme légèrement supérieure à celle figurant dans ses comptes.</p>
	</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>658</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'>écart</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401/411</div>
		  <div class='cell' data-title='Intitulé'>Fournisseurs/Clients</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>écart</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

	";	#cat_2 Courant section ecarts de reglement FIN
	
	#cat_2 Courant Section travaux_periodiques
	$cat_2 .= "
		<section id='travaux_periodiques' class='main-section'>
		<header class='header'><h3>Travaux periodiques</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Voici la check-list des tâches à faire tous les mois</p>
		  <ul class=checklist>
		  <li>Saisir les pièces comptables</li>
		  <li>Saisir les opérations de banque</li>
		  <li>Lettrer les comptes clients</li>
		  <li>Lettrer les comptes de tiers</li>
		  <li>Lettrer les comptes 467 débiteurs/créditeurs</li>
		  <li>Vérifier le solde du compte 471 qui doit être à 0 €</li>
		  <li>Vérifier le solde du compte 580 qui doit être à 0 €</li>
		  <li>Faire le rapprochement bancaire</li>
		</ul>
	".$hidden[22]."
	".$hidden[20]."
	</section>	
	";	
		
		#cat_3 Utilitaires
		my $cat_3 .= "
		
		
  	<section id='exportations' class='main-section'>
    <header class='header'><h3>Exportations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>Le menu 'Export' permet d'exporter et d'archiver les écritures enregistrées dans la base</p>
	<h4>Options d'exportation</h4>
	<ul>
  <li>liste des comptes</li>
  <li>Fichier d'exportation FEC conforme aux dispositions prévues à l'article A47 A-1 du livre des procédures fiscales contenant toutes les écritures enregistrées dans l'exercice</li>
  <li>Ensemble des données enregistrées dans la base pour l'exercice (le format 'Données')</li>
  <li>Écritures archivées</li>
	</ul>
	<p>Il existe deux types d'archivage : mensuel et incrémentiel<br>
  <strong>L'archivage mensuel</strong> permet d'archiver un mois de l'exercice. Après archivage, il n'est plus possible d'ajouter, modifier ou supprimer des écritures pour ce mois. Les écritures d'un mois archivé peuvent être téléchargées au format FEC ou au format 'Données', qui contient toutes les données enregistrées dans le logiciel. On clique sur le numéro du mois pour déclencher l'archivage.<br>
  <strong>L'archivage incrémentiel</strong> permet d'archiver toutes les écritures non encore enregistrées, sans considération de date. Les écritures archivées incrémentiellement ne peuvent plus être modifiées ni supprimées, mais il est possible d'ajouter de nouvelles écritures.<br>
  Les deux modes d'archivage peuvent être utilisés ensemble ou séparément</p>
	<p>Exemple de fichier d'exportation tel qu'il apparaît dans un tableur :</p>
	<table style=\"text-align: left; border: thin solid #444;\">
  <tr><th>id_entry</th><th> date</th><th>numéro de pièce</th><th>libellé</th><th>débit</th><th>crédit</th><th> libre</th><th>numéro de compte</th><th>exercice</th><th>journal</th><th>lettrage</th><th>pointage</th><th> date_validation</th></tr>
  <tr><td>11114</td><td>2016-01-01</td><td>A03</td><td>SNCF paris</td><td style=\"text-align: right;\">        84,00</td><td style=\"text-align: right;\">         0,00</td><td>A51</td><td>401SNCF</td><td>2016</td><td>Banque</td><td>a</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>11114</td><td>2016-01-01</td><td>A03</td><td>SNCF paris</td><td style=\"text-align: right;\">         0,00</td><td style=\"text-align: right;\">        84,00</td><td>A51</td><td>5121CRA</td><td>2016</td><td>Banque</td><td>a</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         9,99</td><td style=\"text-align: right;\">         0,00</td><td></td><td>611010</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         0,00</td><td style=\"text-align: right;\">        11,99</td><td></td><td>401SERV</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         2,00</td><td style=\"text-align: right;\">         0,00</td><td></td><td>4456600</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
	</table>
	".$hidden[23]."
	".$hidden[20]."
	</section>
  
  	<section id='importations' class='main-section'>
			<header class='header'><h3>Importations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Il est possible d'importer des écritures dans l'exercice en cours à partir du Journal Général (lien 'Importer des écritures', en haut de page).<strong> Le fichier à fournir doit être encodé au format UTF-8</strong>, sans en-tête, et se conformer au format ci-dessous. Les champs obligatoires sont précédés d'une étoile (*). Séparateurs de champs : \";\" (point-virgule)</p>
			<p>L'importation des écritures est totale, si aucune erreur n'est détectée. Sinon, aucune écriture n'est importée, et un message d'erreur affiche la liste des écritures empêchant l'importation</p>
			<p>Les écritures doivent être équilibrées par date, numéro de pièce et libellé</p>
			<table style=\"text-align: left; border: thin solid #444;\">
		  <tr><th></th><th>Nom du champ</th><th>Type de données</th><th>Remarques</th></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Journal</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\">le journal doit être présent dans l'exercice d'importation</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Date d'écriture</td><td style=\"border-bottom: 1px solid black;\">Date</td><td style=\"border-bottom: 1px solid black;\">Plusieurs formats et séparateurs sont acceptés : 2020-02-25 ou 25/02/2020 ou 25#02#2020 ou 2020 02 25</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Libre</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Numéro de compte</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\">Le numéro de compte doit être présent dans la liste des comptes de l'exercice d'importation</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Numéro de pièce</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Libellé</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Débit</td><td style=\"border-bottom: 1px solid black;\">Numérique</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Crédit</td><td style=\"border-bottom: 1px solid black;\">Numérique</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Lettrage</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Pointage</td><td style=\"border-bottom: 1px solid black;\">Booléen</td><td style=\"border-bottom: 1px solid black;\">2 valeurs possibles : (t)rue or (f)alse. En l'absence de données, la valeur enregistrée est 'False', non pointé</td></tr>
			</table>
	".$hidden[23]."
	".$hidden[20]."
		</section>
		
		
		";
		
		
		my $cat_4 .= "
		";
		
		my $cat_5 .= "
		";
		
		my $contenu_web .= "
		






                
       
  
  
  
 	<section id='calcul_du_bilan' class='main-section'>
    <header class='header'><h3>Opérations de calcul du bilan</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>Préparer le calcul des cases à renseigner dans le formulaire 2033 B (Cerfa 2) :<br>
  -Voir le chapitre <a href=\"#liasse_fiscale\">Liasse fiscale</a>
	</p>
	<p>Avant calcul de résultat :<br>
  -Enlever les rompus<br>
  -Imprimer la page 'Liasse fiscale'<br>
  -Afficher la balance, l'imprimer et/ou l'exporter (lien 'Télécharger' à côté du bouton valider)<br>
  -Imprimer le Grand Livre (lien 'Grand Livre' en haut de la page 'Comptes'); passer en mode paysage pour afficher toutes les colonnes<br>
	</p>
	<p>Calcul du résultat :<br>
  -Cliquer dans Compte -> <a href=\"#cloture\">Clôture</a> (lien en haut à droite de la page)
	</p>
	<p>Après calcul du résultat :<br>
  -Éditer la nouvelle balance (les comptes 6 et 7 sont soldés)<br>
  -Reporter les soldes sur les documents Cerfa A et B
	</p>
	".$hidden[24]."
	".$hidden[20]."
		</section> 
  
  
  	<section id='cloture' class='main-section'>
    <header class='header'><h3>Clôture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>La clôture des comptes (lien 'Clôture' dans le menu 'Comptes', en haut de page) solde les comptes de classe 6 et 7, calcule le résultat et l'inscrit au débit ou au crédit du compte de résultat (12000[0...]). Les opérations effectuées sont d'abord affichées dans le formulaire de saisie d'une écriture pour validation. Si le compte 12000 n'existe pas, le créer, ou bien modifier la dernière ligne du formulaire de validation pour servir le compte souhaité</p>
	<p>L'opération est réversible par suppression de l'OD enregistrée, si les comptes n'ont pas été archivés (voir le chapitre <a href=\'index.html#export\'>Exportations</a>)</p>
	".$hidden[24]."
	".$hidden[20]."
		</section>
  
    <section id='reports' class='main-section'>
    <header class='header'><h3>Reports à nouveaux</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>Les reports à nouveaux des soldes de l'année N - 1 sont générés en début d'année N à partir du menu Comptes, lien 'Reports' en haut de page</p>
	".$hidden[24]."
	".$hidden[20]."
		</section>
 	
	
	
	
	
	
	<section id='reconduite' class='main-section'>
    <header class='header'><h3>Reconduite du plan comptable</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>
  En début d'un nouvel exercice, pour reprendre le plan comptable de l'année précédente :<br>
  -Dans Journaux -> Modifier la liste, cliquer sur 'Reconduire <i>exercice précédent</i>'<br>
  -Dans Comptes -> Modifier la liste, cliquer sur 'Reconduire <i>exercice précédent</i>'<br>
  -Cliquer dans Comptes -> Reports (lien en haut à droite) pour reporter les soldes de l'exercice précédent
	</p> 
	".$hidden[24]."
	".$hidden[20]."
		</section>
	
	
	<section id='version' class='main-section'>
    <header class='header'><h3>Gestion des versions</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
  <section id='timeline' class='timeline-outer'>
    
   
      <div class='row'>
        <div class='col s12 m12 l12'>
          <ul class='timeline'>
            
            <li class='event' data-date='2015/Present'>
				<h3>Juin 2021 Version 1.1</h3>
              <p>
                This September 2015 I will begin an MSc in Management and Entrepreneurship at University of Sussex, to broaden my knowledge and gain skills necessary for my future in business and management.
              </p>
            </li>
           
            
            
            <li class='event' data-date='2010/2012'>
            <h3>Mars 2021 Version 1.0</h3>
            <p>This is where my interest in building things for interactive media began. During my first computing course I studied a range of core topics including multimedia design, database design, computer games development, computer networks and object
                oriented programming.</p>
            </li>
            
          </ul>
        </div>
      </div>
    
  </section>

	</section>
  
  



  
</main>


		";
		

	if (defined $args->{cat1} && $args->{cat1} eq 1) {$hidden[1] = $cat_1} else {$hidden[1] = '';}
	if (defined $args->{cat2} && $args->{cat2} eq 1) {$hidden[2] = $cat_2} else {$hidden[2] = '';}
	if (defined $args->{cat3} && $args->{cat3} eq 1) {$hidden[3] = $cat_3} else {$hidden[3] = '';}
	if (defined $args->{cat4} && $args->{cat4} eq 1) {$hidden[4] = $cat_4} else {$hidden[4] = '';}
	if (defined $args->{cat5} && $args->{cat5} eq 1) {$hidden[5] = $cat_5} else {$hidden[5] = '';}
		
		
	$content .= '<div class="wrapperfaq">' . $side_bar . $hidden[1] . $hidden[2] . $hidden[3] . $hidden[4] . $hidden[5] . $contenu_web . '</div>' ;
		
    return $content ;
    
    
} #sub menu1 

sub menu2 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########
		
		my $contenu_web .= '
	
		';
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;
    
} #sub menu2 

sub menu3 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########


		my $contenu_web .= '
	
		';
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;
    
} #sub menu3 

sub menu4 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########

		my $contenu_web .= '

      ';
      
     
		
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;
    
} #sub menu4 

sub menu5 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########


		my $contenu_web .= "

		";
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;

    
} #sub menu5 




sub display_menu {

    my ( $r, $args ) = @_ ;
    
   unless ( defined $args->{menu2} || defined $args->{menu3} || defined $args->{menu4} || defined $args->{menu5} ) {
	   $args->{menu1} = '' ;
    } 	
 	

    
#########################################	
#Filtrage du Menu - Début				#
#########################################		
	my $menu1_link = '<a class=' . ( (defined $args->{menu1} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu1" style="margin-left: 3ch;">Premiers pas</a>' ;
	my $menu2_link = '<a class=' . ( (defined $args->{menu2} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu2" style="margin-left: 3ch;">Courant</a>' ;
	my $menu3_link = '<a class=' . ( (defined $args->{menu3} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu3" style="margin-left: 3ch;">Utilitaires</a>' ;
	my $menu4_link = '<a class=' . ( (defined $args->{menu4} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu4" style="margin-left: 3ch;">Paramétrage</a>' ;
	my $menu5_link = '<a class=' . ( (defined $args->{menu5} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu5" style="margin-left: 3ch;">Fin d\'exercice</a>' ;
	my $content .= '<div class="menu"><li style="list-style: none; margin: 0;">' . $menu1_link . $menu2_link . $menu3_link . $menu4_link . $menu5_link .'</li></div>' ;

#########################################	
#Filtrage du Menu - Fin					#
#########################################
    
    return $content ;

} #sub display_menu_formulaire 

1 ;
