package Base::Site::formulaire;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use utf8 ;
use Apache2::Const -compile => qw( OK REDIRECT ) ;

sub formulaire2033_a {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array ) ;
    
    my $numero_compte ||= '0';
     
######## Affichage MENU display_compte_set Début ######
    my $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########

    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit, credit FROM tbljournal WHERE id_client = ? and fiscal_year = ?
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit, credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

#to_char(sum(credit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_credit
#to_char(sum(credit-debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_line), \'999G999G999G990D00\') as solde

    
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    # variable
	my ($total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP,
	$total,$numero_compte);
   
   
    for ( @$result_set ) {

		#AA	Débit de : 206 207
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{debit});$total_AA += $total;}
		#AB Débit de :	201	203	204	205	208	232	237
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{debit});$total_AB += $total;}
		#AC Débit de :	21 22 231 238
		if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{debit});$total_AC += $total;}
		#AD Débit de :	25 à 268 271 à 277 Moins le débit de : 259
		#AJ Solde débiteur de : 410 à 418
		if  (substr( $_->{numero_compte}, 0, 3 ) >= 410 && (substr( $_->{numero_compte}, 0, 3 ) <= 418)) 
		{(my $total = $_->{credit});(my $total2 = $_->{debit});$total_AJ += ($total2 - $total);}
		#AM Solde débiteur de : 511 à 517 5187 à 59
		if  (
		(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
		(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
		){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$total_AM += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}	
		#BC Crédit de : 281 291 282 292 2931
		if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/ ) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/ )) {(my $total = $_->{credit});$total_BC += $total;}
		#EE Solde créditeur de : 455
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /455/) {(my $total = $_->{credit});(my $total2 = $_->{debit});$total_EE += ($total - $total2);}
		#FA Solde créditeur de : 101 Crédit de : 108 Moins le solde débiteur de : 109
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /101|108/) {(my $total = $_->{credit});$total_FA += $total;}
		#FL Solde créditeur de :16 à 17 426 451 456 458 512 à 517 5181	5186 519 à 58
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17/) 
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /512|513|514|515|516|517|426|451|456|458/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 3 ) <= 580))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if ($_->{solde_crediteur} > 'O'){
		(my $total = $_->{solde_crediteur});$total_FL += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}
	    
		#FP Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 427) && (substr( $_->{numero_compte}, 0, 4 ) <= 4286))
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 431) && (substr( $_->{numero_compte}, 0, 4 ) <= 4386))
		||	((substr( $_->{numero_compte}, 0, 4 ) >= 4411) && (substr( $_->{numero_compte}, 0, 4 ) <= 4487))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		#$content .= 'total debit ' . $_->{numero_compte} . ' et ' . $_->{total_debit} . ' solde debiteur ' . $_->{numero_compte} . ' et ' . $_->{solde_debiteur}. ' solde crediteur' . $_->{numero_compte} . ' et ' . $_->{solde_crediteur};
		if ($_->{solde_crediteur} > 'O'){
		(my $total = $_->{solde_crediteur});$total_FP += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}


	
		} #  fin for ( @$result_set ) {

########## DEBUT AFFICHAGE VALUE SANS ARRONDIES ##########

		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP
		) {
		if ($value_numbers != ('0' || '')) {
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; ;
		
		#$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}

    
	$content .= '
	<a style="float:right;margin-top:12px" href="/assets/images/2021/2033-NOT-2021.pdf" target="_blank" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-paperclip"></i> Voir la notice 2033-NOT</a>
	<h3 class="page-subtitle">2033-A - Bilan simplifié</h3>
	<div class="modal fade" id="neant-confirmation-modal"><div class="modal-dialog"><div class="modal-content"><div class="modal-header">
	<div style="background-image: url(/Compta/images/2033A.png);width:960px; height:1323px;position:relative" class="cerfa-form">
	<div class="general-info" style="top:86px; left:188px">SCI PENCHENAT CANTAGREL - SIREN : 878523513</div>
	<div class="general-info" style="top:117px; left:296px">15</div>
	<div class="general-info" style="top:156px; left:844px">31/12/2020</div>
	<div name="AA" class="general-value" style="top: 211px; left: 501px; width: 142px; height: 28px;">'.$total_AA.'</div>
	<div name="AB" class="general-value" style="top:241px; left:501px;width:142px;height:28px">'.$total_AB.'</div>
	<div name="AC" class="general-value" style="top:272px; left:501px;width:142px;height:28px" >'.$total_AC.'</div>
	<div name="AD" class="general-value" style="top:302px; left:501px;width:142px;height:28px" >'.$total_AD.'</div>
	<div name="AJ" class="general-value" style="top:454px; left:501px;width:142px;height:28px" >'.$total_AJ.'</div>
	<div name="AM" class="general-value" style="top:545px; left:501px;width:142px;height:28px">'.$total_AM.'</div>
	<div name="BC" class="general-value" style="top:272px; left:671px;width:141px;height:28px" >'.$total_BC.'</div>
	<div name="EE" class="general-value"  style="top:1090px; left:671px;width:99px;height:29px" >'.$total_EE.'</div>
	<div name="FA" class="general-value"  style="top:696px; left:816px;width:141px;height:29px" >'.$total_FA.'</div>
	<div name="FL" class="general-value"  style="top:1000px; left:816px;width:141px;height:28px" >'.$total_FL.'</div>
	<div name="FP" class="general-value"  style="top:1091px; left:816px;width:141px;height:28px"  >'.$total_FP.'</div>
	<div name="JB" class="general-value"  title="Variation au crédit de :33C.BK" style="top:1242px; left:816px;width:141px;height:29px" ></div>
	';
	
########## FIN AFFICHAGE VALUE SANS ARRONDIES ##########



		
		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP
		) {
		if ($value_numbers != ('0' || '')) {
		#($numbers = sprintf( "%.2f",$numbers/100)) ;
		$value_numbers = int(($value_numbers)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}

		#Calcul des totaux
		my $total_AE = $total_AA + $total_AB + $total_AC + $total_AD ;
		my $total_AQ = $total_AJ + $total_AM ;
		my $total_BE = $total_BC;
		my $total_CC = $total_AC - $total_BC;
		my $total_CJ = $total_AJ;
		my $total_CM = $total_AM;
		my $total_CE = $total_AE - $total_BE;
		my $total_CQ = $total_AQ;
		my $total_AR = $total_AE + $total_AQ ;
		my $total_BR = $total_BE;
		my $total_CR = $total_AR - $total_BR; 
		my $total_FR = $total_FL + $total_FP ;
		my $total_FS = $total_FR;
		
		
		#Mise en forme affichage du total général
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		$total_AE,$total_AQ,$total_BE,$total_CC,$total_CJ,$total_CM,$total_CE,$total_CQ,$total_AR,$total_BR,$total_CR,$total_FR,$total_FS
		) {
		if ($total_numbers != ('0' || '')) {
		$total_numbers = int($total_numbers+ 0.5) ;
		$total_numbers =~ s/\B(?=(...)*$)/ /g ;
		} else { 
		$total_numbers = '';
		}	
		}


    
	$content .= '
	<div name="AE" class="general-total" style="top:333px; left:501px;width:142px;height:27px" >'.$total_AE.'</div>
	<div name="AQ" class="general-total" style="top:606px; left:501px;width:142px;height:27px" >'.$total_AQ.'</div>
	<div name="AR" class="general-total" style="top:636px; left:501px;width:142px;height:27px"  >'.$total_AR.'</div>
	<div name="BE" class="general-total" style="top:333px; left:671px;width:141px;height:27px" >'.$total_BE.'</div>
	<div name="BR" class="general-total" style="top:636px; left:671px;width:141px;height:27px" >'.$total_BR.'</div>
	<div name="CC" class="general-total" style="top:272px; left:814px;width:143px;height:28px" >'.$total_CC.'</div>
	<div name="CE" class="general-total" style="top:333px; left:814px;width:143px;height:27px" >'.$total_CE.'</div>
	<div name="CJ" class="general-total" style="top:454px; left:814px;width:143px;height:28px" >'.$total_CJ.'</div>
	<div name="CM" class="general-total" style="top:545px; left:814px;width:143px;height:28px" >'.$total_CM.'</div>
	<div name="CQ" class="general-total" style="top:606px; left:814px;width:143px;height:27px" >'.$total_CQ.'</div>
	<div name="CR" class="general-total" style="top:636px; left:814px;width:143px;height:27px" >'.$total_CR.'</div>
	<div name="FR" class="general-total" style="top:1152px; left:816px;width:141px;height:27px" >'.$total_FR.'</div>
	<div name="FS" class="general-total" style="top:1182px; left:816px;width:141px;height:27px" >'.$total_FS.'</div>
	</div></div></div></div></div>
	';
   
   
    return $content ;
    
} #sub formulaire2033a 


sub formulaire2033_b {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array ) ;
    
    my $numero_compte ||= '0';
     
######## Affichage MENU display_compte_set Début ######
    my $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########

    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit, credit FROM tbljournal WHERE id_client = ? and fiscal_year = ?
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit, credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

#to_char(sum(credit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_credit
#to_char(sum(credit-debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_line), \'999G999G999G990D00\') as solde

    
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    # variable
	my ($total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP,
	$total,$numero_compte);
   
   
    for ( @$result_set ) {

		#AA	Débit de : 206 207
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{debit});$total_AA += $total;}
		#AB Débit de :	201	203	204	205	208	232	237
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{debit});$total_AB += $total;}
		#AC Débit de :	21 22 231 238
		if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{debit});$total_AC += $total;}
		#AD Débit de :	25 à 268 271 à 277 Moins le débit de : 259
		#AJ Solde débiteur de : 410 à 418
		if  (substr( $_->{numero_compte}, 0, 3 ) >= 410 && (substr( $_->{numero_compte}, 0, 3 ) <= 418)) 
		{(my $total = $_->{credit});(my $total2 = $_->{debit});$total_AJ += ($total2 - $total);}
		#AM Solde débiteur de : 511 à 517 5187 à 59
		if  (
		(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
		(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
		){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$total_AM += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}	
		#BC Crédit de : 281 291 282 292 2931
		if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/ ) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/ )) {(my $total = $_->{credit});$total_BC += $total;}
		#EE Solde créditeur de : 455
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /455/) {(my $total = $_->{credit});(my $total2 = $_->{debit});$total_EE += ($total - $total2);}
		#FA Solde créditeur de : 101 Crédit de : 108 Moins le solde débiteur de : 109
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /101|108/) {(my $total = $_->{credit});$total_FA += $total;}
		#FL Solde créditeur de :16 à 17 426 451 456 458 512 à 517 5181	5186 519 à 58
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17/) 
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /512|513|514|515|516|517|426|451|456|458/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 3 ) <= 580))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if ($_->{solde_crediteur} > 'O'){
		(my $total = $_->{solde_crediteur});$total_FL += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}
	    
		#FP Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 427) && (substr( $_->{numero_compte}, 0, 4 ) <= 4286))
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 431) && (substr( $_->{numero_compte}, 0, 4 ) <= 4386))
		||	((substr( $_->{numero_compte}, 0, 4 ) >= 4411) && (substr( $_->{numero_compte}, 0, 4 ) <= 4487))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		#$content .= 'total debit ' . $_->{numero_compte} . ' et ' . $_->{total_debit} . ' solde debiteur ' . $_->{numero_compte} . ' et ' . $_->{solde_debiteur}. ' solde crediteur' . $_->{numero_compte} . ' et ' . $_->{solde_crediteur};
		if ($_->{solde_crediteur} > 'O'){
		(my $total = $_->{solde_crediteur});$total_FP += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}


	
		} #  fin for ( @$result_set ) {

########## DEBUT AFFICHAGE VALUE SANS ARRONDIES ##########

		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP
		) {
		if ($value_numbers != ('0' || '')) {
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; ;
		
		#$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}

    
	$content .= '
	<a style="float:right;margin-top:12px" href="/assets/images/2021/2033-NOT-2021.pdf" target="_blank" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-paperclip"></i> Voir la notice 2033-NOT</a>
	<h3 class="page-subtitle">2033-B - Compte de résultat simplifié</h3>
	<div class="modal fade" id="neant-confirmation-modal"><div class="modal-dialog"><div class="modal-content"><div class="modal-header">
	<div style="background-image: url(/Compta/images/2033A.png);width:960px; height:1323px;position:relative" class="cerfa-form">
	<div class="general-info" style="top:86px; left:188px">SCI PENCHENAT CANTAGREL - SIREN : 878523513</div>
	<div class="general-info" style="top:117px; left:296px">15</div>
	<div class="general-info" style="top:156px; left:844px">31/12/2020</div>
	<div name="AA" class="general-value" style="top: 211px; left: 501px; width: 142px; height: 28px;">'.$total_AA.'</div>
	<div name="AB" class="general-value" style="top:241px; left:501px;width:142px;height:28px">'.$total_AB.'</div>
	<div name="AC" class="general-value" style="top:272px; left:501px;width:142px;height:28px" >'.$total_AC.'</div>
	<div name="AD" class="general-value" style="top:302px; left:501px;width:142px;height:28px" >'.$total_AD.'</div>
	<div name="AJ" class="general-value" style="top:454px; left:501px;width:142px;height:28px" >'.$total_AJ.'</div>
	<div name="AM" class="general-value" style="top:545px; left:501px;width:142px;height:28px">'.$total_AM.'</div>
	<div name="BC" class="general-value" style="top:272px; left:671px;width:141px;height:28px" >'.$total_BC.'</div>
	<div name="EE" class="general-value"  style="top:1090px; left:671px;width:99px;height:29px" >'.$total_EE.'</div>
	<div name="FA" class="general-value"  style="top:696px; left:816px;width:141px;height:29px" >'.$total_FA.'</div>
	<div name="FL" class="general-value"  style="top:1000px; left:816px;width:141px;height:28px" >'.$total_FL.'</div>
	<div name="FP" class="general-value"  style="top:1091px; left:816px;width:141px;height:28px"  >'.$total_FP.'</div>
	<div name="JB" class="general-value"  title="Variation au crédit de :33C.BK" style="top:1242px; left:816px;width:141px;height:29px" ></div>
	';
	
########## FIN AFFICHAGE VALUE SANS ARRONDIES ##########



		
		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP
		) {
		if ($value_numbers != ('0' || '')) {
		#($numbers = sprintf( "%.2f",$numbers/100)) ;
		$value_numbers = int(($value_numbers)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}

		#Calcul des totaux
		my $total_AE = $total_AA + $total_AB + $total_AC + $total_AD ;
		my $total_AQ = $total_AJ + $total_AM ;
		my $total_BE = $total_BC;
		my $total_CC = $total_AC - $total_BC;
		my $total_CJ = $total_AJ;
		my $total_CM = $total_AM;
		my $total_CE = $total_AE - $total_BE;
		my $total_CQ = $total_AQ;
		my $total_AR = $total_AE + $total_AQ ;
		my $total_BR = $total_BE;
		my $total_CR = $total_AR - $total_BR; 
		my $total_FR = $total_FL + $total_FP ;
		my $total_FS = $total_FR;
		
		
		#Mise en forme affichage du total général
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		$total_AE,$total_AQ,$total_BE,$total_CC,$total_CJ,$total_CM,$total_CE,$total_CQ,$total_AR,$total_BR,$total_CR,$total_FR,$total_FS
		) {
		if ($total_numbers != ('0' || '')) {
		$total_numbers = int($total_numbers+ 0.5) ;
		$total_numbers =~ s/\B(?=(...)*$)/ /g ;
		} else { 
		$total_numbers = '';
		}	
		}


    
	$content .= '
	<div name="AE" class="general-total" style="top:333px; left:501px;width:142px;height:27px" >'.$total_AE.'</div>
	<div name="AQ" class="general-total" style="top:606px; left:501px;width:142px;height:27px" >'.$total_AQ.'</div>
	<div name="AR" class="general-total" style="top:636px; left:501px;width:142px;height:27px"  >'.$total_AR.'</div>
	<div name="BE" class="general-total" style="top:333px; left:671px;width:141px;height:27px" >'.$total_BE.'</div>
	<div name="BR" class="general-total" style="top:636px; left:671px;width:141px;height:27px" >'.$total_BR.'</div>
	<div name="CC" class="general-total" style="top:272px; left:814px;width:143px;height:28px" >'.$total_CC.'</div>
	<div name="CE" class="general-total" style="top:333px; left:814px;width:143px;height:27px" >'.$total_CE.'</div>
	<div name="CJ" class="general-total" style="top:454px; left:814px;width:143px;height:28px" >'.$total_CJ.'</div>
	<div name="CM" class="general-total" style="top:545px; left:814px;width:143px;height:28px" >'.$total_CM.'</div>
	<div name="CQ" class="general-total" style="top:606px; left:814px;width:143px;height:27px" >'.$total_CQ.'</div>
	<div name="CR" class="general-total" style="top:636px; left:814px;width:143px;height:27px" >'.$total_CR.'</div>
	<div name="FR" class="general-total" style="top:1152px; left:816px;width:141px;height:27px" >'.$total_FR.'</div>
	<div name="FS" class="general-total" style="top:1182px; left:816px;width:141px;height:27px" >'.$total_FS.'</div>
	</div></div></div></div></div>
	';
   
   
    return $content ;
    
} #sub formulaire2033b 



sub formulaire2033_c {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array ) ;
     
######## Affichage MENU display_compte_set Début ######
    my $content .= display_menu_formulaire( $r, $args ) ;
######## Affichage MENU display_compte_set Fin ########

    $sql = '
	with t1 as (SELECT id_client, fiscal_year, numero_compte, id_entry, id_line, date_ecriture, debit, credit FROM tbljournal WHERE id_client = ? and fiscal_year = ?
	ORDER BY numero_compte, date_ecriture, id_line) 
	SELECT t1.numero_compte, id_entry, id_line, date_ecriture, debit, credit, (sum(debit) over (PARTITION BY numero_compte))::numeric as total_debit, (sum(credit) over (PARTITION BY numero_compte))::numeric as total_credit,(sum(credit-debit) over (PARTITION BY numero_compte))::numeric as solde_crediteur, (sum(debit-credit) over (PARTITION BY numero_compte))::numeric as solde_debiteur
	FROM t1 INNER JOIN tblcompte t2 using (id_client, fiscal_year, numero_compte) 
	' ;  

#to_char(sum(credit) over (PARTITION BY numero_compte), \'999G999G999G990D00\') as total_credit
#to_char(sum(credit-debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_line), \'999G999G999G990D00\') as solde

    
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
    my $result_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
    
    # variable
	my ($total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP,
	$total,$numero_compte);
   
   
    for ( @$result_set ) {

		#AA	Débit de : 206 207
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /206|207/) {(my $total = $_->{debit});$total_AA += $total;}
		#AB Débit de :	201	203	204	205	208	232	237
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /201|203|204|205|208|232|237/) {(my $total = $_->{debit});$total_AB += $total;}
		#AC Débit de :	21 22 231 238
		if  ((substr( $_->{numero_compte}, 0, 2 ) =~ /21|22/) || (substr( $_->{numero_compte}, 0, 3 ) =~ /231|238/)) { (my $total = $_->{debit});$total_AC += $total;}
		#AD Débit de :	25 à 268 271 à 277 Moins le débit de : 259
		#AJ Solde débiteur de : 410 à 418
		if  (substr( $_->{numero_compte}, 0, 3 ) >= 410 && (substr( $_->{numero_compte}, 0, 3 ) <= 418)) 
		{(my $total = $_->{credit});(my $total2 = $_->{debit});$total_AJ += ($total2 - $total);}
		#AM Solde débiteur de : 511 à 517 5187 à 59
		if  (
		(substr( $_->{numero_compte}, 0, 3 ) >= 511 && (substr( $_->{numero_compte}, 0, 3 ) <= 517)) ||	
		(substr( $_->{numero_compte}, 0, 4 ) >= 5187 && (substr( $_->{numero_compte}, 0, 2 ) <= 59))
		){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if ($_->{solde_debiteur} > 'O'){
		(my $total = $_->{solde_debiteur});$total_AM += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}	
		#BC Crédit de : 281 291 282 292 2931
		if  ((substr( $_->{numero_compte}, 0, 3 ) =~ /281|291|282|292/ ) || (substr( $_->{numero_compte}, 0, 4 ) =~ /2931/ )) {(my $total = $_->{credit});$total_BC += $total;}
		#EE Solde créditeur de : 455
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /455/) {(my $total = $_->{credit});(my $total2 = $_->{debit});$total_EE += ($total - $total2);}
		#FA Solde créditeur de : 101 Crédit de : 108 Moins le solde débiteur de : 109
		if  (substr( $_->{numero_compte}, 0, 3 ) =~ /101|108/) {(my $total = $_->{credit});$total_FA += $total;}
		#FL Solde créditeur de :16 à 17 426 451 456 458 512 à 517 5181	5186 519 à 58
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /16|17/) 
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /512|513|514|515|516|517|426|451|456|458/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /426|451|456|458/)
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /5181|5186/)
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 519) && (substr( $_->{numero_compte}, 0, 3 ) <= 580))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		if ($_->{solde_crediteur} > 'O'){
		(my $total = $_->{solde_crediteur});$total_FL += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}
	    
		#FP Solde créditeur de : 18 259 269 279 404 à 405 4084	410 à 418 4196 à 4198 421 à 425	427 à 4286 431 à 4386 4411 à 4487 449
		# 	455	457	460 à 464	467	4686 471 à 475	477 à 478	488	489	509"
		if	(
		(substr( $_->{numero_compte}, 0, 2 ) =~ /18/)
		|| (substr( $_->{numero_compte}, 0, 3 ) =~ /259|269|279|404|405|410|411|412|413|414|415|416|417|418|421|422|423|424|425|449|455|457|460|461|462|463|464|467|471|472|473|474|475|477|478|488|489|509/) 
		|| (substr( $_->{numero_compte}, 0, 4 ) =~ /4084|4196|4197|4198|4686/) 
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 427) && (substr( $_->{numero_compte}, 0, 4 ) <= 4286))
		|| ((substr( $_->{numero_compte}, 0, 3 ) >= 431) && (substr( $_->{numero_compte}, 0, 4 ) <= 4386))
		||	((substr( $_->{numero_compte}, 0, 4 ) >= 4411) && (substr( $_->{numero_compte}, 0, 4 ) <= 4487))
			){
		unless ( $_->{numero_compte} eq $numero_compte ) {
		#$content .= 'total debit ' . $_->{numero_compte} . ' et ' . $_->{total_debit} . ' solde debiteur ' . $_->{numero_compte} . ' et ' . $_->{solde_debiteur}. ' solde crediteur' . $_->{numero_compte} . ' et ' . $_->{solde_crediteur};
		if ($_->{solde_crediteur} > 'O'){
		(my $total = $_->{solde_crediteur});$total_FP += $total ;
		}
		$numero_compte = $_->{numero_compte} ;
	    }}


	
		} #  fin for ( @$result_set ) {

########## DEBUT AFFICHAGE VALUE SANS ARRONDIES ##########

		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP
		) {
		if ($value_numbers != ('0' || '')) {
		($value_numbers = sprintf( "%.2f",$value_numbers/100)) =~ s/\./\,/g; ;
		
		#$value_numbers = int(($value_numbers/100)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}

    
	$content .= '
	<a style="float:right;margin-top:12px" href="/assets/images/2021/2033-NOT-2021.pdf" target="_blank" class="btn btn-info btn-xs"><i class="glyphicon glyphicon-paperclip"></i> Voir la notice 2033-NOT</a>
	<h3 class="page-subtitle">2033-A - Bilan simplifié</h3>
	<div class="modal fade" id="neant-confirmation-modal"><div class="modal-dialog"><div class="modal-content"><div class="modal-header">
	<div style="background-image: url(/Compta/images/2033A.png);width:960px; height:1323px;position:relative" class="cerfa-form">
	<div class="general-info" style="top:86px; left:188px">SCI PENCHENAT CANTAGREL - SIREN : 878523513</div>
	<div class="general-info" style="top:117px; left:296px">15</div>
	<div class="general-info" style="top:156px; left:844px">31/12/2020</div>
	<div name="AA" class="general-value" style="top: 211px; left: 501px; width: 142px; height: 28px;">'.$total_AA.'</div>
	<div name="AB" class="general-value" style="top:241px; left:501px;width:142px;height:28px">'.$total_AB.'</div>
	<div name="AC" class="general-value" style="top:272px; left:501px;width:142px;height:28px" >'.$total_AC.'</div>
	<div name="AD" class="general-value" style="top:302px; left:501px;width:142px;height:28px" >'.$total_AD.'</div>
	<div name="AJ" class="general-value" style="top:454px; left:501px;width:142px;height:28px" >'.$total_AJ.'</div>
	<div name="AM" class="general-value" style="top:545px; left:501px;width:142px;height:28px">'.$total_AM.'</div>
	<div name="BC" class="general-value" style="top:272px; left:671px;width:141px;height:28px" >'.$total_BC.'</div>
	<div name="EE" class="general-value"  style="top:1090px; left:671px;width:99px;height:29px" >'.$total_EE.'</div>
	<div name="FA" class="general-value"  style="top:696px; left:816px;width:141px;height:29px" >'.$total_FA.'</div>
	<div name="FL" class="general-value"  style="top:1000px; left:816px;width:141px;height:28px" >'.$total_FL.'</div>
	<div name="FP" class="general-value"  style="top:1091px; left:816px;width:141px;height:28px"  >'.$total_FP.'</div>
	<div name="JB" class="general-value"  title="Variation au crédit de :33C.BK" style="top:1242px; left:816px;width:141px;height:29px" ></div>
	';
	
########## FIN AFFICHAGE VALUE SANS ARRONDIES ##########



		
		# Préparation calculs des totaux avec arrondies
		foreach my $value_numbers ( 
		#variable
		$total_AA,$total_AB,$total_AC,$total_AD,$total_AJ,$total_AM,$total_BC,$total_EE,$total_FA,$total_FL,$total_FP
		) {
		if ($value_numbers != ('0' || '')) {
		#($numbers = sprintf( "%.2f",$numbers/100)) ;
		$value_numbers = int(($value_numbers)+ 0.5) ;
		} else { 
		$value_numbers = '';
		}	
		}

		#Calcul des totaux
		my $total_AE = $total_AA + $total_AB + $total_AC + $total_AD ;
		my $total_AQ = $total_AJ + $total_AM ;
		my $total_BE = $total_BC;
		my $total_CC = $total_AC - $total_BC;
		my $total_CJ = $total_AJ;
		my $total_CM = $total_AM;
		my $total_CE = $total_AE - $total_BE;
		my $total_CQ = $total_AQ;
		my $total_AR = $total_AE + $total_AQ ;
		my $total_BR = $total_BE;
		my $total_CR = $total_AR - $total_BR; 
		my $total_FR = $total_FL + $total_FP ;
		my $total_FS = $total_FR;
		
		
		#Mise en forme affichage du total général
		foreach my $total_numbers ( 
		#variable_totaux général
		#variable_totaux
		$total_AE,$total_AQ,$total_BE,$total_CC,$total_CJ,$total_CM,$total_CE,$total_CQ,$total_AR,$total_BR,$total_CR,$total_FR,$total_FS
		) {
		if ($total_numbers != ('0' || '')) {
		$total_numbers = int($total_numbers+ 0.5) ;
		$total_numbers =~ s/\B(?=(...)*$)/ /g ;
		} else { 
		$total_numbers = '';
		}	
		}


    
	$content .= '
	<div name="AE" class="general-total" style="top:333px; left:501px;width:142px;height:27px" >'.$total_AE.'</div>
	<div name="AQ" class="general-total" style="top:606px; left:501px;width:142px;height:27px" >'.$total_AQ.'</div>
	<div name="AR" class="general-total" style="top:636px; left:501px;width:142px;height:27px"  >'.$total_AR.'</div>
	<div name="BE" class="general-total" style="top:333px; left:671px;width:141px;height:27px" >'.$total_BE.'</div>
	<div name="BR" class="general-total" style="top:636px; left:671px;width:141px;height:27px" >'.$total_BR.'</div>
	<div name="CC" class="general-total" style="top:272px; left:814px;width:143px;height:28px" >'.$total_CC.'</div>
	<div name="CE" class="general-total" style="top:333px; left:814px;width:143px;height:27px" >'.$total_CE.'</div>
	<div name="CJ" class="general-total" style="top:454px; left:814px;width:143px;height:28px" >'.$total_CJ.'</div>
	<div name="CM" class="general-total" style="top:545px; left:814px;width:143px;height:28px" >'.$total_CM.'</div>
	<div name="CQ" class="general-total" style="top:606px; left:814px;width:143px;height:27px" >'.$total_CQ.'</div>
	<div name="CR" class="general-total" style="top:636px; left:814px;width:143px;height:27px" >'.$total_CR.'</div>
	<div name="FR" class="general-total" style="top:1152px; left:816px;width:141px;height:27px" >'.$total_FR.'</div>
	<div name="FS" class="general-total" style="top:1182px; left:816px;width:141px;height:27px" >'.$total_FS.'</div>
	</div></div></div></div></div>
	';
   
   
    return $content ;
    
} #sub formulaire2033c 



sub display_menu_formulaire {

    my ( $r, $args ) = @_ ;
    
    unless ( defined $args->{formulaire}) {
	    $args->{formulaire} = '2033A' ;
    } 	

    
#########################################	
#Filtrage des formulaires - Début		#
#########################################		
	my $print_link ='<a class="btn btn-success" href="#" style="margin-left: 3ch;" onClick="window.print();return false" >Print</a>' ;
   my $form2033_A_link = '<a class=' . ( ($args->{formulaire} eq '2033A' ) ? 'selecteditem' : 'nav' ) . ' href="/base/bilan?formulaire=2033A" style="margin-left: 3ch;">2033A</a>' ;
   my $form2033_B_link = '<a class=' . ( ($args->{formulaire} eq '2033B' ) ? 'selecteditem' : 'nav' ) . ' href="/base/bilan?formulaire=2033B" style="margin-left: 3ch;">2033B</a>' ;
   my $form2033_C_link = '<a class=' . ( ($args->{formulaire} eq '2033C' ) ? 'selecteditem' : 'nav' ) . ' href="/base/bilan?formulaire=2033C" style="margin-left: 3ch;">2033C</a>' ;
   my $form2033_D_link = '<a class=' . ( ($args->{formulaire} eq '2033D' ) ? 'selecteditem' : 'nav' ) . ' href="/base/bilan?formulaire=2033D" style="margin-left: 3ch;">2033D</a>' ;

	my $content .= '<li style="text-align: center; list-style: none; margin: 0;">' . $form2033_A_link . $form2033_B_link . $form2033_C_link . $form2033_D_link . $print_link . '</li>' ;

#########################################	
#Filtrage des formulaires - Fin			#
#########################################
    
    return $content ;

} #sub display_menu_formulaire 


1 ;
