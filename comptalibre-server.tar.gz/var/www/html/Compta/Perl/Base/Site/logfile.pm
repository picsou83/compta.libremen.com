package Base::Site::logfile;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Apache2::URI ();
use utf8 ;
use Apache2::Const -compile => qw( OK REDIRECT ) ;
use Fcntl qw< LOCK_EX SEEK_END >;

sub handler {

    binmode(STDOUT, ":utf8") ;

    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content ;
	my $req = Apache2::Request->new( $r ) ;

    #récupérer les arguments
    my (%args, @args) ;

    #recherche des paramètres de la requête
    @args = $req->param ;

    for ( @args ) {

	$args{ $_ } = Encode::decode_utf8( $req->param($_) ) ;

	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;

    }
    
    if ( defined $args{menu1} ) {

	    $content = menu1( $r, \%args ) ;

	} elsif ( defined $args{menu2}) {

	    $content = menu2( $r, \%args ) ;

	} elsif ( defined $args{menu3}) {

	    $content = menu3( $r, \%args ) ;
	
	} elsif ( defined $args{menu4}) {

	    $content = menu4( $r, \%args ) ;
	    
	} elsif ( defined $args{menu5}) {

	    $content = menu5( $r, \%args ) ;
	    
	} else {
		$content = menu1( $r, \%args ) ;
	}

  
   
    $r->no_cache(1) ;
    
    $r->content_type('text/html; charset=utf-8') ;

    print $content ;

    return Apache2::Const::OK ;

}

sub menu1 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   #$content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########


	
	#my $menu1 = (($r->args  =~ /top/ ) ? 'nav-link2' : 'nav-link' );
  
		my $contenu_web .= '
		
		<fieldset><legend><h2 style="color: green; background-color: #ddefef;">Gestion des logs</h2></legend>
		<div style="width: max-content;">
		
		<div >
		';
		
		#<div style="text-align : left; padding: 15px; margin: 10px;  border-radius: 5px;">
		
		my $file = "/var/www/html/Compta/base/logs/Compta.log";
		
		open my $fh, "<:encoding(UTF-8)", $file or die "Could not open $!\n";
		my $line = <$fh>;

		seek  $fh, -5500, SEEK_END;              # move to the beginning of the file 

		while (my $l = <$fh>) {
        chomp $l;
        $contenu_web .= "<br>$l";
		}
	
	
	
		
		close (FH);
		#my $tail = File::Tail->new( name => $file );
		#while (defined( my $line = $tail->read() )) {
		
		#}

		
		#$contenu_web .= $_; 
		
		$contenu_web .='</div></div></fieldset>';
		
		$content .= '
		
		<div class="wrapper">' . $contenu_web . '</div>' ;
		
    return $content ;
    
    
} #sub menu1 

sub menu2 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########
		
		my $contenu_web .= '
	
		';
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;
    
} #sub menu2 

sub menu3 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########


		my $contenu_web .= '
	
		';
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;
    
} #sub menu3 

sub menu4 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########

		my $contenu_web .= '

      ';
      
     
		
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;
    
} #sub menu4 

sub menu5 {
	
	my ( $r, $args ) = @_ ;

    my $dbh = $r->pnotes('dbh') ;

    my ( $sql, @bind_array, $content ) ;
    
######## Affichage MENU display_menu Début ######
   $content .= display_menu( $r, $args ) ;
######## Affichage MENU display_menu Fin ########


		my $contenu_web .= "

		";
		$content .= '<div class="wrapper"><ul>' . $contenu_web . '</ul></div>' ;
		
    return $content ;

    
} #sub menu5 

sub display_menu {

    my ( $r, $args ) = @_ ;
    
   unless ( defined $args->{menu2} || defined $args->{menu3} || defined $args->{menu4} || defined $args->{menu5} ) {
	   $args->{menu1} = '' ;
    } 	
 	

    
#########################################	
#Filtrage du Menu - Début				#
#########################################		
	my $menu1_link = '<a class=' . ( (defined $args->{menu1} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu1" style="margin-left: 3ch;">Premiers pas</a>' ;
	my $menu2_link = '<a class=' . ( (defined $args->{menu2} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu2" style="margin-left: 3ch;">Courant</a>' ;
	my $menu3_link = '<a class=' . ( (defined $args->{menu3} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu3" style="margin-left: 3ch;">Utilitaires</a>' ;
	my $menu4_link = '<a class=' . ( (defined $args->{menu4} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu4" style="margin-left: 3ch;">Paramétrage</a>' ;
	my $menu5_link = '<a class=' . ( (defined $args->{menu5} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/documentation?menu5" style="margin-left: 3ch;">Fin d\'exercice</a>' ;
	my $content .= '<div class="menu"><li style="list-style: none; margin: 0;">' . $menu1_link . $menu2_link . $menu3_link . $menu4_link . $menu5_link .'</li></div>' ;

#########################################	
#Filtrage du Menu - Fin					#
#########################################
    
    return $content ;

} #sub display_menu_formulaire 

1 ;
