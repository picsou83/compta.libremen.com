package Base::Site::menu;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Apache2::URI ();
use Time::Piece;
use utf8 ;
use Apache2::Const -compile => qw( OK DECLINED REDIRECT);

sub handler {

    binmode(STDOUT, ":utf8") ;
    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content = '';
	my $req = Apache2::Request->new( $r ) ;

    #récupérer les arguments
    my (%args, @args) ;

    #recherche des paramètres de la requête
    @args = $req->param ;

    for ( @args ) {

	$args{ $_ } = Encode::decode_utf8( $req->param($_) ) ;

	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;

    }
    
    if (defined $args{journal})  {
	
	my $location = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $args{journal} ) . '&amp;id_entry=0' ;

	$r->headers_out->set(Location => $location) ;

	return Apache2::Const::REDIRECT ;
	}

	$content = menu1( $r, \%args ) ;
	
    $r->no_cache(1) ;
    
    $r->content_type('text/html; charset=utf-8') ;

    print $content ;

    return Apache2::Const::OK ;

}

sub menu1 {
	
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
    $args->{_token_id} ||= join "", map +(0..9,"a".."z","A".."Z")[rand(10+26*2)], 1..32 ;

    
    
    	#/************ ACTION DEBUT *************/#
    	
#######################################################################  
#ACTION forms_ecri_rec DEBUT										  #
#menu?select_month=12&ecriture_recurrente=0
	if ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '0' ) {
		
	$sql = '
	with t1 as ( SELECT id_entry, date_ecriture FROM tbljournal
	WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
	GROUP BY id_entry, date_ecriture)
	SELECT count(id_entry) FROM t1
	';

	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;

	my $en_attente_count = '';
	
	eval { $en_attente_count = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] } ;	
	
	if ( $@ ) {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
	    return $content ;  
	} #	if 
		
	if ($en_attente_count != 0) {
	
			my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;select_month=' . $args->{select_month} . '
		&amp;ecriture_recurrente=1' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Voulez-vous vraiment générer les ' . $en_attente_count .' écritures récurrentes pour le mois ' . $args->{select_month} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;	
		
	} else {
	
		my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;select_month=' . $args->{select_month} . '
		&amp;ecriture_recurrente=2' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Il n\'y a aucune écriture récurrente de paramétrée sur cette exercice. <br> 
		Voulez-vous importer les écritures récurrentes de l\'exercice précédent ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;		
	}
		
	# enregistrement des écritures récurrentes	
		} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '1' ) {
	
	$sql = '
	SELECT id_entry, date_ecriture FROM tbljournal
	WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
	GROUP BY id_entry, date_ecriture
	';
	
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	
	my $token = $r->pnotes('session')->{_session_id};
	my $id_entry= '';
	
    
    foreach ( @{$resultat} ) {
		
	#$sql = 'SELECT id_entry, id_line, id_client, fiscal_year, libelle_journal, numero_compte, date_ecriture, id_paiement, id_facture, libelle, documents1, documents2, debit, credit, id_export, lettrage, pointage, recurrent
	#FROM tbljournal	WHERE id_client = ? AND recurrent = true AND fiscal_year = ? AND id_entry = ?';
	
	my $day = substr($_->{date_ecriture},0,2);
	my $date = $r->pnotes('session')->{fiscal_year}.'-'.$args->{select_month}.'-'.$day;


	$sql = '
	INSERT INTO tbljournal_staging (_session_id, id_entry, id_client, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, numero_compte, date_ecriture, id_paiement, id_facture, libelle, documents1, documents2, debit, credit, _token_id ) SELECT ?, ?, t1.id_client, t1.fiscal_year, ?, ?, ?, t1.libelle_journal, t1.numero_compte, ?, t1.id_paiement, t1.id_facture, t1.libelle, t1.documents1, t1.documents2, t1.debit, t1.credit, ?
	FROM tbljournal t1 
	WHERE t1.id_entry = ? ORDER BY id_line' ;
	
	@bind_array = ( $r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $date, $token, $_->{id_entry} ) ;
	
	$dbh->do( $sql, undef, @bind_array ) ;

    #my $resultat_identry = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year},$_->{id_entry} ) ) ;
	

	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Debug vérification des résultats libelle : '.$_->{libelle}.' id_entry : '.$_->{id_entry}.' debit : '.$_->{debit}.' credit : '.$_->{credit}.'');
	
	#première écriture
	#$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)' ;
	#@bind_array = ( 
	#$token, 0, $date, $_->{libelle}, $_->{numero_compte}, undef, $_->{debit}, $_->{credit}, $r->pnotes('session')->{id_client}, $_->{id_facture}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $_->{libelle_journal}, $args->{_token_id}, ($_->{documents1} || undef), ($_->{documents2} || undef)) ;
	#$dbh->do( $sql, undef, @bind_array ) ;
	
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $token, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
		} 
		
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Enregistrement de l\'écriture récurrente pour le mois numéro: '.$args->{select_month}.' avec l\'id_entry: '.$_->{id_entry}.'');
	
	}
		
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Enregistrement des écritures récurrentes pour le mois numéro: '.$args->{select_month}.' ');
	
			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/menu' ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
    
    # enregistrement des écritures récurrentes de l'exercice précédent	
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '2' ) {
	
	$sql = '
	SELECT id_entry, date_ecriture FROM tbljournal
	WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
	GROUP BY id_entry, date_ecriture
	';
	
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1) ) ;
	
	my $token = $r->pnotes('session')->{_session_id};
	my $id_entry= '';
	
    
    foreach ( @{$resultat} ) {
	
	my $day = substr($_->{date_ecriture},0,2);
	my $date = $r->pnotes('session')->{fiscal_year}.'-'.$args->{select_month}.'-'.$day;

	$sql = '
	INSERT INTO tbljournal_staging (_session_id, id_entry, id_client, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, numero_compte, date_ecriture, id_paiement, id_facture, libelle, documents1, documents2, debit, credit, recurrent, _token_id ) SELECT ?, ?, t1.id_client, ?, ?, ?, ?, t1.libelle_journal, t1.numero_compte, ?, t1.id_paiement, t1.id_facture, t1.libelle, t1.documents1, t1.documents2, t1.debit, t1.credit, t1.recurrent, ?
	FROM tbljournal t1 
	WHERE t1.id_entry = ? ORDER BY id_line' ;
	
	@bind_array = ( $r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $date, $token, $_->{id_entry} ) ;
	
	$dbh->do( $sql, undef, @bind_array ) ;

	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $token, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
		} 
		

	}
		
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Enregistrement des écritures récurrentes pour le mois numéro: '.$args->{select_month}.'');

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/menu' ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
    	
	}
#ACTION forms_ecri_rec FIN											  #
####################################################################### 
	
	
#######################################################################  
#ACTION appel_loyer DEBUT											  #
#date_comptant=2021-01-05&montant=780.00&select_month=01&appel_loyer=0
	if ( defined $args->{appel_loyer} and $args->{appel_loyer} eq '0' ) {
		
		my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;select_month=' . $args->{select_month} . '
		&amp;appel_loyer=1' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Voulez-vous vraiment générer les appels de loyer pour le mois ' . $args->{select_month} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		} elsif ( defined $args->{appel_loyer} and $args->{appel_loyer} eq '1' ) {
	
	
	$sql = 'SELECT loyer_libelle, loyer_date, loyer_montant, loyer_classe4, loyer_classe7, loyer_piece FROM tblloyer_liste WHERE id_client = ? ORDER by loyer_libelle' ;
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    
    #$journal_set->[0]->{libelle_journal}
    $sql = 'SELECT libelle_journal, type_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? AND type_journal ~* \'Ventes\' ORDER by code_journal' ;
    my $journal_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $loyer_libelle;
	my $token = $r->pnotes('session')->{_session_id};
    
    foreach ( @{$resultat} ) {

		
	my $libelle = $_->{loyer_libelle} .' - '.$args->{select_month}.'/'.$r->pnotes('session')->{fiscal_year}.'';
	my $compte_classe_7 = $_->{loyer_classe7};
	my $compte_classe_4 = $_->{loyer_classe4};
	my $num_piece = substr($_->{loyer_piece},0,15);
	my $date = $r->pnotes('session')->{fiscal_year}.'-'.$args->{select_month}.'-'.$_->{loyer_date};
	
	#recherche de la liste des documents enregistrés
    $sql = 'SELECT id_name FROM tbldocuments WHERE substring(id_name from 1 for 15) = ? AND id_client = ? ORDER BY 1 DESC LIMIT 1' ;
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $num_piece, $r->pnotes('session')->{id_client} ) ;
	
	#première écriture
	$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$token, 0, $date, $libelle, $compte_classe_7, undef, 0, $_->{loyer_montant}, $r->pnotes('session')->{id_client}, $num_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $journal_set->[0]->{libelle_journal}, $args->{_token_id}, ($array_of_documents->[0]->{id_name} || undef), ($args->{docs2} || undef), 
	$token, 0, $date, $libelle, $compte_classe_4, undef, $_->{loyer_montant}, 0, $r->pnotes('session')->{id_client}, $num_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $journal_set->[0]->{libelle_journal}, $args->{_token_id}, ($array_of_documents->[0]->{id_name} || undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
		} 


	}
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Enregistrement des appels de loyer pour le mois : '.$args->{select_month}.'');

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/menu' ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
    	
	}
#ACTION appel_loyer FIN											      #
####################################################################### 
		
#######################################################################  
# ACTION move_compte DEBUT											  #
#menu?date_comptant=2021-10-09&id_compte_1_select=R%C3%A9glement+Banque&id_compte_2_select=R%C3%A9glement+Paypal&libelle=test&montant=100.00&docs1=&docs2=&move_compte=0
	if ( defined $args->{move_compte} and $args->{move_compte} eq '0' ) {
	
			if 	(defined $args->{id_compte_1_select} && $args->{id_compte_1_select} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le compte n\'a pas été sélectionné</h3>' ;	
		} elsif (defined $args->{id_compte_2_select} && $args->{id_compte_2_select} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le compte de destination n\'a pas été sélectionné</h3>' ;	
		} else {	
		my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;date_comptant=' . $args->{date_comptant} . '
		&amp;id_compte_1_select=' . $args->{id_compte_1_select} . '
		&amp;id_compte_2_select=' . $args->{id_compte_2_select} . '
		&amp;montant=' . $args->{montant} . '
		&amp;piece=' . $args->{piece} . '
		&amp;libelle=' . $args->{libelle} . '
		&amp;menu=' . $args->{menu}  . '
		&amp;docs1=' . $args->{docs1}  . '
		&amp;docs2=' . $args->{docs2}  . '
		&amp;move_compte=1' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Du compte ' . $args->{id_compte_1_select} .' vers le compte ' . $args->{id_compte_2_select} .' d\'un montant de ' . $args->{montant} .'€ avec pour libellé ' . $args->{libelle} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}
		
	}  elsif ( defined $args->{move_compte} and $args->{move_compte} eq '1' ) {
	
	my ($journal1, $journal2, $month, $year) = '';
	
	#récupération journal de réglement et compte de réglement pour id_compte_1_select et id_compte_2_select
	$sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? and config_libelle = ?' ;
    my $resultat_1 = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{id_compte_1_select} ) ) ;
	my $resultat_2 = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{id_compte_2_select} ) ) ;
	my $reglement_journal_1 = $resultat_1->[0]->{config_journal};
	my $reglement_compte_1 = $resultat_1->[0]->{config_compte};
	my $reglement_journal_2 = $resultat_2->[0]->{config_journal};
	my $reglement_compte_2 = $resultat_2->[0]->{config_compte};
	
	#mise en forme montant pour enregistrement en bdd
	#ne pas laisser des montants nulls : mettre un zéro
	$args->{montant} ||= '0.00';
	#remplacer la virgule par le point dans les montants soumis
	$args->{montant} =~ s/,/./ ;
	#enlever les espaces de présentation
	$args->{montant} =~ s/\s//g ;
	
	#recherche du lettrage existant pour ce compte
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
    
    my $lettrage_total = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
    
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND numero_compte = \'580000\' AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	
	my $lettrage = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;

    if ( $lettrage ) {

	$lettrage++ ;

    } else {
	
	if ($lettrage_total) {
	my $lettrage_sub = substr( $lettrage_total, 0, 2 );
	$lettrage = ++$lettrage_sub.'01';
    } else {
	$lettrage = 'AA01' ;
    }	
    }
	
	
#première écriture
	$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte_1, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_1, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, '580000', $lettrage, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_1, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
    } else {      

#deuxième écriture
    $sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte_2, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_2, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, '580000', $lettrage, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_2, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
	}} else {
		
				my $varmenu ;	
		if (defined $args->{menu} && $args->{menu} ne '') {$varmenu = 'docsentry?id_name='.$args->{menu}} else { $varmenu = 'menu';}

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
	}     
    
	}	
		
	}
#ACTION move_compte FIN											      #
####################################################################### 	
	
#######################################################################  
# ACTION achat_comptant DEBUT										  #
#menu?date_comptant=2020-12-31&compte_comptant=401CAAE&libelle=test&montant=100.00&select_achats=default_caisse_journal%21%21CAISSE&docs1=&docs2=&achat_comptant=0
    if ( defined $args->{achat_comptant} and $args->{achat_comptant} eq '0' ) {
		
		if 	(defined $args->{compte_comptant} && $args->{compte_comptant} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de compte fournisseur en 401</h3>' ;	
		} elsif (defined $args->{select_achats} && $args->{select_achats} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de journal de réglement configuré</h3>' ;	
		} else {	
		my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;date_comptant=' . $args->{date_comptant} . '
		&amp;compte_comptant=' . $args->{compte_comptant} . '
		&amp;montant=' . $args->{montant} . '
		&amp;libelle=' . $args->{libelle} . '
		&amp;select_achats=' . $args->{select_achats} . '
		&amp;compte_charge_comptant=' . $args->{compte_charge_comptant} . '
		&amp;menu=' . $args->{menu}  . '
		&amp;docs1=' . $args->{docs1}  . '
		&amp;docs2=' . $args->{docs2}  . '
		&amp;calcul_piece3=' . $args->{calcul_piece3}  . '
		&amp;achat_comptant=1' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Compte ' . $args->{compte_comptant} .' d\'un montant de ' . $args->{montant} .'€ avec pour libellé ' . $args->{libelle} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}
    } elsif ( defined $args->{achat_comptant} and $args->{achat_comptant} eq '1' ) {
	
	my ($journal, $month, $year) = '';
	
#récupération journal de réglement et compte de réglement

	$sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? and config_libelle = ?' ;
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{select_achats} ) ) ;
    	
	my $reglement_journal = $resultat->[0]->{config_journal};
	my $reglement_compte = $resultat->[0]->{config_compte};
	
#mise en forme montant pour enregistrement en bdd
	#ne pas laisser des montants nulls : mettre un zéro
	$args->{montant} ||= '0.00';
	#remplacer la virgule par le point dans les montants soumis
	$args->{montant} =~ s/,/./ ;
	#enlever les espaces de présentation
	$args->{montant} =~ s/\s//g ;
	
#calcul numéro de pièce auto
	$sql = 'SELECT libelle_journal, code_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_code_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	
	my $journal_achats = 'ACHATS';
	
	for ( @$journal_code_set ) {
	if ($journal_achats =~ $_->[0]) {
		$journal = $_->[1];	
		} 
	}    
	    
	if ((defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<year>[0-9]{4}).*(?<month>[0-9]{2}).*(?<day>[0-9]{2})$/) {
	$month= substr($args->{date_comptant},5,2);
    $year= substr($args->{date_comptant},0,4);		
	} elsif (( defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
	$month= substr($args->{date_comptant},3,2);
    $year= substr($args->{date_comptant},6,4);	
	}
	
    my $item_num = 1;
    
	#on regarde s'il existe des factures enregistrées pour le mois et l'année de la date d'enregistrement
	$sql = '
	SELECT id_facture as item_number, extract(month from ?::date) as month_number, extract(year from ?::date) as year_number
	FROM tbljournal
	WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE ? and id_client = ? and fiscal_year = ? and libelle_journal = ? AND substring(id_facture from 8 for 2) = ?
	ORDER BY 1 DESC LIMIT 1
	' ;
	
	@bind_array = ( $args->{date_comptant}, $args->{date_comptant}, $journal, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $journal_achats, $month ) ;
	my $calcul_piece = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;     
	
	for ( @$calcul_piece ) {
	if (substr( $_->{item_number}, 10, 2 ) =~ /\d/ && substr( $_->{item_number}, 0, 2 ) =~ /$journal/) {
	$item_num = int(substr( $_->{item_number}, 10, 2 )) + 1	;} 
	} 
	
	#my $format ='%0' . $1 . 'd' ;
	
	if ($item_num<10) {	$item_num="0".$item_num; }
	
	#my $numero_piece = $journal . $year . '-' . $month . '_' . $item_num ;
	#my $numero_piece = $journal . $year . '-' . $month . '_' . sprintf("$format", $item_num );
	my $numero_piece = $args->{calcul_piece3} ;

#recherche du lettrage existant pour ce compte
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
    
    my $lettrage_total = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
    
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND numero_compte = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{compte_comptant} ) ;
	
	my $lettrage = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;

    if ( $lettrage ) {

	$lettrage++ ;

    } else {
	
	if ($lettrage_total) {
	
	my $lettrage_sub = substr( $lettrage_total, 0, 2 );
	$lettrage = ++$lettrage_sub.'01';

    } else {
	
	$lettrage = 'AA01' ;
    }	
    }

#première écriture
	$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_comptant}, $lettrage, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'ACHATS', $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_charge_comptant}, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'ACHATS', $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
    } else {      

#deuxième écriture
    $sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_comptant}, $lettrage, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
	}} else {
				my $varmenu ;	
		if (defined $args->{menu} && $args->{menu} ne '') {$varmenu = 'docsentry?id_name='.$args->{menu}} else { $varmenu = 'menu';}

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
	}    
    
	}
	}
# ACTION achat_comptant FIN											  #
####################################################################### 	

#######################################################################  
# ACTION reglement_client DEBUT										  #
#menu?date_comptant=30%2F04%2F2021&compte_client=411302&libelle=test&montant=780.00&select_achats=Banque&docs1=&docs2=&reglement_client=0
    if ( defined $args->{reglement_client} and $args->{reglement_client} eq '0' ) {
		
		
		if 	(defined $args->{compte_client} && $args->{compte_client} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de compte client</h3>' ;	
		} elsif (defined $args->{select_achats} && $args->{select_achats} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de journal de réglement configuré</h3>' ;	
		} else {	
			
							
		my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;date_comptant=' . $args->{date_comptant} . '
		&amp;compte_client=' . $args->{compte_client} . '
		&amp;montant=' . $args->{montant} . '
		&amp;libelle=' . $args->{libelle} . '
		&amp;select_achats=' . $args->{select_achats} . '
		&amp;docs1=' . $args->{docs1}  . '
		&amp;docs2=' . $args->{docs2}  . '
		&amp;menu=' . $args->{menu}  . '
		&amp;reglement_client=1' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Date: ' .$args->{date_comptant} . ' Client: '. $args->{compte_client} .' Journal: '.$args->{select_achats}.' Montant: ' . $args->{montant} .'€ Libellé: ' . $args->{libelle} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}
    } elsif ( defined $args->{reglement_client} and $args->{reglement_client} eq '1' ) {
		
    #définition des variables
	my ($journal, $month, $year) = '';
	#récupération journal de réglement et compte de réglement
	$sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? and config_libelle = ?' ;
	my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{select_achats} ) ) ;
    my $reglement_journal = $resultat->[0]->{config_journal};
	my $reglement_compte = $resultat->[0]->{config_compte};	
	
	#mise en forme montant pour enregistrement en bdd
	#ne pas laisser des montants nulls : mettre un zéro
	$args->{montant} ||= '0.00';
	#remplacer la virgule par le point dans les montants soumis
	$args->{montant} =~ s/,/./ ;
	#enlever les espaces de présentation
	$args->{montant} =~ s/\s//g ;
	
	#calcul numéro de pièce auto
	$sql = 'SELECT libelle_journal, code_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_code_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	

	for ( @$journal_code_set ) {
	if ($reglement_journal =~ $_->[0]) {
		$journal = $_->[1];	
		} 
	}    
	    
	if ((defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<year>[0-9]{4}).*(?<month>[0-9]{2}).*(?<day>[0-9]{2})$/) {
	$month= substr($args->{date_comptant},5,2);
    $year= substr($args->{date_comptant},0,4);		
	} elsif (( defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
	$month= substr($args->{date_comptant},3,2);
    $year= substr($args->{date_comptant},6,4);	
	}
	
    my $item_num = 1;
    
	#on regarde s'il existe des factures enregistrées pour le mois et l'année de la date d'enregistrement
	$sql = '
	SELECT id_facture as item_number, extract(month from ?::date) as month_number, extract(year from ?::date) as year_number
	FROM tbljournal
	WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE ? and id_client = ? and fiscal_year = ? and libelle_journal = ? AND substring(id_facture from 8 for 2) = ?
	ORDER BY 1 DESC LIMIT 1
	' ;
	
	@bind_array = ( $args->{date_comptant}, $args->{date_comptant}, $journal, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $reglement_journal, $month ) ;
	my $calcul_piece = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;     
	
	for ( @$calcul_piece ) {
	if (substr( $_->{item_number}, 10, 2 ) =~ /\d/ && substr( $_->{item_number}, 0, 2 ) =~ /$journal/) {
	$item_num = int(substr( $_->{item_number}, 10, 2 )) + 1	;} 
	} 
	
	#my $format ='%0' . $1 . 'd' ;
	
	if ($item_num<10) {	$item_num="0".$item_num; }
	
	my $numero_piece = $journal . $year . '-' . $month . '_' . $item_num ;

#recherche du lettrage existant pour ce compte
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
    
    my $lettrage_total = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
    
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND numero_compte = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{compte_client} ) ;
	
	my $lettrage = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;

    if ( $lettrage ) {

	$lettrage++ ;

    } else {
	
	if ($lettrage_total) {
	
	my $lettrage_sub = substr( $lettrage_total, 0, 2 );
	$lettrage = ++$lettrage_sub.'01';

    } else {
	
	$lettrage = 'AA01' ;
    }	
    }

#première écriture
	$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_client}, $lettrage, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
    } else {
	Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm =>
	Ajout du réglement client : Date: ' .$args->{date_comptant} . ' Client: '. $args->{compte_client} .' Journal: '.$reglement_journal.' Compte: '.$reglement_compte .' Montant: ' . $args->{montant} .'€ Libellé: ' . $args->{libelle} .'
	');
	
		my $varmenu ;	
		if (defined $args->{menu} && $args->{menu} ne '') {$varmenu = 'docsentry?id_name='.$args->{menu}} else { $varmenu = 'menu';}

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
			
			

	
	
	}
	}
# ACTION reglement_client FIN										  #
####################################################################### 


#######################################################################  
# ACTION reglement_fournisseur DEBUT										  #
    if ( defined $args->{reglement_fournisseur} and $args->{reglement_fournisseur} eq '0' ) {
		
		if 	(defined $args->{compte_client} && $args->{compte_client} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de compte fournisseur</h3>' ;	
		} elsif (defined $args->{select_achats} && $args->{select_achats} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de journal de réglement configuré</h3>' ;	
		} else {	
		my $confirm_href = '/'.$r->pnotes('session')->{racine}.'/menu?
		id_client=' . $r->pnotes('session')->{id_client} . '
		&amp;date_comptant=' . $args->{date_comptant} . '
		&amp;compte_fournisseur=' . $args->{compte_fournisseur} . '
		&amp;montant=' . $args->{montant} . '
		&amp;libelle=' . $args->{libelle} . '
		&amp;select_achats=' . $args->{select_achats} . '
		&amp;menu=' . $args->{menu}  . '
		&amp;docs1=' . $args->{docs1}  . '
		&amp;docs2=' . $args->{docs2}  . '
		&amp;reglement_fournisseur=1' ;
		my $deny_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Date: ' .$args->{date_comptant} . ' Client: '. $args->{compte_client} .' Journal: '.$args->{select_achats}.' Montant: ' . $args->{montant} .'€ Libellé: ' . $args->{libelle} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}
    } elsif ( defined $args->{reglement_fournisseur} and $args->{reglement_fournisseur} eq '1' ) {
	
	my ($journal, $month, $year) = '';
	
#récupération journal de réglement et compte de réglement

	$sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? and config_libelle = ?' ;
    my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{select_achats} ) ) ;
    	
	my $reglement_journal = $resultat->[0]->{config_journal};
	my $reglement_compte = $resultat->[0]->{config_compte};
	
#mise en forme montant pour enregistrement en bdd
	#ne pas laisser des montants nulls : mettre un zéro
	$args->{montant} ||= '0.00';
	#remplacer la virgule par le point dans les montants soumis
	$args->{montant} =~ s/,/./ ;
	#enlever les espaces de présentation
	$args->{montant} =~ s/\s//g ;
	
#calcul numéro de pièce auto
	$sql = 'SELECT libelle_journal, code_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_code_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	

	for ( @$journal_code_set ) {
	if ($reglement_journal =~ $_->[0]) {
		$journal = $_->[1];	
		} 
	}    
	    
	if ((defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<year>[0-9]{4}).*(?<month>[0-9]{2}).*(?<day>[0-9]{2})$/) {
	$month= substr($args->{date_comptant},5,2);
    $year= substr($args->{date_comptant},0,4);		
	} elsif (( defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
	$month= substr($args->{date_comptant},3,2);
    $year= substr($args->{date_comptant},6,4);	
	}
	
    my $item_num = 1;
    
	#on regarde s'il existe des factures enregistrées pour le mois et l'année de la date d'enregistrement
	$sql = '
	SELECT id_facture as item_number, extract(month from ?::date) as month_number, extract(year from ?::date) as year_number
	FROM tbljournal
	WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE ? and id_client = ? and fiscal_year = ? and libelle_journal = ? AND substring(id_facture from 8 for 2) = ?
	ORDER BY 1 DESC LIMIT 1
	' ;
	
	@bind_array = ( $args->{date_comptant}, $args->{date_comptant}, $journal, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $reglement_journal, $month ) ;
	my $calcul_piece = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;     
	
	for ( @$calcul_piece ) {
	if (substr( $_->{item_number}, 10, 2 ) =~ /\d/ && substr( $_->{item_number}, 0, 2 ) =~ /$journal/) {
	$item_num = int(substr( $_->{item_number}, 10, 2 )) + 1	;} 
	} 
	
	#my $format ='%0' . $1 . 'd' ;
	
	if ($item_num<10) {	$item_num="0".$item_num; }
	
	my $numero_piece = $journal . $year . '-' . $month . '_' . $item_num ;

#recherche du lettrage existant pour ce compte
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
    @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
    
    my $lettrage_total = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
    
    $sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND numero_compte = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{compte_client} ) ;
	
	my $lettrage = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;

    if ( $lettrage ) {

	$lettrage++ ;

    } else {
	
	if ($lettrage_total) {
	
	my $lettrage_sub = substr( $lettrage_total, 0, 2 );
	$lettrage = ++$lettrage_sub.'01';

    } else {
	
	$lettrage = 'AA01' ;
    }	
    }

#première écriture
	$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
	@bind_array = ( 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, $lettrage, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
	$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_fournisseur}, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
	$dbh->do( $sql, undef, @bind_array ) ;
	$sql = 'SELECT record_staging(?, ?)' ;
	eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	#erreur dans la procédure store_staging : l'afficher dans le navigateur
	if ( $@ ) {
		if ( $@ =~ /archived/ ) {
		$content .= '<h3 class=warning>Des dates d\'écriture se trouvent dans un mois archivé - Enregistrement impossible</h3>'	
		} else {
		$content .= '<h3 class=warning>' . $@ . '</h3>' ;
		}
    
    } else {
	Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm =>
	Ajout du réglement fournisseur : Date: ' .$args->{date_comptant} . ' Client: '. $args->{compte_client} .' Journal: '.$reglement_journal.' Compte: '.$reglement_compte .' Montant: ' . $args->{montant} .'€ Libellé: ' . $args->{libelle} .'
	');
	
			my $varmenu ;	
		if (defined $args->{menu} && $args->{menu} ne '') {$varmenu = 'docsentry?id_name='.$args->{menu}} else { $varmenu = 'menu';}

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
	}
	}
# ACTION reglement_fournisseur FIN									  #
####################################################################### 

    	#/************ ACTION FIN *************/#

	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

  
#####################################       
# Manipulation des dates			#
#####################################  
	my $date_comptant;
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	my $date_1 = localtime->strftime('%Y-%m-%d');
	my $date_2 = $r->pnotes('session')->{Exercice_fin_YMD} ;
	if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}
	
	my $contenu_web_doc .= '
	<div class="style1 card">
	<p class="card-text"></p>
    <br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/docs?import=0">Importer les données</a>
    </div>';

	my $contenu_web_etats .= '
	<div class="style1 card">
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/menu">Etats</a></div>
    <p class="card-text"></p>
    <a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0">Grand Livre</a>
	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/compte?balance=0">Balance</a>
   	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/bilan?bilan">Bilan</a>
   	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/bilan?resultat">Compte de Résultat</a>
   	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033A">Liasse 2033A</a>
   	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033B">Liasse 2033B</a>
   	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033C">Liasse 2033C</a>
    </div>
	';
	
	my $contenu_web_param .= '
	<div class="style1 card">
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/parametres">Paramètres</a></div>
    <p class="card-text"></p>
    <a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/parametres?societes">Gestion des sociétés</a>
	<br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/parametres?utilisateurs">Gestion des utilisateurs</a>
    <br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde">Gestion des sauvegardes</a>
    <br/><a style="margin-left: 1ch;" class="card-link" href="/'.$r->pnotes('session')->{racine}.'/parametres?logs">Logs</a>
    </div>
    ';
    
    #####################################       
	# Menu chekbox
	#####################################   
	#définition des variables
	my @checked = ('0') x 10;
	my @dispcheck = ('0') x 10;
	my $retour_href = 'javascript:history.go(-1)';
    
    #checked par défault label1 et 2
    unless (defined $args->{label1}) {$args->{label1} = 1;}
	#unless (defined $args->{label2}) {$args->{label2} = 1;}
	
	if (defined $args->{label1} && $args->{label1} eq 1) {$checked[1] = 'checked';} else {$checked[1] = '';}
	if (defined $args->{label2} && $args->{label2} eq 1) {$checked[2] = 'checked';} else {$checked[2] = '';}
	if (defined $args->{label3} && $args->{label3} eq 1) {$checked[3] = 'checked';} else {$checked[3] = '';}
	if (defined $args->{label4} && $args->{label4} eq 1) {$checked[4] = 'checked';} else {$checked[4] = '';}
	if (defined $args->{label5} && $args->{label5} eq 1) {$checked[5] = 'checked';} else {$checked[5] = '';}

	my $fiche_client .= '
	<div class=centrer>

	<div class="my-checkbox">


	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check1" class="forms2_label">Documentation</label>
	<input id="check1" type="checkbox" class="demo5" '.$checked[1].' onchange="submit()" name="label1" value=1>
	<label for="check1" class="forms2_label"></label>
	<input type=hidden name="label1" value=0 >
	<input type=hidden name="label2" value="' . ($args->{label2} || '') . '">
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label5" value="' . ($args->{label5} || ''). '">
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check2" class="forms2_label">Rechercher</label>
	<input id="check2" type="checkbox" class="demo5" '.$checked[2].' onchange="submit()" name="label2" value=1>
	<label for="check2" class="forms2_label"></label>
	<input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value=0 >
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label5" value="' . ($args->{label5} || ''). '">
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check3" class="forms2_label">Ecritures récurrentes</label>
	<input id="check3" type="checkbox" class="demo5" '.$checked[3].' onchange="submit()" name="label3" value=1>
	<label for="check3" class="forms2_label"></label>
	<input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value="' . ($args->{label2} || ''). '">
	<input type=hidden name="label3" value=0 >
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label5" value="' . ($args->{label5} || ''). '">
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check4" class="forms2_label">Transfert entre comptes</label>
	<input id="check4" type="checkbox" class="demo5" '.$checked[4].' onchange="submit()" name="label4" value=1>
	<label for="check4" class="forms2_label"></label>
	<input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value="' . ($args->{label2} || ''). '">
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value=0 >
	<input type=hidden name="label5" value="' . ($args->{label5} || ''). '">
	</form>
	
	<form method="post" action="' . $r->unparsed_uri() . '">
	<label for="check5" class="forms2_label">Paiement comptant</label>
	<input id="check5" type="checkbox" class="demo5" '.$checked[5].' onchange="submit()" name="label5" value=1>
	<label for="check5" class="forms2_label"></label>
	<input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value="' . ($args->{label2} || ''). '">
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label5" value=0 >
	</form>

	</div>	
		
	';
	
	my $forms_paiement_comptant = '<div class="style1 card" style="width: 100%; "> '.forms_paiement_comptant( $r, $args ).'</div>' ; 
	my $forms_appel_loyer = '<div class="style1 card" style="width: 100%; "> '.forms_appel_loyer( $r, $args ).'</div>' ; 
	my $forms_ecri_rec = '<div class="style1 card" style="width: 100%; "> '.forms_ecri_rec( $r, $args ).'</div>' ; 
	my $forms_transfert_compte = '<div class="style1 card" style="width: 100%; "> '.forms_transfert_compte( $r, $args ).'</div>' ;   
	my $forms_search = '<div class="style1 card" style="width: 100%; "> '.forms_search( $r, $args ).'</div>' ; 
	
	my $forms_documentation = forms_documentation( $r, $args ) ; 

	if (defined $args->{label1} && $args->{label1} eq 1) {$dispcheck[1] = $forms_documentation;} else {$dispcheck[1] = '';}
	if (defined $args->{label2} && $args->{label2} eq 1) {$dispcheck[2] = $forms_search;} else {$dispcheck[2] = '';}
	if (defined $args->{label3} && $args->{label3} eq 1) {$dispcheck[3] = $forms_ecri_rec;} else {$dispcheck[3] = '';}
	if (defined $args->{label4} && $args->{label4} eq 1) {$dispcheck[4] = $forms_transfert_compte;} else {$dispcheck[4] = '';}
	if (defined $args->{label5} && $args->{label5} eq 1) {$dispcheck[5] = $forms_paiement_comptant;} else {$dispcheck[5] = '';} 
		
	if ($result_reglement_set->[0]->{type_compta} eq 'tresorerie') {
	#$content .= '<div class="wrapper">' . $contenu_web_etats . $contenu_web_param .'</div>' ;
	$content .= '<div class="wrapper"></div>' ;
	} elsif ($r->pnotes('session')->{Exercice_Cloture} ne '1') {		
	#$content .= '<div class="wrapper">' . $fiche_client . $contenu_web_etats . $contenu_web_param . $dispcheck[5] . $dispcheck[3] . $dispcheck[4] . '</div>' ;
	$content .= '<div class="wrapper">' . $fiche_client . $dispcheck[2] . $dispcheck[5] . $dispcheck[3] . $dispcheck[4] . $dispcheck[1] . '</div>' ;
	
	} else {
	$content .= '<div class="wrapper">' . $fiche_client . $dispcheck[2] . $dispcheck[5] . $dispcheck[3] . $dispcheck[4] . $dispcheck[1] . '</div>' ;
	}

    return $content ;

} #sub menu5 

#/*—————————————— Formulaire Saisie achat en paiement comptant 	——————————————*/
sub forms_paiement_comptant {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my $content = '';

############## Manipulation des dates ##############
	my ($date_comptant, $montant_entry, $calcul_piece3);
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	#my $date_1 = localtime->strftime('%Y-%m-%d');
	#my $date_2 = $r->pnotes('session')->{Exercice_fin_DMY} ;
	#if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}	
	
	# récupération des variables de docsentry.pm
	if (defined $args->{date_doc_entry}) {
	$date_comptant = $args->{date_doc_entry} ;
	}
	
	if (defined $args->{montant_doc_entry}) {
	$montant_entry = $args->{montant_doc_entry} ;
	}
	
#####################################       
# Récupérations d'informations		#
#####################################  
	
	# on peut réutiliser la liste des journaux précédemment créée pour journal_tva
    my $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;
	
	#numero compte et libelle compte 40
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'40\') ORDER by libelle_compte' ;
    my $compte_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_comptant = '<select class="forms2_input" style="width: 35ch;" onchange="select_contrepartie_401(this, \'' . $r->pnotes('session')->{racine} . '\')" name=compte_comptant id=compte_comptant10>' ;
	$compte_comptant .= '<option value="" selected>--Sélectionner--</option>' ;
	for ( @$compte_set ) {
	$compte_comptant .= '<option value="' . $_->{numero_compte} . '">' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_comptant .= '</select>' ;
	
	#numero compte et libelle compte 60
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 1) IN (\'6\') ORDER by libelle_compte' ;
    my $compte_charge_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_charge_comptant = '<select class="forms2_input" style="width: 35ch;" name=compte_charge_comptant id=compte_charge_comptant>' ;
	$compte_charge_comptant .= '<option value="" selected>--Sélectionner--</option>' ;
	for ( @$compte_charge_set ) {
	$compte_charge_comptant .= '<option value="' . $_->{numero_compte} . '">' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_charge_comptant .= '</select>' ;
	
	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    #select_achats
	my $select_achats = '<select class="forms2_input" name=select_achats id=select_achats1 onchange="calcul_piece_achat(\'' . $r->pnotes('session')->{racine} . '\')">' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	$select_achats .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;

	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (libelle_cat_doc = \'Inter-exercice\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception
	' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my $id_name;
	my ($document_select1, $document_select2);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label8}){
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs10>
    <option value="" selected>--Sélectionner le document 1--</option>
    ' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs10>
    <option value="" >--Sélectionner le document 1--</option>
    ' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label9}){
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs20>
    <option value="" selected>--Sélectionner le document 2--</option>
    ' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs20>
    <option value="" >--Sélectionner le document 2--</option>
    ' ;
	}
	

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
		
		my $selected1 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1) ? 'selected' : '' ;
		my $selected2 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1) ? 'selected' : '' ;
			
		$document_select1 .= '
		<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>		
		' ;
		$document_select2 .= '
		<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>		
		' ;		
	    }
		$id_name = $_->{id_name} ;	
    }

    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
############## MISE EN FORME DEBUT ##############
 my $contenu_web_ach_comptant .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Saisie achat en paiement comptant</a></div>

    <form action="/'.$r->pnotes('session')->{racine}.'/menu">
    
    <div class="forms2_row">

        <div class="forms2_col">
        <label class="forms2_label" for="date_comptant20">Date</label>
		<input class="forms2_input" style="width: 15ch;" type="text" name=date_comptant id=date_comptant20 value="' . ($date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required>
		</div>

        <div class="forms2_col">
        <label class="forms2_label" for="compte_comptant10">Compte</label>
        ' . $compte_comptant . '
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="libelle1">Libellé</label>
		<input class="forms2_input" style="width: 80ch;" type=text id=libelle1 name=libelle value="" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist>
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="montant5">Montant</label>
        <input class="forms2_input" style="width: 20ch;" type=text id=montant5 name=montant value="'.($montant_entry || '').'" onchange="format_and_stage(this)" required/>
		</div>

		<div class="forms2_col">
        <label class="forms2_label" for="compte_charge_comptant">Compte de charge</label>
        ' . $compte_charge_comptant . '
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="select_achats1">Réglement</label>
        ' . $select_achats . '
		</div>  

		<div class="forms2_col">
		<label class="forms2_label" for="docs10">Documents 1</label>
		' . $document_select1 . '
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="docs20">Documents 2</label>
		' . $document_select2 . '
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="calcul_piece3">Pièce</label>
        <input class="forms2_input" style="width: 30ch;" type=text id=calcul_piece3 name=calcul_piece3 value="'.($calcul_piece3 || '').'" required/>
		</div>
		
		
	<input type=hidden name="achat_comptant" id="achat_comptant" value="0">
	<input type=hidden name="menu" id="menu" value="'.($args->{id_name} || '').'">
	<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 
	</div></form>
		';

	$content .= $contenu_web_ach_comptant;

    return $content ;
############## MISE EN FORME FIN ##############
    
    
} #sub forms_paiement_comptant 	
	
#/*—————————————— Formulaire Appel de loyer ——————————————*/
sub forms_appel_loyer {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my $content = '';

	
	#Fiscal year start format :
	my $select_month = '<select class="forms2_input" style="width: 30ch;" name=select_month id=select_month>
	<option value="01">Janvier</option>
	<option value="02">Février</option>
	<option value="03">Mars</option>
	<option value="04">Avril</option>
	<option value="05">Mai</option>
	<option value="06">Juin</option>
	<option value="07">Juillet</option>
	<option value="08">Août</option>
	<option value="09">Septembre</option>
	<option value="10">Octobre</option>
	<option value="11">Novembre</option>
	<option value="12">Décembre</option>
	</select>
	' ;
	
############## MISE EN FORME DEBUT ##############		
	my $contenu_web_appel_loyer .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Générer les appels de loyer</a></div>
	
    <form action="/'.$r->pnotes('session')->{racine}.'/menu">
    <div style="justify-content: center;"class="forms2_row">

		<div class="forms2_col">
        <label style="display: contents;"class="forms2_label" for="select_month">Sélectionner le mois</label>
        ' . $select_month . '
		</div>
	<input type=hidden name="appel_loyer" id="appel_loyer" value="0">
	<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 
	</div></form>
		';		

	$content .= $contenu_web_appel_loyer;

    return $content ;
############## MISE EN FORME FIN ##############

} #sub forms_appel_loyer 		

#/*—————————————— Formulaire Ecritures récurrentes ——————————————*/
sub forms_ecri_rec {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my $content = '';

	
	#Fiscal year start format :
	my $select_month = '<select class="forms2_input" style="width: 30ch;" name=select_month id=select_month>
	<option value="01">Janvier</option>
	<option value="02">Février</option>
	<option value="03">Mars</option>
	<option value="04">Avril</option>
	<option value="05">Mai</option>
	<option value="06">Juin</option>
	<option value="07">Juillet</option>
	<option value="08">Août</option>
	<option value="09">Septembre</option>
	<option value="10">Octobre</option>
	<option value="11">Novembre</option>
	<option value="12">Décembre</option>
	</select>
	' ;
	
############## MISE EN FORME DEBUT ##############		
	my $contenu_web_ecri_rec .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Générer les écritures récurentes</a></div>
	
    <form action="/'.$r->pnotes('session')->{racine}.'/menu">
    <div style="justify-content: center;"class="forms2_row">

		<div class="forms2_col">
        <label style="display: contents;"class="forms2_label" for="select_month">Sélectionner le mois</label>
        ' . $select_month . '
		</div>
	<input type=hidden name="ecriture_recurrente" id="ecriture_recurrente" value="0">
	<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 
	</div></form>
		';		

	$content .= $contenu_web_ecri_rec;

    return $content ;
############## MISE EN FORME FIN ##############

} #sub forms_ecri_rec 		
		
#/*—————————————— Formulaire Transfert entre comptes ——————————————*/
sub forms_transfert_compte {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
	    my ( $sql, @bind_array, $content  ) ;
		my $calcul_piece;
		
#####################################       
# Manipulation des dates			#
#####################################  
	my ($date_comptant, $montant_entry);
	
	# récupération des variables de docsentry.pm
	if (defined $args->{date_doc_entry}) {
	$date_comptant = $args->{date_doc_entry} ;
	}
	
	if (defined $args->{montant_doc_entry}) {
	$montant_entry = $args->{montant_doc_entry} ;
	}
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	#my $date_1 = localtime->strftime('%Y-%m-%d');
	#my $date_2 = $r->pnotes('session')->{Exercice_fin_YMD} ;
	#if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}
		
#####################################       
# Requête SQL						#
#####################################  

my ($compte_var, $reglement_journal_1, $journal1, $month, $year) ;



    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    

    #select_achats
	my $select_achats = '<select class="login-text" name=select_achats id=select_achats2>' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	$select_achats .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;
	
    #id_compte_1_select
	my $id_compte_1_select = '<select class="forms2_input" style="width: 30ch;" onchange="calcul_piece_journal(this, \'' . $r->pnotes('session')->{racine} . '\')" name=id_compte_1_select id=id_compte_1_select>' ;
	$id_compte_1_select .= '<option value="" selected>--Choix Compte--</option>' ;
	for ( @$resultat_tblconfig ) {
	$id_compte_1_select .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$id_compte_1_select .= '</select>' ;
	
	#id_compte_2_select
	my $id_compte_2_select = '<select class="forms2_input" style="width: 30ch;" name=id_compte_2_select id=id_compte_2_select>' ;
	$id_compte_2_select .= '<option value="" selected>--Choix Compte--</option>' ;
	for ( @$resultat_tblconfig ) {
	$id_compte_2_select .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$id_compte_2_select .= '</select>' ;
	
	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (libelle_cat_doc = \'Inter-exercice\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception
	' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my $id_name;
	my ($document_select1, $document_select2);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label8}){
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs11>
    <option value="" selected>--Sélectionner le document 1--</option>
    ' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs11>
    <option value="" >--Sélectionner le document 1--</option>
    ' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label9}){
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs21>
    <option value="" selected>--Sélectionner le document 2--</option>
    ' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs21>
    <option value="" >--Sélectionner le document 2--</option>
    ' ;
	}
	

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
		
		my $selected1 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1) ? 'selected' : '' ;
		my $selected2 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1) ? 'selected' : '' ;
			
		$document_select1 .= '
		<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>		
		' ;
		$document_select2 .= '
		<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>		
		' ;		
	    }
		$id_name = $_->{id_name} ;	
    }

    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
    
	############## MISE EN FORME DEBUT ##############

	#fonction javascript qui efface le lien de téléchargement si l'utilisateur modifie la date
	#ce dernier doit alors cliquer sur 'Valider' pour que le lien réapparaisse avec la nouvelle date
	# + document.getElementById => affichage des options via le bouton
	#my $contenu_web_move_compte .= '<script>var update_nom_periode = function(input) {document.getElementById("nom_periode").value = input.options[input.selectedIndex].text}</script>' ;


	my $contenu_web_move_compte .= '
	
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Transfert entre comptes</a></div>
	
	<span class="memoinfo">Mémo: total débit du relevé = total credit du 512 et total crédit du relevé => total débit du 512</span>
	<br>
		
    <form action="/'.$r->pnotes('session')->{racine}.'/menu">
    <div class="forms2_row">

        <div class="forms2_col">
        <label class="forms2_label" for="date_comptant">Date</label>
		<input class="forms2_input" style="width: 15ch;" type="text" name=date_comptant id=date_comptant value="' . ($date_comptant || '') . '"  pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" onblur="calcul_piece_date(this, \'' . $r->pnotes('session')->{racine} . '\')" required>
		
		</div>

        <div class="forms2_col">
        <label class="forms2_label" for="id_compte_1_select">Transfert de :</label>
        ' . $id_compte_1_select . '
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="id_compte_2_select">vers :</label>
        ' . $id_compte_2_select . '
		</div>
		  
        <div class="forms2_col">
        <label class="forms2_label" for="libelle2">Libellé</label>
		<input class="forms2_input" style="width: 80ch;" type=text id=libelle2 name=libelle value="" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist>
		</div>
		
   
		<div class="forms2_col">
            <label class="forms2_label" for="montant2">Montant</label>
            <input class="forms2_input" style="width: 20ch;" type=text id=montant2 name=montant value="'.($montant_entry || '').'"  required/>
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="calcul_piece">Pièce</label>
        <input class="forms2_input" style="width: 30ch;" type=text id=calcul_piece name=piece value="'.($calcul_piece || '').'" required/>
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="docs11">Documents 1</label>
		' . $document_select1 . '
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="docs21">Documents 2</label>
		' . $document_select2 . '
		</div>
		
		<input type=hidden name="move_compte" id="move_compte" value="0">
		<input type=hidden name="menu" id="menu" value="'.($args->{id_name} || '').'">
		<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 

	</div></form>
	    <br/>
		';	
		
	$content .= $contenu_web_move_compte;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_transfert_compte 

#/*—————————————— Formulaire Saisie reglement client 	——————————————*/
sub forms_reglement_client {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my $content = '';

############## Manipulation des dates ##############
	my ($date_comptant, $montant_entry, $id_docs);
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	#my $date_1 = localtime->strftime('%Y-%m-%d');
	#my $date_2 = $r->pnotes('session')->{Exercice_fin_DMY} ;
	#if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}	
	
	# récupération des variables de docsentry.pm
	if (defined $args->{date_doc_entry}) {
	$date_comptant = $args->{date_doc_entry} ;
	}
	
	if (defined $args->{montant_doc_entry}) {
	$montant_entry = $args->{montant_doc_entry} ;
	}
	
	if (defined $args->{docs_doc_entry}) {
	$id_docs = $args->{docs_doc_entry} ;
	}
	
#####################################       
# Récupérations d'informations		#
#####################################  
	
	# on peut réutiliser la liste des journaux précédemment créée pour journal_tva
    my $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;
	
	#numero compte et libelle client 41
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'41\') ORDER by libelle_compte' ;
    my $compte_client_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_client = '<select class="forms2_input" style="width: 35ch;" name=compte_client id=compte_client>' ;
	$compte_client .= '<option value="" selected>--Choix client--</option>' ;
	for ( @$compte_client_set ) {
	$compte_client .= '<option value="' . $_->{numero_compte} . '">' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_client .= '</select>' ;
	
	
	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    #select_achats
	my $select_achats = '<select class="forms2_input" name=select_achats id=select_achats2>' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	$select_achats .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;

	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (libelle_cat_doc = \'Inter-exercice\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception
	' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my $id_name;
	my ($document_select1, $document_select2,$calcul_piece);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label8}){
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs12>
    <option value="" selected>--Sélectionner le document 1--</option>
    ' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs12>
    <option value="" >--Sélectionner le document 1--</option>
    ' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label9}){
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs22>
    <option value="" selected>--Sélectionner le document 2--</option>
    ' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs22>
    <option value="" >--Sélectionner le document 2--</option>
    ' ;
	}
	

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
		
		my $selected1 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1) ? 'selected' : '' ;
		my $selected2 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1) ? 'selected' : '' ;
			
		$document_select1 .= '
		<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>		
		' ;
		$document_select2 .= '
		<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>		
		' ;		
	    }
		$id_name = $_->{id_name} ;	
    }

    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
############## MISE EN FORME DEBUT ##############
 my $contenu_web_reglement .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Saisie d\'un réglement client</a></div>

    <form action="/'.$r->pnotes('session')->{racine}.'/menu">
    
    <div class="forms2_row">

        <div class="forms2_col">
        <label class="forms2_label" for="date_comptant2">Date</label>
		<input class="forms2_input" style="width: 15ch;" type="text" name=date_comptant id=date_comptant2 value="' . ($date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required>
		</div>

		<div class="forms2_col">
        <label class="forms2_label" for="compte_client">Client</label>
        ' . $compte_client . '
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="libelle1">Libellé</label>
		<input class="forms2_input" style="width: 80ch;" type=text id=libelle1 name=libelle value="" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist>
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="montant6">Montant</label>
        <input class="forms2_input" style="width: 20ch;" type=text id=montant6 name=montant value="'.($montant_entry || '').'" onchange="format_and_stage(this)" required/>
		</div>

		<div class="forms2_col">
        <label class="forms2_label" for="select_achats2">Réglement</label>
        ' . $select_achats . '
		</div>  

		<div class="forms2_col">
		<label class="forms2_label" for="docs12">Documents 1</label>
		' . $document_select1 . '
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="docs22">Documents 2</label>
		' . $document_select2 . '
		</div>
    
  
	<input type=hidden name="reglement_client" id="reglement_client" value="0">
	<input type=hidden name="menu" id="menu" value="'.($args->{id_name} || '').'">
	<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 
	</div></form>
		';

	$content .= $contenu_web_reglement;

    return $content ;
############## MISE EN FORME FIN ##############
    
    
} #sub forms_reglement_client 	

#/*—————————————— Formulaire Saisie reglement fournisseur 	——————————————*/
sub forms_reglement_fournisseur {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
		my $content = '';

############## Manipulation des dates ##############
	my ($date_comptant, $montant_entry);
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	#my $date_1 = localtime->strftime('%Y-%m-%d');
	#my $date_2 = $r->pnotes('session')->{Exercice_fin_DMY} ;
	#if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}	
	
	# récupération des variables de docsentry.pm
	if (defined $args->{date_doc_entry}) {
	$date_comptant = $args->{date_doc_entry} ;
	}
	
	if (defined $args->{montant_doc_entry}) {
	$montant_entry = $args->{montant_doc_entry} ;
	}
	
#####################################       
# Récupérations d'informations		#
#####################################  
	
	# on peut réutiliser la liste des journaux précédemment créée pour journal_tva
    my $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;
	
	#numero compte et libelle fournisseur 40
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'40\',\'44\') ORDER by libelle_compte' ;
    my $compte_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_fournisseur = '<select class="forms2_input" style="width: 35ch;" name=compte_fournisseur id=compte_fournisseur onselect=>' ;
	$compte_fournisseur .= '<option value="" selected>--Choix fournisseur--</option>' ;
	for ( @$compte_set ) {
	$compte_fournisseur .= '<option value="' . $_->{numero_compte} . '">' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_fournisseur .= '</select>' ;

	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal FROM tblconfig_liste WHERE id_client = ? ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    #select_achats
	my $select_achats = '<select class="forms2_input" name=select_achats id=select_achats3>' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	$select_achats .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;

	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (libelle_cat_doc = \'Inter-exercice\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception
	' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my $id_name;
	my ($document_select1, $document_select2);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label8}){
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs13>
    <option value="" selected>--Sélectionner le document 1--</option>
    ' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 50ch;" name=docs1 id=docs13>
    <option value="" >--Sélectionner le document 1--</option>
    ' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs_doc_entry} && !defined $args->{label9}){
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs23>
    <option value="" selected>--Sélectionner le document 2--</option>
    ' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 50ch;" name=docs2 id=docs23>
    <option value="" >--Sélectionner le document 2--</option>
    ' ;
	}
	

    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
		
		my $selected1 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1) ? 'selected' : '' ;
		my $selected2 = ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1) ? 'selected' : '' ;
			
		$document_select1 .= '
		<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>		
		' ;
		$document_select2 .= '
		<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>		
		' ;		
	    }
		$id_name = $_->{id_name} ;	
    }

    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
############## MISE EN FORME DEBUT ##############
 my $contenu_web_reglement .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Saisie d\'un réglement fournisseur</a></div>

    <form action="/'.$r->pnotes('session')->{racine}.'/menu">
    
    <div class="forms2_row">

        <div class="forms2_col">
        <label class="forms2_label" for="date_comptant21">Date</label>
		<input class="forms2_input" style="width: 15ch;" type="text" name=date_comptant id=date_comptant21 value="' . ($date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required>
		</div>

		<div class="forms2_col">
        <label class="forms2_label" for="compte_fournisseur">Fournisseur</label>
        ' . $compte_fournisseur . '
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="libelle1">Libellé</label>
		<input class="forms2_input" style="width: 80ch;" type=text id=libelle1 name=libelle value="" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist>
		</div>
		
		<div class="forms2_col">
        <label class="forms2_label" for="montant7">Montant</label>
        <input class="forms2_input" style="width: 20ch;" type=text id=montant7 name=montant value="'.($montant_entry || '').'" onchange="format_and_stage(this)" required/>
		</div>

		<div class="forms2_col">
        <label class="forms2_label" for="select_achats3">Réglement</label>
        ' . $select_achats . '
		</div>  

		<div class="forms2_col">
		<label class="forms2_label" for="docs13">Documents 1</label>
		' . $document_select1 . '
		</div>
		
		<div class="forms2_col">
		<label class="forms2_label" for="docs23">Documents 2</label>
		' . $document_select2 . '
		</div>
    
	<input type=hidden name="reglement_fournisseur" id="reglement_fournisseur" value="0">
	<input type=hidden name="menu" id="menu" value="'.($args->{id_name} || '').'">
	<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 
	</div></form>
		';

	$content .= $contenu_web_reglement;

    return $content ;
############## MISE EN FORME FIN ##############
    
    
} #sub forms_reglement_fournisseur 	

#/*—————————————— Formulaire recherche d'écriture ——————————————*/
sub forms_search {

	# définition des variables
		my ( $r, $args ) = @_ ;
		my $dbh = $r->pnotes('dbh') ;
	    my ( $sql, @bind_array, $content  ) ;

#####################################       
# Manipulation des dates			#
#####################################  
	my ($date_comptant, $montant_entry);
		
#####################################       
# Requête SQL						#
#####################################  
	
	#recherche de la liste des documents enregistrés
    $sql = 'SELECT id_name, date_reception, montant/100::numeric as montant, libelle_cat_doc, fiscal_year, check_banque, last_fiscal_year, id_compte FROM tbldocuments WHERE id_name = ? AND id_client = ?' ;
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $args->{id_name}, $r->pnotes('session')->{id_client} ) ;
	
	############## Choix du numero compte ##############	
	#tous les comptes
	my $select_all_compte='';
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER by numero_compte' ;
    my $compte_all_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_all = '<select class="forms2_input" style="width: 40ch;" name=search_compte id=search_compte>' ;
	
	if (!defined $args->{search_compte} || $args->{search_compte} eq ''){
	$compte_all .= '<option value="" selected>--Choix Compte--</option>' ;
	} else {
	$select_all_compte = $args->{search_compte};
	}

	for ( @$compte_all_set ) {
	my $selected = ( $_->{numero_compte} eq $select_all_compte) ? 'selected' : '' ;	
	$compte_all .= '<option value="' . $_->{numero_compte} . '" '.$selected.'>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_all .= '<option value="">--Choix Compte--</option>';
	$compte_all .= '</select>' ;
	
	
    my ($compte_var, $reglement_journal_1, $journal1, $month, $year, $var_search_montant, $var_search_lib) ;


	#####################################       
	#Rechercher des entrées du journal
	#####################################    
	my $propo_list .= '';

    if ((defined $args->{search_date} && $args->{search_date} ne '')|| (defined $args->{search_lib} && $args->{search_lib} ne '') || (defined $args->{search_compte} && $args->{search_compte} ne '')|| (defined $args->{search_montant} && $args->{search_montant} ne '') ) {
	
	my $search_date = ( defined $args->{search_date} && $args->{search_date} ne '' ) ? ' AND t1.date_ecriture = ?' : '' ;
	my $search_lib = ( defined $args->{search_lib} && $args->{search_lib} ne '' ) ? ' AND t1.libelle ILIKE ?' : '' ;
	my $search_compte = ( defined $args->{search_compte} && $args->{search_compte} ne '') ? ' AND t1.numero_compte = ?' : '' ;
	my $search_montant = ( defined $args->{search_montant} && $args->{search_montant} ne '') ? ' AND (t1.debit::TEXT ILIKE ? OR t1.credit::TEXT ILIKE ?)' : '' ;

	$sql = '
	SELECT t1.id_entry, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit
	FROM tbljournal t1
	WHERE t1.id_client = ? AND t1.fiscal_year = ? '.$search_date.' '. $search_lib . ' '.$search_compte . ' '.$search_montant .'
	ORDER BY date_ecriture, id_entry, id_line
	' ;
	
	if (defined $args->{search_montant} && $args->{search_montant} ne ''){
	$var_search_montant = '%' . $args->{search_montant} . '%' ;
	}
	
	if (defined $args->{search_lib} && $args->{search_lib} ne ''){
	$var_search_lib = '%' . $args->{search_lib} . '%' ;
	}

	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	
	#ne pas ajouter le paramètre tant que condition est vrai
    push @bind_array, $args->{search_date} unless ( $args->{search_date} eq '' ) ;
    push @bind_array, $var_search_lib unless ( $args->{search_lib} eq '') ;
    push @bind_array, $args->{search_compte} unless ( $args->{search_compte} eq '' ) ;
    push @bind_array, $var_search_montant , $var_search_montant unless ( $args->{search_montant} eq '') ;
    
    #Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'docsentry.pm => Rechercher montant: '.$args->{search_montant}.' date : '.$args->{search_date}.' libellé : '.$args->{search_lib}.' compte : '.$args->{search_compte}.'');

	$propo_list .= '
	<ul class="wrapper style1">
   ' ;

	my $result_set = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;

	#ligne d'en-têtes
    $propo_list .= '
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=headerspan style="width: 8%;">Date</span>
	<span class=headerspan style="width: 8%;">Libre</span>
	<span class=headerspan style="width: 8%;">Journal</span>
	<span class=headerspan style="width: 8%;">Compte</span>
	<span class=headerspan style="width: 12%;">Pièce</span>
	<span class=headerspan style="width: 29.9%;">Libellé</span>
	<span class=headerspan style="width: 8%; text-align: right;">Débit</span>
	<span class=headerspan style="width: 8%; text-align: right;">Crédit</span>
	<span class=headerspan style="width: 5%; text-align: center;">&nbsp;</span>
	<span class=headerspan style="width: 5%; text-align: center;">&nbsp;</span>
	<div class=spacer></div></div></li>
	' ;

	my $id_entry = '' ;
    
    for ( @$result_set ) {

	#si on est dans une nouvelle entrée, clore la précédente et ouvrir la suivante
	unless ( $_->{id_entry} eq $id_entry ) {

	    #lien de modification de l'entrée
	    my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;

	    #cas particulier de la première entrée de la liste : pas de liste précédente
	    unless ( $id_entry ) {
		$propo_list .= '<li class=listitem>' ;
	    } else {
		$propo_list .= '</a></li><li class=listitem>'
	    } #	    unless ( $id_entry ) 

	} #	unless ( $_->{id_entry} eq $id_entry ) 

	#marquer l'entrée en cours
	$id_entry = $_->{id_entry} ;
	
	#pour le journal général, ajouter la colonne libelle_journal
	#my $libelle_journal = ( $args->{open_journal} eq 'Journal général' ) ? '<span class=blockspan style="width: 25ch;">' . $_->{libelle_journal} . '</span>' : '' ;

	my $http_link_documents1 = '';
	my $http_link_documents2 = '';
	if ( $_->{documents1} =~ /docx|odt|pdf|jpg/) { 
    my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
    my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents1} ) ;
		if ($id_name_documents->[0]->{id_name} || '') {
		$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img style="border: 0;" src="/Compta/images/documents.png" height="16" width="16" alt="documents"></a>' ;
		} else {
		$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
		} 
	} 	
	if ( $_->{documents2} =~ /docx|odt|pdf|jpg/) { 
	my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
    my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents2} ) ;
    	if ($id_name_documents->[0]->{id_name} || '') {
		$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img style="border: 0;" src="/Compta/images/releve-bancaire.png" height="16" width="16" alt="releve-bancaire"></a>' ;	
		} else {
		$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
		} 
	} 
	
	 #lien de modification de l'entrée
	 my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;


	$propo_list .= '
	<div class=flex-table><div class=spacer></div><a href="' . ($id_entry_href || ''). '" >
	<span class=displayspan style="width: 8%;">' . $_->{date_ecriture} . '</span>
	<span class=displayspan style="width: 8%;">' . $_->{id_paiement} . '</span>
	<span class=displayspan style="width: 8%;">' . $_->{libelle_journal} .'</span>
	<span class=displayspan style="width: 8%;">' . $_->{numero_compte} . '</span>
	<span class=displayspan style="width: 12%;">' . $_->{id_facture} . '</span>
	<span class=displayspan style="width: 29.9%;">' . $_->{libelle} . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' . $_->{debit} . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' .  $_->{credit} . '</span>
	<span style="margin-left: 2ch;">' . ($http_link_documents1 || '<img src="&nbsp;" alt="" height="16" width="16">' ) . '</span>
	<span style="margin-left: 2ch;">' . ($http_link_documents2 || '<img src="&nbsp;" alt="" height="16" width="16">' ) . '</span>
	<div class=spacer>
	</div>
	</div>
	' ;

    } #    for ( @$result_set ) 

    #on clot la liste s'il y avait au moins une entrée dans le journal
    $propo_list .= '</a></li>' if ( @$result_set ) ;

    #pour le journal général, ajouter la colonne libelle_journal
    #$libelle_journal = ( $args->{open_journal} eq 'Journal général' ) ? '<span class=blockspan style="width: 25ch;">&nbsp;</span>' : '' ;
    
    $propo_list .=  '<li class=listitem><hr></li>
    <li class=listitem><div class=flex-table><div class=spacer></div>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 12%;">&nbsp;</span>
	<span class=blockspan style="width: 29.9%; text-align: right;">Total</span>
	<span class=blockspan style="width: 8%; text-align: right;">' . ( $result_set->[0]->{total_debit} || 0 ) . '</span>
	<span class=blockspan style="width: 8%; text-align: right;">' . ( $result_set->[0]->{total_credit} || 0 ) . '</span>
	</span><div class=spacer></div></li></ul>' ;

	}
    
	############## MISE EN FORME DEBUT ##############

	my $contenu_search .= '
	
	<div class="Titre10 centrer">Rechercher des entrées du journal</div>

	<form method=POST><div class="forms2_row">

        <div class="forms2_col">
            <label class="forms2_label" for="search_date">Date</label>
			<input class="forms2_input" style="width: 15ch;" type=text id=search_date name=search_date value="' . ($args->{search_date} || ''). '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')"/>
        </div>
          
        <div class="forms2_col">
            <label class="forms2_label" for="search_lib">Libellé</label>
			<input class="forms2_input"  style="width: 60ch;" type=text id=search_lib name=search_lib value="' . ($args->{search_lib} || ''). '" onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\')" list="libellelist"><datalist id="libellelist"></datalist> 
		</div>
		
		<div class="forms2_col">
            <label class="forms2_label" for="search_compte">Compte</label>
			' .  $compte_all . '
		</div>
		  
		<div class="forms2_col">
            <label class="forms2_label" for="search_montant">Montant</label>
            <input class="forms2_input" style="width: 15ch;" type=text id=search_montant name=search_montant value="' . ($args->{search_montant} || ''). '" />
		</div>
		
    <input type=hidden name=search value="1" >
    <input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value="' . ($args->{label2} || ''). '">
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label5" value="' . ($args->{label5} || ''). '">
    <input type=hidden name="label6" value="' . ($args->{label6} || ''). '">
    <input type=hidden name="label7" value="' . ($args->{label7} || ''). '">  
    <input type=hidden name="label8" value="' . ($args->{label8} || ''). '">
	<input type=hidden name="label9" value="' . ($args->{label9} || ''). '">  
	<input type="submit" class="btnform1 vert" style="width: 20ch; height: 5ch; " value="Valider"> 
	</div></form><br/>
		';	
		
	$content .= $contenu_search . $propo_list;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_search 

      
# Définitions des sidebars			#
##################################### 
#/*—————————————— side_bar_1 => Premiers pas ——————————————*/
sub side_bar_1 {
	my $content = "
		<li class='titre-link'>Premiers pas</li>
		<li><a href='#introduction'>Fonctionnement général</a></li>
		<li><a href='#journaux'>Journaux</a></li>
		<li><a href='#comptes'>Comptes</a></li>
		<li><a href='#documents'>Documents</a></li>
		<li><a href='#ecriturescomptables'>Ecritures comptables</a></li>
		<li><a href='#format'>Format des dates d'écriture</a></li>
		<li><a href='#lettrage'>Lettrage et Pointage</a></li>
		<li><a href='#parametres'>Paramètres</a></li>
		<li><a href='#raccourcis_clavier'>Raccourcis clavier</a></li>
		<li><a href='#tva'>Déclaration de TVA</a></li>
 		<li><a href='#liasse_fiscale'>Liasse fiscale</a></li>
	";
	 return $content ;
} #sub side_bar_1 

#/*—————————————— side_bar_2 => Courant ——————————————*/
sub side_bar_2 {
	my $content = "
 		<li class='titre-link' >Courant</li>
 		<li><a href='#affectation'>Affectation du résultat</a></li>
		<li><a href='#cca'>Comptes Courants Associés</a></li>
		<li><a href='#ecarts'>Ecarts de règlement</a></li>
		<li><a href='#declaration'>Les déclarations</a></li>
		<li><a href='#paiementcheque'>Paiement Chèque</a></li>
		<li><a href='#paiementespece'>Paiement Espèce</a></li>
		<li><a href='#paiementvirement'>Paiement Virement</a></li>
		<li><a href='#travaux_periodiques'>Travaux periodiques</a></li>
	";
	 return $content ;
} #sub side_bar_new 

#/*—————————————— side_bar_3 => Utilitaires  ——————————————*/
sub side_bar_3 {
	my $content = "
		<li class='titre-link'>Utilitaires</li>    
		<li><a href='#exportations'>Exportations</a></li>
		<li><a href='#importations'>Importations</a></li>    
	";
	 return $content ;
} #sub side_bar_new 

#/*—————————————— side_bar_4 => Fin d'exercice  ——————————————*/
sub side_bar_4 {
	my $content = "
		<li class='titre-link'>Début et fin d'exercice</li> 
		<li><a href='#reconduite'>Début d'exercice</a></li>
		<li><a href='#cloture'>Clôture d'exercice</a></li>
		<li><a href='#prepcloture'>Check-list avant clôture</a></li>
		<li><a href='#calcul_du_bilan'>Opérations de calcul du bilan</a></li>
	";
	 return $content ;
} #sub side_bar_4 

#/*—————————————— side_bar_5 => Utilitaires  ——————————————*/
sub side_bar_5 {
	my $content = "
		<li class='titre-link'>Paramétrage</li> 
		<li><a href='#version'>Gestion des versions</a></li>
	";
	 return $content ;
} #sub side_bar_5 


# Définitions des articles			#
#####################################  
#/*—————————————— articles_bar1 => Premiers pas ——————————————*/
sub articles_bar1 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;
	my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 
    
    
    # sélection du journal pour formulaire
    $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_1 premier pas
    $content .= "
        
    <section id='introduction' class='main-section'>
		<header class='header'><h3>Fonctionnement général</h3></header><hr class='hrperso'>
			<p>compta.libremen.com est un outil d\'enregistrement et de restitution d\'écritures comptables.</p>
			<p>Son utilisation suppose que l\'utilisateur possède les connaissances minimales d\'un aide-comptable.</p>
			
			<p>Le menu principal contenant cette documentation est disponible à tout moment via clic sur l'icône de la balance en haut à gauche du site.</p>
			<p><a href=".$r->pnotes('session')->{racine}." title='Retour vers Menu'><img height='50' width='64' src='/Compta/style/logo.png' alt='Logo'></a></p>
			
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='journaux' class='main-section'>
			<header class='header'><h3>Journaux</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>le Journal Général (<a href='journal'>Journaux</a>) est constitué de l'ensemble des écritures des journaux auxiliaires</p>
			<form action=/".$r->pnotes('session')->{racine}."/menu >Toutes les écritures sont inscrites dans les journaux auxiliaires, en utilisant le lien 'Nouvelle entrée' en haut à gauche de chaque journal
			(Accès rapide => " . $journal_entree . "
			<input type=submit style='width: 17ch;' class='btnform2 vert' value='Nouvelle Entrée'> )</form>
			<p>L'utilisateur peut créer autant de journaux qu'il le souhaite (<a href='journal?edit_journal_set=0'>Journaux => Modifier la liste</a>)</p>
			<p>Les journaux de type 'Achats' et 'Ventes' offrent une fonction d'enregistrement automatique des paiements dans le journal de votre choix, avec reprise des dates, des libellés et des montants de débit/crédit inversés;
			<br>Pour cela, cliquer dans l'écriture et utiliser le lien '--Choix Règlement--' du formulaire de saisie .</p>
			<p>Seuls les journaux OD, CLOTURE et A-NOUVEAUX sont obligatoires et non modifiables</p>
			<p>A chaque nouvel exercice il faut reconduire les journaux via <a href='journal?edit_journal_set=0&reconduire=0'>Journaux => Modifier la liste => Reconduire les journaux de l'exercice précédent</a></p>
			<p>Les filtres de recherche peuvent être réinitialisés en cliquant sur le lien R (* R 01 02 03 04 ...)</p>
			<p>check1 permet de filtrer les écritures lettrées mais non équilibrées (<a href='journal?open_journal=Journal%20général&mois=0&equilibre=true'>check1</a>) </p>
			<p>Recurrent permet de filtrer les écritures servant à générer des écritures récurrentes.  (<a href='journal?open_journal=Journal%20général&mois=0&recurrent=true'>Récurrent</a>)</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='comptes' class='main-section'>
			<header class='header'><h3>Comptes</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Il est possible d'éditer la liste des comptes depuis le Menu <a href='compte?edit_compte_set=0'>Comptes => Modifier la liste</a></p>
			<p>La liste des comptes peut être importée depuis le Menu <a href='compte?edit_compte_set=0&import=0'>Comptes => Modifier la liste => Importer</a></p>
			<p>Le fichier texte doit contenir pour chaque ligne deux valeurs séparées par un point virgule (1ère valeur = numéro de compte, 2ème valeur = libellé du compte, 3ème valeur = compte de contrepartie). <strong>Le fichier doit être encodé en UTF-8</strong>, avec en-tête (comptenum,comptelib,contrepartie) ou sans en-tête. Exemple :</p>
			<pre>
			comptenum;comptelib;contrepartie
			401PUBN;PUBLICATIONS;
			401FDIV;F DIVERS;
			401PAPE;PAPETERIE;606800
			</pre>
			<p>Les comptes peuvent être exporté depuis le Menu <a href='export?select_export=liste_comptes'>Export => Liste des comptes pour l'exercice en cours</a></p>
			<p>Les comptes peuvent comporter autant de décimales que souhaité</p>
			<p>Il est également possible de sélectionner un compte de contrepartie qui sera repris automatiquement lors du choix d'un paiement comptant</p>
			<p>La liste peut être reconduite chaque année via le Menu <a href='compte?edit_compte_set=0&reconduire=0'>Comptes => Modifier la liste => Reconduire</a>; cette opération reconduit également les réglages du menu <a href=\"index.html#liasse_fiscale\">Liasse Fiscale</a> sur le nouvel exercice</p>
			<p>Les soldes des comptes de bilan sont reportables sur le nouvel exercice via le Menu <a href='compte?reports=0'>Comptes -> Reports</a></p>
			<p>La clôture des comptes en fin d'année se fait depuis le menu <a href='compte?cloture=0'>Comptes => Clôture</a></p>
			<p><a href='compte?balance=0'>Balance</a> et <a href='compte?grandlivre=0'>Grand Livre</a> sont disponibles via les liens en haut de page</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='documents' class='main-section'>
			<header class='header'><h3>Documents</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>le menu <a href='docs'>Documents</a> affiche tous les documents enregistrés sur l'exercice en cours.</p>
			<p>Il est possible d'ajouter des documents depuis le Menu <a href='docs?new_document=0'>Documents => Ajouter un document</a></p>
			<p>L'utilisateur peut créer autant de catégorie de document qu'il le souhaite (<a href='docs?edit_cat_doc_set=0'>Documents => Modifier la liste </a>)
			<p>Seuls les catégories Temp et Inter-exercice sont obligatoires et non modifiables</p>
			<p>Lors de l'ajout d'un document celui-ci est automatiquement placé dans la catégorie Temp</p>
			<p>Les documents placés dans Inter-exercice ne sont modifiables que depuis l'exercice non cloturé auquel ils ont été uploadés.</p>
			<p>Les documents Inter-exercice sont disponibles pour les tous les exercices tant que \"Last exercice\" n'est pas renseigné</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='ecriturescomptables' class='main-section'>
			<header class='header'><h3>Ecritures Comptables</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Les écritures peuvent être déplacées d'un journal à un autre via le lien 'Déplacer' du formulaire de saisie</p>
			<p>Elles peuvent également être extournées et dupliquées via le lien 'Extourner' et 'Dupliquer' du même formulaire</p>
			<p>Pour qu'un écriture soit définie comme écriture récurrente cocher la case à droite et valider<p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
                
    </div>
            
	<section id='format' class='main-section'>
		<header class='header'><h3>Format des dates d'écriture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Il est possible de régler le format d'affichage des dates dans le Menu <a href='parametres?utilisateurs'>Paramètres => Utilisateurs => Modifier</a> ( AAAA-MM-JJ ou JJ/MM/AAAA)</p>
		<p>Pour la saisie, plusieurs formats et séparateurs sont acceptés : 2020-02-25 ou 25/02/2020 ou 25#02#2020 ou 2020 02 25. <br>
		L'année doit être écrite sur 4 chiffres</p>
		<p>Voir les <a href=\"index.html#raccourcis_clavier\">raccourcis clavier</a> pour une saisie rapide</p>
		<p><strong>N.B.</strong>: il existe une séparation physique entre les exercices. Le changement d'exercice se fait en cliquant sur le titre 'Exercice XXXX', en haut de page.</p>
		<p>L'utilisateur peut travailler sur plusieurs onglets à la fois (en utilisant Click-droit ou Ctrl-Click) mais toujours dans le même exercice.<br>
		Si l'utilisateur souhaite travailler sur deux exercices différents en même temps, il doit utiliser deux navigateurs différents, un pour chaque exercice</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
  
	<section id='lettrage' class='main-section'>
		<header class='header'><h3>Lettrage et Pointage</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Tous les comptes peuvent être pointés, lettrés et rapprochés</p> 
		<div>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='parametres' class='main-section'>
		<header class='header'><h3>Paramètres</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Il existe deux options de calcul de la TVA due : débits ou encaissements; voir le chapitre <a href=\"index.html#ca3\">Déclaration de TVA (formulaire CA3)</a>; la période de calcul peut être mensuelle ou trimestrielle</p>
		<p>L'option 'Journal de TVA' permet de sélectionner le journal d'enregistrement des écritures résultant du calcul de la TVA due</p>
		<p>L'option 'Activer les règlements par défaut' permet de sélectionner automatiquement le journal et le numéro de compte à utiliser pour l'enregistrement des règlements/paiements; les enregistrements des factures émises ou reçues sont reprises automatiquement, les montants des débits/crédits étant affectés au compte sélectionné</p>
		<p>Il existe deux options pour le format d'affichage des dates : le format classique (JJ/MM/AAAA) et le format ISO 8601 (AAAA-MM-JJ); le format est paramétrable pour chaque utilisateur du compte</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>	
  
 	<section id='raccourcis_clavier' class='main-section'>
		<header class='header'><h3>Raccourcis clavier du formulaire de saisie d'une écriture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<img src=\"/Compta/images/saisie.png\" alt=\"Formulaire de saisie d'une écriture\">
		<p>Date : il est possible de taper par exemple \"0225\" (JJMM, sans les guillemets); la date sera alors complétée avec l'année en cours et formatée pour obtenir 2020-02-25 ou 05/02/2020, suivant l'option d'affichage sélectionnée par l'utilisateur dans le menu 'Paramètres'</p>
		<p>Les cases au fond grisé reproduisent automatiquement la valeur de la ligne précédente</p>
		<p>Compte : taper les premiers chiffres pour obtenir une fenêtre déroulante affichant les comptes disponibles. Seuls les comptes enregistrés dans le menu 'Comptes' pour l'exercice en cours sont acceptés</p>
		<p>Pièce : le symbole '&rarr;' indique un calcul automatique du numéro; taper \"Espace\"; les factures fournisseurs sont au format \"MD...D\" où M est la lettre du mois (janvier = A, février = B...) et D...D le numéro de la pièce pour le mois (01, 02...); le numéro de pièce peut comporter jusqu'à 5 décimales (voir le menu 'Paramètres'). Pour les factures de ventes, le numéro est une séquence pluriannuelle continue qui ajoute 1 à la dernière valeur enregistrée</p>
		<p>Libellé : le symbole '&rarr;' indique une recopie automatique de la ligne précédente; taper \"Espace\"</p>
		<p>Les lignes dont le débit et le crédit valent O (zéro) sont ignorées lors de la validation</p>
		<p>Les signes '+' et '-' sur les côtés du formulaire permettent respectivement d'ajouter et de retirer une ligne</p>
	".$hidden[21]."
	".$hidden[20]."
	</section> 
  
	<section id='tva' class='main-section'>
		<header class='header'><h3>Déclaration de TVA (formulaire CA3)</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Dans le menu TVA, sélectionner la période à déclarer puis cliquer sur 'Valider'; le logiciel affiche alors une réplique partielle du formulaire 3310CA3 (visible sur impots.gouv.fr), avec un calcul des champs principaux à renseigner. <strong>Les périodes de déclaration correspondent à la période en cours et celles de l'année qui précède</strong>. Le formulaire ne peut donc pas être utilisé pour les dates antérieures de plus de 12 mois à la date du jour, mais il est possible d'enregistrer manuellement des écritures antérieures</p>
		<p>En cliquant sur 'Valider' en bas du formulaire, les écritures à passer sont affichées dans le formulaire de saisie d'une écriture et peuvent y être modifiées si besoin</p>
		<p>Le calcul de la TVA exigible est fait à partir des montants enregistrés dans les comptes de classe 7, pour lesquels on paramètre le pourcentage de TVA applicable. Ce calcul peut être fait sur les débits ou sur les encaissements</p>
		<p>Si l'option choisie est <strong>'TVA sur encaissements'</strong>, le logiciel calcule la TVA collectée sur la période à partir des comptes 7 qui sont lettrés et non pointés; il faut donc dans ce cas, pour obtenir une déclaration conforme :</p>
		<ul>
		<li>Lettrer les comptes clients après encaissement de la facture; le lettrage est enregistré dans la ligne des comptes 7 concernés par l'écriture lettrée</li>
		<li>Calculer la TVA due et enregistrer les écritures</li>
		<li>Pointer les écritures des comptes de classe 7 précédemment lettrées, pour qu'elles n'apparaissent plus dans les déclarations suivantes</li>
		</ul>
		<p>L'option <strong>'TVA sur débits'</strong> calcule la TVA due sur l'ensemble des factures enregistrées dans la période considérée<p>
		<p>Il est possible dans ce cas d'enregistrer des ventes de services (TVA exigible à l'encaissement), en utilisant des comptes d'attente :</p>
		<ul>
		<li>Créer un ou plusieurs compte 418 'Ventes non taxables', un compte 44578 'tva collectée non exigible', et un ou plusieurs comptes 7 paramétrés à 0% de TVA et terminés par '*'</li>
		<li>Enregistrer les ventes dans ces comptes</li>
		<li>Lors du règlement, extourner l'écriture initiale, puis enregistrer la vente dans les comptes 411, 4457 et les comptes de classe 7 normaux à la date du règlement</li>
		<li>Calculer la TVA due pour la période</li>
		</ul> 
	".$hidden[21]."
	".$hidden[20]."
	</section>  
  
  	<section id='liasse_fiscale' class='main-section'>
			<header class='header'><h3>Liasse fiscale</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#liasse_fiscale_1' >Quelle liasse fiscale ?</a></li>
		<li><a class=summary href='#liasse_fiscale_2' >Générer la liasse fiscale gratuitement via TELEDEC</a></li>
		<li><a class=summary href='#liasse_fiscale_3' >Les points clés de la liasse fiscale</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>
		
		<div class=intro2>
		<p>Le pré-remplissages des formulaires <a href='bilan?liasse2033A'>2033A</a> <a href='bilan?liasse2033B'>2033B</a> et <a href='bilan?liasse2033C'>2033C</a> sont disponibles via le menu Bilan (<a href='bilan?liasse2033A'>Bilan => 2033A / 2033B / 2033C</a>)</p>
		</div>	
				
		<hr class=mainPageTutoriel>
			
		<div id='liasse_fiscale_1'>	
		<p class=title1>Quelle liasse fiscale ?</p>
		<p>À l’IS, il existe deux régimes : <strong>R</strong>égime <strong>S</strong>implifié ou <strong>R</strong>égime <strong>N</strong>ormal.</p>
		<ul><li><h4>Cas 1 : régime simplifié d’imposition (RS)</h4></li></ul>
		
		<p>Si vous êtes en régime simplifié d’imposition, votre liasse fiscale est la 2065 et les annexes à déclarer sont les formulaires 2033 A, B, C, D, E, F, G.</p>
		
		<p>Vous avez la possibilité d'effectuer la déclarations de résultats directement sur votre compte \"professionnel\" sur <a href='https://www.impots.gouv.fr/accueil'>impots.gouv.fr</a> => Rubrique \"Déclarer résultat\" ou par par l’intermédiaire d’un partenaire EDI (mode EDI-TDFC)</p>
	
		<p>Important : Le régime simplifié d’imposition ne concerne que les entreprises dont le chiffre d’affaires HT est inférieur à :</p>
		<ul><li>238 000 € pour les activités de prestation de services.</li>
		<li>789 000 € pour les autres activités (vente de marchandises, hébergement).</li></ul>
		<p><div class='label yellow'>Remarque :</div> l’intérêt unique mais essentiel du régime simplifié d’imposition est l’allégement des formalités fiscales de fin d’année</p>

		<ul><li><h4>Cas 2 : régime normal d’imposition (RN)</h4></li></ul>

		<p>Si vous dépassez les seuils ci dessus, vous êtes en régime normal d’imposition, votre liasse fiscale est la 2065 et les annexes à déclarer sont les formulaires 2050 à 2057, 2058 A, B, C et 2059 A, B, C, D, E, F, G.
		</p>
		<p>Concernant la déclarations de résultats, vous êtes dans l'obligation de passer par l’intermédiaire d’un partenaire EDI (mode EDI-TDFC)</p>
		<p><div class='label yellow'>Conseil :</div> ne choisissez le régime normal que si vous dépassez les seuils de chiffre d’affaires.</p>	
		

		</div>	
			
			<hr class=mainPageTutoriel>
		
			<div id='liasse_fiscale_2'>	
			<p class=title1>Générer la liasse fiscale gratuitement via TELEDEC</p>
			<p>Vous pouvez réaliser gratuitement votre liasse fiscale avec édition papier via <a href='https://www.teledec.fr/se-connecter'>TELEDEC</a></p>
			<p>TELEDEC est un partenaire EDI agréé par l'état seul la télédéclaration est payante</p>
			<p>Après avoir terminé la comptabilité de votre exercice télécharger la balance via le menu balance (<a href='compte?balance=0'>Balance => Télécharger</a>)     </p>	
			<p>Depuis TELEDEC, confirmer les informations de l'exercice et de la liasse fiscale, puis cliquer sur Autres actions => Remplir cette liasse à partir d'un logiciel comptable => sélectionner le fichier de balance et cliquer sur importer</p>
			<p>Il ne vous reste qu'à vous laissez guider dans les étapes de vérification et génération de la liasse fiscale.</p>
			</div>		
			
			<hr class=mainPageTutoriel>		
			
			<div id='liasse_fiscale_3'>	
			<p class=title1>Les points clés de la liasse fiscale</p>
			<ul><li><h4>Le formulaire 2033A</h4></li></ul>
			<p class=tab1>Ne pas oublier la case 195 \"Dont dettes à plus d'un an\" avec par exemple le montant du capital restant dû du crédit immobilier en date de fin d'exercice</p>
			<ul><li><h4>Le formulaire 2033B</h4></li></ul>
			<ul><li><h4>Le formulaire 2033C</h4></li></ul>
			</div>	
		
			<hr class=mainPageTutoriel>	
			
			

	".$hidden[21]."
	".$hidden[20]."
	</section>
        ";
    
    $hidden[25] = "
    <div>
    <a href='#paiementcheque'><span class='tags'>#cheque</span></a>
	<a href='#paiementespece'><span class='tags'>#espece</span></a>
	<a href='#paiementvirement'><span class='tags'>#virement</span></a>
	<a href='#top'><span class='tags'>#top</span></a> 
	</div>
	";        
	
	
	 return $content ;
} #sub articles_bar1 

#/*—————————————— articles_bar2 => Courant ——————————————*/
sub articles_bar2 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_2 Courant - affectation du résultat  
	my $content .= "
	<section id='affectation' class='main-section'>
    	<header class='header'><h3>Affectation du résultat</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#affectation_1' >Comptabilisation de l'affectation du résultat dans une société</a></li>
		<li><a class=summary href='#affectation_2' >Comptabilisation de l'affectation du résultat dans une entreprise individuelle</a></li>
		<li><a class=summary href='#affectation_3' >Comptabilisation de l'affectation du résultat dans une association</a></li>
		</ul>
		
    <hr class=mainPageTutoriel>
			
	<p>Lorsque vous clôturez votre exercice, les comptes de charges et de produits sont soldés et le montant du résultat est enregistré dans le compte « résultat » (n°120 si c’est un bénéfice, 129 si c’est une perte). Cette affectation est automatique dans la procédure de clôture.</p>
    <p>Une deuxième écriture devra être passée, au cours de l’exercice suivant, après la tenue de l’assemblée générale annuelle, pour affecter ce résultat.</p>
	<p>L'affectation dépend de votre structure juridique et des décisions prises.</p>
	
	<hr class=mainPageTutoriel>

	
    <details id=affectation_1 class=warningdoc open><summary class=title1>Comptabilisation de l'affectation du résultat dans une société</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Dans une société, le résultat est affecté en fonction de la décision de l'assemblée générale prise au plus tard dans les 6 mois de la fin de l'exercice. Si le résultat est une perte, il est généralement affecté au compte N° 119... \"report à nouveau (solde débiteur)\". Si le résultat est un bénéfice, il peut être affecté en :
	</p>
			
<ul><li><h4>Report à nouveau (solde créditeur) : N° 110...</h4></li></ul>
	
	<p class=tab1>
	Le report à nouveau permet aux associés ou actionnaires de décider de laisser tout ou partie des bénéfices en report à nouveau, ce qui signifie que le montant reste en instance d'affectation jusqu'à la prochaine assemblée. Un report à nouveau créditeur est donc constaté, il pourra être distribué en dividendes, apurer les déficits antérieurs ou postérieurs, affecté en réserves, augmenter le capital.
	</p>

	<ul><li><h4>Réserves : N° 106...</h4></li></ul>
	<p class=tab1>	Une partie du bénéfice doit être obligatoirement affecté à la \"Réserve légale\", compte N° 106100 (5 % du bénéfice jusqu'à ce que la réserve atteigne 10 % du capital).
	<br>Les autres réserves 1068 sont des sommes mises à la disposition de la société qui en principe ne peuvent pas être touchées par les associés. Elles permettent de valoriser les capitaux propres.
	</p>

	<ul><li><h4>Associés, Dividendes à Payer : N° 457...</h4></li></ul>
	<p class=tab1>Le compte 457 Associés - dividende à payer est un compte temporaire, l'inscription ne vaut pas paiement et n'entraîne pas l'exigibilité des retenues à la source ( Le paiement des dividendes devra s’effectuer dans les 9 mois suivant la clôture de l’exercice et permettra de solder le compte 457)</p>

	<p>
	Généralement les bénéfices sont comptabilisés en report à nouveau en début d'activité afin que ceux-ci épongent d'éventuels déficits. Une fois que le report à nouveau est assez conséquent, il peut être utile de doter les autres réserves. Le cas échéant il vous reste la possibilité de les distribuer sous forme de dividendes.
Il est toujours possible de distribuer les autres réserves en dividendes (sauf si vos statuts l'en empêche) ou d'imputer des déficits dessus mais ce n'est par définition pas le but des autres réserves.
	</p>
	<p>En cas de déficits ultérieurs, au niveau de la présentation du bilan vous pouvez décider de :
<br>- laisser les autres réserves et comptabiliser un report à nouveau débiteur
<br>- diminuer les autres réserves du montant du déficit
<br>Si vous optez pour la première option, les bénéfices futurs devront être utilisés en priorité pour apurer le report à nouveau débiteur avant d'envisager une distribution de dividendes ou doter de nouveau les autres réserves.

Deuxième chose, il faudra surveiller également que vos capitaux propres ne soient pas inférieurs à la moitié du capital social.</p>

	
	<hr class=mainPageTutoriel>
	<p class=classp>Cas d'un bénéfice avec RAN N-1 bénéficaire</p>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>110</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau N-1 (créditeur)</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>120</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - bénéfice</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1061</div>
		  <div class='cell' data-title='Intitulé'>Réserve légale</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>limite 10% du capital</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1063</div>
		  <div class='cell' data-title='Intitulé'>Réserves statuaires</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1068</div>
		  <div class='cell' data-title='Intitulé'>Autres réserves</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>110</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde créditeur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>119</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde débiteur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>457</div>
		  <div class='cell' data-title='Intitulé'>Associés - dividende à payer</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas d'un bénéfice avec RAN N-1 déficitaire</p>
	
	<p >Exemple : Affectation du bénéfice de 1500 € pour solder le RAN N-1 débiteur de 1000€ , 100€ pour la réserve légale, 100€ en autres réserves et dividendes à payer pour le solde </p>
	
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>120</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - bénéfice</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1500</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>119</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde débiteur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1000</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1061</div>
		  <div class='cell' data-title='Intitulé'>Réserve légale</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>100</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1068</div>
		  <div class='cell' data-title='Intitulé'>Autres réserves</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>100</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>457</div>
		  <div class='cell' data-title='Intitulé'>Associés - dividende à payer</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>300</div>
		</div>
	</div></div>
	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas d'une perte</p>
	
	<p>Lorsque le résultat est une perte, il est très souvent affecté dans le compte « report à nouveau » dans l’attente de bénéfices futurs qui viendront le compenser.
			</p>
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>129</div>
		  <div class='cell' data-title='Intitulé'> Résultat de l'exercice - pertes</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1000</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>119</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde débiteur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1000</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>

		
	</div></div>
	<hr class=mainPageTutoriel>
	</details>
	
	<details id=affectation_2 class=alert open><summary class=title1>Comptabilisation de l'affectation du résultat dans une entreprise individuelle</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Dans une entreprise individuelle, le résultat est généralement affecté dans le \"compte de l'exploitant\" N° 10800000, le 1er jour du nouvel exercice.
	</p>
	<hr class=mainPageTutoriel>
	<p class=classp>Cas d'un bénéfice</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>120</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - bénéfice</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1500</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>101</div>
		  <div class='cell' data-title='Intitulé'>Capital individuelle</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat/div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1500</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	<p class=classp>Cas d'un déficit</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>129</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - perte</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1500</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>101</div>
		  <div class='cell' data-title='Intitulé'>Capital individuelle</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1500</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	</details>
	
	<details id=affectation_3 class=info open><summary class=title1>Comptabilisation de l'affectation du résultat dans une association</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Dans une association, la distribution de dividendes est impossible. Le Résultat vient donc augmenter ou diminuer le \"report à nouveau\", les \"réserves\" ou le \"fonds associatif\" (compte N° 10200000).
	</p>
		
	<hr class=mainPageTutoriel>
	
	</details>

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	
	#cat_2 Courant Section comptes courants associés
	$content .= "
	<section id='cca' class='main-section'>
		<header class='header'><h3>Comptes Courants Associés</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#cca_1' >Comptabilisation des intérêts des comptes courants associés</a></li>
		<li><a class=summary href='#cca_2' >Remboursement d'un compte courant d'associé</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=cca_1 class=warningdoc open><summary class=title1>Comptabilisation des intérêts des comptes courants associés</summary>

	<hr class=mainPageTutoriel>
	
	<p>Lors du versement des intérêts des comptes courants associés</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>455</div>
		  <div class='cell' data-title='Intitulé'>Associé Compte courant</div>
		  <div class='cell' data-title='Libellé'>INTERET CCA 202*</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant net (60€)</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>4425</div>
		  <div class='cell' data-title='Intitulé'>État – Impôts et taxes</div>
		  <div class='cell' data-title='Libellé'>INTERET CCA 202*</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Part impôts (30€)</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>6615</div>
		  <div class='cell' data-title='Intitulé'>Intérêt des comptes courants</div>
		  <div class='cell' data-title='Libellé'>INTERET CCA 202*</div>
		  <div class='cell' data-title='Débit'>Montant brut des intérêts (90€)</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>
	
	<p>Par la suite, lorsque l’état prélève le montant</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>Prélevement SIE</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Part impôts (30€)</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>4425</div>
		  <div class='cell' data-title='Intitulé'>État – Impôts et taxes</div>
		  <div class='cell' data-title='Libellé'>Prélevement SIE</div>
		  <div class='cell' data-title='Débit'>Part impôts (30€)</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>
	<hr class=mainPageTutoriel>
	</details>
	
	
	<details id=cca_2 class=alerte open><summary class=title1>Remboursement d'un compte courant d'associé</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>virement cca du</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
				<div class='row'>
		  <div class='cell' data-title='Comptes'>455</div>
		  <div class='cell' data-title='Intitulé'>Associé Compte courant</div>
		  <div class='cell' data-title='Libellé'>virement cca du </div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	#cat_2 Courant section ecarts de reglement DEBUT
	$content .= "
	<section id='ecarts' class='main-section'>
	<header class='header'><h3>Ecarts de règlement</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#ecarts_1' >Ecarts de règlement positifs</a></li>
		<li><a class=summary href='#ecarts_2' >Ecarts de règlement négatifs</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=ecarts_1 class=warningdoc open><summary class=title1>Ecarts de règlement positifs</summary>

	<hr class=mainPageTutoriel>
	<p>
	La différence de règlement, lorsqu’elle est en faveur de l’entreprise, est dite positive. Il pourra s’agir des cas suivants :
	<p> une entreprise reçoit sur son compte bancaire une somme plus importante de la part de son client</p>	
	<p> une entreprise paie à son fournisseur un montant moindre que celui figurant sur la facture</p>	
	<p> une entreprise s’acquitte de ses cotisations sociales pour une somme légèrement inférieure à celle figurant dans ses comptes (de
l’ordre de quelques centimes).</p>	
	</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401/411</div>
		  <div class='cell' data-title='Intitulé'>Fournisseurs/Clients</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'>écart</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>758</div>
		  <div class='cell' data-title='Intitulé'>Produits divers gestion courante</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>écart</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=ecarts_2 class=alerte open><summary class=title1>Ecarts de règlement négatifs</summary>

	<hr class=mainPageTutoriel>
	<p>
	A l’inverse, lorsque les différences de règlement sont en la défaveur de l’entreprise, ils sont négatifs. Il s’agit principalement des cas
suivants :
<p>une entreprise perçoit de la part de son client une somme moindre que celle figurant sur la facture de vente,</p>
<p>une entreprise règle une somme plus importante à son fournisseur que celui figurant sur la facture d’achat,</p>
<p>une entreprise s’acquitte de ses cotisations sociales pour une somme légèrement supérieure à celle figurant dans ses comptes.</p>
	</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>658</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'>écart</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401/411</div>
		  <div class='cell' data-title='Intitulé'>Fournisseurs/Clients</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>écart</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

	";	#cat_2 Courant section ecarts de reglement FIN
	
	
	
	
	#cat_2 Courant - les déclarations  
	$content .= "
	<section id='declaration' class='main-section'>
		<header class='header'><h3>Les déclarations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
    
    	<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#declaration_1' >Déclaration 2777</a></li>
		<li><a class=summary href='#declaration_2' >Déclaration 2561 IFU</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=declaration_1 class=warningdoc open><summary class=title1>Déclaration 2777</summary>

	<hr class=mainPageTutoriel>
	<p>
	Sont concernés le paiement des intérêts des comptes courants d'associés ou bien le paiement des dividendes
	<p> à produire le 15 du mois qui suit le paiement donc pour un versement au 31/12 déclaration avant 15/01</p>
	
	<p>La déclaration 2777 réalise désormais la collecte du prélèvement forfaitaire sur les revenus distribués, au taux de 12,8%, ce qui permet donc d’arriver au taux global de 30% (soit 17,2% + 12,8%) constituant le prélèvement forfaitaire unique ou PFU.	
	</p>
	<p>Le paiement du PFU se fait par prélèvement en ligne sur le compte de la société
	<p>Le contribuable aura la possibilité de renoncer au mécanisme du prélèvement forfaitaire à 12,8% lors du dépôt de sa déclaration d’impôt sur le revenu.
	</p></p></p>	
	
	<hr class=mainPageTutoriel>
	</details>
	
	<details id=declaration_2 class=alerte open><summary class=title1>Déclaration 2561 IFU</summary>

	<hr class=mainPageTutoriel>
	<p>
	Concerne les sociétés ayant versé des dividendes et/ou des intérêts de compte courant à leurs associés au titre de l’année civile précédente.
	</p>
	<p>Il faut déclarer une fois par an l'IFU en N+1, et avant le 15/02</p>
	<p>Le formulaire reprend toutes les déclarations de revenus de capitaux mobiliers de l'année.</p>
	<p>On ne le fait pas via son espace pro sur IMPOT GOUV mais sur un espace dédié au TIERS DECLARANT, dont il faut demander ses identifiants au préalable

	<p><a href='https://www.impots.gouv.fr/portail/tiers-declarants'>Tiers déclarants | impots.gouv.fr</a>  et cliquer sur Accès à la déclaration en ligne des données</p>

	<p>Il faut faire une déclaration par société (par SIRET), donc par tiers déclarant, avec par société autant de ligne que des personnes à déclarer</p>
	<ul><li><h4>Les dividendes</h4></li></ul>
	<p class=tab1>Indiquez dans la « case AY » le montant brut des dividendes versés (c’est-à-dire avant paiement de l’impôt et des prélèvements sociaux).
	</p>
	<ul><li><h4>Les intérêts de compte courant d’associé</h4></li></ul>
	<p class=tab1>Indiquez dans la « case AR » le montant brut des intérêts de compte courant d’associé versés.</p>
	<ul><li><h4>Les prélèvements sociaux</h4></li></ul>
	<p class=tab1>En principe, il convient de reporter dans la « case DQ » le montant brut des dividendes et intérêts de compte courant versés à l’associé.
	</p>
	<ul><li><h4>Le prélèvement forfaitaire non libératoire (PFNL)</h4></li></ul>
	<p class=tab1>Dans la « case AD » indiquez le montant du PFNL de 12,80% qui a été prélevé à la source lors du versement des dividendes et des intérêts de compte courant. Il s’agit du montant figurant sur la déclaration 2777.</p>
	<p class=tab1>Cette case doit rester vide uniquement si l’associé a demandé à être dispensé du PFNL.</p>
	
	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	
	#cat_2 Courant section paiementcheque
	$content .= "
	<section id='paiementcheque' class='main-section'>
	<header class='header'><h3>Paiement Chèque</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
	    <hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#paiementcheque_1' >Comptabilisation en tant que vendeur => Réglement du client par chèque</a></li>
		<li><a class=summary href='#paiementcheque_2' >Comptabilisation en tant qu'acheteur => Réglement au fournisseur par chèque</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=paiementcheque_1 class=warningdoc open><summary class=title1>Comptabilisation en tant que vendeur => Réglement du client par chèque</summary>

	<hr class=mainPageTutoriel>
	<p class=classp>Cas avec utilisation directe du compte 512 banque</p>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'>Montant chèque</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant chèque</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas avec utilisation du compte intermédiaire 5112 chèques à encaisser</p>
	
	<p>D’abord : À chaque fois que l’entreprise réceptionne le chèque d’un client</p>
		
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD (ou de chèque à encaisser) / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>5112</div>
		  <div class='cell' data-title='Intitulé'>Chèque à encaisser</div>
		  <div class='cell' data-title='Libellé'>N° du chèque de client</div>
		  <div class='cell' data-title='Débit'>Montant chèque</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>N° du chèque de client</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant chèque</div>
		</div>
	</div></div>

	<p>Ensuite : Lors de la remise en banque d’un ensemble de chèques reçus des clients</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de remise des chèques</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'>Total remise</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>5112</div>
		  <div class='cell' data-title='Intitulé'>Chèques à encaisser</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Total remise</div>
		</div>
	</div></div><hr class=mainPageTutoriel>
	
	</details>
	
	<details id=paiementcheque_2 class=alerte open><summary class=title1>Comptabilisation en tant qu'acheteur => Réglement au fournisseur par chèque</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° de chèque</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de chèque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	
		
	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	
		";
		
	#cat_2 Courant section paiementespece DEBUT
	$content .= "
	<section id='paiementespece' class='main-section'>
	<header class='header'><h3>Paiement Espèce</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#paiementespece_1' >Comptabilisation en tant que vendeur => Réglement du client en espèce</a></li>
		<li><a class=summary href='#paiementespece_2' >Comptabilisation en tant qu'acheteur => Réglement au fournisseur en espèce</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=paiementespece_1 class=warningdoc open><summary class=title1>Comptabilisation en tant que vendeur => Réglement du client en espèce</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de caisse</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>530</div>
		  <div class='cell' data-title='Intitulé'>Caisse</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=paiementespece_2 class=alerte open><summary class=title1>Comptabilisation en tant qu'acheteur => Réglement au fournisseur en espèce</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de caisse</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>530</div>
		  <div class='cell' data-title='Intitulé'>Caisse</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

	";	#cat_2 Courant section paiementespece FIN
		
	#cat_2 Courant section paiementvirement DEBUT
	$content .= "
	<section id='paiementvirement' class='main-section'>
	<header class='header'><h3>Paiement Virement</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#paiementvirement_1' >Comptabilisation en tant que vendeur => Réglement du client par virement</a></li>
		<li><a class=summary href='#paiementvirement_2' >Comptabilisation en tant qu'acheteur => Réglement au fournisseur en virement</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=paiementvirement_1 class=warningdoc open><summary class=title1>Comptabilisation en tant que vendeur => Réglement du client par virement</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=paiementvirement_2 class=alerte open><summary class=title1>Comptabilisation en tant qu'acheteur => Réglement au fournisseur en virement</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";	#cat_2 Courant section paiementvirement FIN

	#cat_2 Courant Section travaux_periodiques
	$content .= "
		<section id='travaux_periodiques' class='main-section'>
		<header class='header'><h3>Travaux periodiques</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Voici la check-list des tâches à faire tous les mois</p>
		  <ul class=checklist>
		  <li>Saisir les pièces comptables</li>
		  <li>Saisir les opérations de banque</li>
		  <li>Lettrer les comptes clients</li>
		  <li>Lettrer les comptes de tiers</li>
		  <li>Lettrer les comptes 467 débiteurs/créditeurs</li>
		  <li>Vérifier le solde du compte 471 qui doit être à 0 €</li>
		  <li>Vérifier le solde du compte 580 qui doit être à 0 €</li>
		  <li>Faire le rapprochement bancaire</li>
		</ul>
	".$hidden[22]."
	".$hidden[20]."
	</section>	
	";	
	
	 return $content ;
} #sub articles_bar2 

#/*—————————————— articles_bar3 => Utilitaires ——————————————*/
sub articles_bar3 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_2 Courant Section comptes courants associés
	my $content .= "
	
  	<section id='exportations' class='main-section'>
    <header class='header'><h3>Exportations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>Le menu 'Export' permet d'exporter et d'archiver les écritures enregistrées dans la base</p>
	<h4>Options d'exportation</h4>
	<ul>
  <li>liste des comptes</li>
  <li>Fichier d'exportation FEC conforme aux dispositions prévues à l'article A47 A-1 du livre des procédures fiscales contenant toutes les écritures enregistrées dans l'exercice</li>
  <li>Ensemble des données enregistrées dans la base pour l'exercice (le format 'Données')</li>
  <li>Écritures archivées</li>
	</ul>
	<p>Il existe deux types d'archivage : mensuel et incrémentiel<br>
  <strong>L'archivage mensuel</strong> permet d'archiver un mois de l'exercice. Après archivage, il n'est plus possible d'ajouter, modifier ou supprimer des écritures pour ce mois. Les écritures d'un mois archivé peuvent être téléchargées au format FEC ou au format 'Données', qui contient toutes les données enregistrées dans le logiciel. On clique sur le numéro du mois pour déclencher l'archivage.<br>
  <strong>L'archivage incrémentiel</strong> permet d'archiver toutes les écritures non encore enregistrées, sans considération de date. Les écritures archivées incrémentiellement ne peuvent plus être modifiées ni supprimées, mais il est possible d'ajouter de nouvelles écritures.<br>
  Les deux modes d'archivage peuvent être utilisés ensemble ou séparément</p>
	<p>Exemple de fichier d'exportation tel qu'il apparaît dans un tableur :</p>
	<table style=\"text-align: left; border: thin solid #444;\">
  <tr><th>id_entry</th><th> date</th><th>numéro de pièce</th><th>libellé</th><th>débit</th><th>crédit</th><th> libre</th><th>numéro de compte</th><th>exercice</th><th>journal</th><th>lettrage</th><th>pointage</th><th> date_validation</th></tr>
  <tr><td>11114</td><td>2016-01-01</td><td>A03</td><td>SNCF paris</td><td style=\"text-align: right;\">        84,00</td><td style=\"text-align: right;\">         0,00</td><td>A51</td><td>401SNCF</td><td>2016</td><td>Banque</td><td>a</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>11114</td><td>2016-01-01</td><td>A03</td><td>SNCF paris</td><td style=\"text-align: right;\">         0,00</td><td style=\"text-align: right;\">        84,00</td><td>A51</td><td>5121CRA</td><td>2016</td><td>Banque</td><td>a</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         9,99</td><td style=\"text-align: right;\">         0,00</td><td></td><td>611010</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         0,00</td><td style=\"text-align: right;\">        11,99</td><td></td><td>401SERV</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         2,00</td><td style=\"text-align: right;\">         0,00</td><td></td><td>4456600</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
	</table>
	".$hidden[23]."
	".$hidden[20]."
	</section>
  
  	<section id='importations' class='main-section'>
			<header class='header'><h3>Importations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Il est possible d'importer des écritures dans l'exercice en cours à partir du Journal Général (lien 'Importer des écritures', en haut de page).<strong> Le fichier à fournir doit être encodé au format UTF-8</strong>, sans en-tête, et se conformer au format ci-dessous. Les champs obligatoires sont précédés d'une étoile (*). Séparateurs de champs : \";\" (point-virgule)</p>
			<p>L'importation des écritures est totale, si aucune erreur n'est détectée. Sinon, aucune écriture n'est importée, et un message d'erreur affiche la liste des écritures empêchant l'importation</p>
			<p>Les écritures doivent être équilibrées par date, numéro de pièce et libellé</p>
			<table style=\"text-align: left; border: thin solid #444;\">
		  <tr><th></th><th>Nom du champ</th><th>Type de données</th><th>Remarques</th></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Journal</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\">le journal doit être présent dans l'exercice d'importation</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Date d'écriture</td><td style=\"border-bottom: 1px solid black;\">Date</td><td style=\"border-bottom: 1px solid black;\">Plusieurs formats et séparateurs sont acceptés : 2020-02-25 ou 25/02/2020 ou 25#02#2020 ou 2020 02 25</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Libre</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Numéro de compte</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\">Le numéro de compte doit être présent dans la liste des comptes de l'exercice d'importation</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Numéro de pièce</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Libellé</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Débit</td><td style=\"border-bottom: 1px solid black;\">Numérique</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Crédit</td><td style=\"border-bottom: 1px solid black;\">Numérique</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Lettrage</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Pointage</td><td style=\"border-bottom: 1px solid black;\">Booléen</td><td style=\"border-bottom: 1px solid black;\">2 valeurs possibles : (t)rue or (f)alse. En l'absence de données, la valeur enregistrée est 'False', non pointé</td></tr>
			</table>
	".$hidden[23]."
	".$hidden[20]."
		</section>
	";	
	
	 return $content ;
} #sub articles_bar3 

#/*—————————————— articles_bar4 => Fin d'exercice ——————————————*/
sub articles_bar4 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_4 Fin d'exercice
	my $content .= "

	<section id='reconduite' class='main-section'>
		<header class='header'><h3>Début d'exercice</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#reconduite_1' >Nouvel exercice comptable</a></li>
		<li><a class=summary href='#reconduite_2' >Premier exercice comptable</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>
		
		<div id='reconduite_1'>	
		<p class=title1>Nouvel exercice comptable</p>
		<p>En début d'un nouvel exercice, il faut reprendre le plan comptable de l'année précédente (les journaux et les comptes) et générer les à nouveaux (écritures d'ouverture qui reprennent le solde des comptes de bilan de la CLASSES 1 à 5) :</p>
 		<ul>
		<li>Reconduire les journaux via <a href='journal?edit_journal_set=0&reconduire=0'>Journaux => Modifier la liste => Reconduire les journaux de l'exercice précédent</a></li>
		<li>Reconduire les comptes via 	<a href='compte?edit_compte_set=0&reconduire=0'>Comptes => Modifier la liste => Reconduire</a></li>
		<li>Reporter les soldes de l'exercice précédent en générant les à nouveaux via <a href='compte?reports=0'>Comptes => Reports</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>	
	
		<div id='reconduite_2'>	
		<p class=title1>Premier exercice comptable</p>
		<p>Dans le cas d'un premier exercice, il vous faut :</p>
		<ul>
		<li>Créer vos journaux depuis le Menu <a href='journal?edit_journal_set=0'>Journaux => Modifier la liste</a> (voir le chapitre <a href='#journaux'>Journaux</a>)</li>
		<li>Créer vos comptes depuis le Menu <a href='compte?edit_compte_set=0'>Comptes => Modifier la liste</a> (voir le chapitre <a href='#comptes'>Comptes</a>)</li>
		</ul>
	
		<hr class=mainPageTutoriel>	
		".$hidden[24]."
		".$hidden[20]."
	</section>
		
	<section id='cloture' class='main-section'>
		<header class='header'><h3>Clôture d'exercice</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>

		<p>La clôture des comptes (lien 'Clôture' dans le menu 'Comptes', en haut de page) solde les comptes de classe 6 et 7, calcule le résultat et l'inscrit au débit ou au crédit du compte de résultat (12000[0...]). Les opérations effectuées sont d'abord affichées dans le formulaire de saisie d'une écriture pour validation. Si le compte 12000 n'existe pas, le créer, ou bien modifier la dernière ligne du formulaire de validation pour servir le compte souhaité</p>
		<p>L'opération est réversible par suppression de l'OD enregistrée, si les comptes n'ont pas été archivés (voir le chapitre <a href=\'index.html#export\'>Exportations</a>)</p>
		".$hidden[24]."
		".$hidden[20]."
	</section>
	
	<section id='prepcloture' class='main-section'>
		<header class='header'><h3>Check-list avant clôture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#prepcloture_1' >Contrôles d'ensemble</a></li>
		<li><a class=summary href='#prepcloture_2' >Trésorerie</a></li>
		<li><a class=summary href='#prepcloture_3' >Achats</a></li>
		<li><a class=summary href='#prepcloture_4' >Ventes</a></li>
		<li><a class=summary href='#prepcloture_5' >Stocks</a></li>
		<li><a class=summary href='#prepcloture_6' >Immobilisations</a></li>
		<li><a class=summary href='#prepcloture_7' >Personnel</a></li>
		<li><a class=summary href='#prepcloture_8' >Etat</a></li>
		<li><a class=summary href='#prepcloture_9' >Capitaux</a></li>
		</ul>
		
	<hr class=mainPageTutoriel>
			
		<div id='prepcloture_1'>	
		<p class=title1>Contrôles d'ensemble</p>
		<ul>
		<li>Contrôler les comptes d’attente (471 à 475) qui doivent être soldés</li>
		<li>Contrôler les comptes de virements internes (58) qui doivent être soldés</li>
		<li>Contrôler par sondages que les enregistrements comptables s’appuient sur une pièce justificative et que l'imputation comptable est correcte </li>
		<li>Contrôler la cohérence des principaux ratios par rapport à ceux de l’exercice précédent</li>
		<li>Tous les soldes des comptes des classes 1, 2, 3, 4, et 5 doivent être justifiés, c'est à dire qu'ils doivent être expliqués facilement à l'aide 
		d'une ou plusieurs pièces comptables telles que factures, déclaration sociale ou fiscale, releve, tableau.
		</ul>
		</div>	
			
	<hr class=mainPageTutoriel>
	
		<div id='prepcloture_2'>	
		<p class=title1>Trésorerie</p>
		<ul>
		<li>Contrôler et justifier les comptes de trésorerie (banques, caisses, CCP)</li>
		<li>Contrôler les états de rapprochement si les règlements sont enregistrés d'après les pièces
		(talons de chèques, effets de commerce, avis de virement et de prélèvement, etc.)</li>
		<li>Contrôler par épreuve l’absence de soldes créditeurs en caisse au cours de l’exercice</li>
		<li>Contrôler l’état des valeurs mobilières avec la comptabilité</li>
		<li>Contrôler les tableaux d’amortissement des emprunts avec la comptabilité. Les soldes des comptes d'emprunt (16) doivent correspondre au capital restant dû à la clôture de l'exercice.</li>
		</ul>
		</div>		
			
	<hr class=mainPageTutoriel>		
	
		<div id='prepcloture_3'>	
		<p class=title1>Achats</p>
		<ul>
		<li>Analyser les principaux comptes d’achats afin de détecter d’éventuelles anomalies qui pourraient justifier des contrôles complémentaires</li>
		<li>Contrôler les comptes des fournisseurs (40) débiteurs (ils doivent en principe présenter un solde créditeur et les éventuelles créances fournisseurs (acomptes notamment) devraient figurer en 409</li>
		<li>Contrôler la cohérence du ratio fournisseurs</li>
		<li>Contrôler la correcte séparation des exercices</li>
		<li>Contrôler la concordance entre la comptabilité et les contrats et échéanciers pour crédit-bail, loyer, assurances …</li>
		<li>S’assurer que les comptes de charges ne contiennent pas des biens susceptibles de constituer des immobilisations</li>
		</ul>
		</div>			
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_4'>	
		<p class=title1>Ventes</p>
		<ul>
		<li>Contrôler par épreuve le dénouement en N+1 de certaines créances clients significatives</li>
		<li>Contrôler les créances douteuses et leur dépréciation</li>
		<li>Contrôler la cohérence du ration crédit clients</li>
		<li>Contrôler la correcte séparation des exercices</li>
		<li>Contrôler les comptes clients (41) créditeurs (ils doivent en principe présenter un solde débiteur et les éventuelles dettes clients (acomptes notamment) en 419</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_5'>	
		<p class=title1>Stocks</p>
		<ul>
		<li>Les comptes de stocks et en-cours (classe 3) doivent traduire la valeur des stocks et en-cours après inventaire, à la clôture de l'exercice</li>
		<li>Contrôler, par épreuves, l’application de la méthode de valorisation annoncée et de dépréciation</li>
		<li>Contrôler la cohérence du montant des en-cours avec la facturation de l’exercice suivant</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	

		<div id='prepcloture_6'>	
		<p class=title1>Immobilisations</p>
		<ul>
		<li>Contrôler les soldes des comptes d'immobilisation (20, 21, 22) pour qu'il corresponde à la valeur brute
		en fin d'exercice fournie par le tableau des immobilisations. Les amortissements (28) doivent correspondre au cumul des amortissements
		en fin d'exercice fourni par le tableau des	immobilisations.</li>
		<li>Contrôler les mouvements des immobilisations financières</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_7'>	
		<p class=title1>Personnel</p>
		<ul>
		<li>Contrôler le rapprochement entre les salaires comptabilisés et la DADS/DSN</li>
		<li>Contrôler les soldes des dettes fiscales et sociales avec les déclarations de la dernière période</li>
		<li>Apprécier le taux global de charges sociales </li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_8'>	
		<p class=title1>Etat</p>
		<ul>
		<li>Contrôler le rapprochement du chiffre d’affaires déclaré en TVA avec la comptabilité</li>
		<li>Contrôler le calcul du résultat fiscal et de l’IS</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_9'>	
		<p class=title1>Capitaux</p>
		<ul>
		<li>Vérifier l’affectation du résultat N-1 (les comptes 120 et 129 doivent être soldés)</li>
		<li>Vérifier la bonne application des décisions des assemblées</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
	".$hidden[24]."
	".$hidden[20]."
	</section>
	

	
	
	<section id='calcul_du_bilan' class='main-section'>
		<header class='header'><h3>Opérations de calcul du bilan</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Préparer le calcul des cases à renseigner dans le formulaire 2033 B (Cerfa 2) :<br>
	  -Voir le chapitre <a href=\"#liasse_fiscale\">Liasse fiscale</a>
		</p>
		<p>Avant calcul de résultat :<br>
	  -Enlever les rompus<br>
	  -Imprimer la page 'Liasse fiscale'<br>
	  -Afficher la balance, l'imprimer et/ou l'exporter (lien 'Télécharger' à côté du bouton valider)<br>
	  -Imprimer le Grand Livre (lien 'Grand Livre' en haut de la page 'Comptes'); passer en mode paysage pour afficher toutes les colonnes<br>
		</p>
		<p>Calcul du résultat :<br>
	  -Cliquer dans Compte -> <a href=\"#cloture\">Clôture</a> (lien en haut à droite de la page)
		</p>
		<p>Après calcul du résultat :<br>
	  -Éditer la nouvelle balance (les comptes 6 et 7 sont soldés)<br>
	  -Reporter les soldes sur les documents Cerfa A et B
		</p>
		".$hidden[24]."
		".$hidden[20]."
			</section> 
  
	";	
	
	 return $content ;
} #sub articles_bar4 

#/*—————————————— articles_bar5 => Utilitaires ——————————————*/
sub articles_bar5 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_5 Paramètrage
	my $content .= "
	
  	<section id='version' class='main-section'>
    <header class='header'><h3>Gestion des versions</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
	<section id='timeline' class='timeline-outer'>
   
      <div class='row'>
        <div class='col s12 m12 l12'>
          <ul class='timeline'>
            
            <li class='event' data-date='2015/Present'>
				<h3>Juillet 2022 Version 1.10</h3>
              <p>Version modifiée par picsou83 (<a href='https://github.com/picsou83'>https://github.com/picsou83</a>) </p>
            </li>
           
            
            
            <li class='event' data-date='2010/2012'>
            <h3>Mars 2021 Version 1.0</h3>
            <p>Version initiale de Vincent Veyron - Aôut 2016 (<a href='https://compta.libremen.com/'>https://compta.libremen.com/</a>) </p>
            </li>
            
          </ul>
        </div>
      </div>
    ".$hidden[24]."
	".$hidden[20]."
	</section>
	
	</section>
	";	
	
	 return $content ;
} #sub articles_bar5 

#/*—————————————— Formulaire documentation ——————————————*/
sub forms_documentation {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content  ) ;
	my @hidden = ('0') x 40;
	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

	#checked par défault label1 et 2
    unless (defined $args->{cat1} || defined $args->{cat2} || defined $args->{cat3} || defined $args->{cat4} || defined $args->{cat5}) {$args->{cat1} = 1; $args->{cat2} = 1; $args->{cat3} = 1; $args->{cat4} = 1; $args->{cat5} = 1;}


#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
		
	if (defined $args->{cat1} && $args->{cat1} eq 1) {$hidden[11] = side_bar_1() } else {$hidden[11] = '';}
	if (defined $args->{cat2} && $args->{cat2} eq 1) {$hidden[12] = side_bar_2() } else {$hidden[12] = '';}
	if (defined $args->{cat3} && $args->{cat3} eq 1) {$hidden[13] = side_bar_3() } else {$hidden[13] = '';}
	if (defined $args->{cat4} && $args->{cat4} eq 1) {$hidden[14] = side_bar_4() } else {$hidden[14] = '';}
	if (defined $args->{cat5} && $args->{cat5} eq 1) {$hidden[15] = side_bar_5() } else {$hidden[15] = '';}
  
  	#fonction javascript scroll menu
	my $side_bar .= '
	<script>

	window.addEventListener("load", () => {
	
	const sections = Array.from(document.querySelectorAll("section[id]"));
	
	var observer = new IntersectionObserver(function (entries) {

			entries.forEach(entry => {
				const section = entry.target;
				const sectionId = section.id;
				const sectionLink = document.querySelector(`a[href="#${sectionId}"]`);
				
				var intersecting = typeof entry.isIntersecting === \'boolean\' ?
                entry.isIntersecting : (entry.intersectionRatio > 0)
                sectionLink && sectionLink.classList.toggle(\'active\', intersecting)
			//sectionLink.parentElement.classList.add(\'active\');
			});
		
		}, {
            root: null,
            rootMargin: \'-150px 0px -150px 0px\',
			threshold: [0, 0.25, 0.75, 1]
        })
        
	sections && sections.forEach(section => observer.observe(section));
	
	});

	</script>' ;
  
	#class='docs-sidebar'
	$side_bar .= "
    <div class='sidebar'><nav class='section-nav'><ul class='nav' style='padding: 0px; list-style-type: none;'>
	".$hidden[11]."
	".$hidden[12]."
	".$hidden[13]."
	".$hidden[14]."
	".$hidden[15]."

	</nav></ul></nav></div>
    <main class='content' id='main-doc'>    
    
    <input style='position: sticky; top: 65px; background-color: #fff; width: 100%; '
	class='login-text' type='text' id='Search' onkeyup='searchFunction2()'
	placeholder='Saisissez le terme de recherche..' title='Rechercher' autofocus>	
	
	<div style='position: sticky; top: 110px; background-color: #fff;     text-align: center; padding-top: 5px;
    padding-bottom: 1%;'>
	".$hidden[20]."
	
	<div class='posts'>
    
    <!-- A single blog post -->
    "; 
		
	if (defined $args->{cat1} && $args->{cat1} eq 1) {$hidden[1] = articles_bar1( $r, $args )} else {$hidden[1] = '';}
	if (defined $args->{cat2} && $args->{cat2} eq 1) {$hidden[2] = articles_bar2( $r, $args )} else {$hidden[2] = '';}
	if (defined $args->{cat3} && $args->{cat3} eq 1) {$hidden[3] = articles_bar3( $r, $args )} else {$hidden[3] = '';}
	if (defined $args->{cat4} && $args->{cat4} eq 1) {$hidden[4] = articles_bar4( $r, $args )} else {$hidden[4] = '';}
	if (defined $args->{cat5} && $args->{cat5} eq 1) {$hidden[5] = articles_bar5( $r, $args )} else {$hidden[5] = '';}
	
	my $documentation .= '</div><div class="wrapperfaq">' . $side_bar . $hidden[1] . $hidden[2] . $hidden[3] . $hidden[4] . $hidden[5] . '</main></div>' ;
				
	$content .= $documentation;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_documentation 


#/*—————————————— Menu 	——————————————*/
sub display_menu {

    my ( $r, $args ) = @_ ;
    
   unless ( defined $args->{menu2} || defined $args->{menu3} || defined $args->{menu4} || defined $args->{menu5} ) {
	   $args->{menu1} = '' ;
    } 	
 	
#########################################	
#Filtrage du Menu - Début				#
#########################################		
	my $menu1_link = '<a class=' . ( (defined $args->{menu1} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?menu1" style="margin-left: 3ch;">Premiers pas</a>' ;
	my $menu2_link = '<a class=' . ( (defined $args->{menu2} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?menu2" style="margin-left: 3ch;">Courant</a>' ;
	my $menu3_link = '<a class=' . ( (defined $args->{menu3} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?menu3" style="margin-left: 3ch;">Utilitaires</a>' ;
	my $menu4_link = '<a class=' . ( (defined $args->{menu4} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?menu4" style="margin-left: 3ch;">Paramétrage</a>' ;
	my $menu5_link = '<a class=' . ( (defined $args->{menu5} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?menu5" style="margin-left: 3ch;">Fin d\'exercice</a>' ;
	my $content .= '<div class="menu"><li style="list-style: none; margin: 0;">' . $menu1_link . $menu2_link . $menu3_link . $menu4_link . $menu5_link .'</li></div>' ;

#########################################	
#Filtrage du Menu - Fin					#
#########################################
    
    return $content ;

} #sub display_menu_formulaire 

1 ;
