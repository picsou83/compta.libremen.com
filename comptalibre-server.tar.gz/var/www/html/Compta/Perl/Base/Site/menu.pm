package Base::Site::menu;
#-----------------------------------------------------------------------------------------
#Version 1.10 - Juillet 1th, 2022
#-----------------------------------------------------------------------------------------
#	
#	Créé par picsou83 (https://github.com/picsou83)
#	
#-----------------------------------------------------------------------------------------
#Version History (Changelog)
#-----------------------------------------------------------------------------------------
#
##########################################################################################
#
#Ce logiciel est un programme informatique de comptabilité
#
#Ce logiciel est régi par la licence CeCILL-C soumise au droit français et
#respectant les principes de diffusion des logiciels libres. Vous pouvez
#utiliser, modifier et/ou redistribuer ce programme sous les conditions
#de la licence CeCILL-C telle que diffusée par le CEA, le CNRS et l'INRIA 
#sur le site "http://www.cecill.info".
#
#En contrepartie de l'accessibilité au code source et des droits de copie,
#de modification et de redistribution accordés par cette licence, il n'est
#offert aux utilisateurs qu'une garantie limitée.  Pour les mêmes raisons,
#seule une responsabilité restreinte pèse sur l'auteur du programme,  le
#titulaire des droits patrimoniaux et les concédants successifs.
#
#A cet égard  l'attention de l'utilisateur est attirée sur les risques
#associés au chargement,  à l'utilisation,  à la modification et/ou au
#développement et à la reproduction du logiciel par l'utilisateur étant 
#donné sa spécificité de logiciel libre, qui peut le rendre complexe à 
#manipuler et qui le réserve donc à des développeurs et des professionnels
#avertis possédant  des  connaissances  informatiques approfondies.  Les
#utilisateurs sont donc invités à charger  et  tester  l'adéquation  du
#logiciel à leurs besoins dans des conditions permettant d'assurer la
#sécurité de leurs systèmes et ou de leurs données et, plus généralement, 
#à l'utiliser et l'exploiter dans les mêmes conditions de sécurité. 
#
#Le fait que vous puissiez accéder à cet en-tête signifie que vous avez 
#pris connaissance de la licence CeCILL-C, et que vous en avez accepté les
#termes.
##########################################################################################

use strict ;
use warnings ;
use Apache2::URI ();
use PDF::API2;
use Time::Piece;
use utf8 ;
use Apache2::Const -compile => qw( OK DECLINED REDIRECT);

sub handler {

    binmode(STDOUT, ":utf8") ;
    my $r = shift ;
    #utilisation des logs
    Base::Site::logs::redirect_sig($r->pnotes('session')->{debug});
    my $content = '';
	my $req = Apache2::Request->new( $r ) ;

    #récupérer les arguments
    my (%args, @args) ;

    #recherche des paramètres de la requête
    @args = $req->param ;

    for ( @args ) {

	$args{ $_ } = Encode::decode_utf8( $req->param($_) ) ;

	#les double-quotes et les <> viennent interférer avec le html
	$args{ $_ } =~ tr/<>"/'/ ;

    }
    
    if (defined $args{journal})  {
	
	my $location = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $args{journal} ) . '&amp;id_entry=0&amp;nouveau' ;

	$r->headers_out->set(Location => $location) ;

	return Apache2::Const::REDIRECT ;
	}
	
	#Vérification update BDD 
	verif_bdd_update( $r, \%args );

	$content = principal( $r, \%args ) ;
	
    $r->no_cache(1) ;
    
    $r->content_type('text/html; charset=utf-8') ;

    print $content ;

    return Apache2::Const::OK ;

}

sub principal {
	
	my ( $r, $args ) = @_ ;
    my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
    $args->{_token_id} ||= join "", map +(0..9,"a".."z","A".."Z")[rand(10+26*2)], 1..32 ;

	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

	#####################################       
	# Manipulation des dates			#
	#####################################  
	my $date_comptant;
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	my $date_1 = localtime->strftime('%Y-%m-%d');
	my $date_2 = $r->pnotes('session')->{Exercice_fin_YMD} ;
	if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}
	
	my $contenu_web_doc .= '
	<div class="card">
	<p class="card-text"></p>
    <br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/docs?import=0">Importer les données</a>
    </div>';

	my $contenu_web_etats .= '
	<div class="card">
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/menu">Etats</a></div>
    <p class="card-text"></p>
    <a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/compte?grandlivre=0">Grand Livre</a>
	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/compte?balance=0">Balance</a>
   	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/bilan?bilan">Bilan</a>
   	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/bilan?resultat">Compte de Résultat</a>
   	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033A">Liasse 2033A</a>
   	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033B">Liasse 2033B</a>
   	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/bilan?liasse2033C">Liasse 2033C</a>
    </div>
	';
	
	my $contenu_web_param .= '
	<div class="card">
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/parametres">Paramètres</a></div>
    <p class="card-text"></p>
    <a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/parametres?societes">Gestion des sociétés</a>
	<br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/parametres?utilisateurs">Gestion des utilisateurs</a>
    <br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/parametres?sauvegarde">Gestion des sauvegardes</a>
    <br/><a style="margin-left: 1ch;" class="decoff" href="/'.$r->pnotes('session')->{racine}.'/parametres?logs">Logs</a>
    </div>
    ';
    
    #####################################       
	# Menu chekbox
	#####################################   
	#définition des variables
	my @checked = ('0') x 15;
	my @dispcheck = ('0') x 15;
	my $retour_href = 'javascript:history.go(-1)';
    
    #checked par défault menu1
    unless (defined $args->{menu1}) {$args->{menu1} = 1;}
	
	if (defined $args->{menu1} && $args->{menu1} eq 1) {$checked[1] = 'checked';} else {$checked[1] = '';}
	if (defined $args->{menu2} && $args->{menu2} eq 1) {$checked[2] = 'checked';} else {$checked[2] = '';}
	if ((defined $args->{menu3} && $args->{menu3} eq 1) || defined $args->{ecriture_recurrente}) {$checked[3] = 'checked';} else {$checked[3] = '';}
	if ((defined $args->{menu4} && $args->{menu4} eq 1) || defined $args->{move_compte}) {$checked[4] = 'checked';} else {$checked[4] = '';}
	if ((defined $args->{menu5} && $args->{menu5} eq 1) || defined $args->{achat_comptant}) {$checked[5] = 'checked';} else {$checked[5] = '';}
	if ((defined $args->{menu6} && $args->{menu6} eq 1) || defined $args->{reglement_client}) {$checked[6] = 'checked';} else {$checked[6] = '';}
	if ((defined $args->{menu7} && $args->{menu7} eq 1) || defined $args->{reglement_fournisseur}) {$checked[7] = 'checked';} else {$checked[7] = '';}
	if ((defined $args->{menu8} && $args->{menu8} eq 1) || defined $args->{interet_cca}) {$checked[8] = 'checked';} else {$checked[8] = '';}
	if (defined $args->{menu9} && $args->{menu9} eq 1) {$checked[9] = 'checked';} else {$checked[9] = '';}

	my $fiche_client .= '
	<div class=centrer>
	<div class="flex-checkbox">

	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check1" class="forms2_label">Documentation</label>
	<input id="check1" type="checkbox" class="demo5" '.$checked[1].' onchange="submit()" name="menu1" value=1>
	<label for="check1" class="forms2_label"></label>
	<input type=hidden name="menu1" value=0 >
	<input type=hidden name="menu2" value="' . ($args->{menu2} || '') . '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check2" class="forms2_label">Rechercher</label>
	<input id="check2" type="checkbox" class="demo5" '.$checked[2].' onchange="submit()" name="menu2" value=1>
	<label for="check2" class="forms2_label"></label>
	<input type=hidden name="menu1" value="' . ($args->{menu1} || ''). '">
	<input type=hidden name="menu2" value=0 >
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check3" class="forms2_label">Ecritures récurrentes</label>
	<input id="check3" type="checkbox" class="demo5" '.$checked[3].' onchange="submit()" name="menu3" value=1>
	<label for="check3" class="forms2_label"></label>
	<input type=hidden name="menu1" value="' . ($args->{menu1} || ''). '">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || ''). '">
	<input type=hidden name="menu3" value=0 >
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check4" class="forms2_label">Transfert entre comptes</label>
	<input id="check4" type="checkbox" class="demo5" '.$checked[4].' onchange="submit()" name="menu4" value=1>
	<label for="check4" class="forms2_label"></label>
	<input type=hidden name="menu1" value="' . ($args->{menu1} || ''). '">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || ''). '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value=0 >
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check5" class="forms2_label">Paiement comptant</label>
	<input id="check5" type="checkbox" class="demo5" '.$checked[5].' onchange="submit()" name="menu5" value=1>
	<label for="check5" class="forms2_label"></label>
	<input type=hidden name="menu1" value="' . ($args->{menu1} || ''). '">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || ''). '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value=0 >
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check6" class="forms2_label">Réglement Client</label>
	<input id="check6" type="checkbox" class="demo5" '.$checked[6].' onchange="submit()" name="menu6" value=1>
	<label for="check6" class="forms2_label"></label>
	<input type=hidden name="menu1" value="' . ($args->{menu1} || ''). '">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || ''). '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value=0 >
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check7" class="forms2_label">Réglement Fournisseur</label>
	<input id="check7" type="checkbox" class="demo5" '.$checked[7].' onchange="submit()" name="menu7" value=1>
	<label for="check7" class="forms2_label"></label>
	<input type=hidden name="menu1" value="' . ($args->{menu1} || ''). '">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || ''). '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value=0 >
	<input type=hidden name="menu8" value="' . ($args->{menu8} || ''). '">
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>
	
	<form method="post" action=/'.$r->pnotes('session')->{racine}.'/menu>
	<label for="check8" class="forms2_label">Intérêts CCA</label>
	<input id="check8" type="checkbox" class="demo5" '.$checked[8].' onchange="submit()" name="menu8" value=1>
	<label for="check8" class="forms2_label"></label>
	<input type=hidden name="menu1" value="1">
	<input type=hidden name="menu2" value="' . ($args->{menu2} || ''). '">
	<input type=hidden name="menu3" value="' . ($args->{menu3} || ''). '">
	<input type=hidden name="menu4" value="' . ($args->{menu4} || ''). '">
	<input type=hidden name="menu5" value="' . ($args->{menu5} || ''). '">
	<input type=hidden name="menu6" value="' . ($args->{menu6} || ''). '">
	<input type=hidden name="menu7" value="' . ($args->{menu7} || ''). '">
	<input type=hidden name="menu8" value=0 >
	<input type=hidden name="menu9" value="' . ($args->{menu9} || ''). '">
	</form>

	</div>	
	';
	
	my $forms_paiement_comptant = '<div class="card"> '.forms_paiement_comptant( $r, $args ).'</div>' ; 
	my $forms_ecri_rec = '<div class="card"> '.forms_ecri_rec( $r, $args ).'</div>' ; 
	my $forms_transfert_compte = '<div class="card"> '.forms_transfert_compte( $r, $args ).'</div>' ;   
	my $forms_search = '<div class="card"> '.forms_search( $r, $args ).'</div>' ; 
	my $forms_reglement_client = '<div class="card"> '.forms_reglement_client( $r, $args ).'</div>' ; 
	my $forms_reglement_fournisseur = '<div class="card"> '.forms_reglement_fournisseur( $r, $args ).'</div>' ; 
	my $forms_interet_cca = '<div class="card"> '.forms_interet_cca( $r, $args ).'</div>' ;
	
	my $forms_documentation = forms_documentation( $r, $args ) ; 

	if (defined $args->{menu1} && $args->{menu1} eq 1) {$dispcheck[1] = $forms_documentation;} else {$dispcheck[1] = '';}
	if (defined $args->{menu2} && $args->{menu2} eq 1) {$dispcheck[2] = $forms_search;} else {$dispcheck[2] = '';}
	if ((defined $args->{menu3} && $args->{menu3} eq 1) || defined $args->{ecriture_recurrente}) {$dispcheck[3] = $forms_ecri_rec;} else {$dispcheck[3] = '';}
	if ((defined $args->{menu4} && $args->{menu4} eq 1) || defined $args->{move_compte}) {$dispcheck[4] = $forms_transfert_compte;} else {$dispcheck[4] = '';}
	if ((defined $args->{menu5} && $args->{menu5} eq 1) || defined $args->{achat_comptant}) {$dispcheck[5] = $forms_paiement_comptant;} else {$dispcheck[5] = '';} 
	if ((defined $args->{menu6} && $args->{menu6} eq 1) || defined $args->{reglement_client}) {$dispcheck[6] = $forms_reglement_client;} else {$dispcheck[6] = '';} 
	if ((defined $args->{menu7} && $args->{menu7} eq 1) || defined $args->{reglement_fournisseur}) {$dispcheck[7] = $forms_reglement_fournisseur;} else {$dispcheck[7] = '';} 
	if ((defined $args->{menu8} && $args->{menu8} eq 1) || defined $args->{interet_cca}) {$dispcheck[8] = $forms_interet_cca;} else {$dispcheck[8] = '';} 
	
	
	if ($result_reglement_set->[0]->{type_compta} eq 'tresorerie') {
	#$content .= '<div class="wrapper">' . $contenu_web_etats . $contenu_web_param .'</div>' ;
	$content .= '<div class="wrapper1"></div>' ;
	} elsif ($r->pnotes('session')->{Exercice_Cloture} ne '1') {		
	$content .= '<div class="wrapper1">' . $fiche_client . $dispcheck[2] . $dispcheck[5] . $dispcheck[3] . $dispcheck[4] . $dispcheck[6] . $dispcheck[7] . $dispcheck[8] . $dispcheck[1] .'</div>' ;
	} else {
	$content .= '<div class="wrapper1">' . $fiche_client . $dispcheck[2] . $dispcheck[5] . $dispcheck[3] . $dispcheck[4] . $dispcheck[6] . $dispcheck[7] . $dispcheck[8] . $dispcheck[1] .'</div>' ;
	}

    return $content ;

}#sub principal

#/*—————————————— Formulaire Saisie achat en paiement comptant 	——————————————*/
sub forms_paiement_comptant {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
	my $selected = '';

	# récupération des variables de docsentry.pm
	my ($date_comptant, $montant_entry, $calcul_piece3);
	if (defined $args->{date_doc_entry}) {$date_comptant = $args->{date_doc_entry} ;}
	if (defined $args->{montant_doc_entry}) {$montant_entry = $args->{montant_doc_entry} ;}
	
	#/************ ACTION DEBUT *************/
 
	#demande confirmation achat_comptant 								
	#menu?date_comptant=2020-12-31&compte_comptant=401CAAE&libelle=test&montant=100.00&select_achats=default_caisse_journal%21%21CAISSE&docs1=&docs2=&achat_comptant=0
    if ( defined $args->{achat_comptant} and $args->{achat_comptant} eq '0' ) {
		
		if 	(defined $args->{compte_comptant} && $args->{compte_comptant} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de compte fournisseur en 401</h3>' ;	
		} elsif (defined $args->{select_achats} && $args->{select_achats} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de journal de réglement configuré</h3>' ;	
		} elsif (defined $args->{montant} && $args->{montant} eq '0.00') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le montant est à 0.00</h3>' ;	
		} else {	
		(my $confirm_href = $r->unparsed_uri()) =~ s/&achat_comptant=0/&achat_comptant=1/ ;
		$confirm_href =~ s/docsentry/menu/ ;
		(my $deny_href = $r->unparsed_uri()) =~ s/&achat_comptant=0/&achat_comptant=9/ ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Date: ' .($args->{date_comptant} || '') . ' Compte: '. ($args->{compte_comptant} || '') .' Libellé: ' . ($args->{libelle} || '') .' Montant: ' . ($args->{montant} || '') .'€ Journal: '.($args->{select_achats} || '').' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}

    } elsif ( defined $args->{achat_comptant} and $args->{achat_comptant} eq '1' ) {
	
		my ($journal, $month, $year) = '';
		
		#récupération journal de réglement et compte de réglement

		$sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? and config_libelle = ? AND module = \'achats\'' ;
		my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{select_achats} ) ) ;
			
		my $reglement_journal = $resultat->[0]->{config_journal};
		my $reglement_compte = $resultat->[0]->{config_compte};
		
		#mise en forme montant pour enregistrement en bdd
		#ne pas laisser des montants nulls : mettre un zéro
		$args->{montant} ||= '0.00';
		#remplacer la virgule par le point dans les montants soumis
		$args->{montant} =~ s/,/./ ;
		#enlever les espaces de présentation
		$args->{montant} =~ s/\s//g ;
	
		#calcul numéro de pièce auto
		$sql = 'SELECT libelle_journal, code_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
		my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
		my $journal_code_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
		
		my $journal_achats = 'ACHATS';
	
		for ( @$journal_code_set ) {
		if ($journal_achats =~ $_->[0]) {
			$journal = $_->[1];	
			} 
		}    
	    
		if ((defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<year>[0-9]{4}).*(?<month>[0-9]{2}).*(?<day>[0-9]{2})$/) {
		$month= substr($args->{date_comptant},5,2);
		$year= substr($args->{date_comptant},0,4);		
		} elsif (( defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
		$month= substr($args->{date_comptant},3,2);
		$year= substr($args->{date_comptant},6,4);	
		}
	
		my $item_num = 1;
		
		#on regarde s'il existe des factures enregistrées pour le mois et l'année de la date d'enregistrement
		$sql = '
		SELECT id_facture as item_number, extract(month from ?::date) as month_number, extract(year from ?::date) as year_number
		FROM tbljournal
		WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE ? and id_client = ? and fiscal_year = ? and libelle_journal = ? AND substring(id_facture from 8 for 2) = ?
		ORDER BY 1 DESC LIMIT 1
		' ;
	
		@bind_array = ( $args->{date_comptant}, $args->{date_comptant}, $journal, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $journal_achats, $month ) ;
		my $calcul_piece = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;     
		
		for ( @$calcul_piece ) {
		if (substr( $_->{item_number}, 10, 2 ) =~ /\d/ && substr( $_->{item_number}, 0, 2 ) =~ /$journal/) {
		$item_num = int(substr( $_->{item_number}, 10, 2 )) + 1	;} 
		} 
	
		#my $format ='%0' . $1 . 'd' ;
		
		if ($item_num<10) {	$item_num="0".$item_num; }
		
		#my $numero_piece = $journal . $year . '-' . $month . '_' . $item_num ;
		#my $numero_piece = $journal . $year . '-' . $month . '_' . sprintf("$format", $item_num );
		my $numero_piece = $args->{calcul_piece3} ;

		#recherche du lettrage existant pour ce compte
		$sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
		
		my $lettrage_total = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
		
		$sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND numero_compte = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{compte_comptant} ) ;
		
		my $lettrage = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;

		if ( $lettrage ) {
		$lettrage++ ;
		} else {
			if ($lettrage_total) {
			my $lettrage_sub = substr( $lettrage_total, 0, 2 );
			$lettrage = ++$lettrage_sub.'01';
			} else {
			$lettrage = 'AA01' ;
			}	
		}
		
		#supprime les espaces de début et de fin de ligne
		$args->{libelle} =~ s/^\s+|\s+$//g;

		#première écriture
		$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
		@bind_array = ( 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_comptant}, $lettrage, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'ACHATS', $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_charge_comptant}, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'ACHATS', $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
		$dbh->do( $sql, undef, @bind_array ) ;
		$sql = 'SELECT record_staging(?, ?)' ;
		eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
	
		#erreur dans la procédure store_staging : l'afficher dans le navigateur
		if ( $@ ) {
			if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
			$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
			$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /unbalanced/ ) {
			$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ / bad fiscal / ) {
			$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /archived/ ) {
			$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
			$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
			} else {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}
		} else {      
			#deuxième écriture
			$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
			@bind_array = ( 
			$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_comptant}, $lettrage, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
			$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
			$dbh->do( $sql, undef, @bind_array ) ;
			$sql = 'SELECT record_staging(?, ?)' ;
			eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
		
			#erreur dans la procédure store_staging : l'afficher dans le navigateur
			if ( $@ ) {
				if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
				$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
				$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /unbalanced/ ) {
				$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ / bad fiscal / ) {
				$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /archived/ ) {
				$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
				$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
				} else {
				$content .= '<h3 class=warning>' . $@ . '</h3>' ;
				}
			} else {
			
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm =>	Ajout d\'un paiement comptant => Date: ' .($args->{date_comptant} || '') . ' Montant: ' . ($args->{montant} || '') .'€ Libellé: ' . ($args->{libelle} || '') .' Compte: '. ($reglement_compte || '') .' Journal: '.($reglement_journal || '').'');
		
			my $varmenu ;	
			if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}} else { $varmenu = 'journal?open_journal='.($reglement_journal || '' ).'';}

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;    
			}    
		}
	}
	
	#/************ ACTION FIN *************/
			
	#####################################       
	# Récupérations d'informations		#
	#####################################  
	
	# on peut réutiliser la liste des journaux précédemment créée pour journal_tva
    $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	if 	(defined $args->{journal}) {
	$selected = ( $_->{libelle_journal} eq $args->{journal} ) ? 'selected' : '' ;
	}	
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '" '.$selected.'>' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;
	
	#numero compte et libelle compte 40
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'40\') ORDER by libelle_compte' ;
    my $compte_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_comptant = '<select class="forms2_input" style="width: 18%;" onchange="select_contrepartie_401(this, \'' . $r->pnotes('session')->{racine} . '\')" name=compte_comptant id=compte_comptant10>' ;
	$compte_comptant .= '<option value="" selected>--Sélectionner--</option>' ;
	for ( @$compte_set ) {
	if 	(defined $args->{compte_comptant}) {
	$selected = ( $_->{numero_compte} eq $args->{compte_comptant} ) ? 'selected' : '' ;
	}		
	$compte_comptant .= '<option value="' . $_->{numero_compte} . '" '.$selected.'>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_comptant .= '</select>' ;
	
	#numero compte et libelle compte 60
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 1) IN (\'6\') ORDER by libelle_compte' ;
    my $compte_charge_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_charge_comptant = '<select class="forms2_input" style="width: 18%;" name=compte_charge_comptant id=compte_charge_comptant>' ;
	$compte_charge_comptant .= '<option value="" selected>--Sélectionner--</option>' ;
	for ( @$compte_charge_set ) {
	if 	(defined $args->{compte_charge_comptant}) {
	$selected = ( $_->{numero_compte} eq $args->{compte_charge_comptant} ) ? 'selected' : '' ;
	}			
	$compte_charge_comptant .= '<option value="' . $_->{numero_compte} . '" '.$selected.'>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_charge_comptant .= '</select>' ;
	
	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? AND module = \'achats\' ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    #select_achats
	my $select_achats = '<select style="width: 13%;" class="forms2_input" name=select_achats id=select_achats1 onchange="calcul_piece_achat(\'' . $r->pnotes('session')->{racine} . '\')">' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	if 	(defined $args->{select_achats}) {
	$selected = ( $_->{config_libelle} eq $args->{select_achats} ) ? 'selected' : '' ;
	}			
	$select_achats .= '<option value="' . $_->{config_libelle} . '" '.$selected.'>' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;

	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my ($id_name, $document_select1, $document_select2,$calcul_piece);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs1} && (!defined $args->{docs_doc_entry} && !defined $args->{label8})){
    $document_select1 = '<select class="forms2_input" style="width: 28%;" name=docs1 id=docs12>
    <option value="" selected>--Sélectionner le document 1--</option>' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 28%;" name=docs1 id=docs12>
    <option value="" >--Sélectionner le document 1--</option>' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs2} && (!defined $args->{docs_doc_entry} && !defined $args->{label9})){
    $document_select2 = '<select class="forms2_input" style="width: 28%;" name=docs2 id=docs22>
    <option value="" selected>--Sélectionner le document 2--</option>' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 28%;" name=docs2 id=docs22>
    <option value="" >--Sélectionner le document 2--</option>' ;
	}
	
    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
			my $selected1 = (($_->{id_name} eq ($args->{docs1} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1)) ? 'selected' : '' ;
			my $selected2 = (($_->{id_name} eq ($args->{docs2} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1)) ? 'selected' : '' ;
			$document_select1 .= '<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>' ;
			$document_select2 .= '<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>' ;		
	    }
		$id_name = $_->{id_name} ;	
    }
    
    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
	############## MISE EN FORME DEBUT ##############
	
	my $contenu_web_ach_comptant .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Saisie achat en paiement comptant</a></div>

    <form class=wrapper1 action="' . $r->unparsed_uri() . '">
    
    <div class=formflexN2>
        <label style="width: 10%;" class="forms2_label" for="date_comptant20">Date</label>
		<label style="width: 18%;" class="forms2_label" for="compte_comptant10">Compte</label>
		<label style="width: 32%;" class="forms2_label" for="libelle4">Libellé</label>
		<label style="width: 10%;" class="forms2_label" for="montant5">Montant</label>
		<label style="width: 18%;" class="forms2_label" for="compte_charge_comptant">Compte de charge</label>
	</div>	
	
	<div class=formflexN2>
		<input class="forms2_input" style="width: 10%;" type="text" name=date_comptant id=date_comptant20 value="' . ($args->{date_comptant} || $date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required>
		' . $compte_comptant . '
		<input class="forms2_input" style="width: 32%;" type=text id=libelle4 name=libelle value="'.($args->{libelle}|| '').'" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\', 4)" list="libellelist_4"><datalist id="libellelist_4"></datalist>
		<input class="forms2_input" style="width: 10%;" type=text id=montant5 name=montant value="'.($args->{montant} || $montant_entry || '').'" onchange="format_and_stage(this)" required/>
		' . $compte_charge_comptant . '
	</div>

	<div class=formflexN2>
        <label style="width: 13%;" class="forms2_label" for="select_achats1">Réglement</label>
        <label style="width: 28%;" class="forms2_label" for="docs12" >Documents 1</label>
        <label style="width: 28%;" class="forms2_label" for="docs22">Documents 2</label>
        <label style="width: 15%;" class="forms2_label" for="calcul_piece3">Pièce</label>
        <label style="width: 10%;" class="forms2_label" for="submit3">&nbsp;</label>
    </div>    
    
    <div class=formflexN2>    
        ' . $select_achats . '
		' . $document_select1 . '
		' . $document_select2 . '
		<input class="forms2_input" style="width: 15%;" type=text id=calcul_piece3 name=calcul_piece3 value="'.($args->{calcul_piece3} || $calcul_piece3 || '').'" required/>
		<input type=submit id=submit3 style="width: 10%;" class="btn btn-vert" value=Valider>
	</div>
		
	<input type=hidden name="achat_comptant" id="achat_comptant" value="0">
	<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">
	
	</form>';

	$content .= $contenu_web_ach_comptant;

    return $content ;
	############## MISE EN FORME FIN ##############

} #sub forms_paiement_comptant 	
	
#/*—————————————— Formulaire Ecritures récurrentes ——————————————*/
sub forms_ecri_rec {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
    my ($token_id, $entry_list, $verif_list) ;
    my @token ;
	my  $id_entry= '';
	
	# Sélection du mois
	my $select_month = '<select class="forms2_input" style="width: 13%;" name=select_month id=select_month>
	<option value="01">Janvier</option>
	<option value="02">Février</option>
	<option value="03">Mars</option>
	<option value="04">Avril</option>
	<option value="05">Mai</option>
	<option value="06">Juin</option>
	<option value="07">Juillet</option>
	<option value="08">Août</option>
	<option value="09">Septembre</option>
	<option value="10">Octobre</option>
	<option value="11">Novembre</option>
	<option value="12">Décembre</option>
	</select>' ;
	
	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my ($id_name, $document_select1, $document_select2);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs1} && (!defined $args->{docs_doc_entry} && !defined $args->{label8})){
    $document_select1 = '<select class="forms2_input" style="width: 26%;" name=docs1 id=docs14>
    <option value="" selected>--Sélectionner le document 1--</option>' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 26%;" name=docs1 id=docs14>
    <option value="" >--Sélectionner le document 1--</option>' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs2} && (!defined $args->{docs_doc_entry} && !defined $args->{label9})){
    $document_select2 = '<select class="forms2_input" style="width: 26%;" name=docs2 id=docs24>
    <option value="" selected>--Sélectionner le document 2--</option>' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 26%;" name=docs2 id=docs24>
    <option value="" >--Sélectionner le document 2--</option>' ;
	}
	
    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
			my $selected1 = (($_->{id_name} eq ($args->{docs1} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1)) ? 'selected' : '' ;
			my $selected2 = (($_->{id_name} eq ($args->{docs2} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1)) ? 'selected' : '' ;
			$document_select1 .= '<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>' ;
			$document_select2 .= '<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>' ;		
	    }
		$id_name = $_->{id_name} ;	
    }
    
    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
	############## MISE EN FORME DEBUT ##############
	# Formulaire de génération des écritures récurrentes 	
	my $contenu_web_ecri_rec .= '
		<div class="Titre10 centrer"><a class=aperso2>Générer les écritures récurrentes</a></div>
		<form class=wrapper1 action="' . $r->unparsed_uri() . '">
    
		<div class=formflexN2>
        <label style="width: 13%;" class="forms2_label" for="select_month">Sélectionner le mois</label>
		<label style="width: 26%;" class="forms2_label" for="docs14">Modifier document 1</label>
		<label style="width: 26%;" class="forms2_label" for="docs24">Modifier document 2</label>
		<label style="width: 33%;" class="forms2_label" for="periodicite">Indiquer la périodicité dans le libellé de l\'écriture ?</label>
		</div>
       
		<div class=formflexN2>
        ' . $select_month . '
        ' . $document_select1 . '
        ' . $document_select2 . '
        <input class="forms2_input" type="checkbox" style="width: 33%; height:4ch;" id="periodicite" name="add_periodicite" value=1 checked>
        </div>
        
		<div class=formflexN3>
		<input type=submit id=submit10 style="width: 10%;" class="btn btn-vert" value=Générer>
		</div>
        
		<input type=hidden name="ecriture_recurrente" id="ecriture_recurrente" value="0">
		<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">
		</form>';

	#Vérification si des écritures récurrentes n'en pas encore été générée dans tbljournal_staging 
    $sql = '
    SELECT t1.id_entry, t1.id_export, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit, lettrage, pointage, recurrent, _token_id
	FROM tbljournal_staging t1 
	WHERE t1._token_id LIKE \'%recurrent%\' AND id_client = ? AND fiscal_year = ?
	ORDER BY date_ecriture, libelle, _token_id
	' ;

	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	my $result_gen = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;
	
	# Ajout du menu Vérification des écritures récurrentes à générer 
	if ( @$result_gen ) {
		$verif_list .= '<div class="Titre10 centrer"><a class=aperso2 id=rec >Ecritures récurrentes générées en attente de validation</a></div><br>';
	
		$verif_list .= '
		<form action="' . $r->unparsed_uri() . '">
		<ul class="wrapper style1">
		<li class="style1"><div class=flex-table><div class=spacer></div>
		<span class=headerspan style="width: 8%;">Date</span>
		<span class=headerspan style="width: 8%;">Libre</span>
		<span class=headerspan style="width: 8%;">Journal</span>
		<span class=headerspan style="width: 8%;">Compte</span>
		<span class=headerspan style="width: 12%;">Pièce</span>
		<span class=headerspan style="width: 28.9%;">Libellé</span>
		<span class=headerspan style="width: 8%; text-align: right;">Débit</span>
		<span class=headerspan style="width: 8%; text-align: right;">Crédit</span>
		<span class=headerspan style="width: 5%; text-align: center;">&nbsp;</span>
		<span class=headerspan style="width: 4%; text-align: center;">&nbsp;</span>
		<div class=spacer></div></div></li>' ;

		my $token_entry = '';
		my $id_entry_href;
	
		for ( @$result_gen ) {
			
			#my $pointage = '<span class=displayspan style="width: 1%; margin-left: 1ch; margin-right: 1ch;">&nbsp;</span>';

			if ( defined $token_entry ) { 
		
				unless ( $_->{_token_id} eq $token_entry ) {

					#lien de modification de l'entrée
					my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;mois=0&amp;id_entry=' . $_->{id_entry}. '&amp;_token_id=' . $_->{_token_id};
					
					#cas particulier de la première entrée de la liste : pas de liste précédente
					unless ( $token_entry ) {
						$entry_list .= '<li class=listitem>' ;
						#$pointage = '<span class=displayspan style="width: 1%; margin-left: 1ch; margin-right: 1ch;"><input id="tok1" type="checkbox" class="forms2_input" name="token" value=' . $_->{_token_id}.' checked></span>';
						} else {
						$entry_list .= '</a></li><li class=listitem>';
						#$pointage = '<span class=displayspan style="width: 1%; margin-left: 1ch; margin-right: 1ch;"><input id="tok1" type="checkbox" class="forms2_input" name="token" value=' . $_->{_token_id}.' checked></span>';
					} #	    unless ( $token_entry ) 
	
				} #	unless ( $_->{_token_id} eq $token_entry ) 
		
			}
			
			my $http_link_documents1 = '';
			my $http_link_documents2 = '';

			if ( $_->{documents1} =~ /docx|odt|pdf|jpg/) { 
				my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
 				my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents1} ) ;
				if ($id_name_documents->[0]->{id_name} || '') {
					$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img class=redimmage style="border: 0;" src="/Compta/style/icons/documents.png" alt="documents"></a>' ;
				} else {
					$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
				} 
			} 	
			 
			if ( $_->{documents2} =~ /docx|odt|pdf|jpg/) { 
				my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
				my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents2} ) ;
				if ($id_name_documents->[0]->{id_name} || '') {
					$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img class=redimmage style="border: 0;" src="/Compta/style/icons/releve-bancaire.png" alt="releve-bancaire"></a>' ;	
				} else {
					$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
				} 
			} 	

			#marquer l'entrée en cours
			$token_entry = $_->{_token_id} ;
			
			#Ajouter l'argument id_name si on vient de docsentry
			my $docsentry ;
			if (defined $args->{id_name} && $args->{id_name} ne '') {
			$docsentry = '&amp;id_name=' . ($args->{id_name} || ''). '';
			}
			
			#lien de modification de l'entrée
			my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;mois=0&amp;id_entry=' . $_->{id_entry} . ($docsentry || ''). '&amp;_token_id=' . $_->{_token_id};

			$sql = 'SELECT libelle_compte FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND numero_compte like ? ORDER BY 1 DESC LIMIT 1';
			my $libelle_compte_set = $dbh->selectall_arrayref(  $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $_->{numero_compte} ) ) ;

			$entry_list .= '
				<div class=flex-table><div class=spacer></div><a href="' . ($id_entry_href || ''). '" >
				<span class=displayspan style="width: 8%;">' . ($_->{date_ecriture} || '&nbsp;') . '</span>
				<span class=displayspan style="width: 8%;">' . ($_->{id_paiement}  || '&nbsp;') . '</span>
				<span class=displayspan style="width: 8%;">' . ($_->{libelle_journal}  || '&nbsp;') .'</span>
				<span class=displayspan style="width: 8%;" title="'. ($libelle_compte_set->[0]->{libelle_compte}  || '&nbsp;') .'">' . ($_->{numero_compte}  || '&nbsp;') . '</span>
				<span class=displayspan style="width: 12%;">' . ($_->{id_facture}  || '&nbsp;') . '</span>
				<span class=displayspan style="width: 28.9%;">' . ($_->{libelle} || '&nbsp;') . '</span>
				<span class=displayspan style="width: 8%; text-align: right;">' . $_->{debit} . '</span>
				<span class=displayspan style="width: 8%; text-align: right;">' .  $_->{credit} . '</span>
				<span style="width: 2.4%; margin-left : 1%;">' . ($http_link_documents1 || '<a><img class=redimmage style="border: 0;" src="/Compta/style/icons/vide.png" alt="" height="16" width="16"></a>' ) . '</span>
				<span style="width: 2.4%; margin-left : 0.5%;">' . ($http_link_documents2 || '<img class=redimmage style="border: 0;" src="/Compta/style/icons/vide.png" alt="" height="16" width="16">' ) . '</span>
				<div class=spacer>
				</div>
				</div>
				' ;

		}#Fin Boucle for ( @$result_gen ) 
 
		#on clot la liste s'il y avait au moins une entrée dans le journal
		$entry_list .= '</a></li>' if ( @$result_gen ) ;
		
		$entry_list .= '
			</ul>
			<div class="form-int" style="display: flex; align-items:center; justify-content: flex-end;">
			<form action="' . $r->unparsed_uri() . '">
			<input type="submit" class="btn btn-vert" style ="width : 250px;" value="Valider toutes les écritures">
			<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">
			<input type=hidden name="ecriture_recurrente" id="ecriture_recurrente" value="4">
			</form>
			<form action="' . $r->unparsed_uri() . '">
			<input type="submit" class="btn btn-rouge" style ="width : 250px;" value="Supprimer toutes les écritures">
			<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">
			<input type=hidden name="ecriture_recurrente" id="ecriture_recurrente" value="5">
			</form>
			</div>
			';
		

	}#Fin Boucle if ( @$result_gen ) 

	#/************ ACTION DEBUT *************/
 
	#demande confirmation génération ecriture_recurrente 											  
	#menu?select_month=12&ecriture_recurrente=0
	if ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '0' ) {
		
		$sql = '
		with t1 as ( SELECT id_entry, date_ecriture FROM tbljournal
		WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
		GROUP BY id_entry, date_ecriture)
		SELECT count(id_entry) FROM t1
		';

		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;

		my $en_attente_count = '';
		
		eval { $en_attente_count = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] } ;	
	
		if ( $@ ) {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			return $content ;  
		} #	if 
		
		if ($en_attente_count != 0) {
			
			(my $confirm_href = $r->unparsed_uri()) =~ s/&ecriture_recurrente=0/&ecriture_recurrente=1/ ;
			$confirm_href =~ s/docsentry/menu/ ;
			(my $deny_href = $r->unparsed_uri()) =~ s/&ecriture_recurrente=0/&ecriture_recurrente=9/ ;
			my $message = ( 'Voulez-vous vraiment générer les ' . $en_attente_count .' écritures récurrentes pour le mois ' . $args->{select_month} .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
			$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;	
			
		} else {

			(my $confirm_href = $r->unparsed_uri()) =~ s/&ecriture_recurrente=0/&ecriture_recurrente=2/ ;
			$confirm_href =~ s/docsentry/menu/ ;
			(my $deny_href = $r->unparsed_uri()) =~ s/&ecriture_recurrente=0/&ecriture_recurrente=9/ ;
			my $message = ( 'Il n\'y a aucune écriture récurrente de paramétrée sur cette exercice. <br> 
			Voulez-vous importer les écritures récurrentes de l\'exercice précédent ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
			$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;		
		}
		
	# enregistrement des écritures récurrentes	
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '1' ) {

		$sql = '
		SELECT id_entry, date_ecriture FROM tbljournal
		WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
		GROUP BY id_entry, date_ecriture
		';
	
		my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;

		foreach ( @{$resultat} ) {
	
			my $token_id_temp = join "", map +(0..9,"a".."z","A".."Z")[rand(10+26*2)], 1..32 ;	
			$token_id = 'recurrent-'.$token_id_temp ;
		
			my $day = substr($_->{date_ecriture},0,2);
			my $date = $r->pnotes('session')->{fiscal_year}.'-'.$args->{select_month}.'-'.$day;
			my $yyyy = $r->pnotes('session')->{fiscal_year}; 
			my $mm = $args->{select_month}; 
			my $from = "(?:0[1-9]|1[0-2])/(?<year>[0-9]{4})";  
			my $to = $mm.'/'.$yyyy;
			
	        if (not($date =~ /(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))/)) {
			$date = $r->pnotes('session')->{fiscal_year}.'-'.$args->{select_month}.'-05';	
			}
					
			$sql = '
			INSERT INTO tbljournal_staging (_session_id, id_entry, id_client, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, numero_compte, date_ecriture, id_paiement, id_facture, libelle, documents1, documents2, debit, credit, _token_id ) SELECT ?, ?, t1.id_client, t1.fiscal_year, ?, ?, ?, t1.libelle_journal, t1.numero_compte, ?, t1.id_paiement, t1.id_facture, t1.libelle, t1.documents1, t1.documents2, t1.debit, t1.credit, ?
			FROM tbljournal t1 
			WHERE t1.id_entry = ? ORDER BY id_line' ;
			@bind_array = ( $r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $date, $token_id, $_->{id_entry} ) ;

			$dbh->do( $sql, undef, @bind_array ) ;
	
			#update le choix du document
			
			if ((defined $args->{docs2}) && (not($args->{docs2} eq ''))) {
				$sql = 'UPDATE tbljournal_staging SET documents2 = ? WHERE _token_id = ? AND documents2 is not null' ;
				@bind_array = ( ($args->{docs2} || undef), $token_id ) ;
				$dbh->do( $sql, undef, @bind_array ) ;	
			} 
			
			if ((defined $args->{docs1}) && (not($args->{docs1} eq ''))) {
				$sql = 'UPDATE tbljournal_staging SET documents1 = ? WHERE _token_id = ? AND documents1 is not null' ;
				@bind_array = ( ($args->{docs1} || undef), $token_id ) ;
				$dbh->do( $sql, undef, @bind_array ) ;	
			} 
			
			#Ajout de la périodicité dans le libellé de l'écriture
			if ( defined $args->{add_periodicite} and $args->{add_periodicite} eq '1' ) {

				$sql = 'SELECT id_line, libelle FROM tbljournal_staging WHERE _token_id = ? ORDER BY id_line' ;

				my $resultat_lib = $dbh->selectall_arrayref( $sql, { Slice => { } }, $token_id) ;

				foreach ( @{$resultat_lib} ) {
 	
					my $lib = $_->{libelle} ;
					my $dateform1 = "(?:0[1-9]|1[0-2])/(?<year>[0-9]{2})";
					my $dateform2 = "(?:0[1-9]|1[0-2])/(?<year>[0-9]{4})";
      
					if ($lib =~ /(?:0[1-9]|1[0-2])\/(?<year>[0-9]{4})/) {
					$lib =~s/$dateform2/$to/ig;
					} elsif ($lib =~ /(?:0[1-9]|1[0-2])\/(?<year>[0-9]{2})/) {
					$lib =~s/$dateform1/$to/ig;
					}
	
					#update du libellé 	
					$sql = 'UPDATE tbljournal_staging SET libelle = ? WHERE _token_id = ? and id_line = ?' ;
					@bind_array = ( $lib, $token_id, $_->{id_line}  ) ;
					$dbh->do( $sql, undef, @bind_array ) ;
	
				}#Fin foreach ( @{$resultat_lib})
				
			}#Fin $args->{add_periodicite}

			push @token, $token_id;
			
		}#Fin foreach ( @{$resultat})
	
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Génération des écritures récurrentes à valider pour le mois ' . $args->{select_month} .'');

		my $varmenu ;	
		if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}.'&amp;ecriture_recurrente='} else { $varmenu = 'menu?&amp;menu3=1';}

		#rediriger l'utilisateur vers la page d'accueil
		my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
		$r->headers_out->set(Location => $location) ;
		#rediriger le navigateur vers le fichier
		$r->status(Apache2::Const::REDIRECT) ;
		return Apache2::Const::REDIRECT ;   
	
	# enregistrement des écritures récurrentes de l'exercice précédent	
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '2' ) {
	
		$sql = '
		SELECT id_entry, date_ecriture FROM tbljournal
		WHERE id_client = ? AND recurrent = true AND fiscal_year = ?
		GROUP BY id_entry, date_ecriture
		';
		
		my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} - 1) ) ;
		
		foreach ( @{$resultat} ) {
	
			my $token_id_temp = join "", map +(0..9,"a".."z","A".."Z")[rand(10+26*2)], 1..32 ;	
			$token_id = 'recurrent-'.$token_id_temp ;
		
			my $day = substr($_->{date_ecriture},0,2);
			my $date = $r->pnotes('session')->{fiscal_year}.'-'.$args->{select_month}.'-'.$day;
			my $yyyy = $r->pnotes('session')->{fiscal_year}; 
			my $mm = $args->{select_month}; 
			my $from = "(?:0[1-9]|1[0-2])/(?<year>[0-9]{4})";  
			my $to = $mm.'/'.$yyyy;
	
			$sql = '
			INSERT INTO tbljournal_staging (_session_id, id_entry, id_client, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, numero_compte, date_ecriture, id_paiement, id_facture, libelle, documents1, documents2, debit, credit, _token_id ) SELECT ?, ?, t1.id_client, t1.fiscal_year + 1, ?, ?, ?, t1.libelle_journal, t1.numero_compte, ?, t1.id_paiement, t1.id_facture, t1.libelle, t1.documents1, t1.documents2, t1.debit, t1.credit, ?
			FROM tbljournal t1 
			WHERE t1.id_entry = ? ORDER BY id_line' ;
			@bind_array = ( $r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $date, $token_id, $_->{id_entry} ) ;

			$dbh->do( $sql, undef, @bind_array ) ;
	
			#update le choix du document
			
			if ((defined $args->{doc2}) && (not($args->{doc2} eq ''))) {
				$sql = 'UPDATE tbljournal_staging SET documents2 = ? WHERE _token_id = ? AND documents2 is not null' ;
				@bind_array = ( ($args->{doc2} || undef), $token_id ) ;
				$dbh->do( $sql, undef, @bind_array ) ;	
			} 
			
			if ((defined $args->{doc1}) && (not($args->{doc1} eq ''))) {
				$sql = 'UPDATE tbljournal_staging SET documents1 = ? WHERE _token_id = ? AND documents1 is not null' ;
				@bind_array = ( ($args->{doc1} || undef), $token_id ) ;
				$dbh->do( $sql, undef, @bind_array ) ;	
			} 
			
			#Ajout de la périodicité dans le libellé de l'écriture
			if ( defined $args->{add_periodicite} and $args->{add_periodicite} eq '1' ) {

				$sql = 'SELECT id_line, libelle FROM tbljournal_staging WHERE _token_id = ? ORDER BY id_line' ;

				my $resultat_lib = $dbh->selectall_arrayref( $sql, { Slice => { } }, $token_id) ;

				foreach ( @{$resultat_lib} ) {
 	
					my $lib = $_->{libelle} ;
					my $dateform1 = "(?:0[1-9]|1[0-2])/(?<year>[0-9]{2})";
					my $dateform2 = "(?:0[1-9]|1[0-2])/(?<year>[0-9]{4})";
      
					if ($lib =~ /(?:0[1-9]|1[0-2])\/(?<year>[0-9]{4})/) {
					$lib =~s/$dateform2/$to/ig;
					} elsif ($lib =~ /(?:0[1-9]|1[0-2])\/(?<year>[0-9]{2})/) {
					$lib =~s/$dateform1/$to/ig;
					}
	
					#update du libellé 	
					$sql = 'UPDATE tbljournal_staging SET libelle = ? WHERE _token_id = ? and id_line = ?' ;
					@bind_array = ( $lib, $token_id, $_->{id_line}  ) ;
					$dbh->do( $sql, undef, @bind_array ) ;
	
				}#Fin foreach ( @{$resultat_lib})
				
			}#Fin $args->{add_periodicite}

			push @token, $token_id;
			
		}#Fin foreach ( @{$resultat})
	
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Génération des écritures récurrentes à valider pour le mois ' . $args->{select_month} .' (depuis l\'exercice précédent)');

		my $varmenu ;	
		if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}.'&amp;ecriture_recurrente='} else { $varmenu = 'menu?&amp;menu3=1';}

		#rediriger l'utilisateur vers la page d'accueil
		my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
		$r->headers_out->set(Location => $location) ;
		#rediriger le navigateur vers le fichier
		$r->status(Apache2::Const::REDIRECT) ;
		return Apache2::Const::REDIRECT ;   
    	
	#demande confirmation validation des ecritures recurrentes	
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '4' ) {
		
		(my $confirm_href = $r->unparsed_uri()) =~ s/ecriture_recurrente=4/ecriture_recurrente=7/ ;
		$confirm_href =~ s/docsentry/menu/ ;
		(my $deny_href = $r->unparsed_uri()) =~ s/&ecriture_recurrente=4/&ecriture_recurrente=9/ ;
		my $message = ( 'Voulez-vous vraiment valider toutes les écritures récurrentes en attente de validation ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;	

	#demande confirmation suppression des ecritures recurrentes		
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '5' ) {
		
		(my $confirm_href = $r->unparsed_uri()) =~ s/ecriture_recurrente=5/ecriture_recurrente=6/ ;
		$confirm_href =~ s/docsentry/menu/ ;
		(my $deny_href = $r->unparsed_uri()) =~ s/&ecriture_recurrente=5/&ecriture_recurrente=9/ ;
		my $message = ( 'Voulez-vous vraiment supprimer toutes les écritures récurrentes en attente de validation ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;	
	
	#suppression des ecritures recurrentes	
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '6' ) {	
	
		#on supprime toutes les données concernant les écritures récurrentes dans tbljournal_staging pour cet utilisateur
		$sql = 'DELETE FROM tbljournal_staging WHERE id_client = ? AND _token_id LIKE \'%recurrent%\'';
		@bind_array = ($r->pnotes('session')->{id_client}) ;
		$dbh->do( $sql, undef, @bind_array ) ;
		
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Suppression de toutes les écritures récurrentes en attente de validation');

		my $varmenu ;	
		if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}.'&amp;ecriture_recurrente='} else { $varmenu = 'menu?&amp;menu3=1';}

		#rediriger l'utilisateur vers la page d'accueil
		my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
		$r->headers_out->set(Location => $location) ;
		#rediriger le navigateur vers le fichier
		$r->status(Apache2::Const::REDIRECT) ;
		return Apache2::Const::REDIRECT ;  
	
	#validation des ecritures recurrentes
	} elsif ( defined $args->{ecriture_recurrente} and $args->{ecriture_recurrente} eq '7' ) {
				
		$sql = '
		SELECT _token_id FROM tbljournal_staging t1 
		WHERE t1._token_id LIKE \'%recurrent%\' AND id_client = ? AND fiscal_year = ?
		' ;
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
		my $result_gen = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;
		
		foreach ( @{$result_gen} ) {
			
			$sql = 'SELECT record_staging(?, ?)' ;
			eval { $dbh->selectall_arrayref( $sql, undef, ( $_->{_token_id}, 0 ) ) } ;
			#erreur dans la procédure store_staging : l'afficher dans le navigateur
			if ( $@ ) {
				if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : Il faut une date valide - Enregistrement impossible');
				} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : Un numéro de compte est invalide - Enregistrement impossible');
				} elsif ( $@ =~ /unbalanced/ ) {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : Montants déséquilibrés - Enregistrement impossible');
				} elsif ( $@ =~ / bad fiscal / ) {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible');
				} elsif ( $@ =~ /archived/ ) {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible');
				} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : Il faut un numéro de compte pour chaque ligne');
				} else {
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Ecritures récurrentes : ' . $@ . '');
				} #	     if ( $@ =~ /date_ecriture/ )
			}
		}
		
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => Enregistrement de toutes les écritures récurrentes en attente de validation');
		
		my $varmenu ;	
		if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}.'&amp;ecriture_recurrente='} else { $varmenu = 'menu?&amp;menu3=1';}

		#rediriger l'utilisateur vers la page d'accueil
		my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
		$r->headers_out->set(Location => $location) ;
		#rediriger le navigateur vers le fichier
		$r->status(Apache2::Const::REDIRECT) ;
		return Apache2::Const::REDIRECT ;  
	}
	
	$content .= $contenu_web_ecri_rec;
	
	$content .= ($verif_list || '') . ($entry_list || '') ;

	return $content ;
	############## MISE EN FORME FIN ##############

}#sub forms_ecri_rec 		
		
#/*—————————————— Formulaire Transfert entre comptes ——————————————*/
sub forms_transfert_compte {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content) ;
	my ($calcul_piece, $compte_var, $reglement_journal_1, $journal1, $journal2, $month, $year) ;
	my $selected = '';
		
	# récupération des variables de docsentry.pm
	my ($date_comptant, $montant_entry) ;
	if (defined $args->{date_doc_entry}) {$date_comptant = $args->{date_doc_entry} ;}
	if (defined $args->{montant_doc_entry}) {$montant_entry = $args->{montant_doc_entry} ;}
	
	#/************ ACTION DEBUT *************/
		
	#demande confirmation move_compte 											  #
	#menu?date_comptant=2021-10-09&id_compte_1_select=R%C3%A9glement+Banque&id_compte_2_select=R%C3%A9glement+Paypal&libelle=test&montant=100.00&docs1=&docs2=&move_compte=0
	if ( defined $args->{move_compte} and $args->{move_compte} eq '0' ) {
	
		if 	(defined $args->{id_compte_1_select} && $args->{id_compte_1_select} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le compte de départ n\'a pas été sélectionné</h3>' ;	
		} elsif (defined $args->{id_compte_2_select} && $args->{id_compte_2_select} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le compte de destination n\'a pas été sélectionné</h3>' ;	
		} elsif (defined $args->{montant} && $args->{montant} eq '0.00') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le montant est à 0.00</h3>' ;	
		} else {	
		(my $confirm_href = $r->unparsed_uri()) =~ s/&move_compte=0/&move_compte=1/ ;
		$confirm_href =~ s/docsentry/menu/ ;
		(my $deny_href = $r->unparsed_uri()) =~ s/&move_compte=0/&move_compte=9/ ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Du compte ' . ($args->{id_compte_1_select} || '') .' vers le compte ' . ($args->{id_compte_2_select} || '') .' d\'un montant de ' . ($args->{montant} || '') .'€ avec pour libellé ' . ($args->{libelle} || '') .' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}

	}  elsif ( defined $args->{move_compte} and $args->{move_compte} eq '1' ) {
	
		#récupération journal de réglement et compte de réglement pour id_compte_1_select et id_compte_2_select
		$sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? and config_libelle = ? AND module = \'achats\'' ;
		my $resultat_1 = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{id_compte_1_select} ) ) ;
		my $resultat_2 = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{id_compte_2_select} ) ) ;
		my $reglement_journal_1 = $resultat_1->[0]->{config_journal};
		my $reglement_compte_1 = $resultat_1->[0]->{config_compte};
		my $reglement_journal_2 = $resultat_2->[0]->{config_journal};
		my $reglement_compte_2 = $resultat_2->[0]->{config_compte};
	
		#mise en forme montant pour enregistrement en bdd
		#ne pas laisser des montants nulls : mettre un zéro
		$args->{montant} ||= '0.00';
		#remplacer la virgule par le point dans les montants soumis
		$args->{montant} =~ s/,/./ ;
		#enlever les espaces de présentation
		$args->{montant} =~ s/\s//g ;
	
		#recherche du lettrage existant pour ce compte
		$sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
		
		my $lettrage_total = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;
		
		$sql = 'SELECT lettrage FROM tbljournal WHERE id_client = ? AND fiscal_year = ? AND numero_compte = \'580000\' AND lettrage IS NOT NULL ORDER BY length(lettrage) DESC, lettrage DESC LIMIT 1' ;
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
		
		my $lettrage = $dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] ;

		if ( $lettrage ) {
		$lettrage++ ;
		} else {
		if ($lettrage_total) {
		my $lettrage_sub = substr( $lettrage_total, 0, 2 );
		$lettrage = ++$lettrage_sub.'01';
		} else {
		$lettrage = 'AA01' ;
		}	
		}
		
		#supprime les espaces de début et de fin de ligne
		$args->{libelle} =~ s/^\s+|\s+$//g;

		#première écriture
		$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
		@bind_array = ( 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte_1, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_1, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, '580000', $lettrage, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_1, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
		$dbh->do( $sql, undef, @bind_array ) ;
		$sql = 'SELECT record_staging(?, ?)' ;
		eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
		#erreur dans la procédure store_staging : l'afficher dans le navigateur
		if ( $@ ) {
			if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
			$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
			$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /unbalanced/ ) {
			$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ / bad fiscal / ) {
			$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /archived/ ) {
			$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
			$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
			} else {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}
		} else {      

			#deuxième écriture
			$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
			@bind_array = ( 
			$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte_2, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_2, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
			$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, '580000', $lettrage, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $args->{piece}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal_2, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
			$dbh->do( $sql, undef, @bind_array ) ;
			$sql = 'SELECT record_staging(?, ?)' ;
			eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
			#erreur dans la procédure store_staging : l'afficher dans le navigateur
			if ( $@ ) {
				if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
				$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
				$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /unbalanced/ ) {
				$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ / bad fiscal / ) {
				$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /archived/ ) {
				$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
				} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
				$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
				} else {
				$content .= '<h3 class=warning>' . $@ . '</h3>' ;
				}
			} else {
				
				Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm =>	Transfert du compte ' . ($reglement_compte_1 || '') .' (journal  '.($reglement_journal_1 || '' ).') vers le compte ' . ($reglement_compte_2 || '') .' (journal  '.($reglement_journal_2 || '' ).') d\'un montant de ' . ($args->{montant} || '') .'€ avec pour libellé ' . ($args->{libelle} || '') .'');
		
				my $varmenu ;	
				if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}} else { $varmenu = 'journal?open_journal='.($reglement_journal_1 || '' ).'';}

				#rediriger l'utilisateur vers la page d'accueil
				my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
				$r->headers_out->set(Location => $location) ;
				#rediriger le navigateur vers le fichier
				$r->status(Apache2::Const::REDIRECT) ;
				return Apache2::Const::REDIRECT ;   
			
			}     
    
		}	
		
	}

	#/************ ACTION FIN *************/
		
	#####################################       
	# Récupérations d'informations		#
	#####################################   

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? AND module = \'achats\'ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    
    #select_achats
	my $select_achats = '<select class="login-text" name=select_achats id=select_achats2>' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	$select_achats .= '<option value="' . $_->{config_libelle} . '">' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;
	
    #id_compte_1_select
	my $id_compte_1_select = '<select class="forms2_input" style="width: 10%;" onchange="calcul_piece_journal(this, \'' . $r->pnotes('session')->{racine} . '\')" name=id_compte_1_select id=id_compte_1_select>' ;
	$id_compte_1_select .= '<option value="" selected>--Choix Compte--</option>' ;
	for ( @$resultat_tblconfig ) {
	if 	(defined $args->{id_compte_1_select}) {
	$selected = ( $_->{config_libelle} eq $args->{id_compte_1_select} ) ? 'selected' : '' ;
	}
	$id_compte_1_select .= '<option value="' . $_->{config_libelle} . '" '.$selected .'>' . $_->{config_libelle} . '</option>' ;
	}
	$id_compte_1_select .= '</select>' ;
	
	#id_compte_2_select
	my $id_compte_2_select = '<select class="forms2_input" style="width: 10%;" name=id_compte_2_select id=id_compte_2_select>' ;
	$id_compte_2_select .= '<option value="" selected>--Choix Compte--</option>' ;
	for ( @$resultat_tblconfig ) {
			if 	(defined $args->{id_compte_2_select}) {
	$selected = ( $_->{config_libelle} eq $args->{id_compte_2_select} ) ? 'selected' : '' ;
	}
	$id_compte_2_select .= '<option value="' . $_->{config_libelle} . '" '.$selected .'>' . $_->{config_libelle} . '</option>' ;
	}
	$id_compte_2_select .= '</select>' ;
	
	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my ($id_name, $document_select1, $document_select2);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs1} && (!defined $args->{docs_doc_entry} && !defined $args->{label8})){
    $document_select1 = '<select class="forms2_input" style="width: 35%;" name=docs1 id=docs11>
    <option value="" selected>--Sélectionner le document 1--</option>' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 35%;" name=docs1 id=docs11>
    <option value="" >--Sélectionner le document 1--</option>' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs2} && (!defined $args->{docs_doc_entry} && !defined $args->{label9})){
    $document_select2 = '<select class="forms2_input" style="width: 35%;" name=docs2 id=docs21>
    <option value="" selected>--Sélectionner le document 2--</option>' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 35%;" name=docs2 id=docs21>
    <option value="" >--Sélectionner le document 2--</option>' ;
	}
	
    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
			my $selected1 = (($_->{id_name} eq ($args->{docs1} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1)) ? 'selected' : '' ;
			my $selected2 = (($_->{id_name} eq ($args->{docs2} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1)) ? 'selected' : '' ;
			$document_select1 .= '<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>' ;
			$document_select2 .= '<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>' ;		
	    }
		$id_name = $_->{id_name} ;	
    }
    
    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
    
	############## MISE EN FORME DEBUT ##############

	#fonction javascript qui efface le lien de téléchargement si l'utilisateur modifie la date
	#ce dernier doit alors cliquer sur 'Valider' pour que le lien réapparaisse avec la nouvelle date
	# + document.getElementById => affichage des options via le bouton
	#my $contenu_web_move_compte .= '<script>var update_nom_periode = function(input) {document.getElementById("nom_periode").value = input.options[input.selectedIndex].text}</script>' ;


	my $contenu_web_move_compte .= '
	
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Transfert entre comptes</a></div>
	
	<span class="memoinfo">Mémo: total débit du relevé = total credit du 512 et total crédit du relevé => total débit du 512</span>
	<br>
		
    <form class=wrapper1 action="' . $r->unparsed_uri() . '">
   
    <div class=formflexN2>
		<label style="width: 10%;" class="forms2_label" for="date_comptant">Date</label>
		<label style="width: 10%;" class="forms2_label" for="id_compte_1_select">Transfert de :</label>
        <label style="width: 10%;" class="forms2_label" for="id_compte_2_select">vers :</label>
        <label style="width: 40%;" class="forms2_label" for="libelle2">Libellé</label>
        <label style="width: 10%;" class="forms2_label" for="montant2">Montant</label>
		<label style="width: 10%;" class="forms2_label" for="calcul_piece">Pièce</label>
    </div>
    
    <div class=formflexN2>
    	<input class="forms2_input" style="width: 10%;" type="text" name=date_comptant id=date_comptant value="' . ($args->{date_comptant} || $date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" onblur="calcul_piece_date(this, \'' . $r->pnotes('session')->{racine} . '\')" required>
		' . $id_compte_1_select . '
		' . $id_compte_2_select . '
		<input class="forms2_input" style="width: 40%;" type=text id=libelle2 name=libelle value="'.($args->{libelle}|| '').'" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\', 2)" list="libellelist_2"><datalist id="libellelist_2"></datalist>
		<input class="forms2_input" style="width: 10%;" type=text id=montant2 name=montant value="'.($args->{montant} || $montant_entry || '').'"  required/>
		<input class="forms2_input" style="width: 10%;" type=text id=calcul_piece name=piece value="'.($args->{piece} || $calcul_piece || '').'" required/>
	</div>
	
	<div class=formflexN2>
	<label style="width: 35%;" class="forms2_label" for="docs11">Documents 1</label>
	<label style="width: 35%;" class="forms2_label" for="docs21">Documents 2</label>
	<label style="width: 10%;" class="forms2_label" for="submit2">&nbsp;</label>
    </div>   
    
    <div class=formflexN2>    
        ' . $document_select1 . '
		' . $document_select2 . '
		<input type=submit id=submit2 style="width: 10%;" class="btn btn-vert" value=Valider>
	</div>
	
	<input type=hidden name="move_compte" id="move_compte" value="0">
	<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">

	</form>';	
		
	$content .= $contenu_web_move_compte;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_transfert_compte 

#/*—————————————— Formulaire Saisie reglement client 	——————————————*/
sub forms_reglement_client {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
	my $selected = '';
	
	# récupération des variables de docsentry.pm
	my ($date_comptant, $montant_entry, $id_docs);
	if (defined $args->{date_doc_entry}) {$date_comptant = $args->{date_doc_entry} ;}
	if (defined $args->{montant_doc_entry}) {$montant_entry = $args->{montant_doc_entry} ;}
	if (defined $args->{docs_doc_entry}) {$id_docs = $args->{docs_doc_entry} ;}
	
	#/************ ACTION DEBUT *************/
	
	#demande confirmation reglement_client 						      
	#menu?date_comptant=30%2F04%2F2021&compte_client=411302&libelle=test&montant=780.00&select_achats=Banque&docs1=&docs2=&reglement_client=0
    if ( defined $args->{reglement_client} and $args->{reglement_client} eq '0' ) {
		
		if 	(defined $args->{compte_client} && $args->{compte_client} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de compte client</h3>' ;	
		} elsif (defined $args->{select_achats} && $args->{select_achats} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de journal de réglement configuré</h3>' ;	
		} elsif (defined $args->{montant} && $args->{montant} eq '0.00') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le montant est à 0.00</h3>' ;	
		} else {	
		(my $confirm_href = $r->unparsed_uri()) =~ s/&reglement_client=0/&reglement_client=1/ ;
		$confirm_href =~ s/docsentry/menu/ ;
		(my $deny_href = $r->unparsed_uri()) =~ s/&reglement_client=0/&reglement_client=9/ ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Date: ' .($args->{date_comptant} || '') . ' Client: '. ($args->{compte_client} || '') .' Libellé: ' . ($args->{libelle} || '') .' Montant: ' . ($args->{montant} || '') .'€ Journal: '.($args->{select_achats} || '').' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}
    } elsif ( defined $args->{reglement_client} and $args->{reglement_client} eq '1' ) {
		
		#définition des variables
		my ($journal, $month, $year) = '';
		#récupération journal de réglement et compte de réglement
		$sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? and config_libelle = ? AND module = \'achats\'' ;
		my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{select_achats} ) ) ;
		my $reglement_journal = $resultat->[0]->{config_journal};
		my $reglement_compte = $resultat->[0]->{config_compte};	
		
		#mise en forme montant pour enregistrement en bdd
		#ne pas laisser des montants nulls : mettre un zéro
		$args->{montant} ||= '0.00';
		#remplacer la virgule par le point dans les montants soumis
		$args->{montant} =~ s/,/./ ;
		#enlever les espaces de présentation
		$args->{montant} =~ s/\s//g ;
		
		#calcul numéro de pièce auto
		$sql = 'SELECT libelle_journal, code_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
		my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
		my $journal_code_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
		
		for ( @$journal_code_set ) {
		if ($reglement_journal =~ $_->[0]) {$journal = $_->[1];} 
		}    
			
		if ((defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<year>[0-9]{4}).*(?<month>[0-9]{2}).*(?<day>[0-9]{2})$/) {
		$month= substr($args->{date_comptant},5,2);
		$year= substr($args->{date_comptant},0,4);		
		} elsif (( defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
		$month= substr($args->{date_comptant},3,2);
		$year= substr($args->{date_comptant},6,4);	
		}
		
		my $item_num = 1;
		
		#on regarde s'il existe des factures enregistrées pour le mois et l'année de la date d'enregistrement
		$sql = '
		SELECT id_facture as item_number, extract(month from ?::date) as month_number, extract(year from ?::date) as year_number
		FROM tbljournal
		WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE ? and id_client = ? and fiscal_year = ? and libelle_journal = ? AND substring(id_facture from 8 for 2) = ?
		ORDER BY 1 DESC LIMIT 1
		' ;
	
		@bind_array = ( $args->{date_comptant}, $args->{date_comptant}, $journal, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $reglement_journal, $month ) ;
		my $calcul_piece = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;     
		
		for ( @$calcul_piece ) {
		if (substr( $_->{item_number}, 10, 2 ) =~ /\d/ && substr( $_->{item_number}, 0, 2 ) =~ /$journal/) {
		$item_num = int(substr( $_->{item_number}, 10, 2 )) + 1	;} 
		} 
		
		#my $format ='%0' . $1 . 'd' ;
	
		if ($item_num<10) {	$item_num="0".$item_num; }
		
		my $numero_piece = $journal . $year . '-' . $month . '_' . $item_num ;
		
		#supprime les espaces de début et de fin de ligne
		$args->{libelle} =~ s/^\s+|\s+$//g;

		#première écriture
		$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
		@bind_array = ( 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_client}, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
		$dbh->do( $sql, undef, @bind_array ) ;
		$sql = 'SELECT record_staging(?, ?)' ;
		eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
		#erreur dans la procédure store_staging : l'afficher dans le navigateur
		if ( $@ ) {
			if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
			$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
			$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /unbalanced/ ) {
			$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ / bad fiscal / ) {
			$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /archived/ ) {
			$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
			$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
			} else {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}

		} else {
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm =>	Ajout du réglement client => Date: ' .($args->{date_comptant} || '' ). ' Client: '. ($args->{compte_client} || '' ) .' Montant : ' . ($args->{montant} || '' ) .'€ Libellé: ' . ($args->{libelle} || '' ) .'	Compte: '.($reglement_compte || '' ) .' Journal: '.($reglement_journal || '' ).' ');
		
			my $varmenu ;	
			if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}} else { $varmenu = 'journal?open_journal='.($reglement_journal || '' ).'';}

			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
		}
	}

	#/************ ACTION FIN *************/

	#####################################       
	# Récupérations d'informations		#
	#####################################  
	
	# on peut réutiliser la liste des journaux précédemment créée pour journal_tva
    $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;
	
	#numero compte et libelle client 41
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'41\') ORDER by libelle_compte' ;
    my $compte_client_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_client = '<select class="forms2_input" style="width: 18%;" name=compte_client id=compte_client>' ;
	$compte_client .= '<option value="" selected>--Choix client--</option>' ;
	for ( @$compte_client_set ) {
	if 	(defined $args->{compte_client}) {
	$selected = ( $_->{numero_compte} eq $args->{compte_client} ) ? 'selected' : '' ;
	}
	$compte_client .= '<option value="' . $_->{numero_compte} . '" ' . $selected . '>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_client .= '</select>' ;
	
	
	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? AND module = \'achats\' ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    #select_achats
	my $select_achats = '<select style="width: 18%;" class="forms2_input" name=select_achats id=select_achats2>' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	if 	(defined $args->{select_achats}) {
	$selected = ( $_->{config_libelle} eq $args->{select_achats} ) ? 'selected' : '' ;
	}
	$select_achats .= '<option value="' . $_->{config_libelle} . '" ' . $selected . '>' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;

	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my ($id_name, $document_select1, $document_select2,$calcul_piece);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs1} && (!defined $args->{docs_doc_entry} && !defined $args->{label8})){
    $document_select1 = '<select class="forms2_input" style="width: 35%;" name=docs1 id=docs15>
    <option value="" selected>--Sélectionner le document 1--</option>' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 35%;" name=docs1 id=docs15>
    <option value="" >--Sélectionner le document 1--</option>' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs2} && (!defined $args->{docs_doc_entry} && !defined $args->{label9})){
    $document_select2 = '<select class="forms2_input" style="width: 35%;" name=docs2 id=docs25>
    <option value="" selected>--Sélectionner le document 2--</option>' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 35%;" name=docs2 id=docs25>
    <option value="" >--Sélectionner le document 2--</option>' ;
	}
	
    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
			my $selected1 = (($_->{id_name} eq ($args->{docs1} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1)) ? 'selected' : '' ;
			my $selected2 = (($_->{id_name} eq ($args->{docs2} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1)) ? 'selected' : '' ;
			$document_select1 .= '<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>' ;
			$document_select2 .= '<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>' ;		
	    }
		$id_name = $_->{id_name} ;	
    }
    
    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
	############## MISE EN FORME DEBUT ##############
	my $contenu_web_reglement .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Saisie d\'un réglement client</a></div>

    <form class=wrapper1 action="' . $r->unparsed_uri() . '">
	
	<div class=formflexN2>
		<label style="width: 9%;" class="forms2_label" for="date_comptant2">Date</label>
		<label style="width: 18%;" class="forms2_label" for="compte_client">Client</label>
		<label style="width: 40%;" class="forms2_label" for="libelle1">Libellé</label>
		<label style="width: 9%;" class="forms2_label" for="montant6">Montant</label>
		<label style="width: 18%;" class="forms2_label" for="select_achats2">Réglement</label>
	</div>
	
	<div class=formflexN2>	
		<input class="forms2_input" style="width: 9%;" type="text" name=date_comptant id=date_comptant2 value="' . ($args->{date_comptant} || $date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required>
		' . $compte_client . '
		<input class="forms2_input" style="width: 40%;" type=text id=libelle1 name=libelle value="'.($args->{libelle}|| '').'" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\', 1)" list="libellelist_1"><datalist id="libellelist_1"></datalist>
		<input class="forms2_input" style="width: 9%;" type=text id=montant6 name=montant value="'.($args->{montant} || $montant_entry || '').'" onchange="format_and_stage(this)" required/>
		' . $select_achats . '
	</div>

    <div class=formflexN2>
	<label style="width: 35%;" class="forms2_label" for="docs15">Documents 1</label>
	<label style="width: 35%;" class="forms2_label" for="docs25">Documents 2</label>
	<label style="width: 10%;" class="forms2_label" for="submit15">&nbsp;</label>
    </div>   
    
    <div class=formflexN2>    
        ' . $document_select1 . '
		' . $document_select2 . '
		<input type=submit id=submit15 style="width: 10%;" class="btn btn-vert" value=Valider>
	</div>
  
	<input type=hidden name="reglement_client" id="reglement_client" value="0">
	<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">

	</form>';

	$content .= $contenu_web_reglement;

    return $content ;
############## MISE EN FORME FIN ##############
    
    
}#sub forms_reglement_client 	

#/*—————————————— Formulaire Saisie reglement fournisseur 	——————————————*/
sub forms_reglement_fournisseur {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;
	my $selected = '';

############## Manipulation des dates ##############
	my ($date_comptant, $montant_entry);
	#en 1ère arrivée, mettre la date du jour par défaut ou date de fin d'exercice
	#my $date_1 = localtime->strftime('%Y-%m-%d');
	#my $date_2 = $r->pnotes('session')->{Exercice_fin_DMY} ;
	#if ($date_1 gt $date_2) {$date_comptant = $date_2;} else {$date_comptant = $date_1;}	
	
	# récupération des variables de docsentry.pm
	if (defined $args->{date_doc_entry}) {$date_comptant = $args->{date_doc_entry} ;}
	if (defined $args->{montant_doc_entry}) {$montant_entry = $args->{montant_doc_entry} ;}
	
	#######################################################################  
	# ACTION reglement_fournisseur DEBUT								  #
    if ( defined $args->{reglement_fournisseur} and $args->{reglement_fournisseur} eq '0' ) {
		
		if 	(defined $args->{compte_client} && $args->{compte_client} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de compte client</h3>' ;	
		} elsif (defined $args->{select_achats} && $args->{select_achats} eq '') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible il n\'y a pas de journal de réglement configuré</h3>' ;	
		} elsif (defined $args->{montant} && $args->{montant} eq '0.00') {
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">Impossible le montant est à 0.00</h3>' ;	
		} else {	
		(my $confirm_href = $r->unparsed_uri()) =~ s/&reglement_fournisseur=0/&reglement_fournisseur=1/ ;
		$confirm_href =~ s/docsentry/menu/ ;
		(my $deny_href = $r->unparsed_uri()) =~ s/&reglement_fournisseur=0/&reglement_fournisseur=9/ ;
		my $message = ( 'Voulez-vous vraiment créer l\'écriture suivante : <br><br>
		Date: ' .($args->{date_comptant} || '') . ' Fournisseur: '. ($args->{compte_fournisseur} || '') .' Libellé: ' . ($args->{libelle} || '') .' Montant: ' . ($args->{montant} || '') .'€ Journal: '.($args->{select_achats} || '').' ?') . '<a class=nav href="' . $confirm_href . '" style="margin-left: 3em;">' . ( 'Oui' ) . '</a><a class=nav href="' . $deny_href . '" style="margin-left: 3em;">' . ( 'Non' ) . '</a>' ;
		$content .= '<h3 class=warning style="margin: 2.5em; padding: 2.5em; text-align: center;">' . $message . '</h3>' ;
		}
		
    } elsif ( defined $args->{reglement_fournisseur} and $args->{reglement_fournisseur} eq '1' ) {
	
		my ($journal, $month, $year) = '';
	
		#récupération journal de réglement et compte de réglement

		$sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? and config_libelle = ? AND module = \'achats\'' ;
		my $resultat = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $args->{select_achats} ) ) ;
			
		my $reglement_journal = $resultat->[0]->{config_journal};
		my $reglement_compte = $resultat->[0]->{config_compte};
		
		#mise en forme montant pour enregistrement en bdd
		#ne pas laisser des montants nulls : mettre un zéro
		$args->{montant} ||= '0.00';
		#remplacer la virgule par le point dans les montants soumis
		$args->{montant} =~ s/,/./ ;
		#enlever les espaces de présentation
		$args->{montant} =~ s/\s//g ;
		
		#calcul numéro de pièce auto
		$sql = 'SELECT libelle_journal, code_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
		my @bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
		my $journal_code_set = $dbh->selectall_arrayref( $sql, undef, @bind_array ) ;
	
		for ( @$journal_code_set ) {
			if ($reglement_journal =~ $_->[0]) {$journal = $_->[1];} 
		}    
	    
		if ((defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<year>[0-9]{4}).*(?<month>[0-9]{2}).*(?<day>[0-9]{2})$/) {
			$month= substr($args->{date_comptant},5,2);
			$year= substr($args->{date_comptant},0,4);		
		} elsif (( defined $args->{date_comptant}) && $args->{date_comptant} =~ /^(?<day>[0-9]{2}).*(?<month>[0-9]{2}).*(?<year>[0-9]{4})$/) {
			$month= substr($args->{date_comptant},3,2);
			$year= substr($args->{date_comptant},6,4);	
		}
	
		my $item_num = 1;
    
		#on regarde s'il existe des factures enregistrées pour le mois et l'année de la date d'enregistrement
		$sql = '
		SELECT id_facture as item_number, extract(month from ?::date) as month_number, extract(year from ?::date) as year_number
		FROM tbljournal
		WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE ? and id_client = ? and fiscal_year = ? and libelle_journal = ? AND substring(id_facture from 8 for 2) = ?
		ORDER BY 1 DESC LIMIT 1
		' ;
	
		@bind_array = ( $args->{date_comptant}, $args->{date_comptant}, $journal, $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $reglement_journal, $month ) ;
		my $calcul_piece = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;     
		
		for ( @$calcul_piece ) {
			if (substr( $_->{item_number}, 10, 2 ) =~ /\d/ && substr( $_->{item_number}, 0, 2 ) =~ /$journal/) {
				$item_num = int(substr( $_->{item_number}, 10, 2 )) + 1	;
			} 
		} 
	
		#my $format ='%0' . $1 . 'd' ;
		
		if ($item_num<10) {	$item_num="0".$item_num; }
		
		my $numero_piece = $journal . $year . '-' . $month . '_' . $item_num ;
		
		#supprime les espaces de début et de fin de ligne
		$args->{libelle} =~ s/^\s+|\s+$//g;

		#première écriture
		$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
		@bind_array = ( 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $reglement_compte, undef, 0, $args->{montant}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1} || undef), ($args->{docs2} || undef), 
		$r->pnotes('session')->{_session_id}, 0, $args->{date_comptant}, $args->{libelle}, $args->{compte_fournisseur}, undef, $args->{montant}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, $reglement_journal, $args->{_token_id}, ($args->{docs1}|| undef), ($args->{docs2}|| undef) ) ;
		$dbh->do( $sql, undef, @bind_array ) ;
		$sql = 'SELECT record_staging(?, ?)' ;
		eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) ) } ;
		#erreur dans la procédure store_staging : l'afficher dans le navigateur
		
		if ( $@ ) {
			if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
			$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
			$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /unbalanced/ ) {
			$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ / bad fiscal / ) {
			$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /archived/ ) {
			$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
			$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
			} else {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}
		} else {
			
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm =>	Ajout du réglement fournisseur => Date: ' .($args->{date_comptant} || '' ). ' Fournisseur: '. ($args->{compte_fournisseur} || '' ) .' Montant : ' . ($args->{montant} || '' ) .'€ Libellé: ' . ($args->{libelle} || '' ) .'	Compte: '.($reglement_compte || '' ) .' Journal: '.($reglement_journal || '' ).' ');
		
			my $varmenu ;	
			
			if (defined $args->{id_name} && $args->{id_name} ne '') {$varmenu = 'docsentry?id_name='.$args->{id_name}} else { $varmenu = 'journal?open_journal='.($reglement_journal || '' ).'';}
				
			#rediriger l'utilisateur vers la page d'accueil
			my $location = '/'.$r->pnotes('session')->{racine}.'/'.$varmenu ;
			$r->headers_out->set(Location => $location) ;
			#rediriger le navigateur vers le fichier
			$r->status(Apache2::Const::REDIRECT) ;
			return Apache2::Const::REDIRECT ;   
		}
	}# ACTION reglement_fournisseur FIN									  #
	####################################################################### 

#####################################       
# Récupérations d'informations		#
#####################################  
	
	# on peut réutiliser la liste des journaux précédemment créée pour journal_tva
    $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;
	
	#numero compte et libelle fournisseur 40
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 2) IN (\'40\',\'44\') ORDER by libelle_compte' ;
    my $compte_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_fournisseur = '<select class="forms2_input" style="width: 18%;" name=compte_fournisseur id=compte_fournisseur onselect=>' ;
	$compte_fournisseur .= '<option value="" selected>--Choix fournisseur--</option>' ;
	for ( @$compte_set ) {
	if 	(defined $args->{compte_fournisseur}) {
	$selected = ( $_->{numero_compte} eq $args->{compte_fournisseur} ) ? 'selected' : '' ;
	}
	$compte_fournisseur .= '<option value="' . $_->{numero_compte} . '" '.$selected.'>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_fournisseur .= '</select>' ;

	# sélection des paramétres de réglements
    $sql = 'SELECT type_compta FROM compta_client WHERE id_client = ?' ;
    my $result_reglement_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;

    # sélection des paramétres de réglements
    $sql = 'SELECT config_libelle, config_compte, config_journal, module FROM tblconfig_liste WHERE id_client = ? AND module = \'achats\' ORDER by config_libelle' ;
    my $resultat_tblconfig = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
    #select_achats
	my $select_achats = '<select style="width: 18%;" class="forms2_input" name=select_achats id=select_achats3>' ;
	$select_achats .= '<option value="" selected>--Choix Réglement--</option>' ;
	for ( @$resultat_tblconfig ) {
	if 	(defined $args->{select_achats}) {
	$selected = ( $_->{config_libelle} eq $args->{select_achats} ) ? 'selected' : '' ;
	}
	$select_achats .= '<option value="' . $_->{config_libelle} . '" '. $selected .'>' . $_->{config_libelle} . '</option>' ;
	}
	$select_achats .= '</select>' ;

	################################################################# 
	# génération du choix de documents				 				#
	#################################################################

	#recherche de la liste des documents enregistrés
    $sql = '
    SELECT id_name
    FROM tbldocuments 
	WHERE id_client = ? AND (fiscal_year = ? OR (multi = \'t\' AND (last_fiscal_year IS NULL OR last_fiscal_year >= ?))) ORDER BY id_name, date_reception' ;	
    
    my @bind_array_1 = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year}) ;	
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array_1 ) ;
	my ($id_name, $document_select1, $document_select2,$calcul_piece);
	
	# Sélection par default du "choix docs1" 
	if (!defined $args->{docs1} && (!defined $args->{docs_doc_entry} && !defined $args->{label8})){
    $document_select1 = '<select class="forms2_input" style="width: 35%;" name=docs1 id=docs13>
    <option value="" selected>--Sélectionner le document 1--</option>' ;
	} else {
    $document_select1 = '<select class="forms2_input" style="width: 35%;" name=docs1 id=docs13>
    <option value="" >--Sélectionner le document 1--</option>' ;
	}
	
	# Sélection par default du "choix docs2" 
	if (!defined $args->{docs2} && (!defined $args->{docs_doc_entry} && !defined $args->{label9})){
    $document_select2 = '<select class="forms2_input" style="width: 35%;" name=docs2 id=docs23>
    <option value="" selected>--Sélectionner le document 2--</option>' ;
	} else {
    $document_select2 = '<select class="forms2_input" style="width: 35%;" name=docs2 id=docs23>
    <option value="" >--Sélectionner le document 2--</option>' ;
	}
	
    for ( @$array_of_documents )   {
		unless ( $_->{id_name} eq (defined $id_name )) {
			my $selected1 = (($_->{id_name} eq ($args->{docs1} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label8} || '') eq 1)) ? 'selected' : '' ;
			my $selected2 = (($_->{id_name} eq ($args->{docs2} || '')) || ($_->{id_name} eq ($args->{docs_doc_entry} || '') && ($args->{label9} || '') eq 1)) ? 'selected' : '' ;
			$document_select1 .= '<option value="' . $_->{id_name} . '" '.$selected1.'>' . $_->{id_name} . '</option>' ;
			$document_select2 .= '<option value="' . $_->{id_name} . '" '.$selected2.'>' . $_->{id_name} . '</option>' ;		
	    }
		$id_name = $_->{id_name} ;	
    }
    
    $document_select1 .= '</select>' ;
    $document_select2 .= '</select>' ;
	
############## MISE EN FORME DEBUT ##############
 my $contenu_web_reglement .= '
	<div class="Titre10 centrer"><a class=aperso2 href="/'.$r->pnotes('session')->{racine}.'/export">Saisie d\'un réglement fournisseur</a></div>

    <form class=wrapper1 action="' . $r->unparsed_uri() . '">
	
	<div class=formflexN2>
		<label style="width: 9%;" class="forms2_label" for="date_comptant21">Date</label>
		<label style="width: 18%;" class="forms2_label" for="compte_fournisseur">Fournisseur</label>
		<label style="width: 40%;" class="forms2_label" for="libelle3">Libellé</label>
		<label style="width: 9%;" class="forms2_label" for="montant7">Montant</label>
		<label style="width: 18%;" class="forms2_label" for="select_achats3">Réglement</label>
	</div>
	
	<div class=formflexN2>	
		<input class="forms2_input" style="width: 9%;" type="text" name=date_comptant id=date_comptant21 value="' . ($args->{date_comptant} || $date_comptant || '') . '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')" required>
		' . $compte_fournisseur . '
		<input class="forms2_input" style="width: 40%;" type=text id=libelle3 name=libelle value="'.($args->{libelle}|| '').'" required onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\', 1)" list="libellelist_3"><datalist id="libellelist_3"></datalist>
		<input class="forms2_input" style="width: 9%;" type=text id=montant7 name=montant value="'.($args->{montant} || $montant_entry || '').'" onchange="format_and_stage(this)" required/>
		' . $select_achats . '
	</div>

    <div class=formflexN2>
	<label style="width: 35%;" class="forms2_label" for="docs13">Documents 1</label>
	<label style="width: 35%;" class="forms2_label" for="docs23">Documents 2</label>
	<label style="width: 10%;" class="forms2_label" for="submit13">&nbsp;</label>
    </div>   
    
    <div class=formflexN2>    
        ' . $document_select1 . '
		' . $document_select2 . '
		<input type=submit id=submit13 style="width: 10%;" class="btn btn-vert" value=Valider>
	</div>

    
	<input type=hidden name="reglement_fournisseur" id="reglement_fournisseur" value="0">
	<input type=hidden name="id_name" value="'.($args->{id_name} || '').'">

	</form>';

	$content .= $contenu_web_reglement;

    return $content ;
############## MISE EN FORME FIN ##############
    
    
} #sub forms_reglement_fournisseur 	

#/*—————————————— Formulaire recherche d'écriture Menu 2 ——————————————*/
sub forms_search {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content  ) ;

	#####################################       
	# Manipulation des dates			#
	#####################################  
	my ($date_comptant, $montant_entry);
		
	#####################################       
	# Requête SQL						#
	#####################################  
	
	#recherche de la liste des documents enregistrés
    $sql = 'SELECT id_name, date_reception, montant/100::numeric as montant, libelle_cat_doc, fiscal_year, check_banque, last_fiscal_year, id_compte FROM tbldocuments WHERE id_name = ? AND id_client = ?' ;
    my $array_of_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $args->{id_name}, $r->pnotes('session')->{id_client} ) ;
	
	############## Choix du numero compte ##############	
	#tous les comptes
	my $select_all_compte='';
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? ORDER by numero_compte' ;
    my $compte_all_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_all = '<select class="forms2_input" style="width: 33%;" name=search_compte id=search_compte>' ;
	
	if (!defined $args->{search_compte} || $args->{search_compte} eq ''){
	$compte_all .= '<option value="" selected>--Choix Compte--</option>' ;
	} else {
	$select_all_compte = $args->{search_compte};
	}

	for ( @$compte_all_set ) {
	my $selected = ( $_->{numero_compte} eq $select_all_compte) ? 'selected' : '' ;	
	$compte_all .= '<option value="' . $_->{numero_compte} . '" '.$selected.'>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_all .= '<option value="">--Choix Compte--</option>';
	$compte_all .= '</select>' ;

    my ($compte_var, $reglement_journal_1, $journal1, $month, $year, $var_search_montant, $var_search_lib) ;

	#####################################       
	#Rechercher des entrées du journal
	#####################################    
	my $propo_list .= '';

    if ((defined $args->{search_date} && $args->{search_date} ne '')|| (defined $args->{search_lib} && $args->{search_lib} ne '') || (defined $args->{search_compte} && $args->{search_compte} ne '')|| (defined $args->{search_montant} && $args->{search_montant} ne '') ) {
	
	my $search_date = ( defined $args->{search_date} && $args->{search_date} ne '' ) ? ' AND t1.date_ecriture = ?' : '' ;
	my $search_lib = ( defined $args->{search_lib} && $args->{search_lib} ne '' ) ? ' AND t1.libelle ILIKE ?' : '' ;
	my $search_compte = ( defined $args->{search_compte} && $args->{search_compte} ne '') ? ' AND t1.numero_compte = ?' : '' ;
	my $search_montant = ( defined $args->{search_montant} && $args->{search_montant} ne '') ? ' AND (t1.debit::TEXT ILIKE ? OR t1.credit::TEXT ILIKE ?)' : '' ;

	$sql = '
	SELECT t1.id_entry, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, coalesce(t1.id_paiement, \'&nbsp;\') as id_paiement, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit
	FROM tbljournal t1
	WHERE t1.id_client = ? AND t1.fiscal_year = ? '.$search_date.' '. $search_lib . ' '.$search_compte . ' '.$search_montant .'
	ORDER BY date_ecriture, id_entry, id_line
	' ;
	
	if (defined $args->{search_montant} && $args->{search_montant} ne ''){
	$var_search_montant = '%' . $args->{search_montant} . '%' ;
	}
	
	if (defined $args->{search_lib} && $args->{search_lib} ne ''){
	$var_search_lib = '%' . $args->{search_lib} . '%' ;
	}

	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}) ;
	
	#ne pas ajouter le paramètre tant que condition est vrai
    push @bind_array, $args->{search_date} unless ( $args->{search_date} eq '' ) ;
    push @bind_array, $var_search_lib unless ( $args->{search_lib} eq '') ;
    push @bind_array, $args->{search_compte} unless ( $args->{search_compte} eq '' ) ;
    push @bind_array, $var_search_montant , $var_search_montant unless ( $args->{search_montant} eq '') ;
    
    #Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'docsentry.pm => Rechercher montant: '.$args->{search_montant}.' date : '.$args->{search_date}.' libellé : '.$args->{search_lib}.' compte : '.$args->{search_compte}.'');

	$propo_list .= '
	<ul class="wrapper style1">
   ' ;

	my $result_set = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;

	#ligne d'en-têtes
    $propo_list .= '
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=headerspan style="width: 8%;">Date</span>
	<span class=headerspan style="width: 8%;">Libre</span>
	<span class=headerspan style="width: 8%;">Journal</span>
	<span class=headerspan style="width: 8%;">Compte</span>
	<span class=headerspan style="width: 12%;">Pièce</span>
	<span class=headerspan style="width: 29.9%;">Libellé</span>
	<span class=headerspan style="width: 8%; text-align: right;">Débit</span>
	<span class=headerspan style="width: 8%; text-align: right;">Crédit</span>
	<span class=headerspan style="width: 5%; text-align: center;">&nbsp;</span>
	<span class=headerspan style="width: 5%; text-align: center;">&nbsp;</span>
	<div class=spacer></div></div></li>
	' ;

	my $id_entry = '' ;
    
    for ( @$result_set ) {

	#si on est dans une nouvelle entrée, clore la précédente et ouvrir la suivante
	unless ( $_->{id_entry} eq $id_entry ) {

	    #lien de modification de l'entrée
	    my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;

	    #cas particulier de la première entrée de la liste : pas de liste précédente
	    unless ( $id_entry ) {
		$propo_list .= '<li class=listitem>' ;
	    } else {
		$propo_list .= '</a></li><li class=listitem>'
	    } #	    unless ( $id_entry ) 

	} #	unless ( $_->{id_entry} eq $id_entry ) 

	#marquer l'entrée en cours
	$id_entry = $_->{id_entry} ;
	
	#pour le journal général, ajouter la colonne libelle_journal
	#my $libelle_journal = ( $args->{open_journal} eq 'Journal général' ) ? '<span class=blockspan style="width: 25ch;">' . $_->{libelle_journal} . '</span>' : '' ;

			my $http_link_documents1 = '';
			my $http_link_documents2 = '';

			if ( $_->{documents1} =~ /docx|odt|pdf|jpg/) { 
				my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
 				my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents1} ) ;
				if ($id_name_documents->[0]->{id_name} || '') {
					$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img class=redimmage style="border: 0;" src="/Compta/style/icons/documents.png" alt="documents"></a>' ;
				} else {
					$http_link_documents1 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
				} 
			} 	
			 
			if ( $_->{documents2} =~ /docx|odt|pdf|jpg/) { 
				my $sql = 'SELECT id_name FROM tbldocuments WHERE id_name = ?' ;
				my $id_name_documents = $dbh->selectall_arrayref( $sql, { Slice => { } }, $_->{documents2} ) ;
				if ($id_name_documents->[0]->{id_name} || '') {
					$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docsentry?id_name='.$id_name_documents->[0]->{id_name}.'"><img class=redimmage style="border: 0;" src="/Compta/style/icons/releve-bancaire.png" alt="releve-bancaire"></a>' ;	
				} else {
					$http_link_documents2 ='<a class=nav href="/'.$r->pnotes('session')->{racine}.'/docs">DOC</a>' ;
				} 
			} 	

	
	 #lien de modification de l'entrée
	 my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;

	$propo_list .= '
	<div class=flex-table><div class=spacer></div><a href="' . ($id_entry_href || ''). '" >
	<span class=displayspan style="width: 8%;">' . $_->{date_ecriture} . '</span>
	<span class=displayspan style="width: 8%;">' . $_->{id_paiement} . '</span>
	<span class=displayspan style="width: 8%;">' . $_->{libelle_journal} .'</span>
	<span class=displayspan style="width: 8%;">' . $_->{numero_compte} . '</span>
	<span class=displayspan style="width: 12%;">' . $_->{id_facture} . '</span>
	<span class=displayspan style="width: 29.9%;">' . $_->{libelle} . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' . $_->{debit} . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' .  $_->{credit} . '</span>
	<span style="width: 2.4%; margin-left : 1%;">' . ($http_link_documents1 || '<a><img class=redimmage style="border: 0;" src="/Compta/style/icons/vide.png" alt="" height="16" width="16"></a>' ) . '</span>
	<span style="width: 2.4%; margin-left : 0.5%;">' . ($http_link_documents2 || '<img class=redimmage style="border: 0;" src="/Compta/style/icons/vide.png" alt="" height="16" width="16">' ) . '</span>
	<div class=spacer>
	</div>
	</div>
	' ;

    } #    for ( @$result_set ) 

    #on clot la liste s'il y avait au moins une entrée dans le journal
    $propo_list .= '</a></li>' if ( @$result_set ) ;

    #pour le journal général, ajouter la colonne libelle_journal
    #$libelle_journal = ( $args->{open_journal} eq 'Journal général' ) ? '<span class=blockspan style="width: 25ch;">&nbsp;</span>' : '' ;
    
    $propo_list .=  '<li class=listitem><hr></li>
    <li class=listitem><div class=flex-table><div class=spacer></div>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 8%;">&nbsp;</span>
	<span class=blockspan style="width: 12%;">&nbsp;</span>
	<span class=blockspan style="width: 29.9%; text-align: right;">Total</span>
	<span class=blockspan style="width: 8%; text-align: right;">' . ( $result_set->[0]->{total_debit} || 0 ) . '</span>
	<span class=blockspan style="width: 8%; text-align: right;">' . ( $result_set->[0]->{total_credit} || 0 ) . '</span>
	</span><div class=spacer></div></li></ul>' ;

	}
    
	############## MISE EN FORME DEBUT ##############

	my $contenu_search .= '
	
	<div class="Titre10 centrer">Rechercher des entrées du journal</div>

	<form class=wrapper1 method=POST>
	<div class=formflexN2>
		<label style="width: 10%;" class="forms2_label" for="search_date">Date</label>
		<label style="width: 43%;" class="forms2_label" for="search_lib">Libellé</label>
        <label style="width: 33%;" class="forms2_label" for="search_compte">Compte</label>
        <label style="width: 10%;" class="forms2_label" for="search_montant">Montant</label>
    </div>    
    
    <div class=formflexN2>        
		<input class="forms2_input" style="width: 10%;" type=text id=search_date name=search_date value="' . ($args->{search_date} || ''). '" pattern="(?:((?:0[1-9]|1[0-9]|2[0-9])\/(?:0[1-9]|1[0-2])|(?:30)\/(?!02)(?:0[1-9]|1[0-2])|31\/(?:0[13578]|1[02]))\/(?:19|20)[0-9]{2})" onchange="format_date(this, \'' . $r->pnotes('session')->{preferred_datestyle} . '\')"/>
		<input class="forms2_input" style="width: 43%;" type=text id=search_lib name=search_lib value="' . ($args->{search_lib} || ''). '" onclick="liste_search_libelle(this.value, \'' . $r->pnotes('session')->{racine}. '\', 5)" list="libellelist_5"><datalist id="libellelist_5"></datalist>
		' .  $compte_all . '
		<input class="forms2_input" style="width: 10%;" type=text id=search_montant name=search_montant value="' . ($args->{search_montant} || ''). '" />
    </div>
		
    <input type=hidden name=menu2 value="1" >
    <input type=hidden name="label1" value="' . ($args->{label1} || ''). '">
	<input type=hidden name="label2" value="' . ($args->{label2} || ''). '">
	<input type=hidden name="label3" value="' . ($args->{label3} || ''). '">
	<input type=hidden name="label4" value="' . ($args->{label4} || ''). '">
	<input type=hidden name="label5" value="' . ($args->{label5} || ''). '">
    <input type=hidden name="label6" value="' . ($args->{label6} || ''). '">
    <input type=hidden name="label7" value="' . ($args->{label7} || ''). '">  
    <input type=hidden name="label8" value="' . ($args->{label8} || ''). '">
	<input type=hidden name="label9" value="' . ($args->{label9} || ''). '"> 
	
	<div class=formflexN3>
	<input type=submit id=submit style="width: 10%;" class="btn btn-vert" value=Rechercher>
	</div>

	</form>
	';	
		
	$content .= $contenu_search . $propo_list;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_search 

#/*—————————————— Formulaire Interet CCA ——————————————*/
sub forms_interet_cca {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content  ) ;
	my $selected = '';
	
	####################################################################### 
	#Formulaire 1 => l'utilisateur a cliqué sur le bouton 'Imprimer'	  #
	#######################################################################
	if ( defined $args->{interet_cca} && defined $args->{imprimer}) {
		my $location = export_pdf2( $r, $args ); ;
	    if ( $location =~ /warning/ ) {
		$content .= $location ;
	    } else {
		$content .= '
		<script type="text/javascript">
		 function Open(){window.open("'.$location.'", "blank");}
		Open();
		</script>';
		}
	}
    
    ####################################################################### 
	#Formulaire 1 => l'utilisateur a cliqué sur le bouton 'Comptabiliser' #
	#######################################################################
    if ( defined $args->{interet_cca} && defined $args->{comptabiliser} && $args->{comptabiliser} eq '0') {
		
		my $non_href = '/'.$r->pnotes('session')->{racine}.'/menu' ;
		
		$content .= '
		<h3 class="warning centrer">
		<form action="' . $non_href . '">
		Voulez-vous vraiment comptabiliser les intérêts des comptes courants d\'associés ? 
		<br><br>
		<a style="margin-left: 3ch;" href="javascript:{};" onclick="parentNode.submit();">Oui</a>
		<a href="' . $non_href . '" style="margin-left: 3ch;">Non</a>
		<input type=hidden name=menu8 value="1">
		<input type=hidden name="menu1" value=0 >
		<input type=hidden name=interet_cca value="1" >
		<input type=hidden name=comptabiliser value="1" >
		<input type=hidden name=taux value="' . ($args->{taux} || ''). '">
		<input type=hidden name=select_compte value="' . ($args->{select_compte} || ''). '">
		<input type=hidden name=ab value="' . ($args->{ab} || ''). '">
		<input type=hidden name=qg value="' . ($args->{qg} || ''). '">
		<input type=hidden name=qh value="' . ($args->{qh} || ''). '">
		<input type=hidden name=aai value="' . ($args->{aai} || ''). '">
		<input type=hidden name=total_2777 value="' . ($args->{total_2777} || ''). '">
		<input type=hidden name=total_c455 value="' . ($args->{total_c455} || ''). '">
		<input type=hidden name=total_interet value="' . ($args->{total_interet} || ''). '">
		<input type=hidden name=last31 value="' . $args->{last31} . '">
		</form>
		</h3>' ;

	} elsif ( defined $args->{interet_cca} && defined $args->{comptabiliser} && $args->{comptabiliser} eq '1') {
	
		#supprimer d'abord les données éventuellement présentes dans tbljournal_staging pour cet utilisateur
		$sql = 'DELETE FROM tbljournal_staging WHERE _session_id = ? AND _token_id NOT LIKE \'%recurrent%\'' ;
		$dbh->do( $sql, undef, ( $r->pnotes('session')->{_session_id} ) ) ;	
		
		#CALCUL NUMERO DE PIECE
		$sql = 'select COALESCE((
		SELECT TO_CHAR(substring(id_facture from 11 for 2)::integer + 1, \'FM00\') as item_number
		FROM tbljournal	WHERE id_facture NOT LIKE \'%MULTI%\' and substring(id_facture from 1 for 2) LIKE \'OD\' and id_client = ? and fiscal_year = ? and libelle_journal = \'OD\'
		AND substring(id_facture from 8 for 2)::NUMERIC = (EXTRACT(MONTH FROM ?::date)::NUMERIC)
		ORDER BY 1 DESC LIMIT 1)
		, \'01\')';
		@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{Exercice_fin_YMD}) ;
		my $select_calcul_piece = eval {$dbh->selectall_arrayref( $sql, undef, @bind_array )->[0]->[0] } ;     
		$sql = 'SELECT EXTRACT(MONTH FROM ?::date) as month, EXTRACT(YEAR FROM ?::date) as year';
		my $select_month_year = eval {$dbh->selectall_arrayref( $sql, { Slice => { } }, ($r->pnotes('session')->{Exercice_fin_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}))} ; 
		my $numero_piece = 'OD'.$select_month_year->[0]->{year} . '-'.$select_month_year->[0]->{month}.'_'.$select_calcul_piece ;	
		
		#Génération nom de fichier
		my $name_file = $numero_piece.'_decompte_interets_cc_'.(Time::Piece->strptime($r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d")->dmy("_")).'.pdf';
		# Remplacer modifier espace et _
		$name_file =~ s/\s+/_/g;
		
		my $doc_categorie = 'Temp';
		#Insertion du nom du document dans la table tbldocuments
		$sql = 'INSERT INTO tbldocuments ( id_client, id_name, fiscal_year, libelle_cat_doc, date_reception, date_upload )
		VALUES ( ? , ? , ? , ?, ?, CURRENT_DATE)
		ON CONFLICT (id_client, id_name ) DO NOTHING
		RETURNING id_name' ;
		my $sth = $dbh->prepare($sql) ;
		eval { $sth->execute( $r->pnotes('session')->{id_client}, $name_file, $r->pnotes('session')->{fiscal_year}, $doc_categorie, $r->pnotes('session')->{Exercice_fin_YMD} )} ;

		#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'ndf.pm =>	Vérification de valeur regroupkm ' .($args->{regroupkm} || '') . ' ');

		#mise en forme montant pour enregistrement en bdd
		foreach my $value_numbers ( $args->{total_2777}, $args->{total_c455}, $args->{total_interet}) {
			#ne pas laisser des montants nulls : mettre un zéro
			$value_numbers ||= '0.00';
			#remplacer la virgule par le point dans les montants soumis
			$value_numbers =~ s/,/./ ;
			#enlever les espaces de présentation
			$value_numbers =~ s/\s//g ;
		}

		$args->{libelle} = 'Décompte Intérêts CC '.$r->pnotes('session')->{Exercice_fin_DMY}.'';
		
		#Génération de l'écriture
		$sql = 'INSERT INTO tbljournal_staging (_session_id, id_entry, date_ecriture, libelle, numero_compte, lettrage, debit, credit, id_client, id_facture, fiscal_year, fiscal_year_offset, fiscal_year_start, fiscal_year_end, libelle_journal, _token_id, documents1, documents2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?), (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?)' ;
		@bind_array = ( 
		$r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{Exercice_fin_YMD}, $args->{libelle}, $args->{select_compte}, undef, 0, $args->{total_c455}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'OD', $args->{_token_id}, ($name_file || undef), ($args->{docs2} || undef),
		$r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{Exercice_fin_YMD}, $args->{libelle}, '442500', undef, 0, $args->{total_2777}*100, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'OD', $args->{_token_id}, ($name_file || undef), ($args->{docs2} || undef),
		$r->pnotes('session')->{_session_id}, 0, $r->pnotes('session')->{Exercice_fin_YMD}, $args->{libelle}, '661500', undef, $args->{total_interet}*100, 0, $r->pnotes('session')->{id_client}, $numero_piece, $r->pnotes('session')->{fiscal_year}, $r->pnotes('session')->{fiscal_year_offset}, $r->pnotes('session')->{Exercice_debut_YMD}, $r->pnotes('session')->{Exercice_fin_YMD}, 'OD', $args->{_token_id}, ($name_file || undef), ($args->{docs2}|| undef) 
		);
		$dbh->do( $sql, undef, @bind_array ) ;
		
		$args->{numero_piece} = $numero_piece;
			
		my $location = export_pdf2( $r, $args );
			
		#Récupérer le pdf généré
		my $pdf_file = $r->document_root() . $location;
		my $pdf = PDF::API2->open($pdf_file);
			
		#définition répertoire
		my $base_dir = $r->document_root() . '/Compta/base/documents/' ;
		my $archive_dir = $base_dir . '/' . $r->pnotes('session')->{id_client} . '/'.$r->pnotes('session')->{fiscal_year}. '/' ;

		#Enregistrer le pdf
		my $export_pdf_file = $archive_dir . $name_file;
		$pdf->saveas($export_pdf_file);
		
		$sql = 'SELECT record_staging(?, ?)' ;
		my $return_identry = eval { $dbh->selectall_arrayref( $sql, undef, ( $args->{_token_id}, 0 ) )->[0]->[0] } ;
	
		#erreur dans la procédure store_staging : l'afficher dans le navigateur
		if ( $@ ) {
			if ( $@ =~ / NOT NULL (.*) date_ecriture / ) {
			$content .= '<h3 class=warning>Il faut une date valide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /tbljournal_id_client_fiscal_year_numero_compte_fkey/ ) {
			$content .= '<h3 class=warning>Un numéro de compte est invalide - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /unbalanced/ ) {
			$content .= '<h3 class=warning>Montants déséquilibrés - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ / bad fiscal / ) {
			$content .= '<h3 class=warning>La date d\'écriture n\'est pas dans l\'exercice en cours - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /archived/ ) {
			$content .= '<h3 class=warning>La date d\'écriture se trouve dans un mois archivé - Enregistrement impossible</h3>' ;
			} elsif ( $@ =~ /null value (.*) "numero_compte"/ )  {
			$content .= '<h3 class=warning>Il faut un numéro de compte pour chaque ligne</h3>' ;
			} else {
			$content .= '<h3 class=warning>' . $@ . '</h3>' ;
			}
		} else {
			
			Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'ndf.pm =>	Comptabilisation des intérêts des comptes courants d\'associés au '.$r->pnotes('session')->{Exercice_fin_DMY}.' .');
			
			#Redirection
			$args->{restart} = 'entry?open_journal=OD&mois=0&id_entry=' . $return_identry.'';
			$content .= restart( $r, $args ) ;	

		}    

	}
    

	#####################################       
	# Requête SQL						#
	#####################################  

	############## Choix du numero compte ##############	
	#tous les comptes
	my $select_all_compte='';
	
	#numero compte et libelle compte tiers
	$sql = 'SELECT numero_compte, libelle_compte, default_id_tva FROM tblcompte WHERE id_client = ? AND fiscal_year = ? AND substring(numero_compte from 1 for 3) IN (\'451\',\'455\') ORDER by libelle_compte' ;
    my $compte_tiers_set = $dbh->selectall_arrayref($sql, { Slice => { } }, ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ) ;
	my $compte_tiers = '<select class="forms2_input" style="width: 30%" name=select_compte id=select_compte
	onchange="if(this.selectedIndex == 0){document.location.href=\'compte?configuration\'}"
	>' ;
	my $count_compte_tiers = scalar(@$compte_tiers_set) || 0;
	$compte_tiers .= '<option class="opt1" value="">Créer un compte</option>' ;
	if (defined $args->{select_compte} ){
	$compte_tiers .= '<option value="">--Sélectionner--</option>';
	} else {
	$compte_tiers .= '<option value="" selected>--Sélectionner--</option>' ;	
	}
	for ( @$compte_tiers_set ) {
	if 	(defined $args->{select_compte}) {
	$selected = ( $_->{numero_compte} eq $args->{select_compte} ) ? 'selected' : '' ;
	}		
	if ($count_compte_tiers eq 1 ) {$selected ='selected';}	
	$compte_tiers .= '<option value="' . $_->{numero_compte} . '" '.$selected.'>' . $_->{numero_compte} . ' - ' . $_->{libelle_compte} . '</option>' ;
	}
	$compte_tiers .= '</select>' ;
	
    my ($compte_var, $reglement_journal_1, $journal1, $month, $year, $var_search_montant, $var_search_lib) ;

	#####################################       
	#Rechercher des entrées du journal
	#####################################    
	my $propo_list .= '';
	
	if (defined $args->{select_compte} && $args->{select_compte} ne '') {
	
	$sql = '
	SELECT t1.id_entry, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, to_char(t1.debit/100::numeric, \'999G999G999G990D00\') as debit, to_char(t1.credit/100::numeric, \'999G999G999G990D00\') as credit, to_char((sum(t1.debit) over())/100::numeric, \'999G999G999G990D00\') as total_debit, to_char((sum(t1.credit) over())/100::numeric, \'999G999G999G990D00\') as total_credit, to_char((sum(t1.credit-t1.debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_facture, libelle))/100::numeric, \'999G999G999G990D00\') as solde, (sum(t1.credit-t1.debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_facture, libelle))/100::numeric as solde2
	FROM tbljournal t1
	WHERE t1.id_client = ? AND t1.fiscal_year = ? AND t1.numero_compte = ?
	ORDER BY date_ecriture, id_entry, id_line
	' ;
	
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{select_compte}) ;
	
	$propo_list .= '
	<div class="Titre10">Calcul des Intérêts (en €)</div>
	<br>
	<ul class="wrapper style1">
	
   ' ;

	my $result_set = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;

	#ligne d'en-têtes
    $propo_list .= '
    
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=headerspan style="width: 1%; ">&nbsp;</span>
	<span class=headerspan style="width: 8%;">Date</span>
	<span class=headerspan style="width: 8%;">Compte</span>
	<span class=headerspan style="width: 12%;">Pièce</span>
	<span class=headerspan style="width: 30%;text-align: left;">Libellé</span>
	<span class=headerspan style="width: 8%; text-align: right;">Débit</span>
	<span class=headerspan style="width: 8%; text-align: right;">Crédit</span>
	<span class=headerspan style="width: 8%; text-align: right;">Solde</span>
	<span class=headerspan style="width: 8%; text-align: right;">Nb Jours</span>
	<span class=headerspan style="width: 8%; text-align: right;">Intérêts</span>
	<span class=headerspan style="width: 1%; ">&nbsp;</span>
	<div class=spacer></div></div></li>
	' ;

	my $id_entry = '' ;
    
    my $date_calcul = '';
    
    my $solde = '';
    my $date_prec;
    my $date_en_cours = '';
    my $date_nb_jour = '';
    my $date_debut = Time::Piece->strptime($r->pnotes('session')->{Exercice_debut_YMD}, "%Y-%m-%d");
    my $date_fin = Time::Piece->strptime($r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d");
    my $date_n1 = Time::Piece->strptime($result_set->[1]->{date_ecriture}, "%d/%m/%Y");
    my $calcul_interet = 0;
    my $total_interet = 0;
    my $solde_prec = 0;
    
    ##Mise en forme de la date dans Exercice_fin_YMD de %Y-%m-%d vers 29/02/2000
	my $date_fin_dmy = eval {Time::Piece->strptime($r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d")->dmy("/")};
    

    #Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'ndf.pm => datadumper : ' . Data::Dumper::Dumper(@$result_set) . ' ');

    
    for ( @$result_set ) {
		
	$date_en_cours = Time::Piece->strptime($_->{date_ecriture}, "%d/%m/%Y");
	
	if ($date_prec) {
	$date_nb_jour = ($date_en_cours - $date_prec)->days ;	
	} else {
	$date_nb_jour = ($date_debut - $date_en_cours)->days ;
	}


	$calcul_interet = (($date_nb_jour * $solde_prec * $args->{taux})/100)/360;
	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => calcul_interet '.$calcul_interet.' et $date_nb_jour'.$date_nb_jour.' et $_->{solde} '.$_->{solde}.' et taux '.$args->{taux}.'');
	if(($calcul_interet=~/\d/) && ($calcul_interet >= 0) && ($calcul_interet < 999999999999999)){
	$total_interet += $calcul_interet;
	}
	($calcul_interet = sprintf( "%.2f",$calcul_interet)) =~ s/\./\,/g;
	$calcul_interet =~ s/\B(?=(...)*$)/ /g ;
	
	$solde_prec = $_->{solde2} ;
	
	#my $date_nb_jour = (Time::Piece->strptime($r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d") - Time::Piece->strptime($r->pnotes('session')->{Exercice_debut_YMD}, "%Y-%m-%d"))->days ;
	#$date_calcul = $r->pnotes('session')->{Exercice_debut_YMD} ;
	
	#Time::Piece->strptime( $_->{date_ecriture}, "%d/%m/%Y" )
	

	#si on est dans une nouvelle entrée, clore la précédente et ouvrir la suivante
	unless ( $_->{id_entry} eq $id_entry ) {

	    #lien de modification de l'entrée
	    my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;

	    #cas particulier de la première entrée de la liste : pas de liste précédente
	    unless ( $id_entry ) {
		$propo_list .= '<li class=listitem>' ;
	    } else {
		$propo_list .= '</a></li><li class=listitem>'
	    } #	    unless ( $id_entry ) 

	} #	unless ( $_->{id_entry} eq $id_entry ) 

	#marquer l'entrée en cours
	$id_entry = $_->{id_entry} ;

	 #lien de modification de l'entrée
	 my $id_entry_href = '/'.$r->pnotes('session')->{racine}.'/entry?open_journal=' . URI::Escape::uri_escape_utf8( $_->{libelle_journal} ) . '&amp;id_entry=' . $_->{id_entry} ;
	
	
	
	$propo_list .= '
	<div class=flex-table><div class=spacer></div><a href="' . ($id_entry_href || ''). '" >
	<span class=displayspan style="width: 1%; ">&nbsp;</span>
	<span class=displayspan style="width: 8%;">' . $_->{date_ecriture} . '</span>
	<span class=displayspan style="width: 8%;">' . ($_->{numero_compte} || '&nbsp;') . '</span>
	<span class=displayspan style="width: 12%;">' . ($_->{id_facture} || '&nbsp;'). '</span>
	<span class=displayspan style="width: 30%; text-align: left;">' . ($_->{libelle}|| '&nbsp;') . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' . ($_->{debit}|| '&nbsp;') . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' .  ($_->{credit}|| '&nbsp;') . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">' .  ($_->{solde}|| '&nbsp;') . '</span>
	<span class=displayspan style="width: 8%; text-align: right;">'.$date_nb_jour.'</span>
	<span class=displayspan style="width: 8%; text-align: right;">'.$calcul_interet.'</span>
	<span class=displayspan style="width: 1%; ">&nbsp;</span>
	<div class=spacer>
	</div>
	</div>
	' ;
	
	$date_prec = Time::Piece->strptime($_->{date_ecriture}, "%d/%m/%Y");
	

    } #    for ( @$result_set ) 
    
    $args->{last31} = 0;
    
    if ($date_en_cours eq $date_fin){
	#on clot la liste s'il y avait au moins une entrée dans le journal
    $propo_list .= '</a></li>' if ( @$result_set ) ;	
    $args->{last31} = 1;
	} else {
	$date_nb_jour = ($date_fin - $date_en_cours)->days ;
    $calcul_interet = (($date_nb_jour * $solde_prec * $args->{taux})/100)/360;
    if(($calcul_interet=~/\d/) && ($calcul_interet >= 0) && ($calcul_interet < 999999999999999)){
	$total_interet += $calcul_interet;
	}
    ($calcul_interet = sprintf( "%.2f",$calcul_interet)) =~ s/\./\,/g;
	$calcul_interet =~ s/\B(?=(...)*$)/ /g ;	
	#on clot la liste s'il y avait au moins une entrée dans le journal
    $propo_list .= '</a></li>
    <li>
    <div class=flex-table><div class=spacer></div>
	<span class=displayspan style="width: 1%; ">&nbsp;</span>
	<span class=displayspan style="width: 8%;">'.$date_fin_dmy.'</span>
	<span class=displayspan style="width: 8%;">&nbsp;</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 30%; text-align: left;">&nbsp;</span>
	<span class=displayspan style="width: 8%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 8%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 8%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 8%; text-align: right;">'.$date_nb_jour.'</span>
	<span class=displayspan style="width: 8%; text-align: right;">'.$calcul_interet.'</span>
	<span class=displayspan style="width: 1%; ">&nbsp;</span>
	<div class=spacer>
	</div>
	</div>
    </li>
    ' if ( @$result_set ) ;	
	}
	
	
	my $ab = ($total_interet * 12.8)/100;
	my $qg = ($total_interet * 9.2)/100;
	my $qh = ($total_interet * 7.5)/100;
	my $aai = ($total_interet * 0.5)/100;

	# Préparation calculs des totaux avec arrondies
	foreach my $value_numbers ( 
	#variable
	$ab, $qg, $qh, $aai) {
	$value_numbers =~ s/\,/\./g;
	if(($value_numbers=~/\d/) && ($value_numbers >= 0) && ($value_numbers < 999999999999999)){
	$value_numbers = int(($value_numbers)+ 0.5) ;
	} elsif (($value_numbers=~/\d/) && ($value_numbers < 0) && ($value_numbers > -999999999999999)) {
	$value_numbers = int(($value_numbers)- 0.5) ;
	} else { 
	$value_numbers = '0';
	}}
	
	my $total_2777 = $ab + $qg + $qh + $aai;
	my $total_c455 = $total_interet - ($ab + $qg + $qh + $aai) ;
	
	($args->{ab} = sprintf( "%.2f",$ab)) =~ s/\./\,/g;
	$args->{ab} =~ s/\B(?=(...)*$)/ /g ;
	($args->{qg} = sprintf( "%.2f",$qg)) =~ s/\./\,/g;
	$args->{qg} =~ s/\B(?=(...)*$)/ /g ;
	($args->{qh} = sprintf( "%.2f",$qh)) =~ s/\./\,/g;
	$args->{qh} =~ s/\B(?=(...)*$)/ /g ;
	($args->{aai} = sprintf( "%.2f",$aai)) =~ s/\./\,/g;
	$args->{aai} =~ s/\B(?=(...)*$)/ /g ;
	($args->{total_2777} = sprintf( "%.2f",$total_2777)) =~ s/\./\,/g;
	$args->{total_2777} =~ s/\B(?=(...)*$)/ /g ;
	($args->{total_c455} = sprintf( "%.2f",$total_c455)) =~ s/\./\,/g;
	$args->{total_c455} =~ s/\B(?=(...)*$)/ /g ;
	($args->{total_interet} = sprintf( "%.2f",$total_interet)) =~ s/\./\,/g;
	$args->{total_interet} =~ s/\B(?=(...)*$)/ /g ;
	
	my $print_href = '/'.$r->pnotes('session')->{racine}.'/menu?imprimer';
	my $comptabilisation_href = '/'.$r->pnotes('session')->{racine}.'/menu?comptabiliser=0';
    
    $propo_list .=  '
    <li class=listitem><hr></li>
    
    <li><div class=spacer></div>
    <span class=displayspan style="width: 1%; ">&nbsp;</span>
	<span class=displayspan style="width: 8%;">&nbsp;</span>
	<span class=displayspan style="width: 8%;">&nbsp;</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 30%; text-align: right; font-weight: bold;">Total</span>
	<span class=displayspan style="width: 8%; text-align: right; font-weight: bold;">' . ( $result_set->[0]->{total_debit} || 0 ) . '</span>
	<span class=displayspan style="width: 8%; text-align: right; font-weight: bold;">' . ( $result_set->[0]->{total_credit} || 0 ) . '</span>
	<span class=displayspan style="width: 8%;">&nbsp;</span>
	<span class=displayspan style="width: 8%;">&nbsp;</span>
	<span class=displayspan style="width: 8%;text-align: right; font-weight: bold;" >'.$args->{total_interet}.'</span>
	<span class=displayspan style="width: 1%; ">&nbsp;</span>
	</span><div class=spacer></li>
	
	<li><br></li>

	<li><br></li>
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=displayspan style="width: 57%;text-align: center;font-weight: bold;">Formulaire 2777</span>
	<span class=displayspan style="width: 12%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 29%; text-align: center;font-weight: bold;">Écritures comptables correspondantes</span>

	<div class=spacer></div></div></li>
	
	<li class="style1"><div class=flex-table><div class=spacer></div>
	<span class=headerspan style="width: 2%; ">&nbsp;</span>
	<span class=headerspan style="width: 6%; ">Case</span>
	<span class=headerspan style="width: 35%; text-align: left;">Description</span>
	<span class=headerspan style="width: 7%;text-align: right; ">Taux</span>
	<span class=headerspan style="width: 7%;text-align: right; ">Montant</span>
	<span class=headerspan style="width: 2%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 10%; text-align: right;">&nbsp;</span>
	<span class=headerspan style="width: 9%;text-align: right; ">Compte</span>
	<span class=headerspan style="width: 9%; text-align: right;">Débit</span>
	<span class=headerspan style="width: 9%; text-align: right;">Crédit</span>
	<span class=headerspan style="width: 2%; ">&nbsp;</span>
	<div class=spacer></div></div></li>
	

	<li><div class=spacer></div>
    <span class=displayspan style="width: 2%; ">&nbsp;</span>
    <span class=displayspan style="width: 6%;">AB</span>
	<span class=displayspan style="width: 35%;text-align: left;">Intérêts, arrérages et produits de toute nature</span>
	<span class=displayspan style="width: 7%;text-align: right;">12,80%</span>
	<span class=displayspan style="width: 7%;text-align: right;">'.$args->{ab}.'</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;">'.($args->{select_compte} || '').'</span>
	<span class=displayspan style="width: 9%; text-align: right;">0,00</span>
	<span class=displayspan style="width: 9%; text-align: right; ">' . ( $args->{total_c455} || 0 ) . '</span>
	<span class=displayspan style="width: 2%; ">&nbsp;</span>
	</span><div class=spacer></li>
	
	<li><div class=spacer></div>
    <span class=displayspan style="width: 2%; ">&nbsp;</span>
    <span class=displayspan style="width: 6%;">QG</span>
	<span class=displayspan style="width: 35%;text-align: left;">Contribution sociale</span>
	<span class=displayspan style="width: 7%;text-align: right;">9,20%</span>
	<span class=displayspan style="width: 7%;text-align: right;">'.$args->{qg}.'</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;">442500</span>
	<span class=displayspan style="width: 9%; text-align: right;">0,00</span>
	<span class=displayspan style="width: 9%; text-align: right; ">' . ( $args->{total_2777} || 0 ) . '</span>
	<span class=displayspan style="width: 2%; ">&nbsp;</span>
	</span><div class=spacer></li>
	
	<li><div class=spacer></div>
    <span class=displayspan style="width: 2%; ">&nbsp;</span>
    <span class=displayspan style="width: 6%;">QH</span>
	<span class=displayspan style="width: 35%;text-align: left;">solidarité</span>
	<span class=displayspan style="width: 7%;text-align: right;">7,50%</span>
	<span class=displayspan style="width: 7%;text-align: right;">'.$args->{qh}.'</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;">661500</span>
	<span class=displayspan style="width: 9%; text-align: right;">'.$args->{total_interet}.'</span>
	<span class=displayspan style="width: 9%; text-align: right; ">0,00</span>
	<span class=displayspan style="width: 2%; ">&nbsp;</span>
	</span><div class=spacer></li>
	
	<li><div class=spacer></div>
    <span class=displayspan style="width: 2%; ">&nbsp;</span>
    <span class=displayspan style="width: 6%;">AAI</span>
	<span class=displayspan style="width: 35%;text-align: left;">Contribution remboursement dette sociale</span>
	<span class=displayspan style="width: 7%;text-align: right;">0,50%</span>
	<span class=displayspan style="width: 7%;text-align: right;">'.$args->{aai}.'</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;font-weight: bold;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;font-weight: bold;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;font-weight: bold; ">&nbsp;</span>
	<span class=displayspan style="width: 2%; ">&nbsp;</span>
	</span><div class=spacer></li>
	
	<li style="width: 59%;"><hr></li>
	
	<li><div class=spacer></div>
    <span class=displayspan style="width: 2%; ">&nbsp;</span>
    <span class=displayspan style="width: 6%;">&nbsp;</span>
	<span class=displayspan style="width: 35%;text-align: right;font-weight: bold;">Total</span>
	<span class=displayspan style="width: 7%;text-align: right;font-weight: bold;">30%</span>
	<span class=displayspan style="width: 7%;text-align: right;font-weight: bold;">'.$args->{total_2777}.'</span>
	<span class=displayspan style="width: 12%;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right;">&nbsp;</span>
	<span class=displayspan style="width: 9%; text-align: right; ">&nbsp;</span>
	<span class=displayspan style="width: 2%; ">&nbsp;</span>
	</span><div class=spacer></li>
	</ul>
	
	<form class=wrapper1 method="post" >
		<div class=formflexN3>
		<input type="submit" id=submit3 style="width: 10%;" class="btn btn-bleuf" formaction="' . $print_href . '" value="Imprimer" >
		<input type="submit" class="btn btn-noir" style="width : 10%;" formaction="' . $comptabilisation_href . '" value="Comptabiliser">
		</div>
		<input type=hidden name=menu8 value="1">
		<input type=hidden name="menu1" value=0 >
		<input type=hidden name=interet_cca value="1" >
		<input type=hidden name=taux value="' . ($args->{taux} || ''). '">
		<input type=hidden name=select_compte value="' . ($args->{select_compte} || ''). '">
		<input type=hidden name=ab value="' . ($args->{ab} || ''). '">
		<input type=hidden name=qg value="' . ($args->{qg} || ''). '">
		<input type=hidden name=qh value="' . ($args->{qh} || ''). '">
		<input type=hidden name=aai value="' . ($args->{aai} || ''). '">
		<input type=hidden name=total_2777 value="' . ($args->{total_2777} || ''). '">
		<input type=hidden name=total_c455 value="' . ($args->{total_c455} || ''). '">
		<input type=hidden name=total_interet value="' . ($args->{total_interet} || ''). '">
		<input type=hidden name=last31 value="' . $args->{last31} . '">
	</form>

	' ;
    
	}
	############## MISE EN FORME DEBUT ##############
	
	#taux au 31/12/2022
	if (!$args->{taux} && $r->pnotes('session')->{Exercice_fin_YMD} eq '2022-12-31'){
	$args->{taux} = 2.21;	
	}
	#taux au 31/12/2021
	if (!$args->{taux} && $r->pnotes('session')->{Exercice_fin_YMD} eq '2021-12-31'){
	$args->{taux} = 1.17;	
	}
	
	my $contenu_search .= '
	
	<div class="Titre10 centrer">Génération des intérêts des comptes courants d\'associés </div>

	<form class=wrapper1 method=POST action=/'.$r->pnotes('session')->{racine}.'/menu>
	<div class=flex-checkbox>
	    <label style="width: 15%;" class="forms2_label" for="taux">Taux à appliquer</label>
        <label style="width: 33%;" class="forms2_label" for="select_compte">Compte</label>
		<label style="width: 10%;" class="forms2_label" for="submit11">&nbsp;</label>
    </div>    
    
    <div class=flex-checkbox>
	<input class="forms2_input" style="width: 15%;" type=text id=taux name=taux value="' . ($args->{taux} || ''). '" required/>        
	' .  $compte_tiers . '
	<input type=submit id=submit11 style="width: 10%;" class="btn btn-vert" value=Rechercher>	
    </div>
    <input type=hidden name=interet_cca value="1" >
    <input type=hidden name=menu8 value=1">
	<input type=hidden name="menu1" value=0 >
	</form>
	';	
		
	$content .= $contenu_search . $propo_list;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_interet_cca

# Définitions des sidebars			#
##################################### 
#/*—————————————— side_bar_1 => Premiers pas ——————————————*/
sub side_bar_1 {
	my $content = "
		<li class='titre-link'>Premiers pas</li>
		<li><a href='#introduction'>Fonctionnement général</a></li>
		<li><a href='#journaux'>Journaux</a></li>
		<li><a href='#comptes'>Comptes</a></li>
		<li><a href='#documents'>Documents</a></li>
		<li><a href='#ecriturescomptables'>Ecritures comptables</a></li>
		<li><a href='#format'>Format des dates d'écriture</a></li>
		<li><a href='#parametres'>Paramètres</a></li>
		<li><a href='#raccourcis_clavier'>Raccourcis clavier</a></li>
		<li><a href='#tva'>Déclaration de TVA</a></li>
 		<li><a href='#liasse_fiscale'>Liasse fiscale</a></li>
	";
	 return $content ;
} #sub side_bar_1 

#/*—————————————— side_bar_2 => Courant ——————————————*/
sub side_bar_2 {
	my $content = "
 		<li class='titre-link' >Courant</li>
 		<li><a href='#affectation'>Affectation du résultat</a></li>
		<li><a href='#cca'>Comptes Courants Associés</a></li>
		<li><a href='#ecarts'>Ecarts de règlement</a></li>
		<li><a href='#declaration'>Les déclarations</a></li>
		<li><a href='#impots'>Les impôts</a></li>
		<li><a href='#paiementcheque'>Paiement Chèque</a></li>
		<li><a href='#paiementespece'>Paiement Espèce</a></li>
		<li><a href='#paiementvirement'>Paiement Virement</a></li>
		<li><a href='#travaux_periodiques'>Travaux periodiques</a></li>
	";
	 return $content ;
} #sub side_bar_new 

#/*—————————————— side_bar_3 => Utilitaires  ——————————————*/
sub side_bar_3 {
	my $content = "
		<li class='titre-link'>Utilitaires</li>    
		<li><a href='#exportations'>Exportations</a></li>
		<li><a href='#importations'>Importations</a></li>    
	";
	 return $content ;
} #sub side_bar_new 

#/*—————————————— side_bar_4 => Fin d'exercice  ——————————————*/
sub side_bar_4 {
	my $content = "
		<li class='titre-link'>Début et fin d'exercice</li> 
		<li><a href='#reconduite'>Début d'exercice</a></li>
		<li><a href='#cloture'>Clôture d'exercice</a></li>
		<li><a href='#prepcloture'>Check-list avant clôture</a></li>
	";
	 return $content ;
} #sub side_bar_4 

#/*—————————————— side_bar_5 => Utilitaires  ——————————————*/
sub side_bar_5 {
	my $content = "
		<li class='titre-link'>Paramétrage</li> 
		<li><a href='#version'>Gestion des versions</a></li>
	";
	 return $content ;
} #sub side_bar_5 

# Définitions des articles			#
#####################################  
#/*—————————————— articles_bar1 => Premiers pas ——————————————*/
sub articles_bar1 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;
	my $dbh = $r->pnotes('dbh') ;
    my ( $sql, @bind_array, $content ) ;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 
    
    
    # sélection du journal pour formulaire
    $sql = 'SELECT libelle_journal FROM tbljournal_liste WHERE id_client = ? AND fiscal_year = ? ORDER BY libelle_journal' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year} ) ;
	my $journal_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array ) ;
	my $journal_entree = '<select style="margin-left: 1ch;" name=journal>' ;
	for ( @$journal_set ) {
	$journal_entree .= '<option value="' . $_->{libelle_journal} . '">' . $_->{libelle_journal} . '</option>' ;
	}
	$journal_entree .= '</select>' ;

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_1 premier pas
    $content .= "
        
    <section id='introduction' class='main-section'>
		<header class='header'><h3>Fonctionnement général</h3></header><hr class='hrperso'>
			<p>compta.libremen.com est un outil d\'enregistrement et de restitution d\'écritures comptables.</p>
			<p>Son utilisation suppose que l\'utilisateur possède les connaissances minimales d\'un aide-comptable.</p>
			
			<p>Le menu principal contenant cette documentation est disponible à tout moment via clic sur l'icône de la balance en haut à gauche du site.</p>
			<p><a href=".$r->pnotes('session')->{racine}." title='Retour vers Menu'><img height='50' width='64' src='/Compta/style/icons/logo.png' alt='Logo'></a></p>
			
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='journaux' class='main-section'>
			<header class='header'><h3>Journaux</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>le Journal Général (<a href='journal'>Journaux</a>) est constitué de l'ensemble des écritures des journaux auxiliaires</p>
			<form action=/".$r->pnotes('session')->{racine}."/menu >Toutes les écritures sont inscrites dans les journaux auxiliaires, en utilisant le lien 'Nouvelle entrée' en haut à gauche de chaque journal
			(Accès rapide => " . $journal_entree . "
			<input type=submit style='width: 17ch;' class='btnform2 vert' value='Nouvelle Entrée'> )</form>
			<p>L'utilisateur peut créer autant de journaux qu'il le souhaite (<a href='journal?configuration'>Journaux => Modifier la liste</a>)</p>
			<p>Les journaux de type 'Achats' et 'Ventes' offrent une fonction d'enregistrement automatique des paiements dans le journal de votre choix, avec reprise des dates, des libellés et des montants de débit/crédit inversés;
			<br>Pour cela, cliquer dans l'écriture et utiliser le lien '--Choix Règlement--' du formulaire de saisie .</p>
			<p>Seuls les journaux OD, CLOTURE et A-NOUVEAUX sont obligatoires et non modifiables</p>
			<p>A chaque nouvel exercice il faut reconduire les journaux via <a href='journal?configuration&reconduire=0'>Journaux => Modifier la liste => Reconduire les journaux de l'exercice précédent</a></p>
			<p>Les filtres de recherche peuvent être réinitialisés en cliquant sur le lien R (* R 01 02 03 04 ...)</p>
			<p>check1 permet de filtrer les écritures lettrées mais non équilibrées (<a href='journal?open_journal=Journal%20général&mois=0&equilibre=true'>check1</a>) </p>
			<p>Recurrent permet de filtrer les écritures servant à générer des écritures récurrentes.  (<a href='journal?open_journal=Journal%20général&mois=0&recurrent=true'>Récurrent</a>)</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='comptes' class='main-section'>
			<header class='header'><h3>Comptes</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Il est possible d'importer, exporter et modifier la liste des comptes depuis le Menu <a href='compte?configuration'>Comptes => Modifier la liste</a></p>
			<p>Le fichier texte doit contenir pour chaque ligne deux valeurs séparées par un point virgule (1ère valeur = numéro de compte, 2ème valeur = libellé du compte, 3ème valeur = compte de contrepartie). <strong>Le fichier doit être encodé en UTF-8</strong>, avec en-tête (comptenum,comptelib,contrepartie) ou sans en-tête. Exemple :</p>
			<pre>
			comptenum;comptelib;contrepartie
			401PUBN;PUBLICATIONS;
			401FDIV;F DIVERS;
			401PAPE;PAPETERIE;606800
			</pre>
			<p>Les comptes peuvent comporter autant de décimales que souhaité.</p>
			<p>Il est également possible de sélectionner un compte de contrepartie qui sera repris automatiquement lors du choix d'un paiement comptant.</p>
			<p class=bold>La liste des comptes peut être reconduite chaque année :</p>
			<ul>
			<li>Lors du reports des soldes des comptes de bilan via le Menu <a href='compte?reports=0'>Comptes -> Reports</a></li>
			<li>Via le Menu <a href='compte?configuration&reconduire=0'>Comptes => Modifier la liste => Reconduire</a></li>
			</ul>
			<p>La clôture des comptes en fin d'année se fait depuis le menu <a href='compte?cloture=0'>Comptes => Clôture</a></p>
			<p><a href='compte?balance=0'>Balance</a> et <a href='compte?grandlivre=0'>Grand Livre</a> sont disponibles via les liens en haut de page</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='documents' class='main-section'>
			<header class='header'><h3>Documents</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			
			<hr class=mainPageTutoriel>
		
				<ul class=summary>
				<li><a class=summary href='#Documents_1' >Gestion des documents</a></li>
				<li><a class=summary href='#Documents_2' >Gestion des catégories de documents</a></li>
				<li><a class=summary href='#Documents_3' >Saisie rapide d'écritures depuis un document</a></li>
				</ul>
		
			<hr class=mainPageTutoriel>
		
				<div id='Documents_1'>	
				<p class=title1>Gestion des documents</p>
				<ul>
				<li><p>le menu <a href='docs'>Documents</a> affiche tous les documents enregistrés sur l'exercice en cours.</p>
				</li><li><p>Il est possible d'ajouter des documents depuis le Menu <a href='docs?new_document=0'>Documents => Ajouter un document</a></p>
				</li>
				</ul>
				</div>	
			
			<hr class=mainPageTutoriel>
			
				<div id='Documents_2'>	
				<p class=title1>Gestion des catégories de documents</p>
				<ul>
				<li><p>L'utilisateur peut créer autant de catégorie de document qu'il le souhaite (<a href='docs?edit_cat_doc_set=0'>Documents => Modifier la liste </a>)
				</li><li><p>Seul la catégorie Temp est obligatoire et non modifiable</p>
				</li><li><p>Lors de l'ajout d'un document celui-ci est automatiquement placé dans la catégorie Temp. Il est également possible de le placer dans une autre catégorie lors de l'import avec la configuration des règles automatiques <a href='docs?new_document=0'>Documents => Nouveau Documents</a>.</p>
				</li><li><p><p>Les documents cochés Multi sont disponibles pour les tous les exercices tant que \"Last exercice\" n'est pas renseigné</p>
				</li>
				</ul>
				</div>	
			
			<hr class=mainPageTutoriel>
			
				<div id='Documents_3'>	
				<p class=title1>Saisie rapide d'écritures depuis un document</p>
				<p>Il est possible d'ajouter rapidement des écritures depuis un document.</p>
				<img style='width:75%;min-width:800px;' src=\"/Compta/images/menu/ecriture5.png\" alt=\"ecriture5\">
				<p>Si compte est renseigné (par exemple 512) Il est possible de pointer les écritures par rapport au relevé de banque.</p>
				</div>	
			
			<hr class=mainPageTutoriel>

	".$hidden[21]."
	".$hidden[20]."
	</section>
	
	<section id='ecriturescomptables' class='main-section'>
		<header class='header'><h3>Ecritures Comptables</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#ecriturescomptables_1' >Gestion des écritures</a></li>
		<li><a class=summary href='#ecriturescomptables_2' >Les écritures récurrentes</a></li>
		<li><a class=summary href='#ecriturescomptables_3' >Lettrage et Pointage</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>
		
			<div id='ecriturescomptables_1'>	
			<p class=title1>Gestion des écritures</p>
			<ul>
			<li><p>Pour saisir une nouvelle écriture : <a href='journal'>Journaux</a> => Choisir un journal => Cliquer sur \"Nouvelle entrée\" </p>
			</li><li><p>Les écritures peuvent être déplacées d'un journal à un autre via le lien 'Déplacer' du formulaire de saisie</p>
			</li><li><p>Elles peuvent également être extournées et dupliquées via le lien 'Extourner' et 'Dupliquer' du même formulaire</p>
			</li><li><p>Documents 1 est la pièce comptable obligatoire (la date de documents 1 est utilisée pour la génération du FEC).</p>
			</li><li><p>Documents 2 est une pièce complémentaire non utilisée pour la génération du FEC (exemple un relevé bancaire).
			</li>
			</ul>
			</div>	
			
		<hr class=mainPageTutoriel>
		
			<div id='ecriturescomptables_2'>	
			<p class=title1>Les écritures récurrentes</p>
			<ul>
			<li><p>Pour qu'un écriture soit définie comme écriture récurrente cocher la case à droite et valider<p>		
			<img style='width:75%;min-width:800px;' src=\"/Compta/images/menu/ecriture2.png\" alt=\"ecriture2\">
			</li><li><p>Pour lister les écritures servant à générer les écritures récurrentes => <a href='journal?open_journal=Journal%20général&mois=0&recurrent=true'>Journaux => Journal Général => Récurrent</a></p>
			</li>
			</li><li><p>Pour générer les écritures récurrentes => <a href='menu?&amp;menu3=1'>Menu => Ecritures récurrentes</a>
			</li><li>Les écritures générées sont en attente de validation. Cliquer sur une écriture pour la modifier et la valider ou sur \"Valider toutes les écritures\" pour toutes les valider en même temps.</p>
			</li>
			</ul>
			</div>
			
		<hr class=mainPageTutoriel>		
			
			<div id='ecriturescomptables_3'>	
			<p class=title1>Lettrage et Pointage</p>
			<p>Tous les comptes peuvent être pointés, lettrés et rapprochés</p> 
			<ul>
			<li><p>Pointage est disponible depuis le module Documents si un compte est sélectionné.</p>
			</li><li><p>Lettrage est disponible depuis les écritures comptables pour les comptes de classe 4.</p>
			</li><li><p>La numérotation automatique du lettrage fonctionne par journal sous la forme : VE2022-01_01 avec CODEJOURNALANNEE-MOIS_NUMERO </p>
			</li><li><p>Lettrage et Pointage sont également disponible pour toutes les écritures sous <a href='compte?numero_compte=0'>Comptes => Grand Livre</a>.</p>
			</li>
			</ul>
			</div>	
		
		<hr class=mainPageTutoriel>	

	".$hidden[21]."
	".$hidden[20]."
	</section>
                
    </div>
            
	<section id='format' class='main-section'>
		<header class='header'><h3>Format des dates d'écriture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Il est possible de régler le format d'affichage des dates dans le Menu <a href='parametres?utilisateurs'>Paramètres => Utilisateurs => Modifier</a> ( AAAA-MM-JJ ou JJ/MM/AAAA)</p>
		<p>Pour la saisie, plusieurs formats et séparateurs sont acceptés : 2020-02-25 ou 25/02/2020 ou 25#02#2020 ou 2020 02 25. <br>
		L'année doit être écrite sur 4 chiffres</p>
		<p>Voir les <a href=\"index.html#raccourcis_clavier\">raccourcis clavier</a> pour une saisie rapide</p>
		<p><strong>N.B.</strong>: il existe une séparation physique entre les exercices. Le changement d'exercice se fait en cliquant sur le titre 'Exercice XXXX', en haut de page.</p>
		<p>L'utilisateur peut travailler sur plusieurs onglets à la fois (en utilisant Click-droit ou Ctrl-Click) mais toujours dans le même exercice.<br>
		Si l'utilisateur souhaite travailler sur deux exercices différents en même temps, il doit utiliser deux navigateurs différents, un pour chaque exercice</p>
	".$hidden[21]."
	".$hidden[20]."
	</section>
  
	<section id='parametres' class='main-section'>
		<header class='header'><h3>Paramètres</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
		<hr class=mainPageTutoriel>
		
			<ul class=summary>
			<li><a class=summary href='#parametres_1' >Fiche sociétés</a></li>
			<li><a class=summary href='#parametres_2' >Utilisateurs</a></li>
			<li><a class=summary href='#parametres_3' >Sauvegarde & restauration</a></li>
			<li><a class=summary href='#parametres_4' >Achats</a></li>
			<li><a class=summary href='#parametres_5' >Logs</a></li>
			</ul>
		
		<hr class=mainPageTutoriel>
		
			<div id='parametres_1'>	
			<p class=title1>Fiche sociétés</p>
			<ul>
			<li><p><a href='parametres?societes'>Fiche sociétés</a> permet de modifier les informations de la société ou de créer une nouvelle société</p>
			<li><p>Lors de la <a href='parametres?societe=0&modification_societe=1'>modification</a> il est possible de définir les dates du premier exercice fiscal, le type de comptabilité et le régime de TVA</p>
			</li><li><p>Il existe trois régimes de TVA : normal, simplifié ou franchise en base et deux options de calcul de la TVA due : débits ou encaissements; voir le chapitre <a href=\"index.html#ca3\">Déclaration de TVA (formulaire CA3)</a>; la période de calcul peut être mensuelle ou trimestrielle</p>
			</li><li><p>L'option 'Journal de TVA' permet de sélectionner le journal d'enregistrement des écritures résultant du calcul de la TVA due</p>
			</li>
			</ul>
			</div>	
			
		<hr class=mainPageTutoriel>
		
			<div id='parametres_2'>	
			<p class=title1>Utilisateurs</p>
			<ul>
			<li><p><a href='parametres?utilisateurs'>Utilisateurs</a> permet de modifier les paramétres d'un utilisateur ou d'en créer un nouveau</p>
			<li><p>Lors de la <a href='parametres?utilisateurs=0&modification_utilisateur=1'>modification</a> il est possible de définir la société de rattachement, l'activation du mode debug log, le format de date</p>
			</li><li><p>L'utilisateur superadmin est le seul utilisateur pouvant accéder aux paramétres de toutes les sociétés</p>
			</li>
			</ul>
			</div>	
			
		<hr class=mainPageTutoriel>
		
			<div id='parametres_3'>	
			<p class=title1>Sauvegarde & restauration</p>
			<ul>
			<li><p><a href='parametres?sauvegarde'>Sauvegarde & restauration</a> permet de sauvegarder et restaurer la base de donnée et l'application contenant les documents</p>
			</li>
			</ul>
			</div>	
			
		<hr class=mainPageTutoriel>
		
			<div id='parametres_4'>	
			<p class=title1>Achats</p>
			<ul>
			<li><p><a href='parametres?achats'>Achats</a> permet de configurer les modes de règlement des achats</p>
			</li>
			</ul>
			</div>	
			
		<hr class=mainPageTutoriel>
		
			<div id='parametres_5'>	
			<p class=title1>Logs</p>
			<ul>
			<li><p><a href='parametres?logs'>Logs</a> permet d'afficher les logs de l'application</p>
			</li>
			</ul>
			</div>	
			
		<hr class=mainPageTutoriel>
		
	".$hidden[21]."
	".$hidden[20]."
	</section>	
  
 	<section id='raccourcis_clavier' class='main-section'>
		<header class='header'><h3>Raccourcis clavier du formulaire de saisie d'une écriture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<img src=\"/Compta/images/menu/saisie.png\" alt=\"Formulaire de saisie d'une écriture\">
		<p>Date : il est possible de taper par exemple \"0225\" (JJMM, sans les guillemets); la date sera alors complétée avec l'année en cours et formatée pour obtenir 2020-02-25 ou 05/02/2020, suivant l'option d'affichage sélectionnée par l'utilisateur dans le menu 'Paramètres'</p>
		<p>Les cases au fond grisé reproduisent automatiquement la valeur de la ligne précédente</p>
		<p>Compte : taper les premiers chiffres pour obtenir une fenêtre déroulante affichant les comptes disponibles. Seuls les comptes enregistrés dans le menu 'Comptes' pour l'exercice en cours sont acceptés</p>
		<p>Pièce : le symbole '&rarr;' indique un calcul automatique du numéro; taper \"Espace\"; les factures fournisseurs sont au format \"MD...D\" où M est la lettre du mois (janvier = A, février = B...) et D...D le numéro de la pièce pour le mois (01, 02...); le numéro de pièce peut comporter jusqu'à 5 décimales (voir le menu 'Paramètres'). Pour les factures de ventes, le numéro est une séquence pluriannuelle continue qui ajoute 1 à la dernière valeur enregistrée</p>
		<p>Libellé : le symbole '&rarr;' indique une recopie automatique de la ligne précédente; taper \"Espace\"</p>
		<p>Les lignes dont le débit et le crédit valent O (zéro) sont ignorées lors de la validation</p>
		<p>Les signes '+' et '-' sur les côtés du formulaire permettent respectivement d'ajouter et de retirer une ligne</p>
	".$hidden[21]."
	".$hidden[20]."
	</section> 
  
	<section id='tva' class='main-section'>
		<header class='header'><h3>Déclaration de TVA (formulaire CA3)</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Dans le menu TVA, sélectionner la période à déclarer puis cliquer sur 'Valider'; le logiciel affiche alors une réplique partielle du formulaire 3310CA3 (visible sur impots.gouv.fr), avec un calcul des champs principaux à renseigner. <strong>Les périodes de déclaration correspondent à la période en cours et celles de l'année qui précède</strong>. Le formulaire ne peut donc pas être utilisé pour les dates antérieures de plus de 12 mois à la date du jour, mais il est possible d'enregistrer manuellement des écritures antérieures</p>
		<p>En cliquant sur 'Valider' en bas du formulaire, les écritures à passer sont affichées dans le formulaire de saisie d'une écriture et peuvent y être modifiées si besoin</p>
		<p>Le calcul de la TVA exigible est fait à partir des montants enregistrés dans les comptes de classe 7, pour lesquels on paramètre le pourcentage de TVA applicable. Ce calcul peut être fait sur les débits ou sur les encaissements</p>
		<p>Si l'option choisie est <strong>'TVA sur encaissements'</strong>, le logiciel calcule la TVA collectée sur la période à partir des comptes 7 qui sont lettrés et non pointés; il faut donc dans ce cas, pour obtenir une déclaration conforme :</p>
		<ul>
		<li>Lettrer les comptes clients après encaissement de la facture; le lettrage est enregistré dans la ligne des comptes 7 concernés par l'écriture lettrée</li>
		<li>Calculer la TVA due et enregistrer les écritures</li>
		<li>Pointer les écritures des comptes de classe 7 précédemment lettrées, pour qu'elles n'apparaissent plus dans les déclarations suivantes</li>
		</ul>
		<p>L'option <strong>'TVA sur débits'</strong> calcule la TVA due sur l'ensemble des factures enregistrées dans la période considérée<p>
		<p>Il est possible dans ce cas d'enregistrer des ventes de services (TVA exigible à l'encaissement), en utilisant des comptes d'attente :</p>
		<ul>
		<li>Créer un ou plusieurs compte 418 'Ventes non taxables', un compte 44578 'tva collectée non exigible', et un ou plusieurs comptes 7 paramétrés à 0% de TVA et terminés par '*'</li>
		<li>Enregistrer les ventes dans ces comptes</li>
		<li>Lors du règlement, extourner l'écriture initiale, puis enregistrer la vente dans les comptes 411, 4457 et les comptes de classe 7 normaux à la date du règlement</li>
		<li>Calculer la TVA due pour la période</li>
		</ul> 
	".$hidden[21]."
	".$hidden[20]."
	</section>  
  
  	<section id='liasse_fiscale' class='main-section'>
			<header class='header'><h3>Liasse fiscale</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#liasse_fiscale_1' >Quelle liasse fiscale ?</a></li>
		<li><a class=summary href='#liasse_fiscale_2' >Générer la liasse fiscale gratuitement via TELEDEC</a></li>
		<li><a class=summary href='#liasse_fiscale_3' >Les points clés de la liasse fiscale</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>
		
		<div class=intro2>
		<p>Le pré-remplissages des formulaires <a href='bilan?liasse2033A'>2033A</a> <a href='bilan?liasse2033B'>2033B</a> et <a href='bilan?liasse2033C'>2033C</a> sont disponibles via le menu Bilan (<a href='bilan?liasse2033A'>Bilan => 2033A / 2033B / 2033C</a>)</p>
		</div>	
				
		<hr class=mainPageTutoriel>
			
		<div id='liasse_fiscale_1'>	
		<p class=title1>Quelle liasse fiscale ?</p>
		<p>À l’IS, il existe deux régimes : <strong>R</strong>égime <strong>S</strong>implifié ou <strong>R</strong>égime <strong>N</strong>ormal.</p>
		<ul><li><h4>Cas 1 : régime simplifié d’imposition (RS)</h4></li></ul>
		
		<p>Si vous êtes en régime simplifié d’imposition, votre liasse fiscale est la 2065 et les annexes à déclarer sont les formulaires 2033 A, B, C, D, E, F, G.</p>
		
		<p>Vous avez la possibilité d'effectuer la déclarations de résultats directement sur votre compte \"professionnel\" sur <a href='https://www.impots.gouv.fr/accueil'>impots.gouv.fr</a> => Rubrique \"Déclarer résultat\" ou par par l’intermédiaire d’un partenaire EDI (mode EDI-TDFC)</p>
	
		<p>Important : Le régime simplifié d’imposition ne concerne que les entreprises dont le chiffre d’affaires HT est inférieur à :</p>
		<ul><li>238 000 € pour les activités de prestation de services.</li>
		<li>789 000 € pour les autres activités (vente de marchandises, hébergement).</li></ul>
		<p><div class='label yellow'>Remarque :</div> l’intérêt unique mais essentiel du régime simplifié d’imposition est l’allégement des formalités fiscales de fin d’année</p>

		<ul><li><h4>Cas 2 : régime normal d’imposition (RN)</h4></li></ul>

		<p>Si vous dépassez les seuils ci dessus, vous êtes en régime normal d’imposition, votre liasse fiscale est la 2065 et les annexes à déclarer sont les formulaires 2050 à 2057, 2058 A, B, C et 2059 A, B, C, D, E, F, G.
		</p>
		<p>Concernant la déclarations de résultats, vous êtes dans l'obligation de passer par l’intermédiaire d’un partenaire EDI (mode EDI-TDFC)</p>
		<p><div class='label yellow'>Conseil :</div> ne choisissez le régime normal que si vous dépassez les seuils de chiffre d’affaires.</p>	
		

		</div>	
			
			<hr class=mainPageTutoriel>
		
			<div id='liasse_fiscale_2'>	
			<p class=title1>Générer la liasse fiscale gratuitement via TELEDEC</p>
			<p>Vous pouvez réaliser gratuitement votre liasse fiscale avec édition papier via <a href='https://www.teledec.fr/se-connecter'>TELEDEC</a></p>
			<p>TELEDEC est un partenaire EDI agréé par l'état seul la télédéclaration est payante</p>
			<p>Après avoir terminé la comptabilité de votre exercice télécharger la balance via le menu balance (<a href='compte?balance=0'>Balance => Télécharger</a>)     </p>	
			<p>Depuis TELEDEC, confirmer les informations de l'exercice et de la liasse fiscale, puis cliquer sur Autres actions => Remplir cette liasse à partir d'un logiciel comptable => sélectionner le fichier de balance et cliquer sur importer</p>
			<p>Il ne vous reste qu'à vous laissez guider dans les étapes de vérification et génération de la liasse fiscale.</p>
			</div>		
			
			<hr class=mainPageTutoriel>		
			
			<div id='liasse_fiscale_3'>	
			<p class=title1>Les points clés de la liasse fiscale</p>
			<ul><li><h4>Le formulaire 2033A</h4></li></ul>
			<p class=tab1>Ne pas oublier la case 195 \"Dont dettes à plus d'un an\" avec par exemple le montant du capital restant dû du crédit immobilier en date de fin d'exercice</p>
			<ul><li><h4>Le formulaire 2033B</h4></li></ul>
			<ul><li><h4>Le formulaire 2033C</h4></li></ul>
			</div>	
		
			<hr class=mainPageTutoriel>	
			
			

	".$hidden[21]."
	".$hidden[20]."
	</section>
        ";
    
	
	 return $content ;
} #sub articles_bar1 

#/*—————————————— articles_bar2 => Courant ——————————————*/
sub articles_bar2 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_2 Courant - affectation du résultat  
	my $content .= "
	<section id='affectation' class='main-section'>
    	<header class='header'><h3>Affectation du résultat</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#affectation_1' >Comptabilisation de l'affectation du résultat dans une société</a></li>
		<li><a class=summary href='#affectation_2' >Comptabilisation de l'affectation du résultat dans une entreprise individuelle</a></li>
		<li><a class=summary href='#affectation_3' >Comptabilisation de l'affectation du résultat dans une association</a></li>
		</ul>
		
    <hr class=mainPageTutoriel>
			
	<p>Lorsque vous clôturez votre exercice, les comptes de charges et de produits sont soldés et le montant du résultat est enregistré dans le compte « résultat » (n°120 si c’est un bénéfice, 129 si c’est une perte). Cette affectation est automatique dans la procédure de clôture.</p>
    <p>Une deuxième écriture devra être passée, au cours de l’exercice suivant, après la tenue de l’assemblée générale annuelle, pour affecter ce résultat.</p>
	<p>L'affectation dépend de votre structure juridique et des décisions prises.</p>
	
	<hr class=mainPageTutoriel>

	
    <details id=affectation_1 class=warningdoc open><summary class=title1>Comptabilisation de l'affectation du résultat dans une société</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Dans une société, le résultat est affecté en fonction de la décision de l'assemblée générale prise au plus tard dans les 6 mois de la fin de l'exercice. Si le résultat est une perte, il est généralement affecté au compte N° 119... \"report à nouveau (solde débiteur)\". Si le résultat est un bénéfice, il peut être affecté en :
	</p>
			
<ul><li><h4>Report à nouveau (solde créditeur) : N° 110...</h4></li></ul>
	
	<p class=tab1>
	Le report à nouveau permet aux associés ou actionnaires de décider de laisser tout ou partie des bénéfices en report à nouveau, ce qui signifie que le montant reste en instance d'affectation jusqu'à la prochaine assemblée. Un report à nouveau créditeur est donc constaté, il pourra être distribué en dividendes, apurer les déficits antérieurs ou postérieurs, affecté en réserves, augmenter le capital.
	</p>

	<ul><li><h4>Réserves : N° 106...</h4></li></ul>
	<p class=tab1>	Une partie du bénéfice doit être obligatoirement affecté à la \"Réserve légale\", compte N° 106100 (5 % du bénéfice jusqu'à ce que la réserve atteigne 10 % du capital).
	<br>Les autres réserves 1068 sont des sommes mises à la disposition de la société qui en principe ne peuvent pas être touchées par les associés. Elles permettent de valoriser les capitaux propres.
	</p>

	<ul><li><h4>Associés, Dividendes à Payer : N° 457...</h4></li></ul>
	<p class=tab1>Le compte 457 Associés - dividende à payer est un compte temporaire, l'inscription ne vaut pas paiement et n'entraîne pas l'exigibilité des retenues à la source ( Le paiement des dividendes devra s’effectuer dans les 9 mois suivant la clôture de l’exercice et permettra de solder le compte 457)</p>

	<p>
	Généralement les bénéfices sont comptabilisés en report à nouveau en début d'activité afin que ceux-ci épongent d'éventuels déficits. Une fois que le report à nouveau est assez conséquent, il peut être utile de doter les autres réserves. Le cas échéant il vous reste la possibilité de les distribuer sous forme de dividendes.
Il est toujours possible de distribuer les autres réserves en dividendes (sauf si vos statuts l'en empêche) ou d'imputer des déficits dessus mais ce n'est par définition pas le but des autres réserves.
	</p>
	<p>En cas de déficits ultérieurs, au niveau de la présentation du bilan vous pouvez décider de :
<br>- laisser les autres réserves et comptabiliser un report à nouveau débiteur
<br>- diminuer les autres réserves du montant du déficit
<br>Si vous optez pour la première option, les bénéfices futurs devront être utilisés en priorité pour apurer le report à nouveau débiteur avant d'envisager une distribution de dividendes ou doter de nouveau les autres réserves.

Deuxième chose, il faudra surveiller également que vos capitaux propres ne soient pas inférieurs à la moitié du capital social.</p>

	
	<hr class=mainPageTutoriel>
	<p class=classp>Cas d'un bénéfice avec RAN N-1 bénéficaire</p>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>110</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau N-1 (créditeur)</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>120</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - bénéfice</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1061</div>
		  <div class='cell' data-title='Intitulé'>Réserve légale</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>limite 10% du capital</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1063</div>
		  <div class='cell' data-title='Intitulé'>Réserves statuaires</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1068</div>
		  <div class='cell' data-title='Intitulé'>Autres réserves</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>110</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde créditeur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>119</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde débiteur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>457</div>
		  <div class='cell' data-title='Intitulé'>Associés - dividende à payer</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas d'un bénéfice avec RAN N-1 déficitaire</p>
	
	<p >Exemple : Affectation du bénéfice de 1500 € pour solder le RAN N-1 débiteur de 1000€ , 100€ pour la réserve légale, 100€ en autres réserves et dividendes à payer pour le solde </p>
	
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>120</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - bénéfice</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1500</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>119</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde débiteur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1000</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1061</div>
		  <div class='cell' data-title='Intitulé'>Réserve légale</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>100</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>1068</div>
		  <div class='cell' data-title='Intitulé'>Autres réserves</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>100</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>457</div>
		  <div class='cell' data-title='Intitulé'>Associés - dividende à payer</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>300</div>
		</div>
	</div></div>
	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas d'une perte</p>
	
	<p>Lorsque le résultat est une perte, il est très souvent affecté dans le compte « report à nouveau » dans l’attente de bénéfices futurs qui viendront le compenser.
			</p>
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>129</div>
		  <div class='cell' data-title='Intitulé'> Résultat de l'exercice - pertes</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1000</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>119</div>
		  <div class='cell' data-title='Intitulé'>Report à nouveau - solde débiteur</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1000</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>

		
	</div></div>
	<hr class=mainPageTutoriel>
	</details>
	
	<details id=affectation_2 class=alert open><summary class=title1>Comptabilisation de l'affectation du résultat dans une entreprise individuelle</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Dans une entreprise individuelle, le résultat est généralement affecté dans le \"compte de l'exploitant\" N° 10800000, le 1er jour du nouvel exercice.
	</p>
	<hr class=mainPageTutoriel>
	<p class=classp>Cas d'un bénéfice</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>120</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - bénéfice</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1500</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>101</div>
		  <div class='cell' data-title='Intitulé'>Capital individuelle</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat/div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1500</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	<p class=classp>Cas d'un déficit</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD / date de l'assemblée générale</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>129</div>
		  <div class='cell' data-title='Intitulé'>Résultat de l'exercice - perte</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>1500</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>101</div>
		  <div class='cell' data-title='Intitulé'>Capital individuelle</div>
		  <div class='cell' data-title='Libellé'>Affectation du résultat</div>
		  <div class='cell' data-title='Débit'>1500</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	</details>
	
	<details id=affectation_3 class=info open><summary class=title1>Comptabilisation de l'affectation du résultat dans une association</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Dans une association, la distribution de dividendes est impossible. Le Résultat vient donc augmenter ou diminuer le \"report à nouveau\", les \"réserves\" ou le \"fonds associatif\" (compte N° 10200000).
	</p>
		
	<hr class=mainPageTutoriel>
	
	</details>

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	
	#cat_2 Courant Section comptes courants associés
	$content .= "
	<section id='cca' class='main-section'>
		<header class='header'><h3>Comptes Courants Associés</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#cca_1' >Comptabilisation des intérêts des comptes courants associés</a></li>
		<li><a class=summary href='#cca_2' >Remboursement d'un compte courant d'associé</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=cca_1 class=warningdoc open><summary class=title1>Comptabilisation des intérêts des comptes courants associés</summary>

	<hr class=mainPageTutoriel>
	
	<p>Lors du versement des intérêts des comptes courants associés</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>455</div>
		  <div class='cell' data-title='Intitulé'>Associé Compte courant</div>
		  <div class='cell' data-title='Libellé'>INTERET CCA 202*</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant net (60€)</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>4425</div>
		  <div class='cell' data-title='Intitulé'>État – Impôts et taxes</div>
		  <div class='cell' data-title='Libellé'>INTERET CCA 202*</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Part impôts (30€)</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>6615</div>
		  <div class='cell' data-title='Intitulé'>Intérêt des comptes courants</div>
		  <div class='cell' data-title='Libellé'>INTERET CCA 202*</div>
		  <div class='cell' data-title='Débit'>Montant brut des intérêts (90€)</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>
	
	<p>Par la suite, lorsque l’état prélève le montant</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>Prélevement SIE</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Part impôts (30€)</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>4425</div>
		  <div class='cell' data-title='Intitulé'>État – Impôts et taxes</div>
		  <div class='cell' data-title='Libellé'>Prélevement SIE</div>
		  <div class='cell' data-title='Débit'>Part impôts (30€)</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>
	<hr class=mainPageTutoriel>
	</details>
	
	
	<details id=cca_2 class=alerte open><summary class=title1>Remboursement d'un compte courant d'associé</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>virement cca du</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
				<div class='row'>
		  <div class='cell' data-title='Comptes'>455</div>
		  <div class='cell' data-title='Intitulé'>Associé Compte courant</div>
		  <div class='cell' data-title='Libellé'>virement cca du </div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	#cat_2 Courant section ecarts de reglement DEBUT
	$content .= "
	<section id='ecarts' class='main-section'>
	<header class='header'><h3>Ecarts de règlement</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#ecarts_1' >Ecarts de règlement positifs</a></li>
		<li><a class=summary href='#ecarts_2' >Ecarts de règlement négatifs</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=ecarts_1 class=warningdoc open><summary class=title1>Ecarts de règlement positifs</summary>

	<hr class=mainPageTutoriel>
	<p>
	La différence de règlement, lorsqu’elle est en faveur de l’entreprise, est dite positive. Il pourra s’agir des cas suivants :
	<p> une entreprise reçoit sur son compte bancaire une somme plus importante de la part de son client</p>	
	<p> une entreprise paie à son fournisseur un montant moindre que celui figurant sur la facture</p>	
	<p> une entreprise s’acquitte de ses cotisations sociales pour une somme légèrement inférieure à celle figurant dans ses comptes (de
l’ordre de quelques centimes).</p>	
	</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401/411</div>
		  <div class='cell' data-title='Intitulé'>Fournisseurs/Clients</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'>écart</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>758</div>
		  <div class='cell' data-title='Intitulé'>Produits divers gestion courante</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>écart</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=ecarts_2 class=alerte open><summary class=title1>Ecarts de règlement négatifs</summary>

	<hr class=mainPageTutoriel>
	<p>
	A l’inverse, lorsque les différences de règlement sont en la défaveur de l’entreprise, ils sont négatifs. Il s’agit principalement des cas
suivants :
<p>une entreprise perçoit de la part de son client une somme moindre que celle figurant sur la facture de vente,</p>
<p>une entreprise règle une somme plus importante à son fournisseur que celui figurant sur la facture d’achat,</p>
<p>une entreprise s’acquitte de ses cotisations sociales pour une somme légèrement supérieure à celle figurant dans ses comptes.</p>
	</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>658</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'>écart</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401/411</div>
		  <div class='cell' data-title='Intitulé'>Fournisseurs/Clients</div>
		  <div class='cell' data-title='Libellé'>écart de réglement</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>écart</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

	";	#cat_2 Courant section ecarts de reglement FIN
	
	
	
	
	#cat_2 Courant - les déclarations  
	$content .= "
	<section id='declaration' class='main-section'>
		<header class='header'><h3>Les déclarations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
    
    	<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#declaration_1' >Déclaration 2777</a></li>
		<li><a class=summary href='#declaration_2' >Déclaration 2561 IFU</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=declaration_1 class=warningdoc open><summary class=title1>Déclaration 2777</summary>

	<hr class=mainPageTutoriel>
	<p>
	Sont concernés le paiement des intérêts des comptes courants d'associés ou bien le paiement des dividendes
	<p> à produire le 15 du mois qui suit le paiement donc pour un versement au 31/12 déclaration avant 15/01</p>
	
	<p>La déclaration 2777 réalise désormais la collecte du prélèvement forfaitaire sur les revenus distribués, au taux de 12,8%, ce qui permet donc d’arriver au taux global de 30% (soit 17,2% + 12,8%) constituant le prélèvement forfaitaire unique ou PFU.	
	</p>
	<p>Le paiement du PFU se fait par prélèvement en ligne sur le compte de la société
	<p>Le contribuable aura la possibilité de renoncer au mécanisme du prélèvement forfaitaire à 12,8% lors du dépôt de sa déclaration d’impôt sur le revenu.
	</p></p></p>	
	
	<hr class=mainPageTutoriel>
	</details>
	
	<details id=declaration_2 class=alerte open><summary class=title1>Déclaration 2561 IFU</summary>

	<hr class=mainPageTutoriel>
	<p>
	Concerne les sociétés ayant versé des dividendes et/ou des intérêts de compte courant à leurs associés au titre de l’année civile précédente.
	</p>
	<p>Il faut déclarer une fois par an l'IFU en N+1, et avant le 15/02</p>
	<p>Le formulaire reprend toutes les déclarations de revenus de capitaux mobiliers de l'année.</p>
	<p>On ne le fait pas via son espace pro sur IMPOT GOUV mais sur un espace dédié au TIERS DECLARANT, dont il faut demander ses identifiants au préalable

	<p><a href='https://www.impots.gouv.fr/portail/tiers-declarants'>Tiers déclarants | impots.gouv.fr</a>  et cliquer sur Accès à la déclaration en ligne des données</p>

	<p>Il faut faire une déclaration par société (par SIRET), donc par tiers déclarant, avec par société autant de ligne que des personnes à déclarer</p>
	<ul><li><h4>Les dividendes</h4></li></ul>
	<p class=tab1>Indiquez dans la « case AY » le montant brut des dividendes versés (c’est-à-dire avant paiement de l’impôt et des prélèvements sociaux).
	</p>
	<ul><li><h4>Les intérêts de compte courant d’associé</h4></li></ul>
	<p class=tab1>Indiquez dans la « case AR » le montant brut des intérêts de compte courant d’associé versés.</p>
	<ul><li><h4>Les prélèvements sociaux</h4></li></ul>
	<p class=tab1>En principe, il convient de reporter dans la « case DQ » le montant brut des dividendes et intérêts de compte courant versés à l’associé.
	</p>
	<ul><li><h4>Le prélèvement forfaitaire non libératoire (PFNL)</h4></li></ul>
	<p class=tab1>Dans la « case AD » indiquez le montant du PFNL de 12,80% qui a été prélevé à la source lors du versement des dividendes et des intérêts de compte courant. Il s’agit du montant figurant sur la déclaration 2777.</p>
	<p class=tab1>Cette case doit rester vide uniquement si l’associé a demandé à être dispensé du PFNL.</p>
	
	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	#cat_2 Courant - Les impôts  
	$content .= "
	<section id='impots' class='main-section'>
    	<header class='header'><h3>Les impôts</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#impots_1' >Comptabilisation de l'impôt sur les bénéfices</a></li>
		<li><a class=summary href='#impots_2' >Comptabilisation des autres impôts et taxes (TF)</a></li>
		<li><a class=summary href='#impots_3' >Comptabilisation de la Contribution annuelle sur les Revenus Locatifs (CRL)</a></li>
		<li><a class=summary href='#impots_4' >Le compte de charge impôt à utiliser</a></li>
		</ul>
		
    <hr class=mainPageTutoriel>
			
	
    <details id=impots_1 class=warningdoc open><summary class=title1>Comptabilisation de l'impôt sur les bénéfices</summary>
	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors du versement des acomptes (IS >3000€) </p>
	<p>Le 1er acompte calculé sur les bénéfices N-2 doit être payé le 15 mars
	<br>Le 2ème acompte calculé sur les bénéfices N-1 ainsi que la régularisation du 1er acompte doivent être payés le 15 juin
	<br>Le 3ème acompte calculé sur les bénéfices N-1 doit être payé le 15 septembre
	<br>Le 4ème acompte calculé sur les bénéfices N-1 doit être payé le 15 décembre 
	</p>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>444</div>
		  <div class='cell' data-title='Intitulé'>État - Impôt sur les bénéfices</div>
		  <div class='cell' data-title='Libellé'>Acompte impot X</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>

		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>Acompte impot X</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>

	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors de la clôture de l'exercice</p>
	
	<p >Le 31 décembre (fin d'exercice), l'impôt sur les bénéfices N doit être évalué :</p>
	
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>695</div>
		  <div class='cell' data-title='Intitulé'>Impôts sur les bénéfices</div>
		  <div class='cell' data-title='Libellé'>Impôts sur les bénéfices</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>444</div>
		  <div class='cell' data-title='Intitulé'>État - Impôt sur les bénéfices</div>
		  <div class='cell' data-title='Libellé'>Impôts sur les bénéfices</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		
	</div></div>
	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors du paiement du solde d'impôt</p>
	
	<p>Le 31 mars N+1, le solde de l'impôt sur les sociétés de N doit être liquidé</p>
	
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal de banque</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>444</div>
		  <div class='cell' data-title='Intitulé'>État - Impôt sur les bénéfices</div>
		  <div class='cell' data-title='Libellé'>Solde impot</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>

		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>Solde impot</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>

		
	</div></div>
	<hr class=mainPageTutoriel>
	</details>
	
	<details id=impots_2 class=alert open><summary class=title1>Comptabilisation des autres impôts et taxes</summary>
	<hr class=mainPageTutoriel>
	
	<p>La comptabilisation des impôts et taxes s'opère en 2 temps, lors de la réception de l'avis d'imposition et lors du paiement de l'impôt.
	</p>
	
	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors de la réception de l'avis d'imposition</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'achats</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>63</div>
		  <div class='cell' data-title='Intitulé'>Compte de charge impôt</div>
		  <div class='cell' data-title='Libellé'>Taxe foncière</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>447</div>
		  <div class='cell' data-title='Intitulé'>Autres impôts, taxes et versements assimilés</div>
		  <div class='cell' data-title='Libellé'>Taxe foncière</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors du paiement d'un acompte ou du solde</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>447</div>
		  <div class='cell' data-title='Intitulé'>Autres impôts, taxes et versements assimilés</div>
		  <div class='cell' data-title='Libellé'>Taxe foncière</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>

		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>Taxe foncière</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=impots_3 class=alerte open><summary class=title1>Comptabilisation de la Contribution annuelle sur les Revenus Locatifs (CRL)</summary>
	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors de la réception de l'avis d'imposition</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal d'achats</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>63513</div>
		  <div class='cell' data-title='Intitulé'>Compte de charge impôt</div>
		  <div class='cell' data-title='Libellé'>CRL</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>447</div>
		  <div class='cell' data-title='Intitulé'>Autres impôts, taxes et versements assimilés</div>
		  <div class='cell' data-title='Libellé'>CRL</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Lors du paiement d'un acompte ou du solde</p>	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>447</div>
		  <div class='cell' data-title='Intitulé'>Autres impôts, taxes et versements assimilés</div>
		  <div class='cell' data-title='Libellé'>CRL</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>

		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>CRL</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	
	<p class=classp>Lors de la clôture de l'exercice</p>
	
	<p >Il faut constater en fin d’exercice une charge à payer (provision) :</p>
	
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>63513</div>
		  <div class='cell' data-title='Intitulé'>CRL</div>
		  <div class='cell' data-title='Libellé'>provision CRL</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>4486</div>
		  <div class='cell' data-title='Intitulé'>Etat Charges à payer</div>
		  <div class='cell' data-title='Libellé'>provision CRL</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		
	</div></div>
		
		<p >Il faut extourner l’écriture en début d’exercice :</p>
	
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>63513</div>
		  <div class='cell' data-title='Intitulé'>CRL</div>
		  <div class='cell' data-title='Libellé'>extourne provision CRL</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>4486</div>
		  <div class='cell' data-title='Intitulé'>Etat Charges à payer</div>
		  <div class='cell' data-title='Libellé'>extourne provision CRL</div>
		  <div class='cell' data-title='Débit'>Montant</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		
	</div></div>
	
	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=impots_4 class=info open><summary class=title1>Le compte de charge impôt à utiliser</summary>
	<hr class=mainPageTutoriel>
	
	<p>
	Le compte 63 à utiliser dépend de la base de calcul de l'impôt et/ou de son organisme collecteur :
	</p>
	<ul>
	<li><strong>631. Impôts, taxes et versements assimilés sur rémunérations (administrations des impôts)</strong> : taxe d'apprentissage, taxe sur les salaires, participation des employeurs à la formation professionnelle continue, cotisation pour défaut d'investissement obligatoire dans la construction ;</li>
	<li><strong>633. Impôts, taxes et versements assimilés sur rémunérations (autres organismes)</strong> : versements libératoires ouvrant droit à l'exonération de la taxe d'apprentissage, participation des employeurs à l'effort de construction lorsqu'il s'agit de versements à fonds perdu, participation des employeurs à la formation professionnelle continue lorsque les dépenses sont libératoires ;</li>
	<li><strong>635. Autres impôts, taxes et versements assimilés (administrations des impôts)</strong> : taxe foncière, taxe sur les émissions de CO2, taxe en fonction de l'ancienneté des véhicules, contribution économique territoriale (cotisation foncière des entreprises et cotisation sur la valeur ajoutée des entreprises) ;
	</li>
	<li><strong>637. Autres impôts, taxes et versements assimilés (autres organismes)</strong> :contribution sociale de solidarité</li>
	</ul>
		
	<hr class=mainPageTutoriel>
	
	</details>
	
	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";
	
	#cat_2 Courant section paiementcheque
	$content .= "
	<section id='paiementcheque' class='main-section'>
	<header class='header'><h3>Paiement Chèque</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
	    <hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#paiementcheque_1' >Comptabilisation en tant que vendeur => Réglement du client par chèque</a></li>
		<li><a class=summary href='#paiementcheque_2' >Comptabilisation en tant qu'acheteur => Réglement au fournisseur par chèque</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=paiementcheque_1 class=warningdoc open><summary class=title1>Comptabilisation en tant que vendeur => Réglement du client par chèque</summary>

	<hr class=mainPageTutoriel>
	<p class=classp>Cas avec utilisation directe du compte 512 banque</p>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'>Montant chèque</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant chèque</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	<p class=classp>Cas avec utilisation du compte intermédiaire 5112 chèques à encaisser</p>
	
	<p>D’abord : À chaque fois que l’entreprise réceptionne le chèque d’un client</p>
		
	<div class='wrappertable'><div class='table'>
		<div class='caption'>Journal d'OD (ou de chèque à encaisser) / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>5112</div>
		  <div class='cell' data-title='Intitulé'>Chèque à encaisser</div>
		  <div class='cell' data-title='Libellé'>N° du chèque de client</div>
		  <div class='cell' data-title='Débit'>Montant chèque</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>N° du chèque de client</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Montant chèque</div>
		</div>
	</div></div>

	<p>Ensuite : Lors de la remise en banque d’un ensemble de chèques reçus des clients</p> 
	
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de remise des chèques</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'>Total remise</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>5112</div>
		  <div class='cell' data-title='Intitulé'>Chèques à encaisser</div>
		  <div class='cell' data-title='Libellé'>n° de remise de chèque en banque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>Total remise</div>
		</div>
	</div></div><hr class=mainPageTutoriel>
	
	</details>
	
	<details id=paiementcheque_2 class=alerte open><summary class=title1>Comptabilisation en tant qu'acheteur => Réglement au fournisseur par chèque</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de banque / date de paiement</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° de chèque</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>512</div>
		  <div class='cell' data-title='Intitulé'>Banque</div>
		  <div class='cell' data-title='Libellé'>n° de chèque</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	
		
	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	
		";
		
	#cat_2 Courant section paiementespece DEBUT
	$content .= "
	<section id='paiementespece' class='main-section'>
	<header class='header'><h3>Paiement Espèce</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#paiementespece_1' >Comptabilisation en tant que vendeur => Réglement du client en espèce</a></li>
		<li><a class=summary href='#paiementespece_2' >Comptabilisation en tant qu'acheteur => Réglement au fournisseur en espèce</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=paiementespece_1 class=warningdoc open><summary class=title1>Comptabilisation en tant que vendeur => Réglement du client en espèce</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de caisse</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>530</div>
		  <div class='cell' data-title='Intitulé'>Caisse</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=paiementespece_2 class=alerte open><summary class=title1>Comptabilisation en tant qu'acheteur => Réglement au fournisseur en espèce</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de caisse</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>530</div>
		  <div class='cell' data-title='Intitulé'>Caisse</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>

	";	#cat_2 Courant section paiementespece FIN
		
	#cat_2 Courant section paiementvirement DEBUT
	$content .= "
	<section id='paiementvirement' class='main-section'>
	<header class='header'><h3>Paiement Virement</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		<ul class=summary>
		<li><a class=summary href='#paiementvirement_1' >Comptabilisation en tant que vendeur => Réglement du client par virement</a></li>
		<li><a class=summary href='#paiementvirement_2' >Comptabilisation en tant qu'acheteur => Réglement au fournisseur en virement</a></li>
		</ul>
		<hr class=mainPageTutoriel>

    <details id=paiementvirement_1 class=warningdoc open><summary class=title1>Comptabilisation en tant que vendeur => Réglement du client par virement</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>411</div>
		  <div class='cell' data-title='Intitulé'>Client</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	
	<details id=paiementvirement_2 class=alerte open><summary class=title1>Comptabilisation en tant qu'acheteur => Réglement au fournisseur en virement</summary>

	<hr class=mainPageTutoriel>
		
	<div class='wrappertable'><div class='table'><div class='caption'>Journal de l'établissement financier</div>
		<div class='row header'>
		  <div class='cell'>Comptes</div>
		  <div class='cell'>Intitulé</div>
		  <div class='cell'>Libellé</div>
		  <div class='cell'>Débit</div>
		  <div class='cell'>Crédit</div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>401</div>
		  <div class='cell' data-title='Intitulé'>Fournisseur</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'>net à payer</div>
		  <div class='cell' data-title='Crédit'></div>
		</div>
		<div class='row'>
		  <div class='cell' data-title='Comptes'>51</div>
		  <div class='cell' data-title='Intitulé'>Etablissement financier</div>
		  <div class='cell' data-title='Libellé'>n° facture réglée</div>
		  <div class='cell' data-title='Débit'></div>
		  <div class='cell' data-title='Crédit'>net à payer</div>
		</div>
	</div></div>	

	<hr class=mainPageTutoriel>
	
	</details>
	

	<br>	
	".$hidden[22]."
	".$hidden[20]."
	</section>
	";	#cat_2 Courant section paiementvirement FIN

	#cat_2 Courant Section travaux_periodiques
	$content .= "
		<section id='travaux_periodiques' class='main-section'>
		<header class='header'><h3>Travaux periodiques</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<p>Voici la check-list des tâches à faire tous les mois</p>
		  <ul class=checklist>
		  <li>Saisir les pièces comptables</li>
		  <li>Saisir les opérations de banque</li>
		  <li>Lettrer les comptes clients</li>
		  <li>Lettrer les comptes de tiers</li>
		  <li>Lettrer les comptes 467 débiteurs/créditeurs</li>
		  <li>Vérifier le solde du compte 471 qui doit être à 0 €</li>
		  <li>Vérifier le solde du compte 580 qui doit être à 0 €</li>
		  <li>Faire le rapprochement bancaire</li>
		</ul>
	".$hidden[22]."
	".$hidden[20]."
	</section>	
	";	
	
	 return $content ;
} #sub articles_bar2 

#/*—————————————— articles_bar3 => Utilitaires ——————————————*/
sub articles_bar3 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_2 Courant Section comptes courants associés
	my $content .= "
	
  	<section id='exportations' class='main-section'>
    <header class='header'><h3>Exportations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	<p>Le menu 'Export' permet d'exporter et d'archiver les écritures enregistrées dans la base</p>
	<h4>Options d'exportation</h4>
	<ul>
  <li>liste des comptes</li>
  <li>Fichier d'exportation FEC conforme aux dispositions prévues à l'article A47 A-1 du livre des procédures fiscales contenant toutes les écritures enregistrées dans l'exercice</li>
  <li>Ensemble des données enregistrées dans la base pour l'exercice (le format 'Données')</li>
  <li>Écritures archivées</li>
	</ul>
	<p>Il existe deux types d'archivage : mensuel et incrémentiel<br>
  <strong>L'archivage mensuel</strong> permet d'archiver un mois de l'exercice. Après archivage, il n'est plus possible d'ajouter, modifier ou supprimer des écritures pour ce mois. Les écritures d'un mois archivé peuvent être téléchargées au format FEC ou au format 'Données', qui contient toutes les données enregistrées dans le logiciel. On clique sur le numéro du mois pour déclencher l'archivage.<br>
  <strong>L'archivage incrémentiel</strong> permet d'archiver toutes les écritures non encore enregistrées, sans considération de date. Les écritures archivées incrémentiellement ne peuvent plus être modifiées ni supprimées, mais il est possible d'ajouter de nouvelles écritures.<br>
  Les deux modes d'archivage peuvent être utilisés ensemble ou séparément</p>
	<p>Exemple de fichier d'exportation tel qu'il apparaît dans un tableur :</p>
	<table style=\"text-align: left; border: thin solid #444;\">
  <tr><th>id_entry</th><th> date</th><th>numéro de pièce</th><th>libellé</th><th>débit</th><th>crédit</th><th> libre</th><th>numéro de compte</th><th>exercice</th><th>journal</th><th>lettrage</th><th>pointage</th><th> date_validation</th></tr>
  <tr><td>11114</td><td>2016-01-01</td><td>A03</td><td>SNCF paris</td><td style=\"text-align: right;\">        84,00</td><td style=\"text-align: right;\">         0,00</td><td>A51</td><td>401SNCF</td><td>2016</td><td>Banque</td><td>a</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>11114</td><td>2016-01-01</td><td>A03</td><td>SNCF paris</td><td style=\"text-align: right;\">         0,00</td><td style=\"text-align: right;\">        84,00</td><td>A51</td><td>5121CRA</td><td>2016</td><td>Banque</td><td>a</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         9,99</td><td style=\"text-align: right;\">         0,00</td><td></td><td>611010</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         0,00</td><td style=\"text-align: right;\">        11,99</td><td></td><td>401SERV</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
  <tr><td>15253</td><td>2016-01-01</td><td>A08</td><td>SERV kimsufi 01</td><td style=\"text-align: right;\">         2,00</td><td style=\"text-align: right;\">         0,00</td><td></td><td>4456600</td><td>2016</td><td>Fournisseurs</td><td>b</td><td>t</td><td>2016-01-01</td></tr>
	</table>
	".$hidden[23]."
	".$hidden[20]."
	</section>
  
  	<section id='importations' class='main-section'>
			<header class='header'><h3>Importations</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
			<p>Il est possible d'importer des écritures dans l'exercice en cours à partir du Journal Général (lien 'Importer des écritures', en haut de page).<strong> Le fichier à fournir doit être encodé au format UTF-8</strong>, sans en-tête, et se conformer au format ci-dessous. Les champs obligatoires sont précédés d'une étoile (*). Séparateurs de champs : \";\" (point-virgule)</p>
			<p>L'importation des écritures est totale, si aucune erreur n'est détectée. Sinon, aucune écriture n'est importée, et un message d'erreur affiche la liste des écritures empêchant l'importation</p>
			<p>Les écritures doivent être équilibrées par date, numéro de pièce et libellé</p>
			<table style=\"text-align: left; border: thin solid #444;\">
		  <tr><th></th><th>Nom du champ</th><th>Type de données</th><th>Remarques</th></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Journal</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\">le journal doit être présent dans l'exercice d'importation</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Date d'écriture</td><td style=\"border-bottom: 1px solid black;\">Date</td><td style=\"border-bottom: 1px solid black;\">Plusieurs formats et séparateurs sont acceptés : 2020-02-25 ou 25/02/2020 ou 25#02#2020 ou 2020 02 25</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Libre</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Numéro de compte</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\">Le numéro de compte doit être présent dans la liste des comptes de l'exercice d'importation</td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Numéro de pièce</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\">*</td><td style=\"border-bottom: 1px solid black;\">Libellé</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Débit</td><td style=\"border-bottom: 1px solid black;\">Numérique</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Crédit</td><td style=\"border-bottom: 1px solid black;\">Numérique</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Lettrage</td><td style=\"border-bottom: 1px solid black;\">Texte</td><td style=\"border-bottom: 1px solid black;\"></td></tr>
		  <tr><td style=\"border-bottom: 1px solid black;\"></td><td style=\"border-bottom: 1px solid black;\">Pointage</td><td style=\"border-bottom: 1px solid black;\">Booléen</td><td style=\"border-bottom: 1px solid black;\">2 valeurs possibles : (t)rue or (f)alse. En l'absence de données, la valeur enregistrée est 'False', non pointé</td></tr>
			</table>
	".$hidden[23]."
	".$hidden[20]."
		</section>
	";	
	
	 return $content ;
} #sub articles_bar3 

#/*—————————————— articles_bar4 => Fin d'exercice ——————————————*/
sub articles_bar4 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_4 Fin d'exercice
	my $content .= "

	<section id='reconduite' class='main-section'>
		<header class='header'><h3>Début d'exercice</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#reconduite_1' >Nouvel exercice comptable</a></li>
		<li><a class=summary href='#reconduite_2' >Premier exercice comptable</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>
		
		<div id='reconduite_1'>	
		<p class=title1>Nouvel exercice comptable</p>
		<p>En début d'un nouvel exercice, il faut reprendre le plan comptable de l'année précédente (les journaux et les comptes) et générer les à nouveaux (écritures d'ouverture qui reprennent le solde des comptes de bilan de la CLASSES 1 à 5) :</p>
 		<p>Toutes ces actions sont disponibles depuis le menu <a href='compte?reports=0'>Comptes => Reports</a>.</p>

		<hr class=mainPageTutoriel>	
	
		<div id='reconduite_2'>	
		<p class=title1>Premier exercice comptable</p>
		<p>Dans le cas d'un premier exercice, il vous faut :</p>
		<ul>
		<li>Créer vos journaux depuis le Menu <a href='journal?configuration'>Journaux => Modifier la liste</a> (voir le chapitre <a href='#journaux'>Journaux</a>)</li>
		<li>Créer vos comptes depuis le Menu <a href='compte?configuration'>Comptes => Modifier la liste</a> (voir le chapitre <a href='#comptes'>Comptes</a>)</li>
		</ul>
	
		<hr class=mainPageTutoriel>	
		".$hidden[24]."
		".$hidden[20]."
	</section>
		
	<section id='cloture' class='main-section'>
		<header class='header'><h3>Clôture d'exercice</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>

		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#cloture_2' >Procédure de clôture</a></li>
		</ul>
		
		<hr class=mainPageTutoriel>
		
		<div id='cloture_2'>	
		<p class=title1>Procédure de clôture</p>
		<ul><li><h4>Analyses des données comptables</h4></li></ul>
		<p>Via le menu <a href='bilan?analyses'>Bilan => Analyses</a><br>
		Ce module permet de lancer une série de vérifications comptables afin de détecter d'éventuelles anomalies.</p>
		</p>
		<ul><li><h4>Sauvegarder les données</h4></li></ul>
		<p>Via le menu <a href='parametres?sauvegarde'>Sauvegarde & restauration => Sauvegarde & restauration database</a></p>
		<ul><li><h4>Valider les écritures</h4></li></ul>
		<p>Via le menu <a href='export'>Export => Validation des écritures.</a><br>
		La validation des écritures a pour objectif le blocage des écritures. Elle va incrémenter un numéro d’ordre, affecter un numéro de pièce automatique si celui-ci n'est pas présent, et enregistre la date du jour comme date de validation. Aucune correction sur ces écritures ne pourra être effectuée. Cependant de nouvelles saisies sur la période restent possibles.</p>
		<ul><li><h4>Clôturer les comptes</h4></li></ul>
		<p>Via le menu <a href='compte?cloture=0'>Comptes => Clôture</a><br>
		La clôture des comptes solde les comptes de classe 6 et 7, calcule le résultat et l'inscrit au compte 12000 ou 12900 selon que le résultat de l'exercice est positif (excédent / bénéfice) ou négatif (déficit / perte). (les comptes sont créés automatiquement s'ils n'existent pas)<br>
		Les opérations effectuées sont d'abord affichées dans le formulaire de saisie d'une écriture pour validation. L'opération est réversible par suppression de l'OD enregistrée, si les journaux n'ont pas été cloturés.</p>
		<ul><li><h4>Editer les documents comptables</h4></li></ul>
		<p>lancer toutes les éditions de type grand livre, journaux, balances</p>
		<ul><li><h4>Exporter le FEC</h4></li></ul>
		<p>Via le menu <a href='export'>Export => Exportations des données => FEC - Fichier des écritures comptables (Article A47 A-1)</a><br>
		<p><div class=\"label red\">Attention !</div> L'archivage est obligatoire pour toutes les comptabilités informatisées de toutes les structures, dès lors qu'elles sont soumises à l'impôts. A défaut, l'entreprise s'expose à des sanctions en cas de contrôle fiscal.</p>
		<ul><li><h4>Clôturer les journaux</h4></li></ul>
		<p>Via le menu <a href='export?archive_this=0&id_month=ALL&pretty_month=ALL'>Export => Clôtures => Clôtures annuelles</a><br>
		La clôture des journaux consiste à bloquer la saisie et la modification des écritures pour tous les journaux.</p>
		
		
		<hr class=mainPageTutoriel>	
		".$hidden[24]."
		".$hidden[20]."
	</section>
	
	<section id='prepcloture' class='main-section'>
		<header class='header'><h3>Check-list avant clôture</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
		<hr class=mainPageTutoriel>
		
		<ul class=summary>
		<li><a class=summary href='#prepcloture_1' >Contrôles d'ensemble</a></li>
		<li><a class=summary href='#prepcloture_2' >Trésorerie</a></li>
		<li><a class=summary href='#prepcloture_3' >Achats</a></li>
		<li><a class=summary href='#prepcloture_4' >Ventes</a></li>
		<li><a class=summary href='#prepcloture_5' >Stocks</a></li>
		<li><a class=summary href='#prepcloture_6' >Immobilisations</a></li>
		<li><a class=summary href='#prepcloture_7' >Personnel</a></li>
		<li><a class=summary href='#prepcloture_8' >Etat</a></li>
		<li><a class=summary href='#prepcloture_9' >Capitaux</a></li>
		</ul>
		
	<hr class=mainPageTutoriel>
			
		<div id='prepcloture_1'>	
		<p class=title1>Contrôles d'ensemble</p>
		<ul>
		<li>Contrôler les comptes d’attente (471 à 475) qui doivent être soldés</li>
		<li>Contrôler les comptes de virements internes (58) qui doivent être soldés</li>
		<li>Contrôler par sondages que les enregistrements comptables s’appuient sur une pièce justificative et que l'imputation comptable est correcte </li>
		<li>Contrôler la cohérence des principaux ratios par rapport à ceux de l’exercice précédent</li>
		<li>Tous les soldes des comptes des classes 1, 2, 3, 4, et 5 doivent être justifiés, c'est à dire qu'ils doivent être expliqués facilement à l'aide 
		d'une ou plusieurs pièces comptables telles que factures, déclaration sociale ou fiscale, releve, tableau.
		</ul>
		</div>	
			
	<hr class=mainPageTutoriel>
	
		<div id='prepcloture_2'>	
		<p class=title1>Trésorerie</p>
		<ul>
		<li>Contrôler et justifier les comptes de trésorerie (banques, caisses, CCP)</li>
		<li>Contrôler les états de rapprochement si les règlements sont enregistrés d'après les pièces
		(talons de chèques, effets de commerce, avis de virement et de prélèvement, etc.)</li>
		<li>Contrôler par épreuve l’absence de soldes créditeurs en caisse au cours de l’exercice</li>
		<li>Contrôler l’état des valeurs mobilières avec la comptabilité</li>
		<li>Contrôler les tableaux d’amortissement des emprunts avec la comptabilité. Les soldes des comptes d'emprunt (16) doivent correspondre au capital restant dû à la clôture de l'exercice.</li>
		</ul>
		</div>		
			
	<hr class=mainPageTutoriel>		
	
		<div id='prepcloture_3'>	
		<p class=title1>Achats</p>
		<ul>
		<li>Analyser les principaux comptes d’achats afin de détecter d’éventuelles anomalies qui pourraient justifier des contrôles complémentaires</li>
		<li>Contrôler les comptes des fournisseurs (40) débiteurs (ils doivent en principe présenter un solde créditeur et les éventuelles créances fournisseurs (acomptes notamment) devraient figurer en 409</li>
		<li>Contrôler la cohérence du ratio fournisseurs</li>
		<li>Contrôler la correcte séparation des exercices</li>
		<li>Contrôler la concordance entre la comptabilité et les contrats et échéanciers pour crédit-bail, loyer, assurances …</li>
		<li>S’assurer que les comptes de charges ne contiennent pas des biens susceptibles de constituer des immobilisations</li>
		</ul>
		</div>			
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_4'>	
		<p class=title1>Ventes</p>
		<ul>
		<li>Contrôler par épreuve le dénouement en N+1 de certaines créances clients significatives</li>
		<li>Contrôler les créances douteuses et leur dépréciation</li>
		<li>Contrôler la cohérence du ration crédit clients</li>
		<li>Contrôler la correcte séparation des exercices</li>
		<li>Contrôler les comptes clients (41) créditeurs (ils doivent en principe présenter un solde débiteur et les éventuelles dettes clients (acomptes notamment) en 419</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_5'>	
		<p class=title1>Stocks</p>
		<ul>
		<li>Les comptes de stocks et en-cours (classe 3) doivent traduire la valeur des stocks et en-cours après inventaire, à la clôture de l'exercice</li>
		<li>Contrôler, par épreuves, l’application de la méthode de valorisation annoncée et de dépréciation</li>
		<li>Contrôler la cohérence du montant des en-cours avec la facturation de l’exercice suivant</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	

		<div id='prepcloture_6'>	
		<p class=title1>Immobilisations</p>
		<ul>
		<li>Contrôler les soldes des comptes d'immobilisation (20, 21, 22) pour qu'il corresponde à la valeur brute
		en fin d'exercice fournie par le tableau des immobilisations. Les amortissements (28) doivent correspondre au cumul des amortissements
		en fin d'exercice fourni par le tableau des	immobilisations.</li>
		<li>Contrôler les mouvements des immobilisations financières</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_7'>	
		<p class=title1>Personnel</p>
		<ul>
		<li>Contrôler le rapprochement entre les salaires comptabilisés et la DADS/DSN</li>
		<li>Contrôler les soldes des dettes fiscales et sociales avec les déclarations de la dernière période</li>
		<li>Apprécier le taux global de charges sociales </li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_8'>	
		<p class=title1>Etat</p>
		<ul>
		<li>Contrôler le rapprochement du chiffre d’affaires déclaré en TVA avec la comptabilité</li>
		<li>Contrôler le calcul du résultat fiscal et de l’IS</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
		<div id='prepcloture_9'>	
		<p class=title1>Capitaux</p>
		<ul>
		<li>Vérifier l’affectation du résultat N-1 (les comptes 120 et 129 doivent être soldés)</li>
		<li>Vérifier la bonne application des décisions des assemblées</li>
		</ul>
		</div>	
		
	<hr class=mainPageTutoriel>	
	
	".$hidden[24]."
	".$hidden[20]."
	</section>
	
	";	
	
	 return $content ;
} #sub articles_bar4 

#/*—————————————— articles_bar5 => Utilitaires ——————————————*/
sub articles_bar5 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my @hidden = ('0') x 40;

	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
	
	#cat_5 Paramètrage
	my $content .= "
	
  	<section id='version' class='main-section'>
    <header class='header'><h3>Gestion des versions</h3><a class='aperso' href='#top'>#back to top</a></header><hr class='hrperso'>
	
	<section id='timeline' class='timeline-outer'>
   
      <div class='row'>
        <div class='col s12 m12 l12'>
          <ul class='timeline'>
            
            <li class='event' data-date='2015/Present'>
				<h3>Juillet 2022 Version 1.1</h3>
              <p>Version modifiée par picsou83 (<a href='https://github.com/picsou83/compta.libremen.com/wiki/Roadmap'>https://github.com/picsou83/compta.libremen.com/wiki/Roadmap</a>) </p>
            </li>
           
            
            
            <li class='event' data-date='2010/2012'>
            <h3>Mars 2021 Version 1.0</h3>
            <p>Version initiale de Vincent Veyron - Aôut 2016 (<a href='https://compta.libremen.com/'>https://compta.libremen.com/</a>) </p>
            </li>
            
          </ul>
        </div>
      </div>
    ".$hidden[24]."
	".$hidden[20]."
	</section>
	
	</section>
	";	
	
	 return $content ;
} #sub articles_bar5 

#/*—————————————— Formulaire documentation ——————————————*/
sub forms_documentation {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content  ) ;
	my @hidden = ('0') x 40;
	my $href_cat = 'href="/'.$r->pnotes('session')->{racine}.'/"> '; 
	my $href_cat1 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat1=1"> '; 
    my $href_cat2 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat2=1"> '; 
    my $href_cat3 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat3=1"> '; 
    my $href_cat4 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat4=1"> '; 
    my $href_cat5 = 'href="/'.$r->pnotes('session')->{racine}.'/?cat5=1"> '; 

	#checked par défault 
    unless (defined $args->{cat1} || defined $args->{cat2} || defined $args->{cat3} || defined $args->{cat4} || defined $args->{cat5}) {$args->{cat1} = 1; $args->{cat2} = 1; $args->{cat3} = 1; $args->{cat4} = 1; $args->{cat5} = 1;}


#####################################       
# Menu sidebar documentation		#
#####################################  
	$hidden[21] = "<div><a class='label grey' ".$href_cat1."Premiers pas</a><div class='pull-right'>";
	$hidden[22] = "<div><a class='label blue' ".$href_cat2."Courant</a><div class='pull-right'>";
	$hidden[23] = "<div><a class='label blue' ".$href_cat3."Utilitaires</a><div class='pull-right'>";
	$hidden[24] = "<div><a class='label blue' ".$href_cat4."Fin d'exercice</a><div class='pull-right'>";
	$hidden[25] = "<div><a class='label blue' ".$href_cat5."Paramètrage</a><div class='pull-right'>";
	$hidden[20] = "
		<a class='label grey' ".$href_cat1."Premiers pas</a> 
		<a class='label blue' ".$href_cat2."Courant</a> 
		<a class='label green' ".$href_cat3."Utilitaires</a> 
		<a class='label cyan' ".$href_cat4."Fin d'exercice</a> 
		<a class='label yellow' ".$href_cat5."Paramètrage</a> 
		<a class='label red' ".$href_cat."Toutes</a>        
		</div>";
		
	if (defined $args->{cat1} && $args->{cat1} eq 1) {$hidden[11] = side_bar_1() } else {$hidden[11] = '';}
	if (defined $args->{cat2} && $args->{cat2} eq 1) {$hidden[12] = side_bar_2() } else {$hidden[12] = '';}
	if (defined $args->{cat3} && $args->{cat3} eq 1) {$hidden[13] = side_bar_3() } else {$hidden[13] = '';}
	if (defined $args->{cat4} && $args->{cat4} eq 1) {$hidden[14] = side_bar_4() } else {$hidden[14] = '';}
	if (defined $args->{cat5} && $args->{cat5} eq 1) {$hidden[15] = side_bar_5() } else {$hidden[15] = '';}
  
  	#fonction javascript scroll menu
	my $side_bar .= '
	<script>

	window.addEventListener("load", () => {
	
	const sections = Array.from(document.querySelectorAll("section[id]"));
	
	var observer = new IntersectionObserver(function (entries) {

			entries.forEach(entry => {
				const section = entry.target;
				const sectionId = section.id;
				const sectionLink = document.querySelector(`a[href="#${sectionId}"]`);
				
				var intersecting = typeof entry.isIntersecting === \'boolean\' ?
                entry.isIntersecting : (entry.intersectionRatio > 0)
                sectionLink && sectionLink.classList.toggle(\'active\', intersecting)
			//sectionLink.parentElement.classList.add(\'active\');
			});
		
		}, {
            root: null,
            rootMargin: \'-150px 0px -150px 0px\',
			threshold: [0, 0.25, 0.75, 1]
        })
        
	sections && sections.forEach(section => observer.observe(section));
	
	});

	</script>' ;
	
	my $autofocus = 'autofocus';
	
	if ((defined $args->{menu2} && $args->{menu2} eq 1) || 
		(defined $args->{menu3} && $args->{menu3} eq 1) || 
		(defined $args->{ecriture_recurrente}) 			||
		(defined $args->{menu4} && $args->{menu4} eq 1) ||
		(defined $args->{menu5} && $args->{menu5} eq 1) ||
		(defined $args->{menu6} && $args->{menu6} eq 1) ||
		(defined $args->{menu7} && $args->{menu7} eq 1) ||
		(defined $args->{menu8} && $args->{menu8} eq 1) ||
		(defined $args->{interet_cca}) 	
		) {$autofocus = '';} else {$autofocus = 'autofocus';}
	

	#class='docs-sidebar'
	$side_bar .= "
    <div class='sidebar'><nav class='section-nav'><ul class='nav' style='padding: 0px; margin-top: 5px; list-style-type: none;'>
	".$hidden[11]."
	".$hidden[12]."
	".$hidden[13]."
	".$hidden[14]."
	".$hidden[15]."

	</nav></ul></nav></div>
    <main class='menu-contenu' id='main-doc'>    
    <div style='position: sticky; top: 68px;height: 45px;width: 100%;background-color : white;'>
    <input style='width: 100%;' class='login-text' type='text' id='Search' onkeyup='searchFunction2()'
	placeholder='Saisissez le terme de recherche..' title='Rechercher' ".$autofocus." >	
	</div>
	
	<div style='position: sticky; top: 110px; background-color: #fff;     text-align: center; padding-top: 5px;
    padding-bottom: 1%;'>
	".$hidden[20]."
	
	<div class='posts'>
    
    <!-- A single blog post -->
    "; 
		
	if (defined $args->{cat1} && $args->{cat1} eq 1) {$hidden[1] = articles_bar1( $r, $args )} else {$hidden[1] = '';}
	if (defined $args->{cat2} && $args->{cat2} eq 1) {$hidden[2] = articles_bar2( $r, $args )} else {$hidden[2] = '';}
	if (defined $args->{cat3} && $args->{cat3} eq 1) {$hidden[3] = articles_bar3( $r, $args )} else {$hidden[3] = '';}
	if (defined $args->{cat4} && $args->{cat4} eq 1) {$hidden[4] = articles_bar4( $r, $args )} else {$hidden[4] = '';}
	if (defined $args->{cat5} && $args->{cat5} eq 1) {$hidden[5] = articles_bar5( $r, $args )} else {$hidden[5] = '';}
	
	my $documentation .= '</div><div class="flex">' . $side_bar . $hidden[1] . $hidden[2] . $hidden[3] . $hidden[4] . $hidden[5] . '</main></div>' ;
				
	$content .= $documentation;

    return $content ;
    ############## MISE EN FORME FIN ##############
    
} #sub forms_documentation 

#/*—————————————— Vérification BDD && update	——————————————*/
sub verif_bdd_update {

	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array, $content ) ;
	
	#Requête all tables and all Columns
	#'data_type' => 'integer',
    #'position' => 1,
    #'table_name' => 'compta_client',
    #'max_length' => 32,
    #'is_nullable' => 'NO',
    #'table_schema' => 'public',
    #'column_name' => 'id_client',
    #'default_value' => 'nextval(\'compta_client_id_client_seq\'::regclass)'
	$sql = '
		select table_schema, table_name, ordinal_position as position, column_name, data_type,
		case when character_maximum_length is not null
		then character_maximum_length 
		else numeric_precision end as max_length,
		is_nullable, 
		column_default as default_value
		from information_schema.columns
		where table_schema not in (\'information_schema\', \'pg_catalog\')
		order by table_schema, 
        table_name,
        ordinal_position 
    ' ;

	my $array_all_bdd = $dbh->selectall_arrayref( $sql, { Slice => { } }) ;
	
	#ajout colonne module suite MAJ 1.103
	my @tblconfig_liste_module = grep { $_->{table_name} eq 'tblconfig_liste' && $_->{column_name} eq 'module' } @{$array_all_bdd};
    if (!@tblconfig_liste_module) {
	$sql = 'ALTER TABLE tblconfig_liste ADD COLUMN IF NOT EXISTS module TEXT';		
	eval { $dbh->do( $sql, undef) } ;
	$sql = 'UPDATE tblconfig_liste SET module = \'achats\' WHERE module is null' ;
	eval {$dbh->do( $sql, undef) } ;
	Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.103 : Ajout de la colonne "module" dans la table tblconfig_liste');
	}
	
	#ajout colonne multi suite MAJ 1.105
	my @tbldocuments_multi = grep { $_->{table_name} eq 'tbldocuments' && $_->{column_name} eq 'multi' } @{$array_all_bdd};
	if (!@tbldocuments_multi) {
		$sql = 'ALTER TABLE tbldocuments ADD COLUMN IF NOT EXISTS multi BOOLEAN NOT NULL DEFAULT FALSE';		
		eval { $dbh->do( $sql, undef) } ;
		$sql = 'UPDATE tbldocuments SET multi = \'t\' WHERE libelle_cat_doc = \'Inter-exercice\'' ;
		eval {$dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la colonne "multi" dans la table tbldocuments');
	}
	
	#ajout table tblndf_bareme suite MAJ 1.105
	my @tblndf_bareme = grep { $_->{table_name} eq 'tblndf_bareme' } @{$array_all_bdd};
	if (!@tblndf_bareme) {
		$sql = q {
		CREATE TABLE IF NOT EXISTS public.tblndf_bareme (
		id_client integer NOT NULL,
		fiscal_year integer NOT NULL,
		vehicule text NOT NULL,
		puissance text NOT NULL,
		distance1 numeric,
		distance2 numeric,
		prime2 numeric,
		distance3 numeric);
		ALTER TABLE public.tblndf_bareme OWNER TO compta;
		ALTER TABLE ONLY public.tblndf_bareme ADD CONSTRAINT tblndf_bareme_id_client_fiscal_year_vehicule_puissance PRIMARY KEY (id_client, fiscal_year, vehicule, puissance);
		ALTER TABLE ONLY public.tblndf_bareme ADD CONSTRAINT tblndf_bareme_id_client_fkey FOREIGN KEY (id_client) REFERENCES public.compta_client(id_client) ON UPDATE CASCADE;
		} ;		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la table tblndf_bareme');
	}
	
	#ajout table tblndf_frais suite MAJ 1.105
	my @tblndf_frais = grep { $_->{table_name} eq 'tblndf_frais' } @{$array_all_bdd};
	if (!@tblndf_frais) {
		$sql = q {
		CREATE TABLE public.tblndf_frais (
			id_client integer NOT NULL,
			fiscal_year integer NOT NULL,
			intitule text NOT NULL,
			compte text NOT NULL,
			tva numeric(4,2) DEFAULT '0'::numeric NOT NULL
		);
		ALTER TABLE public.tblndf_frais OWNER TO compta;
		ALTER TABLE ONLY public.tblndf_frais ADD CONSTRAINT tblndf_frais_id_client_fiscal_year_intitule_compte_tva PRIMARY KEY (id_client, fiscal_year, intitule, compte, tva);
		ALTER TABLE ONLY public.tblndf_frais ADD CONSTRAINT tblndf_frais_id_client_fiscal_year_compte_fkey FOREIGN KEY (id_client, fiscal_year, compte) REFERENCES public.tblcompte(id_client, fiscal_year, numero_compte) ON UPDATE CASCADE;
		ALTER TABLE ONLY public.tblndf_frais ADD CONSTRAINT tblndf_frais_id_client_fkey FOREIGN KEY (id_client) REFERENCES public.compta_client(id_client) ON UPDATE CASCADE;
		} ;		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la table tblndf_frais');
	}
	
	#ajout table tblndf_bareme suite MAJ 1.105
	my @tblndf_vehicule = grep { $_->{table_name} eq 'tblndf_vehicule' } @{$array_all_bdd};
	if (!@tblndf_vehicule) {
		$sql = q {
			CREATE TABLE public.tblndf_vehicule (
				id_client integer NOT NULL,
				fiscal_year integer NOT NULL,
				vehicule text NOT NULL,
				puissance text NOT NULL,
				vehicule_name text NOT NULL,
				numero_compte text NOT NULL,
				documents text,
				id_vehicule integer NOT NULL,
				electrique boolean DEFAULT false NOT NULL
			);
			ALTER TABLE public.tblndf_vehicule OWNER TO compta;
			CREATE SEQUENCE public.tblndf_vehicule_id_vehicule_seq
				START WITH 1
				INCREMENT BY 1
				NO MINVALUE
				NO MAXVALUE
				CACHE 1;
			ALTER TABLE public.tblndf_vehicule_id_vehicule_seq OWNER TO compta;
			ALTER SEQUENCE public.tblndf_vehicule_id_vehicule_seq OWNED BY public.tblndf_vehicule.id_vehicule;
			ALTER TABLE ONLY public.tblndf_vehicule ALTER COLUMN id_vehicule SET DEFAULT nextval('public.tblndf_vehicule_id_vehicule_seq'::regclass);
			ALTER TABLE ONLY public.tblndf_vehicule	ADD CONSTRAINT tblndf_vehicule_id_client_fiscal_year_vehicule_puissance_vehicu UNIQUE (id_client, fiscal_year, vehicule, puissance, vehicule_name);
			ALTER TABLE ONLY public.tblndf_vehicule ADD CONSTRAINT tblndf_vehicule_id_vehicule_id_client_fiscal_year PRIMARY KEY (id_vehicule, id_client, fiscal_year);
			ALTER TABLE ONLY public.tblndf_vehicule ADD CONSTRAINT tblndf_vehicule_id_client_documents_fkey FOREIGN KEY (id_client, documents) REFERENCES public.tbldocuments(id_client, id_name) ON UPDATE CASCADE;
			ALTER TABLE ONLY public.tblndf_vehicule	ADD CONSTRAINT tblndf_vehicule_id_client_fiscal_year_numero_compte_fkey FOREIGN KEY (id_client, fiscal_year, numero_compte) REFERENCES public.tblcompte(id_client, fiscal_year, numero_compte) ON UPDATE CASCADE;
			ALTER TABLE ONLY public.tblndf_vehicule	ADD CONSTRAINT tblndf_vehicule_id_client_fiscal_year_vehicule_puissance_fkey FOREIGN KEY (id_client, fiscal_year, vehicule, puissance) REFERENCES public.tblndf_bareme(id_client, fiscal_year, vehicule, puissance) ON UPDATE CASCADE;
			ALTER TABLE ONLY public.tblndf_vehicule	ADD CONSTRAINT tblndf_vehicule_id_client_fkey FOREIGN KEY (id_client) REFERENCES public.compta_client(id_client) ON UPDATE CASCADE;
			} ;		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la table tblndf_vehicule');
	}
	
	#update Routines delete_account_data pour empêcher la suppression du compte superadmin
		$sql = '
		SELECT routine_definition
		FROM information_schema.routines 
		WHERE routine_type=\'FUNCTION\' 
		  AND specific_schema=\'public\'
		  AND routine_name LIKE \'delete_account_data\'
		' ;

	my $routine_definition = $dbh->selectall_arrayref( $sql, undef )->[0]->[0] ;
	
	if (!($routine_definition =~ /superadmin/ )) {
		$sql = q {
DROP FUNCTION public.delete_account_data(id_client integer);
CREATE FUNCTION public.delete_account_data(id_client integer) RETURNS void
LANGUAGE sql
AS $_$
update tbljournal set id_export = null where id_client = $1;	
delete from tbllocked_month where id_client = $1;	
delete from tblexport where id_client = $1;	
delete from tbljournal where id_client = $1;
delete from tbljournal_liste where id_client = $1;
delete from tbldocuments where id_client = $1;
delete from tbldocuments_categorie where id_client = $1;
delete from tblcompte where id_client = $1;
delete from tbljournal_liste where id_client = $1;
delete from tbljournal_staging where id_client = $1;
delete from tblcerfa_2_detail where id_entry in (select id_entry from tblcerfa_2 where id_client = $1);
delete from tblcerfa_2 where id_client = $1;
delete from compta_user where id_client = $1 and username != 'superadmin' ;
delete from compta_client where id_client = $1;
$_$;
ALTER FUNCTION public.delete_account_data(id_client integer) OWNER TO compta;
		};		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Update Routines delete_account_data pour empêcher la suppression du compte superadmin');
	}
	
	#ajout table tbljournal_type suite MAJ 1.105
	my @tbljournal_type = grep { $_->{table_name} eq 'tbljournal_type' } @{$array_all_bdd};
	if (!@tbljournal_type) {
		$sql = q {
		CREATE TABLE public.tbljournal_type (type_journal text NOT NULL);
		ALTER TABLE public.tbljournal_type OWNER TO compta;
		INSERT INTO tbljournal_type VALUES ('Achats'),('Ventes'),('Trésorerie'),('Clôture'),('OD'),('A-nouveaux');
		ALTER TABLE ONLY public.tbljournal_type	
			ADD CONSTRAINT tbljournal_type_type_journal PRIMARY KEY (type_journal);
		ALTER TABLE ONLY public.tbljournal_liste 
			ADD CONSTRAINT tbljournal_liste_type_journal_fkey FOREIGN KEY (type_journal) REFERENCES public.tbljournal_type(type_journal) ON UPDATE CASCADE;
				} ;		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la table tbljournal_type');
	}
	
	#ajout table tblndf suite MAJ 1.105
	my @tblndf = grep { $_->{table_name} eq 'tblndf' } @{$array_all_bdd};
	if (!@tblndf) {
		$sql = q {
		CREATE TABLE public.tblndf (
			id_client integer NOT NULL,
			fiscal_year integer NOT NULL,
			piece_ref text NOT NULL,
			piece_date date NOT NULL,
			piece_compte text NOT NULL,
			piece_libelle text NOT NULL,
			piece_entry integer,
			id_vehicule integer,
			com1 text,
			com2 text,
			com3 text
		);
		ALTER TABLE public.tblndf OWNER TO compta;
		ALTER TABLE ONLY public.tblndf ADD CONSTRAINT tblndf_id_client_fiscal_year_piece_ref PRIMARY KEY (id_client, fiscal_year, piece_ref);
		ALTER TABLE ONLY public.tblndf ADD CONSTRAINT tblndf_id_client_fiscal_year_id_vehicule_fkey FOREIGN KEY (id_client, fiscal_year, id_vehicule) REFERENCES public.tblndf_vehicule(id_client, fiscal_year, id_vehicule);
		ALTER TABLE ONLY public.tblndf ADD CONSTRAINT tblndf_id_client_fiscal_year_piece_compte_fkey FOREIGN KEY (id_client, fiscal_year, piece_compte) REFERENCES public.tblcompte(id_client, fiscal_year, numero_compte);
		ALTER TABLE ONLY public.tblndf ADD CONSTRAINT tblndf_id_client_fkey1 FOREIGN KEY (id_client) REFERENCES public.compta_client(id_client);
		} ;		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la table tblndf');
	}
	
	#ajout table tblndf_detail suite MAJ 1.105
	my @tblndf_detail = grep { $_->{table_name} eq 'tblndf_detail' } @{$array_all_bdd};
	if (!@tblndf_detail) {
		$sql = q {
		CREATE TABLE public.tblndf_detail (
			id_client integer NOT NULL,
			fiscal_year integer NOT NULL,
			piece_ref text NOT NULL,
			frais_date date NOT NULL,
			frais_compte text NOT NULL,
			frais_libelle text NOT NULL,
			frais_quantite integer,
			frais_montant integer DEFAULT 0 NOT NULL,
			frais_doc text,
			frais_line integer NOT NULL,
			frais_bareme numeric
		);
		ALTER TABLE public.tblndf_detail OWNER TO compta;
		CREATE SEQUENCE public.tblndf_detail_frais_line_seq
		START WITH 1
		INCREMENT BY 1
		NO MINVALUE
		NO MAXVALUE
		CACHE 1;
		ALTER TABLE public.tblndf_detail_frais_line_seq OWNER TO compta;
		ALTER SEQUENCE public.tblndf_detail_frais_line_seq OWNED BY public.tblndf_detail.frais_line;
		ALTER TABLE ONLY public.tblndf_detail ALTER COLUMN frais_line SET DEFAULT nextval('public.tblndf_detail_frais_line_seq'::regclass);
		ALTER TABLE ONLY public.tblndf_detail ADD CONSTRAINT tblndf_detail_pkey PRIMARY KEY (frais_line);
		ALTER TABLE ONLY public.tblndf_detail ADD CONSTRAINT tblndf_detail_id_client_fiscal_year_piece_ref_fkey FOREIGN KEY (id_client, fiscal_year, piece_ref) REFERENCES public.tblndf(id_client, fiscal_year, piece_ref) ON UPDATE CASCADE ON DELETE CASCADE;
		ALTER TABLE ONLY public.tblndf_detail ADD CONSTRAINT tblndf_id_client_fiscal_year_frais_compte_fkey FOREIGN KEY (id_client, fiscal_year, frais_compte) REFERENCES public.tblcompte(id_client, fiscal_year, numero_compte) ON UPDATE CASCADE;
		ALTER TABLE ONLY public.tblndf_detail ADD CONSTRAINT tblndf_id_client_fkey FOREIGN KEY (id_client) REFERENCES public.compta_client(id_client);
		ALTER TABLE ONLY public.tblndf_detail ADD CONSTRAINT tblndf_id_client_frais_doc_fkey FOREIGN KEY (id_client, frais_doc) REFERENCES public.tbldocuments(id_client, id_name) ON UPDATE CASCADE;
		} ;		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Ajout de la table tblndf');
	}
	
		#update Routines record_staging pour retourner _id_entry suite MAJ 1.105
		$sql = '
		SELECT routine_definition
		FROM information_schema.routines 
		WHERE routine_type=\'FUNCTION\' 
		  AND specific_schema=\'public\'
		  AND routine_name LIKE \'record_staging\'
		' ;

	my $routine_def_record_staging = $dbh->selectall_arrayref( $sql, undef )->[0]->[0] ;
	
	if (!($routine_def_record_staging =~ /DECLARE/ )) {
		$sql = q {
DROP FUNCTION public.record_staging(my_token_id text, my_id_entry integer);
CREATE FUNCTION public.record_staging(my_token_id text, my_id_entry integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
DECLARE _id_entry integer;
BEGIN
IF ( not (select sum(credit-debit) from tbljournal_staging where _token_id = $1) = 0 ) then RAISE EXCEPTION 'unbalanced'; END IF;
-- supprimer les champs où débit et crédit sont nulls
delete from tbljournal_staging where ( coalesce(debit, 0) + coalesce(credit, 0) = 0 and _token_id = my_token_id);
-- si c'est une nouvelle entrée, id_entry = 0; lui affecter la nouvelle valeur
IF my_id_entry = 0 THEN
update tbljournal_staging set id_entry = (select nextval('tbljournal_id_entry_seq'::regclass)) where id_entry = 0 and _token_id = my_token_id;
ELSE
-- si c'est une mise à jour d'une entrée existante, il faut la supprimer
delete from tbljournal where id_entry = $2;
END IF;
-- pratiquer l'insertion proprement dite
insert into tbljournal (date_ecriture, id_facture, libelle, debit, credit, lettrage, id_line, id_entry, id_paiement, numero_compte, fiscal_year, id_client, libelle_journal, pointage, id_export, documents1, documents2, recurrent)
select date_ecriture, id_facture, libelle, debit, credit, lettrage, id_line, id_entry, id_paiement, numero_compte, fiscal_year, id_client, libelle_journal, pointage, id_export, documents1, documents2, recurrent
from tbljournal_staging where _token_id = $1;
-- si l'insertion s'est bien passée, on vide tbljournal_stagin
with t1 as (delete from tbljournal_staging where _token_id = $1
RETURNING id_entry)
select id_entry from t1 LIMIT 1 INTO _id_entry;
RETURN _id_entry;
END;
$_$;
ALTER FUNCTION public.record_staging(my_token_id text, my_id_entry integer) OWNER TO compta;
		};		
		eval { $dbh->do( $sql, undef) } ;
		Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => MAJ 1.105 : Update Routines record_staging pour retourner _id_entry');
	}

    return $content ;

} #sub verif_bdd_update 

#/*—————————————— Export PDF Complet——————————————*/
sub export_pdf2 {
	
	# définition des variables
	my ( $r, $args ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array ) ;
	my $book2 ;
	
	############## Récupérations d'informations ##############
	#Requête des informations concernant les entrées du compte sélectionné
	$sql = '
	SELECT t1.id_entry, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, t2.libelle_compte, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, t1.debit/100::numeric as debit, t1.credit/100::numeric as credit, (sum(t1.debit) over())/100::numeric as total_debit, (sum(t1.credit) over())/100::numeric as total_credit, (sum(t1.credit-t1.debit) over (PARTITION BY t1.numero_compte ORDER BY date_ecriture, id_facture, libelle))/100::numeric as solde
	FROM tbljournal t1
	INNER JOIN tblcompte t2 ON t1.id_client = t2.id_client AND t1.fiscal_year = t2.fiscal_year AND t1.numero_compte = t2.numero_compte
	WHERE t1.id_client = ? AND t1.fiscal_year = ? AND t1.numero_compte = ?
	ORDER BY date_ecriture, id_entry, id_line
	' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{select_compte}) ;
	my $result_set = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;
		
	$sql = '
	SELECT t1.piece_ref, t1.piece_date, t1.piece_compte, t2.libelle_compte, t1.piece_libelle, t1.piece_entry, t5.id_facture, t1.id_vehicule, t1.com1, t1.com2, t1.com3, t3.vehicule, t3.vehicule_name, t3.puissance,  COALESCE(t3.electrique,false) as electrique, COALESCE(t4.distance1,0) as distance1, COALESCE(t4.distance2,0) as distance2, COALESCE(t4.distance3,0) as distance3, COALESCE(t4.prime2,0) as prime2
	FROM tblndf t1
	INNER JOIN tblcompte t2 ON t1.id_client = t2.id_client AND t1.fiscal_year = t2.fiscal_year AND t1.piece_compte = t2.numero_compte
	LEFT JOIN tblndf_vehicule t3 ON t1.id_client = t3.id_client AND t1.fiscal_year = t3.fiscal_year AND t1.id_vehicule = t3.id_vehicule
	LEFT JOIN tblndf_bareme t4 ON t1.id_client = t4.id_client AND t1.fiscal_year = t4.fiscal_year AND t3.vehicule = t4.vehicule AND t3.puissance = t4.puissance
	LEFT JOIN (SELECT DISTINCT ON(id_entry) id_entry, id_client, fiscal_year, id_facture FROM tbljournal) t5 ON t1.id_client = t5.id_client AND t1.fiscal_year = t5.fiscal_year AND t1.piece_entry = t5.id_entry
	WHERE t1.id_client = ? AND t1.fiscal_year = ? and t1.piece_ref = ?
	ORDER BY piece_ref' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{piece_ref}) ;	
    my $array_of_notes = eval {$dbh->selectall_arrayref( $sql, { Slice => { } }, @bind_array )} ;

	#Récupérations des informations de la société
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, adresse_1, code_postal, ville, journal_tva FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;


	############## Récupérations d'informations ##############

	
	############## DEFINITION DES VALEURS ##############
	# PDF
	my $pdf = PDF::API2->new;

	#$pdf->mediabox('A4'); => Format A4
	#$pdf->mediabox(595, 842); => format A4 portrait Unite points
	#format A4 paysage landscape
	$pdf->mediabox(842, 595);
	# Get paper size
	my @page_size_infos = $pdf->mediabox;
	my $page_width = $page_size_infos[2];
	my $page_height = $page_size_infos[3];
	# Page margin
	my $page_top_margin = 48;
	my $page_bottom_margin = 48;
	my $page_left_margin = 48;
	my $page_right_margin = 48;
	#Définition des coordonnées de départ et de fin x et y
	my $render_start_x = $page_left_margin;
	my $render_start_y = $page_height - 1 - $page_top_margin;
	my $render_end_x = $page_width - 1 - $page_right_margin;
	my $render_end_y = $page_bottom_margin;

	my $font = $pdf->corefont('Helvetica');
	my $font_bold = $pdf->corefont('Helvetica-Bold');
	my $font_italic = $pdf->corefont('Georgia-Italic', -encode=>'latin1');
	# Font size-default
	my $font_size_default = 10;
	my $font_size_tableau = 9;
	# Format Tableau
	# Set the minimum unit of height and width, the minimum unit of width is divided into 100
	my $unit_height = 14;
	my $unit_width = ($render_end_x-$render_start_x)/100;
	# Text drawing padding
	my $text_bottom_padding = 3;
	my $text_left_padding = 3;

	# Color list
	my $color_black = '#000';

	# Line width
	my $line_width_basic = 0.3;
	my $line_width_bold = 2;

	# Ajout Page depuis template
	my $page = _add_pdf_page( $r, $args , $pdf);

	# Graphic drawing
	my $gfx = $page->gfx;
	# Text drawing
	my $text = $page->text;
	#Couleur texte noir par default
	$text->strokecolor($color_black);
	$text->fillcolor($color_black);
	# Ligne de départ LEFT RIHT MIDDLE
	my $cur_row = 9;
	my $cur_row_left = 6;
	my $cur_row_right = 6;
	my $cur_row_middle = -0.5;
	
	############## INFO TIERS GAUCHE PAGE 1 ##############
	# Libellé
	$text->translate($render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding);
	$text->font($font, $font_size_default);
	$text->text('Libellé : Décompte Intérêts CC '.$r->pnotes('session')->{Exercice_fin_DMY}.'');
	$cur_row_left += 1;
	# Tiers
	$text->translate($render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding);
	$text->font($font, $font_size_default);
	$text->text('Tiers : '.($result_set->[0]->{numero_compte}|| '').' - '.($result_set->[0]->{libelle_compte}|| '').'');
	$cur_row_left += 1;
	# Taux
	$text->translate($render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding);
	$text->font($font, $font_size_default);
	$text->text('Taux : '.$args->{taux}.' %');
	$cur_row_left += 1.75;

	$cur_row_left += 1;

	############## INFO TIERS GAUCHE PAGE 1 ##############
	
	##Mise en forme de la date dans Exercice_fin_YMD de %Y-%m-%d vers 29/02/2000
	my $date_fin_dmy = eval {Time::Piece->strptime($r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d")->dmy("/")};
    
    if (defined $args->{last31} && $args->{last31} eq 0) {
    #ajouter valeur array dans requête
	push @$result_set, {
		'total_credit' => '',
		'credit' => '',
		'id_entry' => 'LAST',
		'date_ecriture' => ''.$date_fin_dmy.'',
		'libelle_compte' => '',
		'numero_compte' => '',
		'documents1' => '',
		'libelle' => '',
		'documents2' => ' ',
		'debit' => '',
		'id_facture' => '',
		'total_debit' => '',
		'solde' => '',
		'libelle_journal' => ''
	};
	}
	my $count_result_set = scalar(@$result_set);	
	
	#split les resultats de la requête
	my $rows_count = $count_result_set; # NOMBRE LIGNE requête
	my $first_line_number = $rows_count;# NOMBRE LIGNE TABLEAU 1ERE PAGE
	my $second_line_number = 20;
	my $third_line_number = 20;
	my $numberofarrays = 17; # NOMBRE LIGNE TABLEAU AUTRES PAGES
	my $addpage = 0 ;
	
	if ($rows_count > 17 && $rows_count < 45){
		if ($rows_count > 17 && $rows_count < 25) {$first_line_number=24;$addpage=1;} else {$first_line_number=24;$numberofarrays=24;}
	} elsif ($rows_count > 44 && $rows_count < 49){
		$first_line_number=24;$numberofarrays=24;$second_line_number=24;$addpage=1;
	} elsif ($rows_count >= 49){
		$first_line_number=24;$numberofarrays=27;$second_line_number=27;$addpage=1;
	}

	my @del = splice @$result_set, $first_line_number; #ENLEVER first_line_number pour 1erpage
	my @new4 = split_by($numberofarrays,@del); #spliter par numberofarrays
	
		# Ligne TOP
		# background 1ère Ligne Decoration en tête
		$gfx->rectxy(
		  $render_start_x, $render_start_y-$unit_height * $cur_row,
		  $render_end_x, $render_start_y-$unit_height * ($cur_row + 1)
		);
		$gfx->fillcolor('# eee');
		$gfx->fill;
		# 1ère Ligne Decoration en tête 
		$gfx->move($render_start_x, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_end_x);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		$cur_row += 1;

		# Save the position of the thick line under the quotation heading
		my $header_bottom_line_row = $cur_row;
		my $cur_column_units_count = 0;

		#espace en tête
		my $date_units_count = 7;
		my $compte_units_count = 6;
		my $piece_units_count = 11.5;
		my $libelle_units_count = 40.5;
		my $debit_units_count = 7;
		my $credit_units_count = 7;
		my $solde_units_count = 7;
		my $nbjours_units_count = 7;
		my $interet_units_count = 7;
		my $depense_units_count = 1;
		my $bareme_units_count = 1;
		my $km_units_count = 1;
		my $montant_units_count = 1;
		
		#APPEL create_entete
		create_entete($r, $args, $pdf, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count);
		
		$cur_row ++;

		my $date_prec ;
		my $calcul_interet = 0;
		my $total_interet = 0;
		my $solde_prec = 0;
		my $date_nb_jour = 0;	
		my $date_en_cours = '';
		my $date_debut = Time::Piece->strptime($r->pnotes('session')->{Exercice_debut_YMD}, "%Y-%m-%d");
		my $date_fin = Time::Piece->strptime($r->pnotes('session')->{Exercice_fin_YMD}, "%Y-%m-%d");
		my $date_n1 = Time::Piece->strptime($result_set->[1]->{date_ecriture}, "%d/%m/%Y");

		#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => datadumper ' . Data::Dumper::Dumper(@$result_set) . ' ');
		
		############## RECUPERATION RESULTAT REQUETE ##############
		for (my $row = 0; $row < $first_line_number; $row ++) {
			
			my $book2 = $result_set->[$row];
		
			if ($book2 && defined $book2->{date_ecriture} && $book2->{date_ecriture} ne '') {
				$date_en_cours = Time::Piece->strptime($book2->{date_ecriture}, "%d/%m/%Y");
				if ($date_prec) {
				$date_nb_jour = ($date_en_cours - $date_prec)->days ;	
				} else {
				$date_nb_jour = ($date_debut - $date_en_cours)->days ;
				}
				$calcul_interet = (($date_nb_jour * $solde_prec * $args->{taux})/100)/360;
				#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => calcul_interet '.$calcul_interet.' et $date_nb_jour'.$date_nb_jour.' et $_->{solde} '.$_->{solde}.' et taux '.$args->{taux}.'');
				if(($calcul_interet=~/\d/) && ($calcul_interet >= 0) && ($calcul_interet < 999999999999999)){
				$total_interet += $calcul_interet;
				}
				($calcul_interet = sprintf( "%.2f",$calcul_interet)) =~ s/\./\,/g;
				$calcul_interet =~ s/\B(?=(...)*$)/ /g ;
				$solde_prec = $book2->{solde} ;
				$date_prec = Time::Piece->strptime($book2->{date_ecriture}, "%d/%m/%Y");
			}

			my ($debit,$credit, $solde);
			
			if ($book2 && defined $book2->{debit} && $book2->{debit} ne '') {
			($debit = sprintf( "%.2f", $book2->{debit} ) ) =~ s/\B(?=(...)*$)/ /g ;
			}

			if ($book2 && defined $book2->{credit} && $book2->{credit} ne '') {
			($credit = sprintf( "%.2f", $book2->{credit} ) ) =~ s/\B(?=(...)*$)/ /g ;
			}

			if ($book2 && defined $book2->{solde} && $book2->{solde} ne '') {
			($solde = sprintf( "%.2f", $book2->{solde} ) ) =~ s/\B(?=(...)*$)/ /g ;
			}
			
		Template_pdf_requete ($r, $args, $pdf, $book2, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count,
		$color_black, $line_width_basic, $line_width_bold, $cur_column_units_count,$debit,$credit, $solde,
		$row, $date_nb_jour, $calcul_interet );

			$cur_row ++;
		}
		
		############## RECUPERATION RESULTAT REQUETE ##############
		# 2ème Ligne décoration En tête
		$gfx->move($render_start_x, $render_start_y-$unit_height * $header_bottom_line_row);
		$gfx->hline($render_end_x);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		
		# si plus de 20 lignes pages 1 génération nouvelle page de 27 lignes 
		foreach (@new4) {

		# Ajout Page depuis template
		$page = _add_pdf_page( $r, $args , $pdf);
		
		# Graphic drawing
		$gfx = $page->gfx;
		# Text drawing
		$text = $page->text;
		#Couleur texte noir par default
		$text->strokecolor($color_black);
		$text->fillcolor($color_black);
		# Ligne de départ nouvelle page
		$cur_row = 5;
		
		# Ligne TOP
		# background 1ère Ligne Decoration en tête
		$gfx->rectxy(
		  $render_start_x, $render_start_y-$unit_height * $cur_row,
		  $render_end_x, $render_start_y-$unit_height * ($cur_row + 1)
		);
		$gfx->fillcolor('# eee');
		$gfx->fill;
		# 1ère Ligne Decoration en tête 
		$gfx->move($render_start_x, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_end_x);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		$cur_row += 1;

		# Save the position of the thick line under the quotation heading
		$header_bottom_line_row = $cur_row;
		$cur_column_units_count = 0;

		#APPEL create_entete
		create_entete($r, $args, $pdf, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count);
		
		$cur_row ++;
		
		$rows_count = $second_line_number; # NOMBRE LIGNE TABLEAU

		############## RECUPERATION RESULTAT REQUETE ##############
		for (my $row = 0; $row < $rows_count; $row ++) {

			my $book2 = $_->[$row];
		
			if ($book2 && defined $book2->{date_ecriture} && $book2->{date_ecriture} ne '') {
			$date_en_cours = Time::Piece->strptime($book2->{date_ecriture}, "%d/%m/%Y");
			if ($date_prec) {
			$date_nb_jour = ($date_en_cours - $date_prec)->days ;	
			} else {
			$date_nb_jour = ($date_debut - $date_en_cours)->days ;
			}
			$calcul_interet = (($date_nb_jour * $solde_prec * $args->{taux})/100)/360;
			#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'menu.pm => calcul_interet '.$calcul_interet.' et $date_nb_jour'.$date_nb_jour.' et $_->{solde} '.$_->{solde}.' et taux '.$args->{taux}.'');
			if(($calcul_interet=~/\d/) && ($calcul_interet >= 0) && ($calcul_interet < 999999999999999)){
			$total_interet += $calcul_interet;
			}
			($calcul_interet = sprintf( "%.2f",$calcul_interet)) =~ s/\./\,/g;
			$calcul_interet =~ s/\B(?=(...)*$)/ /g ;
			
			$solde_prec = $book2->{solde} ;
			$date_prec = Time::Piece->strptime($book2->{date_ecriture}, "%d/%m/%Y");
				
			}

			my ($debit,$credit, $solde);
			if ($book2 && defined $book2->{debit} && $book2->{debit} ne '') {
			($debit = sprintf( "%.2f", $book2->{debit} ) ) =~ s/\B(?=(...)*$)/ /g ;
			}
			if ($book2 && defined $book2->{credit} && $book2->{credit} ne '') {
			($credit = sprintf( "%.2f", $book2->{credit} ) ) =~ s/\B(?=(...)*$)/ /g ;
			}
			if ($book2 && defined $book2->{solde} && $book2->{solde} ne '') {
			($solde = sprintf( "%.2f", $book2->{solde} ) ) =~ s/\B(?=(...)*$)/ /g ;
			}
			
		Template_pdf_requete ($r, $args, $pdf, $book2, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count,
		$color_black, $line_width_basic, $line_width_bold, $cur_column_units_count,$debit,$credit, $solde,
		$row, $date_nb_jour, $calcul_interet );

			  $cur_row ++;
		}
		
		############## RECUPERATION RESULTAT REQUETE ##############
		# 2ème Ligne décoration En tête
		$gfx->move($render_start_x, $render_start_y-$unit_height * $header_bottom_line_row);
		$gfx->hline($render_end_x);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
	}  

	#Ecriture sur dernière page en cours
	$gfx = $page->gfx;
	$text = $page->text;
	$text->strokecolor($color_black);
	$text->fillcolor($color_black);
	
	# Ligne épaisse Séparation Total
	$gfx->move($render_start_x, $render_start_y-$unit_height * ($cur_row - 1));
	$gfx->hline($render_end_x);
	$gfx->linewidth($line_width_bold);
	$gfx->strokecolor($color_black);
	$gfx->stroke;
	
	( my $total_montant = sprintf( "%.2f", ($total_interet || 0) ) ) =~ s/\B(?=(...)*$)/ /g ;
	
	# TOTAL1
	my $price_total_no_tax_label = 'TOTAL';
	$text->translate($render_start_x + ($date_units_count + $compte_units_count + $piece_units_count + $libelle_units_count + $debit_units_count + $credit_units_count + $solde_units_count ) * $unit_width + ($nbjours_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
	$text->font($font_bold, $font_size_tableau);
	$text->text_center($price_total_no_tax_label);
	$text->translate($render_end_x, $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
	$text->font($font_bold, $font_size_tableau);
	$text->text_right(''.$total_montant.' ');
	$cur_row += 2;
	
	if ($addpage eq 1) {
	# Ajout Page depuis template
	$page = _add_pdf_page( $r, $args , $pdf);
	# Graphic drawing
	$gfx = $page->gfx;
	# Text drawing
	$text = $page->text;
	#Couleur texte noir par default
	$text->strokecolor($color_black);
	$text->fillcolor($color_black);
	# Ligne de départ nouvelle page
	$cur_row = 7;
	}
	
	# APPEL create_ecri_compta
	create_ecri_compta ($r, $args, $pdf, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count,
		$color_black, $line_width_basic, $line_width_bold, $total_montant) ;
	
	# HEADER ET FOOTER
	foreach my $pagenum (1 .. $pdf->pages) {

		my $page = $pdf->openpage($pagenum);
		my $font = $pdf->corefont('Helvetica');
		
		# détection format de la page
		(my $llx, my $lly, my $urx, my $ury) = $page->get_mediabox;
		my $render_end_x_page = $urx - 1 - $page_right_margin;
		
		#count nb pages
		my $pages = $pdf->pages;
		my $totalpages += $pages;
		
		$gfx = $page->gfx;
		$text = $page->text;
		$text->strokecolor($color_black);
		$text->fillcolor($color_black);
		$text->translate($render_end_x_page, 28);
		$text->font($font, 8);
		$text->text_right( 'page '.$pagenum.' / '.$totalpages.'' );
  
	}

	#Enregistrer le pdf
	my $file = '/Compta/images/pdf/print.pdf';
	my $pdf_file = $r->document_root() . $file;
	$pdf->saveas($pdf_file);

	return $file ;

}#sub export_pdf2 

#/*—————————————— Fonction split array ——————————————*/
sub split_by {
	my ($num, @arr) = @_;
	my @sub_arrays;

	while (@arr) {
		push(@sub_arrays, [splice @arr, 0, $num]);
	}

	return @sub_arrays;
}#sub split_by

#/*—————————————— Modéle page ——————————————*/
sub _add_pdf_page {
	# définition des variables
	my ( $r, $args, $pdf ) = @_ ;
	my $dbh = $r->pnotes('dbh') ;
	my ( $sql, @bind_array ) ;

	#Base::Site::logs::logEntry("#### INFO ####", $r->pnotes('session')->{username}, 'ndf.pm => datadumper : ' . Data::Dumper::Dumper($args) . ' ');

    ############## Récupérations d'informations ##############
	#Requête des informations concernant la note de frais
	#Requête des informations concernant les entrées du compte sélectionné
	$sql = '
	SELECT t1.id_entry, t1.date_ecriture, t1.libelle_journal, t1.numero_compte, coalesce(t1.id_facture, \'&nbsp;\') as id_facture, coalesce(t1.libelle, \'&nbsp;\') as libelle, coalesce(t1.documents1, \'&nbsp;\') as documents1, coalesce(t1.documents2, \'&nbsp;\') as documents2, t1.debit/100::numeric as debit, t1.credit/100::numeric as credit, (sum(t1.debit) over())/100::numeric as total_debit, (sum(t1.credit) over())/100::numeric as total_credit, (sum(t1.credit-t1.debit) over (PARTITION BY numero_compte ORDER BY date_ecriture, id_facture, libelle))/100::numeric as solde
	FROM tbljournal t1
	WHERE t1.id_client = ? AND t1.fiscal_year = ? AND t1.numero_compte = ?
	ORDER BY date_ecriture, id_entry, id_line
	' ;
	@bind_array = ( $r->pnotes('session')->{id_client}, $r->pnotes('session')->{fiscal_year}, $args->{select_compte}) ;
	my $result_set = $dbh->selectall_arrayref( $sql, { Slice =>{ } }, @bind_array ) ;
	my $count_result_set = scalar(@$result_set);
    #Récupérations des informations de la société
    $sql = 'SELECT etablissement, siret, date_debut, date_fin, padding_zeroes, fiscal_year_start, id_tva_periode, id_tva_option, adresse_1, code_postal, ville, journal_tva FROM compta_client WHERE id_client = ?' ;
    my $parametre_set = $dbh->selectall_arrayref( $sql, { Slice => { } }, ( $r->pnotes('session')->{id_client} ) ) ;
	
    #$pdf->mediabox('A4'); => Format A4
	#$pdf->mediabox(595, 842); => format A4 portrait Unite points
	#format A4 paysage landscape
	$pdf->mediabox(842, 595);
	# Get paper size
	my @page_size_infos = $pdf->mediabox;
	my $page_width = $page_size_infos[2];
	my $page_height = $page_size_infos[3];
	# Page margin
	my $page_top_margin = 48;
	my $page_bottom_margin = 48;
	my $page_left_margin = 48;
	my $page_right_margin = 48;
	#Définition des coordonnées de départ et de fin x et y
	my $render_start_x = $page_left_margin;
	my $render_start_y = $page_height - 1- $page_top_margin;
	my $render_end_x = $page_width - 1- $page_right_margin;
	my $render_end_y = $page_bottom_margin;

	my $font = $pdf->corefont('Helvetica');
	my $font_bold = $pdf->corefont('Helvetica-Bold');
	my $font_italic = $pdf->corefont('Georgia-Italic', -encode=>'latin1');
	# Font size-default
	my $font_size_default = 10;
	my $font_size_tableau = 9;
	# Format Tableau
	# Set the minimum unit of height and width, the minimum unit of width is divided into 100
	my $unit_height = 14;
	my $unit_width = ($render_end_x-$render_start_x)/100;
	# Text drawing padding
	my $text_bottom_padding = 3;
	my $text_left_padding = 3;

    my $page = $pdf->page();
    
    # Graphic drawing
	my $gfx = $page->gfx;
	# Text drawing
	my $text = $page->text;
	#Couleur texte noir par default
	$text->strokecolor('#000');
	$text->fillcolor('#000');

	# Ligne de départ LEFT RIHT MIDDLE
	my $cur_row = 12;
	my $cur_row_left = 0;
	my $cur_row_right = 0;
	my $cur_row_middle = -0.5;

	############## TITRE MIDDLE ##############
	# Top thick line
	$gfx->move($render_start_x+280, $render_start_y-$unit_height * $cur_row_middle + $text_bottom_padding);
	$gfx->hline($render_end_x-280);
	$gfx->linewidth(2);
	$gfx->stroke;
	$cur_row_middle += 1.5;
	# Titre
	$text->translate(421, $render_start_y-$unit_height * $cur_row_middle + $text_bottom_padding);
	$text->font($font_bold, 20);
	$text->text_center('Calcul des Intérêts');
	$cur_row_middle += 1;
	# Titre piece_ref
	$text->translate(421, $render_start_y-$unit_height * $cur_row_middle + $text_bottom_padding);
	$text->font($font, 10);
	$text->text_center('Du '.$r->pnotes('session')->{Exercice_debut_DMY}.' au '.$r->pnotes('session')->{Exercice_fin_DMY}.' ');
	$cur_row_middle += 0.25;
	# Top thick line
	$gfx->move($render_start_x+280, $render_start_y-$unit_height * $cur_row_middle);
	$gfx->hline($render_end_x-280);
	$gfx->linewidth(2);
	$gfx->stroke;
	$cur_row_middle += 1;
	# Com
	$text->translate(421, $render_start_y-$unit_height * $cur_row_middle + $text_bottom_padding);
	$text->font($font_italic, 8);
	$text->text_center('Montant exprimé en euros');
	
	############## TITRE MIDDLE ##############

	############## INFO SOCIETE DROITE ##############
	# piece_date et id_facture
	$text->translate($render_start_x + 86.5 * $unit_width, $render_start_y-$unit_height * $cur_row_right + $text_bottom_padding);
	$text->font($font, $font_size_default);
	$text->text('Date : '.$r->pnotes('session')->{Exercice_fin_DMY}.'');
	$cur_row_right += 1;
	$text->translate($render_start_x + 86.5 * $unit_width, $render_start_y-$unit_height * $cur_row_right + $text_bottom_padding);
	$text->font($font, $font_size_default);
	$text->text('Pièce: '.($args->{numero_piece} || '').'');
	$cur_row_right += 5;
	############## INFO SOCIETE DROITE ##############

	############## INFO SOCIETE GAUCHE ##############
	# etablissement
	my $sender_company_name = ''.$parametre_set->[0]->{etablissement} . '';
	$text->translate(
	  $render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding
	);
	$text->font($font, $font_size_default);
	$text->text($sender_company_name);
	$cur_row_left += 1;
	# Adresse
	my $sender_addr = '' . ($parametre_set->[0]->{adresse_1} || '') . '';
	$text->translate(
	  $render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding
	);
	$text->font($font, $font_size_default);
	$text->text($sender_addr);
	$cur_row_left += 1;
	# code postale
	my $sender_zip_code = '' . ($parametre_set->[0]->{code_postal} || ''). ' ' . ($parametre_set->[0]->{ville} || '').'';
	$text->translate(
	  $render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding
	);
	$text->font($font, $font_size_default);
	$text->text($sender_zip_code);
	$cur_row_left += 1;
	# Siret
	my $sender_siret = 'SIRET : ' . $parametre_set->[0]->{siret} . '';
	$text->translate(
	  $render_start_x, $render_start_y-$unit_height * $cur_row_left + $text_bottom_padding
	);
	$text->font($font, $font_size_default);
	$text->text($sender_siret);
	$cur_row_left += 3;
	############## INFO SOCIETE GAUCHE ##############

    return $page;
}#sub _add_pdf_page

#/*—————————————— Modéle entête ——————————————*/
sub create_entete {
	# définition des variables
	my ($r, $args, $pdf, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count) = @_ ;
		
		#espace en tête
		my $cur_column_units_count = 0;

		############## ENTÊTE TABLEAU ##############
		# Date
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($date_units_count * $unit_width/3), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text('Date');
		$cur_column_units_count += $date_units_count;
		# Compte
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($compte_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Compte');
		$cur_column_units_count += $compte_units_count;
		# Pièce
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($piece_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Pièce');
		$cur_column_units_count += $piece_units_count;
		# Libellé
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($libelle_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Libellé');
		$cur_column_units_count += $libelle_units_count;
		# Débit
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($debit_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Débit');
		$cur_column_units_count += $debit_units_count;
		# Crédit
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($credit_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Crédit');
		$cur_column_units_count += $credit_units_count;
		# Solde
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($solde_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Solde');
		$cur_column_units_count += $solde_units_count;
		# Nb Jours
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($nbjours_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Nb Jours');
		$cur_column_units_count += $nbjours_units_count;
		# Intérêts
		$text->translate($render_start_x + $cur_column_units_count * $unit_width + ($interet_units_count * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Intérêts');
		$cur_column_units_count = 0;
		############## ENTÊTE TABLEAU ##############
    
} #Create_entete {

#/*—————————————— Modéle entête ——————————————*/
sub create_ecri_compta {
	# définition des variables
	my ($r, $args, $pdf, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count,
		$color_black, $line_width_basic, $line_width_bold, $total_montant ) = @_ ;
	
	############## SECTION FORMULAIRE ECRITURE COMPTA ##############
		#espace en tête
		my $section_start = 2;
		my $section_form = 55;
		my $section_form_case = 6;
		my $section_form_description = 35;
		my $section_form_taux = 7;
		my $section_form_montant = 7;
		my $section_dummy = 16;
		my $section_compta = 25;
		my $section_compta_compte = 8;
		my $section_compta_debit = 8;
		my $section_compta_credit = 8;
		my $section_end = 2;
		
		# section_form
		$text->translate($render_start_x + ($section_start ) * $unit_width + ($section_form * $unit_width/2), $render_start_y-$unit_height * ($cur_row -0.15) + $text_bottom_padding);
		$text->font($font_italic, $font_size_default);
		$text->text_center('Formulaire 2777');
		# Ligne 1 TOP trait section_form
		$gfx->rectxy($render_start_x + $section_start * $unit_width, $render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form) * $unit_width, $render_start_y-$unit_height * ($cur_row + 1));
		$gfx->fillcolor('# eee');
		$gfx->fill;
		$gfx->move($render_start_x + $section_start * $unit_width, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_start_x + ($section_start + $section_form) * $unit_width);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		# section_compta
		$text->translate($render_start_x + ($section_start + $section_form + $section_dummy) * $unit_width + ($section_compta * $unit_width/2) , $render_start_y-$unit_height * ($cur_row -0.15) + $text_bottom_padding);
		$text->font($font_italic, $font_size_default);
		$text->text_center('Écritures comptables correspondantes');
		# Ligne 1 TOP trait section_compta
		$gfx->rectxy($render_start_x + ($section_start + $section_form + $section_dummy) * $unit_width, $render_start_y-$unit_height * $cur_row,
		$render_start_x + + ($section_start + $section_form + $section_dummy + $section_compta)* $unit_width, $render_start_y-$unit_height * ($cur_row + 1));
		$gfx->fillcolor('# eee');
		$gfx->fill;
		$gfx->move($render_start_x + ($section_start + $section_form + $section_dummy) * $unit_width, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_start_x + ($section_start + $section_form + $section_dummy + $section_compta)* $unit_width);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		
		$cur_row += 1;
		
		#$section_form_case
		$text->translate($render_start_x + ($section_start ) * $unit_width + ($section_form_case * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Case');
		#$section_form_description
		$text->translate($render_start_x + ($section_start + $section_form_case ) * $unit_width + ($section_form_description * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Description');
		#section_form_taux
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description ) * $unit_width + ($section_form_taux * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Taux');
		#section_form_montant
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width + ($section_form_montant * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Montant');
		#section_compta_compte
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy) * $unit_width + ($section_compta_compte * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Compte');
		#section_compta_debit
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy+ $section_compta_compte) * $unit_width + ($section_compta_debit * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Débit');
		#section_compta_credit
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy+ $section_compta_compte + $section_compta_debit) * $unit_width + ($section_compta_credit * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_default);
		$text->text_center('Crédit');
		
		# Ligne 2 TOP trait section_form
		$gfx->move($render_start_x + $section_start * $unit_width, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_start_x + ($section_start + $section_form) * $unit_width);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		# Ligne 2 TOP trait section_compta
		$gfx->move($render_start_x + ($section_start + $section_form + $section_dummy) * $unit_width, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_start_x + ($section_start + $section_form + $section_dummy + $section_compta)* $unit_width);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		
		$cur_row += 1;
		
 		#Line fond gris
		$gfx->rectxy($render_start_x + $section_start * $unit_width, $render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form) * $unit_width, $render_start_y-$unit_height * ($cur_row + 1));
		$gfx->fillcolor('# eee');
		$gfx->fill;
		#section_form_case Line
		$text->translate($render_start_x + ($section_start ) * $unit_width + ($section_form_case * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('AB');
		#section_form_description Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 0.9)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case ) * $unit_width + (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text('Intérêts, arrérages et produits de toute nature');
		#section_form_taux Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 0.9)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description ) * $unit_width + (($section_form_taux -1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('12,80%');
		#section_form_montant Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 0.9)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width + (($section_form_montant-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{ab}.'');
		#section_compta_compte Line
		$gfx->poly(
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 0.9)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy) * $unit_width + ($section_compta_compte * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('455100');
		#section_compta_debit Line
		$gfx->poly(
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 0.9)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width + (($section_compta_debit-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('0,00');
		#section_compta_credit Line
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width + (($section_compta_credit-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{total_c455}.'');
		
		$cur_row += 1;
		
		#section_form_case Line
		$text->translate($render_start_x + ($section_start ) * $unit_width + ($section_form_case * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('QG');
		#section_form_description Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case ) * $unit_width + (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text('Contribution sociale');
		#section_form_taux Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description ) * $unit_width + (($section_form_taux -1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('9,20%');
		#section_form_montant Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width + (($section_form_montant-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{qg}.'');
		#section_compta_compte Line
		$gfx->poly(
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy) * $unit_width + ($section_compta_compte * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('442500');
		#section_compta_debit Line
		$gfx->poly(
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width + (($section_compta_debit -1)* $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('0,00');
		#section_compta_credit Line
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width + (($section_compta_credit-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{total_2777}.'');
		
		$cur_row += 1;
		
		#Line fond gris
		$gfx->rectxy($render_start_x + $section_start * $unit_width, $render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form) * $unit_width, $render_start_y-$unit_height * ($cur_row + 1));
		$gfx->fillcolor('# eee');
		$gfx->fill;
 
		#section_form_case Line
		$text->translate($render_start_x + ($section_start ) * $unit_width + ($section_form_case * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('QH');
		#section_form_description Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case ) * $unit_width + (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text('Solidarité');
		#section_form_taux Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description ) * $unit_width + (($section_form_taux -1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('7,50%');
		#section_form_montant Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width + (($section_form_montant-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{qh}.'');
		#section_compta_compte Line
		$gfx->poly(
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy) * $unit_width + ($section_compta_compte * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('661500');
		#section_compta_debit Line
		$gfx->poly(
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte) * $unit_width + (($section_compta_debit -1)* $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{total_interet}.'');
		#section_compta_credit Line
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width + (($section_compta_credit-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('0,00');	
		
		# Ligne 2 TOP trait section_compta
		$gfx->move($render_start_x + ($section_start + $section_form + $section_dummy) * $unit_width, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_start_x + ($section_start + $section_form + $section_dummy + $section_compta)* $unit_width);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;
		
		$cur_row += 1;
		
		#section_form_case Line
		$text->translate($render_start_x + ($section_start ) * $unit_width + ($section_form_case * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_center('AAI');
		#section_form_description Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case ) * $unit_width + (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text('Contribution remboursement dette sociale');
		#section_form_taux Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description ) * $unit_width + (($section_form_taux -1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right('0,50%');
		#section_form_montant Line
		$gfx->poly(
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * $cur_row,
		$render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width,
		$render_start_y-$unit_height * ($cur_row - 1)
		);
		$gfx->linewidth(1.5);
		$gfx->strokecolor('# ccc');
		$gfx->stroke;
		$text->translate($render_start_x + ($section_start + $section_form_case + $section_form_description + $section_form_taux) * $unit_width + (($section_form_montant-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font, $font_size_tableau);
		$text->text_right(''.$args->{aai}.'');
		
		# Ligne 2 TOP trait section_form
		$gfx->move($render_start_x + $section_start * $unit_width, $render_start_y-$unit_height * $cur_row);
		$gfx->hline($render_start_x + ($section_start + $section_form) * $unit_width);
		$gfx->linewidth($line_width_bold);
		$gfx->strokecolor($color_black);
		$gfx->stroke;		
		
		#section_compta_compte
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy) * $unit_width + ($section_compta_compte * $unit_width/2), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font_bold, $font_size_default);
		$text->text_center('TOTAL');
		#section_compta_debit Line
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte ) * $unit_width + (($section_compta_debit-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font_bold, $font_size_tableau);
		$text->text_right(''.$total_montant.'');
		#section_compta_credit Line
		$text->translate($render_start_x + ($section_start + 1 + $section_form + $section_dummy + $section_compta_compte + $section_compta_debit) * $unit_width + (($section_compta_credit-1) * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font_bold, $font_size_tableau);
		$text->text_right(''.$total_montant.'');	

		$cur_row += 1;
		
		# TOTAL section_form_description
		$text->translate($render_start_x + ($section_start + $section_form_case + + $section_form_description ) * $unit_width - (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font_bold, $font_size_default);
		$text->text_right('TOTAL');
		# TOTAL section_form_taux
		$text->translate($render_start_x + ($section_start + $section_form_case + + $section_form_description + $section_form_taux ) * $unit_width - (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font_bold, $font_size_default);
		$text->text_right('30%');
		# TOTAL section_form_montant
		$text->translate($render_start_x + ($section_start + $section_form_case + + $section_form_description + $section_form_taux + $section_form_montant ) * $unit_width - (1 * $unit_width), $render_start_y-$unit_height * $cur_row + $text_bottom_padding);
		$text->font($font_bold, $font_size_default);
		$text->text_right(''.$args->{total_2777}.'');

		############## SECTION FORMULAIRE ECRITURE COMPTA##############	
}

#/*—————————————— Modéle entête ——————————————*/
sub Template_pdf_requete {
	# définition des variables
	my ($r, $args, $pdf, $book2, $page, $gfx, $text, $cur_row, $font, $font_bold, $font_italic, $render_start_x, 
		$render_start_y, $render_end_x, $render_end_y, $unit_width, $unit_height , $text_left_padding, $text_bottom_padding,
		$font_size_default, $font_size_tableau, $date_units_count, $compte_units_count, $piece_units_count,
		$libelle_units_count, $debit_units_count, $credit_units_count, $solde_units_count, $nbjours_units_count,
		$interet_units_count, $depense_units_count, $bareme_units_count, $km_units_count, $montant_units_count,
		$color_black, $line_width_basic, $line_width_bold, $cur_column_units_count,$debit,$credit, $solde,
		$row, $date_nb_jour, $calcul_interet ) = @_ ;
		
	# Lines are painted alternately
			if ($row % 2 == 1) {
				$gfx->rectxy(
				$render_start_x,
				$render_start_y-$unit_height * $cur_row,
				$render_end_x,
				$render_start_y-$unit_height * ($cur_row - 1),
				);
				$gfx->fillcolor('# eee');
				$gfx->fill;
			}
			  
			# Date
			if ($book2->{date_ecriture}) {
				$text->translate(
				  $render_start_x + $cur_column_units_count * $unit_width + $text_left_padding,
				  $render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text($book2->{date_ecriture});
			}
			$cur_column_units_count += $date_units_count;

			# Compte
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($book2->{numero_compte}) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + ($compte_units_count * $unit_width/2.5) + $text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text_center($book2->{numero_compte});
			}
			$cur_column_units_count += $compte_units_count;
			
			# Pièce
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($book2->{id_facture}) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + $text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text(substr(($book2->{id_facture} || ''), 0, 56 ));
			}
			$cur_column_units_count += $piece_units_count;
			

			# Libellé
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width ,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($book2->{libelle}) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + $text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text(substr($book2->{libelle}, 0, 59));
			}
			$cur_column_units_count += $libelle_units_count;

			# Débit
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($debit) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + ($debit_units_count * $unit_width)-$text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text_right($debit);
			}
			$cur_column_units_count += $debit_units_count;
			  
			# Crédit
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($credit) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + ($credit_units_count * $unit_width)-$text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text_right($credit);
			}
			$cur_column_units_count += $credit_units_count;
			
			# Solde
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($solde) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + ($solde_units_count * $unit_width)-$text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text_right($solde);
			}
			$cur_column_units_count += $solde_units_count;
			
			# Nb jours
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($book2->{date_ecriture}) {
				$text->translate(
				$render_start_x + $cur_column_units_count * $unit_width + (($nbjours_units_count -1) * $unit_width)-$text_left_padding,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text_right($date_nb_jour);
			}
			$cur_column_units_count += $nbjours_units_count;

			# Intérêts
			$gfx->poly(
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * $cur_row,
			$render_start_x + $cur_column_units_count * $unit_width,
			$render_start_y-$unit_height * ($cur_row - 1)
			);
			$gfx->linewidth(1.5);
			$gfx->strokecolor('# ccc');
			$gfx->stroke;
			if ($book2->{date_ecriture}) {
				$text->translate(
				$render_end_x,
				$render_start_y-$unit_height * $cur_row + $text_bottom_padding
				);
				$text->font($font, $font_size_tableau);
				$text->text_right(''.$calcul_interet.' ');
			}
			$cur_column_units_count = 0;	
	
	
}

#/*—————————————— Menu 	——————————————*/
sub display_menu {

   my ( $r, $args ) = @_ ;
    
	unless ( defined $args->{tag2} || defined $args->{tag3} || defined $args->{tag4} || defined $args->{tag5} ) {
		$args->{tag1} = '' ;
	} 	
 	
#########################################	
#Filtrage du Menu - Début				#
#########################################		
	my $tag1_link = '<a class=' . ( (defined $args->{tag1} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?tag1" style="margin-left: 3ch;">Premiers pas</a>' ;
	my $tag2_link = '<a class=' . ( (defined $args->{tag2} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?tag2" style="margin-left: 3ch;">Courant</a>' ;
	my $tag3_link = '<a class=' . ( (defined $args->{tag3} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?tag3" style="margin-left: 3ch;">Utilitaires</a>' ;
	my $tag4_link = '<a class=' . ( (defined $args->{tag4} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?tag4" style="margin-left: 3ch;">Paramétrage</a>' ;
	my $tag5_link = '<a class=' . ( (defined $args->{tag5} ) ? 'selecteditem' : 'nav' ) . ' href="/'.$r->pnotes('session')->{racine}.'/?tag5" style="margin-left: 3ch;">Fin d\'exercice</a>' ;
	my $content .= '<div class="menu"><li style="list-style: none; margin: 0;">' . $tag1_link . $tag2_link . $tag3_link . $tag4_link . $tag5_link .'</li></div>' ;

#########################################	
#Filtrage du Menu - Fin					#
#########################################
    
    return $content ;

} #sub display_menu_formulaire 

sub restart {
	my ( $r, $args ) = @_ ;
	my $location = '/'.$r->pnotes('session')->{racine}.'/'.($args->{restart} || '').'' ;
	$r->headers_out->set(Location => $location) ;
	$r->status(Apache2::Const::REDIRECT) ;
	return Apache2::Const::REDIRECT ;  
} #sub sub_restart
1 ;
