//
//envoie une requête au serveur avec post_data en payload
//
var send_xmlhttprequest2 = function (handler, post_data, racine) {

    var xhr_object = null;
    
    if(window.XMLHttpRequest) // Firefox

	xhr_object = new XMLHttpRequest();

    else if(window.ActiveXObject) // Internet Explorer

	xhr_object = new ActiveXObject("Microsoft.XMLHTTP");

    else { // XMLHttpRequest non supporté par le navigateur

	alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest...");

	return;

    }

    xhr_object.open("POST", "/"+racine+"/xmlhttprequest/"+handler, true);

    xhr_object.onreadystatechange = function anonymous() {

	if(xhr_object.readyState == 4) {

	    eval(xhr_object.responseText);

	}

    }

    xhr_object.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    var data = post_data;

    xhr_object.send(data);

}

//
//envoie une requête au serveur avec post_data en payload
//
var send_xmlhttprequest = function (handler, post_data) {

    var xhr_object = null;
    
	var racine_id = racine.value;
	
    if(window.XMLHttpRequest) // Firefox

	xhr_object = new XMLHttpRequest();

    else if(window.ActiveXObject) // Internet Explorer

	xhr_object = new ActiveXObject("Microsoft.XMLHTTP");

    else { // XMLHttpRequest non supporté par le navigateur

	alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest...");

	return;

    }

    xhr_object.open("POST", "/"+racine_id+"/xmlhttprequest/"+handler, true);

    xhr_object.onreadystatechange = function anonymous() {

	if(xhr_object.readyState == 4) {

	    eval(xhr_object.responseText);

	}

    }

    xhr_object.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    var data = post_data;

    xhr_object.send(data);

}

//
//renseigne la datalist des comptes quand l'utilisateur tape un ou des chiffres
//
var renseigner_compte = function(my_numero_compte, my_line) {

    //empêcher une validation directe du formulaire sans staging
//    invalidate_form();
    
    var id_line = my_line;

    var numero_compte = my_numero_compte;

    var data = "numero_compte_datalist="+numero_compte+"&id_line="+id_line;

    send_xmlhttprequest("entry_helper", data);

} // var renseigner_compte = function(my_numero_compte, my_line) 

//
//renseigne la datalist des comptes quand l'utilisateur tape un ou des chiffres
//
var renseigner_doc = function(my_documents, my_line) {

    //empêcher une validation directe du formulaire sans staging
	//    invalidate_form();
    
    var id_line = my_line;

    var documents = my_documents;

    var data = "name_doc_datalist="+documents+"&id_line="+id_line;

    send_xmlhttprequest("entry_helper", data);

} // var renseigner_doc = function(my_id_name, my_line) 

//renseigne la datalist des comptes quand l'utilisateur tape un ou des chiffres
//
var renseigner_libre = function(my_libre, my_line) {

    //empêcher une validation directe du formulaire sans staging
	//invalidate_form();
    
    var id_line = my_line;

    var libre = my_libre;

    var data = "name_libre_datalist="+libre+"&id_line="+id_line;

    send_xmlhttprequest("entry_helper", data);

} // var renseigner_libre = function(my_id_name, my_line) 

//
//vide la dataliste de parent_id quand l'utilisateur modifie sa saisie, pour éviter que les anciennes valeurs ne s'affichent en plus des nouvelles
//
var clearChildren = function (parent_id) {

    var parent = document.getElementById(parent_id);

    var childArray = parent.children;

    var cL = childArray.length;

    while(cL > 0) {

	cL--;

	parent.removeChild(childArray[cL]);
    }
    
} // var clearChildren = function (parent_id) 

//
//recopie la valeur du controle de la ligne précédente quand l'utilisateur tape un espace
//utilisé dans date_ecriture, id_facture, libelle
//
var copy_previous_input = function (input, previous_line_number) {

    //les id des contrôles sont au format 'nom_du_controle_1234'; on splite sur le dernier _
    var res = input.id.match(/(.*_)(\d+)/);
    //la première valeur de res contient nom_du_controle
    var id_input = res[1];

    //on copie la valeur la ligne précédente si l'utilisateur a tapé un espace
    if ( input.value.match(/^\s/) ) { 

	input.value = document.getElementById(id_input + previous_line_number).value;
	
	// on doit ajouter stage(input) pour Chrome qui ne déclenche pas onchange après oninput
	stage(input) ;
	
    };

} //var copy_previous_input = function (input, previous_line_number) 

//
//stocke la valeur de l'input dans la table tbljournal_staging
//
var stage = function (input) {

    var _token_id = document.getElementById("_token_id").value;
    
    //les id des contrôles sont au format 'nom_du_controle_1234'; on splite sur le dernier _
    var res = input.id.match(/(.*_)(\d+)/);

    //la première valeur de res contient id_du_controle; on strippe le dernier _
    var id_input = res[1].substring(0, res[1].lastIndexOf("_"));

    //la deuxième valeur de res contient le numero de ligne à modifier
    var id_line = res[2];

    var my_value;

    //pour les colonnes débit/crédit, supprimer le formatage, remplacer la virgule par un point
    var re = /debit|credit/;

    if ( input.id.match(re) ) {

    	my_value = input.value.replace(/\s/g, "");

    } else {

    	my_value = input.value;

    }

    //il faut encoder la valeur sinon ça ne passe pas pour les caractères accentués
    var data = "stage="+input.id+"&value="+encodeURIComponent(my_value)+"&_token_id="+_token_id;

    send_xmlhttprequest("entry_helper", data);

} //var stage = function(input)

//
//ajoute un message dans la div id_bad_input en haut du formulaire et ajoute class=bad_input à l'élément input concerné
//
var signal_bad_input = function(input_id) {

    var input = document.getElementById(input_id);

    var p = document.createElement('p'); 

    p.id = "bad_input_"+input_id;

    p.textContent = "Valeur non valide : "+input.value;

    p.setAttribute("class", "warning");

    document.getElementById("bad_input").appendChild(p);

    input.focus();

    input.setAttribute("class", "bad_input");

    validate_this.disabled = true;


} //    var signal_bad_input = function(input) 

//
//ajoute un message dans la div id_bad_input en haut du formulaire et ajoute class=bad_input à l'élément input concerné
//
var signal_bad_date_input = function(input_id, error) {

    var input = document.getElementById(input_id);
    
    var id_error = error;
    
    //s'il existe des valeurs non valides, leur attribut class=bad_input
    if ( input.getAttribute("class") === "bad_input" ) {

	//on retire l'input de la liste dans bad_input
	bad_input.removeChild(document.getElementById("bad_input_"+input.id));
	}

    var p = document.createElement('p'); 

    p.id = "bad_input_"+input_id;
    
    if (id_error === "manquant"){
	p.textContent = "Date manquante "+input.value;
	} else if (id_error === "fiscal"){
	p.textContent = "Vérifier que la date soit dans le bon exercice fiscal : "+input.value;
	} else {
    p.textContent = "Vérifier que la date soit dans le bon format ( jjmm ou jjmmaaaa ou jj mm aaaa ou jj/mm/aaaa ): "+input.value;
	}
	
    p.setAttribute("class", "warning");
    
    document.getElementById("bad_input").appendChild(p);
    
    input.focus();

    input.setAttribute("class", "bad_input");

    validate_this.disabled = true;


} //    var signal_bad_date_input = function(input, error) 


//
//si stage() s'est bien passé, sort l'input de la liste des bad_input et réactive le bouton Valider si la liste est vide
//
var rehab_bad_input = function(id_input) {

    var input=document.getElementById(id_input);

    //s'il existe des valeurs non valides, leur attribut class=bad_input
    if ( input.getAttribute("class") === "bad_input" ) {

	//on retire l'input de la liste dans bad_input
	bad_input.removeChild(document.getElementById("bad_input_"+input.id));

	input.setAttribute("class", "good_input");

	//si bad_input est vide, on peut réactiver le bouton 'Valider'
	if (document.getElementsByClassName("bad_input").length==0) {

	    bad_input.textContent = "";

	    validate_this.disabled = false

	} else {

	    validate_this.disabled = true;

	}

    }
    
} // var rehab_bad_input = function(id_input)

//
//formate un debit/credit sur 2 décimale et l'enregistre dans staging; formate une date raccourcie avec format_date
//
var format_and_stage = function(input) {
	
	if ( input.name.match(/montant/) ) {
	//remplacer les séparateurs de milliers, et la virgule éventuelle des décimales	
	var raw_value = input.value.replace(/\s/g, "").replace(/,/, ".");
	//signaler l'erreur si on a pas un nombre valide
	if ( isNaN(Number(raw_value)) ) {
    signal_bad_input(input.id);
	} else {
	    //le nombre est valide; le reformatter et l'envoyer à stage
	    input.value = Number(raw_value).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");
	}}

    //debit ou credit
    if ( input.name.match(/debit|credit/) ) {

	//remplacer les séparateurs de milliers, et la virgule éventuelle des décimales	
	var raw_value = input.value.replace(/\s/g, "").replace(/,/, ".");

	//signaler l'erreur si on a pas un nombre valide
	if ( isNaN(Number(raw_value)) ) {
	    
	    signal_bad_input(input.id);
	    
	} else {

	    //le nombre est valide; le reformatter et l'envoyer à stage
	    input.value = Number(raw_value).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");

	    stage(input);

	}

    }

    //date_ecriture
    if ( input.name.match(/date_ecriture/) ) {
		
	//enforce YYYY format
	var my_re = /^(\d\d).(\d\d).(\d\d)$/;

	var NOT_OK = my_re.exec(input.value);

	if ( NOT_OK ) {

	    signal_bad_date_input(input.id, "erreur");

	} else {
	    
	    format_date(input, preferred_datestyle.value);
	    
	    stage(input);

    }
	}
    
} //var format_and_stage = function(input) 

//formate un debit/credit sur 2 décimale et l'enregistre dans staging; formate une date raccourcie avec format_date
//
var format_and_submit = function(input) {
	
	if ((input.value !== undefined) && (input.value !== null) && (input.value!== "")) {

		//remplacer les séparateurs de milliers, et la virgule éventuelle des décimales	
	var raw_value = input.value.replace(/\s/g, "").replace(/,/, ".");

	//signaler l'erreur si on a pas un nombre valide
	if ( isNaN(Number(raw_value)) ) {
	    
	    signal_bad_input(input.id);
	    
	} else {

	    //le nombre est valide; le reformatter et l'envoyer à stage
	    input.value = Number(raw_value).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");
	    
	   
	}
		} 
		
	 document.getElementById("myForm").submit();
	


} //var format_and_submit = function(input) 

//formate un debit/credit sur 2 décimale et l'enregistre dans staging; formate une date raccourcie avec format_date
//
var format_number = function(input) {
	
	if ((input.value !== undefined) && (input.value !== null) && (input.value!== "")) {

		//remplacer les séparateurs de milliers, et la virgule éventuelle des décimales	
	var raw_value = input.value.replace(/\s/g, "").replace(/,/, ".");

	//signaler l'erreur si on a pas un nombre valide
	if ( isNaN(Number(raw_value)) ) {
	    
	    signal_bad_input(input.id);
	    
	} else {

	    //le nombre est valide; le reformatter et l'envoyer à stage
	    input.value = Number(raw_value).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");
	    
	   
	}
		} 
		
} //var format_number = function(input) 

//verification date obligatoire
var verifdt = function(input) {
	if ((input.value !== undefined) && (input.value !== null) && (input.value!== "") ) {
    
    // First check for the pattern
    var date_dd_mm_yyyy = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
    //enforce YYYY format
	var date_ddmm = /^(\d\d).?(\d\d)$/;
	var date_ddmmyy = /^(\d\d).(\d\d).(\d\d)$/;
	var date_ddmmyyyy = /^\d{1,2}\.?\d{1,2}\.?\d{4}$/;

    if ((date_dd_mm_yyyy.test(input.value)) || 
    (date_ddmm.test(input.value)) || 
    (date_ddmmyyyy.test(input.value)) || 
    (!date_ddmmyy.test(input.value)) ){
	format_date(input, preferred_datestyle.value);
	stage(input);
    } else {
	signal_bad_date_input(input.id, "erreur");
	}

} else {signal_bad_date_input(input.id, "manquant");}
}

//
//formate une date raccourcie "0104" en 2016-04-01 et "01042022" en 2022-04-01
//
var format_date = function(input, preferred_datestyle) {
	
    //on accepte dd?mm (le jour et le mois sur deux chiffres, éventuellement séparés par un caractère
	var my_re = /^(\d\d).?(\d\d)$/;
	var my_re2 = /^(\d\d).?(\d\d).?(\d\d\d\d)$/;

	var OK = my_re.exec(input.value);
	var OK2 = my_re2.exec(input.value);
	
	if ( OK ) {
	    
	    var today = new Date();
	    
	    var yyyy = today.getFullYear();
	    
	    if ( preferred_datestyle === 'iso' ) {

		input.value = yyyy+"-"+OK[2]+"-"+OK[1];

	    } else {

		input.value = OK[1]+"/"+OK[2]+"/"+yyyy;

	    }
	} else if ( OK2 ){
	    
	    if ( preferred_datestyle === 'iso' ) {

		input.value = OK2[3]+"-"+OK2[2]+"-"+OK2[1];

	    } else {

		input.value = OK2[1]+"/"+OK2[2]+"/"+OK2[3];

	    }
}
}

//vérification de la balance : si l'opération est déséquilibrée, le bouton valider est désactivée
//déclenchée après une modification de debit|credit
var check_balance = function() {

    var array_debit = document.getElementsByName("debit");

    var total_debit = 0;

    var array_credit = document.getElementsByName("credit");

    var total_credit = 0;

    //on totalise les colonnes debit/credit
    //les nombres ont tous été formatés sur deux décimales, on peut donc retirer le point décimal pour travailler avec des entiers
    for (i=0; i<array_credit.length; i++){

	total_debit = total_debit + Number(array_debit[i].value.replace(/\s/g, "").replace(/\./,""));

	total_credit = total_credit + Number(array_credit[i].value.replace(/\s/g, "").replace(/\./,""));
	
    };

    var solde = total_credit - total_debit;
    
    document.getElementById("total_debit").value = (Number(total_debit)/100).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");

    document.getElementById("total_credit").value = (Number(total_credit)/100).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");

    document.getElementById("total_solde").value = (Number(solde)/100).toLocaleString('fr-FR', {minimumFractionDigits: 2}).replace(/,/, ".");

    //l'opération est déséquilibrée
    if ( solde ) {

	document.getElementById("total_solde").setAttribute("class", "bad_input");

	validate_this.disabled = true;

    } else {

	document.getElementById("total_solde").setAttribute("class", "good_input");

	//l'opération est équilibrée; vérifier qu'il n'y a pas de bad_input avant de réactiver le bouton 'Valider'
	if (document.getElementsByClassName("bad_input").length==0) { 	
	    
	    validate_this.disabled = false;

	}

    }

} //var check_balance = function() 

//var calculer_id_facture = function (input, open_journal, libelle_journal_type) {
var calculer_id_facture = function (input, open_journal) {

    //on copie la valeur la ligne précédente si l'utilisateur a tapé un espace
    if ( input.value.match(/^\s/) ) { 

	//les id des contrôles sont au format 'nom_du_controle_1234'; on splite sur le dernier _
	var res = input.id.match(/(.*_)(\d+)$/);
	//la première valeur de res contient nom_du_controle
	var id_input = res[1];

	//la deuxième valeur contient le numero de ligne
	var id_line = res[2];

	var date_ecriture = document.getElementById("date_ecriture_"+id_line).value;

	if ( date_ecriture ) {
	    
	    var data = "calculer_numero_piece="+input.id+"&date_ecriture="+date_ecriture+"&open_journal="+open_journal;

	    send_xmlhttprequest("entry_helper", data);

	} else {

	    input.value = "Date absente!"

	}

    } //    if ( input.value.match(/^\s/) ) 
    
} //var calculer_id_facture 

//
//enregistrement du lettrage
//
var lettrage = function(input, numero_compte, my_racine) {
	
	var id_racine = my_racine;

    var data = "lettrage="+input.value+"&id_line="+input.id+"&numero_compte="+numero_compte;

    send_xmlhttprequest2("lettrage", data, id_racine);

}

var retour_var = function(input) {
document.getElementById("calcul_piece").value = input.value ;
}

var retour_var2 = function(input) {
document.getElementById("compte_charge_comptant").value = input.value ;
}

//verif date + calcul piece
var calcul_piece_date = function(input, my_racine) {
	
	if (isValidDateddmmyyyy(input.value)) { 
		
	var id_journal = document.getElementById('id_compte_1_select').value;    
	var id_racine = my_racine;
		
	if (!!id_journal) {	
	var data = "calculer_numero_piece2="+id_journal+"&date_ecriture="+input.value;
	send_xmlhttprequest2("entry_helper", data, id_racine);
	}

	} else {
	alert('Vérifier la date!'); 
	}

} //var calcul_piece_date 

//
//enregistrement du pointage
//
var pointage = function(input, numero_compte, my_racine) {
	
var id_racine = my_racine;

var data = "pointage="+input.checked+"&id_line="+input.id+"&numero_compte="+numero_compte;

send_xmlhttprequest2("lettrage", data, id_racine);

}

//
//enregistrement du pointagerecurrent
//
var pointagerecurrent = function(input, idtoken, identry, my_racine) {
	
var id_racine = my_racine;

var data = "pointagerecurrent="+input.checked+"&id_entry="+identry+"&id_token="+idtoken;

send_xmlhttprequest2("lettrage", data, id_racine);

}

//var select_contrepartie_401 = function (input, piece) {
var select_contrepartie_401 = function (input, my_racine) {
	
	var id_racine = my_racine;
	    
	var data = "select_contrepartie_401_entry="+input.value;

	send_xmlhttprequest2("entry_helper", data, id_racine);

} //var select_contrepartie_401 

//var calcul_piece_journal = function (input, piece) {
var calcul_piece_journal = function (input, my_racine) {
	
	var id_date = document.getElementById('date_comptant').value;
	
	if (isValidDateddmmyyyy(id_date)) { 	
	    
	var id_racine = my_racine;
	    
	var data = "calculer_numero_piece2="+input.value+"&date_ecriture="+id_date;

	send_xmlhttprequest2("entry_helper", data, id_racine);

	} else {
	alert('Vérifier la date!'); 
	}

} //var calcul_piece_journal 

//var calcul_piece_achat = function (input, piece) {
var calcul_piece_achat = function (my_racine) {
	
	var id_date = document.getElementById('date_comptant20').value;
	
	if (isValidDateddmmyyyy(id_date)) { 	
	    
	var id_racine = my_racine;
	    
	var data = "calculer_numero_piece3="+id_racine+"&date_ecriture="+id_date;

	send_xmlhttprequest2("entry_helper", data, id_racine);

	} else {
	alert('Vérifier la date!'); 
	}

} //var calcul_piece_achat 

//valider format de date yyyy-mm-dd
function isValidDate(dateString) {
    // First check for the pattern
    var regex_date = /^\d{4}\-\d{1,2}\-\d{1,2}$/;

    if(!regex_date.test(dateString))
    {
        return false;
    }

    // Parse the date parts to integers
    var parts   = dateString.split("-");
    var day     = parseInt(parts[2], 10);
    var month   = parseInt(parts[1], 10);
    var year    = parseInt(parts[0], 10);

    // Check the ranges of month and year
    if(year < 1900 || year > 2300 || month == 0 || month > 12)
    {
        return false;
    }

    var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

    // Adjust for leap years
    if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
    {
        monthLength[1] = 29;
    }

    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
}

function isValidDateddmmyyyy(dateString) {
	
	    // First check for the pattern
    var regex_date = /^\d{1,2}\/\d{1,2}\/\d{4}$/;

    if(!regex_date.test(dateString))
    {
        return false;
    }
	
    // Parse the date parts to integers
    var parts = dateString.split("/");
    var day = parseInt(parts[0], 10);
    var month = parseInt(parts[1], 10);
    var year = parseInt(parts[2], 10);


    // Check the ranges of month and year
    if(year < 1900 || year > 2300 || month == 0 || month > 12)
    {
        return false;
    }
    
    var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

    // Adjust for leap years
    if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
    {
        monthLength[1] = 29;
    }

    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
};

function verifierCaracteres(event) {
	 		
	var keyCode = event.which ? event.which : event.keyCode;
	var touche = String.fromCharCode(keyCode);
			
	var champ = document.getElementById('libelle_*');
			
	var caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
			
	if(caracteres.indexOf(touche) >= 0) {
		champ.value += touche;
	}
			
}

function verif(chars) {
        // Caractères autorisés
    //var regex = new RegExp("[a-z0-9]", "i");
    
    var regex = new RegExp("^[A-Za-zéèà0-9? ,'./\_-]+$", "i");
    var valid;
      for (x = 0; x < chars.value.length; x++) {
        valid = regex.test(chars.value.charAt(x));
        if (valid == false) {
            chars.value = chars.value.substr(0, x) + chars.value.substr(x + 1, chars.value.length - x + 1); x--;
        }
      }
}


// Formatage d'un champs mail onKeypress="return valid_mail(event);"
function valid_mail(evt) {
    var keyCode = evt.which ? evt.which : evt.keyCode;
    var interdit = 'àâäãçéèêëìîïòôöõùûüñ &*?!:;,\t#~"^¨%$£?²¤§%*()[]{}<>|\\/`\'';
    if (interdit.indexOf(String.fromCharCode(keyCode)) >= 0) {
        return false;
    }
}

//Datalist recherche journal quand l'utilisateur tape des lettres
var liste_search_journal = function(my_libre, my_racine) {
    var libre = my_libre;
    var id_racine = my_racine;
    var data = "search_journal_datalist="+libre;
    send_xmlhttprequest2("entry_helper", data, id_racine);
} // var liste_search_journal = function(my_libre,my_racine) 

//Datalist recherche libre id_paiement quand l'utilisateur tape des lettres
var liste_search_libre = function(my_libre, my_racine) {
    var libre = my_libre;
    var id_racine = my_racine;
    var data = "search_libre_datalist="+libre;
    send_xmlhttprequest2("entry_helper", data, id_racine);
} // var liste_search_libre = function(my_libre,my_racine) 

//Datalist recherche liste_search_compte quand l'utilisateur tape des lettres
var liste_search_compte = function(my_libre, my_racine) {
    var libre = my_libre;
    var id_racine = my_racine;
    var data = "search_compte_datalist="+libre;
    send_xmlhttprequest2("entry_helper", data, id_racine);
} // var liste_search_compte = function(my_libre,my_racine) 

//Datalist recherche liste_search_piece quand l'utilisateur tape des lettres
var liste_search_piece = function(my_libre, my_racine) {
    var libre = my_libre;
    var id_racine = my_racine;
    var data = "search_piece_datalist="+libre;
    send_xmlhttprequest2("entry_helper", data, id_racine);
} // var liste_search_piece = function(my_libre,my_racine) 

//Datalist recherche liste_search_libelle quand l'utilisateur tape des lettres
var liste_search_libelle = function(my_libre, my_racine, my_nb) {
    var libre = my_libre;
    var id_racine = my_racine;
    var number = my_nb;
    var data = "search_libelle_datalist="+libre+"&id_nb="+number;
    send_xmlhttprequest2("entry_helper", data, id_racine);
} // var liste_search_libelle = function(my_libre,my_racine) 

//Datalist recherche liste_search_lettrage quand l'utilisateur tape des lettres
var liste_search_lettrage = function(my_libre, my_racine) {
    var libre = my_libre;
    var id_racine = my_racine;
    var data = "search_lettrage_datalist="+libre;
    send_xmlhttprequest2("entry_helper", data, id_racine);
} // var liste_search_lettrage = function(my_libre,my_racine) 

//onclick appliquer list-expand
function myFunction(event) { 
  var x = event.target;
 // x.parentElement.classList.toggle('list-expand');
 x.classList.toggle('list-expand');
}

//onclick appliquer list-expand
function myFunctionchildren(event) { 
  var x = event.target;
 x.parentElement.classList.toggle('list-expand');
}

function searchFunction2() {
	var src, a, searchText, article, item, item_bar, input, filter, table, i, txtValue, myHilitor2;
	input = document.getElementById("Search");
	filter = input.value.toLowerCase().trim().split(' ');
	searchText = event.target.value;
	item = document.getElementsByClassName('main-section');
    item_bar = document.getElementsByClassName('nav-link');

	//surligner
	//myHilitor2 = new Hilitor2('main-section');
	//myHilitor2.setMatchType('left');
	//myHilitor2.apply(searchText);
	
	var myHilitor = new Hilitor2("playground");
	myHilitor.setMatchType("left");
	myHilitor.apply(searchText);
	
	
//filtrer	
	if ((searchText !== undefined) && (searchText !== null) && (searchText!== "")) {
		for (j = 0; j < filter.length; j++) {
		src = filter[j].trim();
			for (i = 0; i < item.length; i++) {
			if (src!='' && item ) {
				if ((item[i].innerText.toLowerCase().indexOf(filter[0]) !== -1 ) && (item[i].innerText.toLowerCase().indexOf(filter[j]) !== -1 )) {
				const sectionId = item[i].id;
				const sectionLink = document.querySelector(`a[href="#${sectionId}"]`);
				item[i].style.display = "";
				(sectionLink) && (sectionLink.style.display = "");
				} else {
				const sectionId = item[i].id;
				const sectionLink = document.querySelector(`a[href="#${sectionId}"]`);
				item[i].style.display = "none";
				(sectionLink) && (sectionLink.style.display = "none");	
				}
				}}
	}
	} else {location.reload();}
}

function Hilitor(id, tag) {

  // private variables
  var targetNode = document.getElementById(id) || document.body;
  var hiliteTag = tag || "MARK";
  var skipTags = new RegExp("^(?:" + hiliteTag + "|SCRIPT|FORM|SPAN)$");
  var colors = ["#ff6", "#a0ffff", "#9f9", "#f99", "#f6f"];
  var wordColor = [];
  var colorIdx = 0;
  var matchRegExp = "";
  var openLeft = false;
  var openRight = false;

  // characters to strip from start and end of the input string
  var endRegExp = new RegExp('^[^\\w]+|[^\\w]+$', "g");

  // characters used to break up the input string into words
  var breakRegExp = new RegExp('[^\\w\'-]+', "g");

  this.setEndRegExp = function(regex) {
    endRegExp = regex;
    return endRegExp;
  };

  this.setBreakRegExp = function(regex) {
    breakRegExp = regex;
    return breakRegExp;
  };

  this.setMatchType = function(type)
  {
    switch(type)
    {
      case "left":
        this.openLeft = false;
        this.openRight = true;
        break;

      case "right":
        this.openLeft = true;
        this.openRight = false;
        break;

      case "open":
        this.openLeft = this.openRight = true;
        break;

      default:
        this.openLeft = this.openRight = false;

    }
  };

  this.setRegex = function(input)
  {
    input = input.replace(endRegExp, "");
    input = input.replace(breakRegExp, "|");
    input = input.replace(/^\||\|$/g, "");
    if(input) {
      var re = "(" + input + ")";
      if(!this.openLeft) {
        re = "\\b" + re;
      }
      if(!this.openRight) {
        re = re + "\\b";
      }
      matchRegExp = new RegExp(re, "i");
      return matchRegExp;
    }
    return false;
  };

  this.getRegex = function()
  {
    var retval = matchRegExp.toString();
    retval = retval.replace(/(^\/(\\b)?|\(|\)|(\\b)?\/i$)/g, "");
    retval = retval.replace(/\|/g, " ");
    return retval;
  };

  // recursively apply word highlighting
  this.hiliteWords = function(node)
  {
    if(node === undefined || !node) return;
    if(!matchRegExp) return;
    if(skipTags.test(node.nodeName)) return;

    if(node.hasChildNodes()) {
      for(var i=0; i < node.childNodes.length; i++)
        this.hiliteWords(node.childNodes[i]);
    }
    if(node.nodeType == 3) { // NODE_TEXT

      var nv, regs;

      if((nv = node.nodeValue) && (regs = matchRegExp.exec(nv))) {

        if(!wordColor[regs[0].toLowerCase()]) {
          wordColor[regs[0].toLowerCase()] = colors[colorIdx++ % colors.length];
        }

        var match = document.createElement(hiliteTag);
        match.appendChild(document.createTextNode(regs[0]));
        match.style.backgroundColor = wordColor[regs[0].toLowerCase()];
        match.style.color = "#000";

        var after = node.splitText(regs.index);
        after.nodeValue = after.nodeValue.substring(regs[0].length);
        node.parentNode.insertBefore(match, after);

      }
    }
  };

  // remove highlighting
  this.remove = function()
  {
    var arr = document.getElementsByTagName(hiliteTag), el;
    while(arr.length && (el = arr[0])) {
      var parent = el.parentNode;
      parent.replaceChild(el.firstChild, el);
      parent.normalize();
    }
  };

  // start highlighting at target node
  this.apply = function(input)
  {
    this.remove();
    if(input === undefined || !(input = input.replace(/(^\s+|\s+$)/g, ""))) {
      return;
    }
    if(this.setRegex(input)) {
      this.hiliteWords(targetNode);
    }
    return matchRegExp;
  };

}

function Hilitor2(id, tag){

  // private variables
  var targetNode = document.getElementById(id) || document.body;
  var hiliteTag = tag || "MARK";
  var skipTags = new RegExp("^(?:" + hiliteTag + "|SCRIPT|FORM)$");
  var colors = ["#ff6", "#a0ffff", "#9f9", "#f99", "#f6f"];
  var wordColor = [];
  var colorIdx = 0;
  var matchRegExp = "";
  var openLeft = false;
  var openRight = false;
  var matches = [];

  // characters to strip from start and end of the input string
  var endRegExp = new RegExp('^[^\\w]+|[^\\w]+$', "g");

  // characters used to break up the input string into words
  var breakRegExp = new RegExp('[^\\w\'-]+', "g");

  this.setEndRegExp = function(regex)
  {
    endRegExp = regex;
    return true;
  };

  this.setBreakRegExp = function(regex)
  {
    breakRegExp = regex;
    return true;
  };

  this.setMatchType = function(type)
  {
    switch(type)
    {
      case "open":
        this.openLeft = this.openRight = true;
        break;

      case "closed":
        this.openLeft = this.openRight = false;
        break;

      case "right":
        this.openLeft = true;
        this.openRight = false;
        break;

      case "left":
      default:
        this.openLeft = false;
        this.openRight = true;

    }
    return true;
  };

  // break user input into words and convert to RegExp
  this.setRegex = function(input)
  {
    input = input.replace(/\\u[0-9A-F]{4}/g, ""); // remove missed unicode
    input = input.replace(endRegExp, "");
    input = input.replace(breakRegExp, "|");
    input = input.replace(/^\||\|$/g, "");
    input = addAccents(input);
    if(input) {
      var re = "(" + input + ")";
      if(!this.openLeft) {
        re = "(?:^|[\\b\\s])" + re;
      }
      if(!this.openRight) {
        re = re + "(?:[\\b\\s]|$)";
      }
      matchRegExp = new RegExp(re, "i");
      return matchRegExp;
    }
    return false;
  };

  this.getRegex = function()
  {
    var retval = matchRegExp.toString();
    retval = retval.replace(/(^\/|\(\?:[^\)]+\)|\/i$)/g, "");
    return retval;
  };

  // recursively apply word highlighting
  this.hiliteWords = function(node)
  {
    if(node === undefined || !node) return;
    if(!matchRegExp) return;
    if(skipTags.test(node.nodeName)) return;

    if(node.hasChildNodes()) {
      for(var i=0; i < node.childNodes.length; i++)
        this.hiliteWords(node.childNodes[i]);
    }
    if(node.nodeType == 3) { // NODE_TEXT
      if((nv = node.nodeValue) && (regs = matchRegExp.exec(nv))) {
        if(!wordColor[regs[1].toLowerCase()]) {
          wordColor[regs[1].toLowerCase()] = colors[colorIdx++ % colors.length];
        }

        var match = document.createElement(hiliteTag);
        match.appendChild(document.createTextNode(regs[1]));
        match.style.backgroundColor = wordColor[regs[1].toLowerCase()];
        match.style.color = "#000";

        var after;
        if(regs[0].match(/^\s/)) { // in case of leading whitespace
          after = node.splitText(regs.index + 1);
        } else {
          after = node.splitText(regs.index);
        }
        after.nodeValue = after.nodeValue.substring(regs[1].length);
        node.parentNode.insertBefore(match, after);
      }
    };
  };

  // remove highlighting
  this.remove = function()
  {
    var arr = document.getElementsByTagName(hiliteTag);
    while(arr.length && (el = arr[0])) {
      var parent = el.parentNode;
      parent.replaceChild(el.firstChild, el);
      parent.normalize();
    }
    return true;
  };

  // start highlighting at target node
  this.apply = function(input)
  {
    this.remove();
    if(input === undefined || !(input = input.replace(/(^\s+|\s+$)/g, ""))) {
      return;
    }
    input = escapeUnicode(input);
    input = removeUnicode(input);
    if(this.setRegex(input)) {
      this.hiliteWords(targetNode);
    }

    // build array of matches
    matches = targetNode.getElementsByTagName(hiliteTag);

    // return number of matches
    return matches.length;
  };

  // scroll to the nth match
  this.gotoMatch = function(idx)
  {
    if(matches[idx]) {
      matches[idx].scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
      for(var i=0; i < matches.length; i++) {
        matches[i].style.outline = (idx == i) ? "2px solid red" : "";
      }
      return true;
    }
    return false;
  };

  // convert escaped UNICODE to ASCII
  function removeUnicode(input)
  {
    var retval = input;
    retval = retval.replace(/\\u(00E[024]|010[23]|00C2)/ig, "a");
    retval = retval.replace(/\\u00E7/ig, "c");
    retval = retval.replace(/\\u00E[89AB]/ig, "e");
    retval = retval.replace(/\\u(00E[EF]|00CE)/ig, "i");
    retval = retval.replace(/\\u00F[46]/ig, "o");
    retval = retval.replace(/\\u00F[9BC]/ig, "u");
    retval = retval.replace(/\\u00FF/ig, "y");
    retval = retval.replace(/\\u(00DF|021[89])/ig, "s");
    retval = retval.replace(/\\u(0163i|021[AB])/ig, "t");
    return retval;
  }

  // convert ASCII to wildcard
  function addAccents(input)
  {
    var retval = input;
    retval = retval.replace(/([ao])e/ig, "$1");
    retval = retval.replace(/ss/ig, "s");
    retval = retval.replace(/e/ig, "[eèéêë]");
    retval = retval.replace(/c/ig, "[cç]");
    retval = retval.replace(/i/ig, "[iîï]");
    retval = retval.replace(/u/ig, "[uùûü]");
    retval = retval.replace(/y/ig, "[yÿ]");
    retval = retval.replace(/s/ig, "(ss|[sßș])");
    retval = retval.replace(/t/ig, "([tţț])");
    retval = retval.replace(/a/ig, "([aàâäă]|ae)");
    retval = retval.replace(/o/ig, "([oôö]|oe)");
    return retval;
  }

  // added by Yanosh Kunsh to include utf-8 string comparison
  function dec2hex4(textString)
  {
    var hexequiv = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F");
    return hexequiv[(textString >> 12) & 0xF] + hexequiv[(textString >> 8) & 0xF] + hexequiv[(textString >> 4) & 0xF] + hexequiv[textString & 0xF];
  }

  // escape UNICODE characters in string
  function escapeUnicode(str)
  {
    // convertCharStr2jEsc
    // Converts a string of characters to JavaScript escapes
    // str: sequence of Unicode characters
    var highsurrogate = 0;
    var suppCP;
    var pad;
    var n = 0;
    var outputString = "";
    for(var i=0; i < str.length; i++) {
      var cc = str.charCodeAt(i);
      if(cc < 0 || cc > 0xFFFF) {
        outputString += '!Error in convertCharStr2UTF16: unexpected charCodeAt result, cc=' + cc + '!';
      }
      if(highsurrogate != 0) { // this is a supp char, and cc contains the low surrogate
        if(0xDC00 <= cc && cc <= 0xDFFF) {
          suppCP = 0x10000 + ((highsurrogate - 0xD800) << 10) + (cc - 0xDC00);
          suppCP -= 0x10000;
          outputString += '\\u' + dec2hex4(0xD800 | (suppCP >> 10)) + '\\u' + dec2hex4(0xDC00 | (suppCP & 0x3FF));
          highsurrogate = 0;
          continue;
        } else {
          outputString += 'Error in convertCharStr2UTF16: low surrogate expected, cc=' + cc + '!';
          highsurrogate = 0;
        }
      }
      if(0xD800 <= cc && cc <= 0xDBFF) { // start of supplementary character
        highsurrogate = cc;
      } else { // this is a BMP character
        switch(cc)
        {
          case 0:
            outputString += '\\0';
            break;
          case 8:
            outputString += '\\b';
            break;
          case 9:
            outputString += '\\t';
            break;
          case 10:
            outputString += '\\n';
            break;
          case 13:
            outputString += '\\r';
            break;
          case 11:
            outputString += '\\v';
            break;
          case 12:
            outputString += '\\f';
            break;
          case 34:
            outputString += '\\\"';
            break;
          case 92:
            outputString += '\\\\';
            break;
          default:
            if(cc > 0x1f && cc < 0x7F) {
              outputString += String.fromCharCode(cc);
            } else {
              pad = cc.toString(16).toUpperCase();
              while(pad.length < 4) {
                pad = '0' + pad;
              }
              outputString += '\\u' + pad;
            }
        }
      }
    }
    return outputString;
  }

}
